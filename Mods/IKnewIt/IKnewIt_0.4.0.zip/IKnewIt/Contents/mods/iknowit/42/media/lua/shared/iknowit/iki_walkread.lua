--[[
    IKnowIt! 0.3.1 - reading while walking (own code; replaces the idea of M-13's Reading Tweaks, nothing copied)
    Author: MKev - Optimized by Grok Bot in combination with Cursor

    B42.21: ISBaseTimedAction:new sets stopOnWalk = true / stopOnRun = true. The Java side
    (LuaTimedActionNew, created in ISBaseTimedAction:create) force-stops the action when the
    player moves while stopOnWalk is set. ISReadABook itself has no movement check in isValid/update.

    Hooks (method hooks only, ISReadABook:new is NOT touched - MP NetTimedAction safety):
      ISReadABook:create  -> stopOnWalk = false (stopOnRun stays true), before the Java action is built
      ISReadABook:update  -> running / sprinting still stops reading; optional speed penalty while walking
    Sandbox: ReadWhileWalking (true), WalkReadSpeed (0.5 = half speed while walking, 1.0 = no penalty).
    No screen darkening, no blur.
]]
require "TimedActions/ISReadABook"

IKnowIt = IKnowIt or {}
local IKI = IKnowIt

local function opt(name, default)
    local sv = SandboxVars and SandboxVars.IKnowIt
    if sv == nil or sv[name] == nil then return default end
    return sv[name]
end

local function call(obj, fn, ...)
    if obj == nil then return nil end
    local ok, f = pcall(function() return obj[fn] end)
    if not ok or type(f) ~= "function" and type(f) ~= "userdata" then return nil end
    local ok2, res = pcall(f, obj, ...)
    if ok2 then return res end
    return nil
end

function IKI.walkReadEnabled()
    return opt("ReadWhileWalking", true) == true
end

function IKI.isFastMoving(chr)
    return call(chr, "isRunning") == true or call(chr, "isSprinting") == true
end

function IKI.isWalking(chr)
    if call(chr, "isPlayerMoving") ~= true then return false end
    return not IKI.isFastMoving(chr)
end

function IKI.walkReadFactor()
    local f = tonumber(opt("WalkReadSpeed", 0.5)) or 0.5
    if f ~= f then f = 0.5 end
    if f < 0.1 then f = 0.1 end
    if f > 1 then f = 1 end
    return f
end

-- per-tick progress correction while walking (returns the new current time or nil)
function IKI.walkReadTick(action)
    if not action.iki_walkread then return nil end
    local chr = action.character
    if not IKI.isWalking(chr) then return nil end
    local f = IKI.walkReadFactor()
    if f >= 1 then return nil end
    local ja = action.action
    if ja == nil then return nil end
    local delta = call(ja, "getJobDelta")
    local maxTime = tonumber(action.maxTime)
    if type(delta) ~= "number" or maxTime == nil or maxTime <= 1 then return nil end
    local gt = getGameTime and getGameTime()
    local mult = tonumber(gt and call(gt, "getMultiplier")) or 1
    local cur = delta * maxTime - mult * (1 - f)
    if cur < 0 then cur = 0 end
    ja:setCurrentTime(cur)
    return cur
end

if ISReadABook and not ISReadABook.iki_walkread_hooked then
    ISReadABook.iki_walkread_hooked = true

    local ownCreate = rawget(ISReadABook, "create")
    function ISReadABook:create()
        local ok, on = pcall(IKI.walkReadEnabled)
        if ok and on then
            self.stopOnWalk = false
            self.stopOnRun = true
            self.iki_walkread = true
        end
        local base = ownCreate or ISBaseTimedAction.create
        return base(self)
    end

    local origUpdate = ISReadABook.update
    function ISReadABook:update()
        local r = origUpdate(self)
        if self.iki_walkread then
            local okF, fast = pcall(IKI.isFastMoving, self.character)
            if okF and fast then
                pcall(self.forceStop, self)
                return r
            end
            pcall(IKI.walkReadTick, self)
        end
        return r
    end
end
