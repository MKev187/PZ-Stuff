--[[ IKnowIt! 0.3.0 - nested loot. Author: MKev - Optimized by Grok Bot in combination with Cursor
     Part 1: [>] arrow (left-click) or right-click "Oeffnen" opens a bag/keyring/kit that lies inside a
             world container as its own loot tab. Never opens anything automatically. The tab vanishes when
             the item is gone, moved, or its parent tab is no longer shown (walk away / parent closed).
     Part 2: right-click "Inhalt nehmen" on a closed container: left-click takes, right-click marks
             (menu stays open, only in OUR submenus), "Markierte nehmen (n)", "Alles nehmen", 1/half/all.
     Every move is a vanilla ISInventoryTransferAction (server-validated) queued after walking to the
     outermost world container. Bags two levels deep in a world container are greyed out
     ("erst die aeussere Tasche nehmen") unless SandboxVars.IKnowIt.NestLootDeep = true.
     0.4.0 (I Knew It!): server addressability mirrors the engine's ContainerID (verified against the B42 jar):
     player inventory (any depth), world containers, a bag lying on the floor (WorldObject, its container is the
     UI "floor" container, not nil) and a bag directly in a vehicle part (ObjectInVehicle) -> vanilla transfer.
     Bags inside furniture/corpses (or 2+ deep on floor/vehicle) -> IKINestTakeAction: one server-validated
     action per source bag (exact item-ID chain, per-item room check). The outer bag is never picked up. ]]
require "ISUI/ISInventoryPage"
require "ISUI/ISInventoryPane"
require "ISUI/ISInventoryPaneContextMenu"
require "ISUI/ISContextMenu"
require "iknowit/iki_shared"
require "TimedActions/iki_nesttakeaction"

local IKI = IKnowIt
local NL = {}
IKI.NestLoot = NL
NL.open = {}          -- [playerNum] = { {item=, inv=, parent=}, ... } in opening order
NL.MAX_DEPTH_MENU = 3

local function opt(n, d) return IKI.opt(n, d) end
local function enabled() return opt("NestLootEnabled", true) == true end

-- ------------------------------------------------------------------ helpers ----
function NL.isContainerItem(item)
    if item == nil or not instanceof(item, "InventoryContainer") then return false end
    local ok, inv = pcall(function() return item:getInventory() end)
    return ok and inv ~= nil
end

-- number of bags between `container` and the first non-item container (world/floor/corpse/car/player)
function NL.depth(container)
    local d, c, guard = 0, container, 0
    while c ~= nil and guard < 16 do
        local ci = c:getContainingItem()
        if ci == nil then return d end
        d = d + 1
        c = ci:getContainer()
        guard = guard + 1
    end
    return d
end

function NL.outermost(container)
    local c, guard = container, 0
    while c ~= nil and guard < 16 do
        local ci = c:getContainingItem()
        local up = ci and ci:getContainer() or nil
        if up == nil then return c end
        c = up
        guard = guard + 1
    end
    return c
end

function NL.inPlayerInv(container, playerObj)
    if container == nil or playerObj == nil then return false end
    if container == playerObj:getInventory() then return true end
    local ok, r = pcall(function() return container:isInCharacterInventory(playerObj) end)
    return ok and r == true
end

-- may items be taken out of `container` (the bag that directly holds them)?
-- returns true or false, reasonKey
function NL.canTakeFrom(container, playerObj)
    if container == nil then return false, "Tooltip_IKI_NestOuterFirst" end
    if NL.inPlayerInv(container, playerObj) then return true end
    if NL.depth(container) <= 1 then return true end
    if opt("NestLootDeep", false) == true then return true end
    return false, "Tooltip_IKI_NestOuterFirst"
end

-- ----------------------------------------------------------------- transfers ----
-- can the B42 SERVER resolve `container` as a vanilla transfer source? (mirrors ContainerID.set/getObject)
local function isFloorC(c)
    if c == nil then return true end
    local ok, t = pcall(function() return c:getType() end)
    return ok and t == "floor"
end
NL.isFloorC = isFloorC

function NL.serverReachable(container, playerObj)
    if container == nil then return false end
    if not isClient() then return true end                 -- SP / host-side: everything is local
    if NL.inPlayerInv(container, playerObj) then return true end
    local ci = container:getContainingItem()
    if ci == nil then return true end                      -- world container itself
    local up = ci:getContainer()
    if isFloorC(up) then                                   -- bag lying on the floor -> ContainerID WorldObject
        local w = nil
        pcall(function() w = ci:getWorldItem() end)
        return w ~= nil
    end
    if up:getContainingItem() == nil then                  -- bag directly in a vehicle part (ObjectInVehicle)
        local vp = nil
        pcall(function() vp = up:getVehiclePart() end)
        return vp ~= nil
    end
    return false
end

local function itemWeight(it)
    local ok, w = pcall(function() return it:getUnequippedWeight() end)
    if ok and type(w) == "number" then return w end
    return 0
end

local function roomForWeight(dest, playerObj, w)
    local ok, r = pcall(function() return dest:hasRoomFor(playerObj, w) end)
    if not ok then return true end
    return r ~= false
end

local function say(playerObj, key)
    pcall(function() HaloTextHelper.addBadText(playerObj, getText(key)) end)
end

-- check used by the menu: (ok, reasonKey)
function NL.takeCheck(container, playerObj)
    local ok, why = NL.canTakeFrom(container, playerObj)
    if not ok then return ok, why end
    if NL.serverReachable(container, playerObj) then return true end
    if IKnowIt.NestTake.addrOf(container) == nil then return false, "Tooltip_IKI_NestOuterFirst" end
    return true
end

-- items: list of InventoryItem that all should go to the main inventory. One walk, then vanilla actions.
function NL.take(playerObj, items)
    if playerObj == nil or items == nil or #items == 0 then return 0 end
    local playerNum = playerObj:getPlayerNum()
    local dest = playerObj:getInventory()
    local first = items[1]:getContainer()
    if first == nil then return 0 end
    local direct, groups, order = {}, {}, {}
    local blocked = nil
    local planned = 0
    for _, it in ipairs(items) do
        local src = it and it:getContainer()
        local eq = false
        pcall(function() eq = it:isEquipped() end)
        if src ~= nil and src ~= dest and NL.canTakeFrom(src, playerObj) and not eq then
            if NL.serverReachable(src, playerObj) then
                table.insert(direct, { it = it, src = src })
            else
                local root, chain, depth = IKnowIt.NestTake.addrOf(src)
                if root == nil or not IKnowIt.NestTake.depthAllowed(depth) then
                    blocked = "Tooltip_IKI_NestOuterFirst"
                elseif not roomForWeight(dest, playerObj, planned + itemWeight(it)) then
                    blocked = "Tooltip_IKI_NestBlocked"       -- only this item does not fit; the bag weight is irrelevant
                else
                    planned = planned + itemWeight(it)
                    local key = tostring(root) .. "|" .. chain
                    if groups[key] == nil then
                        groups[key] = { root = root, chain = chain, ids = {} }
                        table.insert(order, key)
                    end
                    table.insert(groups[key].ids, tostring(it:getID()))
                end
            end
        end
    end
    if #direct == 0 and #order == 0 then
        if blocked then say(playerObj, blocked) end
        return 0
    end
    local outer = NL.outermost(first)
    if not NL.inPlayerInv(first, playerObj) and luautils and luautils.walkToContainer then
        if not luautils.walkToContainer(outer, playerNum) then return 0 end
    end
    local n = 0
    for _, d in ipairs(direct) do
        local a = ISInventoryTransferUtil.newInventoryTransferAction(playerObj, d.it, d.src, dest)
        if a then ISTimedActionQueue.add(a); n = n + 1 end
    end
    for _, key in ipairs(order) do
        local g = groups[key]
        ISTimedActionQueue.add(IKINestTakeAction:new(playerObj, g.root, g.chain, table.concat(g.ids, ",")))
        n = n + #g.ids
    end
    if blocked then say(playerObj, blocked) end
    return n
end

-- ------------------------------------------------------------------ part 1 ----
local function pageFor(playerNum)
    local ok, lp = pcall(getPlayerLoot, playerNum)
    if ok then return lp end
    return nil
end

local function hasButton(page, inv)
    if page == nil or page.backpacks == nil then return false end
    for _, b in ipairs(page.backpacks) do if b.inventory == inv then return true end end
    return false
end

-- may this bag (lying in a container shown on the loot page) be opened as a tab?
function NL.canOpen(item, playerObj)
    if not enabled() or not NL.isContainerItem(item) or playerObj == nil then return false end
    local parent = item:getContainer()
    if parent == nil or NL.inPlayerInv(parent, playerObj) then return false end
    local ok, why = NL.canTakeFrom(item:getInventory(), playerObj)
    if not ok then return false, why end
    if not NL.serverReachable(item:getInventory(), playerObj) then return false, "Tooltip_IKI_NestMPNoTab" end
    return true
end

function NL.openContainer(playerObj, item)
    if not NL.canOpen(item, playerObj) then return false end
    local playerNum = playerObj:getPlayerNum()
    local list = NL.open[playerNum] or {}
    NL.open[playerNum] = list
    local inv = item:getInventory()
    local known = false
    for _, e in ipairs(list) do if e.inv == inv then known = true end end
    if not known then table.insert(list, { item = item, inv = inv, parent = item:getContainer() }) end
    local page = pageFor(playerNum)
    if page then
        if page.refreshBackpacks then page:refreshBackpacks() end
        if page.selectButtonForContainer and hasButton(page, inv) then page:selectButtonForContainer(inv) end
    end
    return true
end

-- stage "buttonsAdded" exists in vanilla and CleanUI ISInventoryPage:refreshBackpacks
function NL.onRefreshContainers(page, stage)
    if stage ~= "buttonsAdded" or page == nil or page.onCharacter then return end
    local list = NL.open[page.player]
    if list == nil or #list == 0 then return end
    if not enabled() then NL.open[page.player] = {}; return end
    local keep = {}
    local playerObj = getSpecificPlayer(page.player)
    for _, e in ipairs(list) do
        local ok = pcall(function()
            if e.item:getContainer() == e.parent and e.item:getInventory() == e.inv
               and hasButton(page, e.parent) and NL.canOpen(e.item, playerObj) then
                if not hasButton(page, e.inv) then
                    local b = page:addContainerButton(e.inv, e.item:getTex(), e.item:getName(), e.item:getName())
                    pcall(function()
                        local c = e.item:getVisual():getTint()
                        if b and c then b:setTextureRGBA(c:getRedFloat(), c:getGreenFloat(), c:getBlueFloat(), 1.0) end
                    end)
                end
                table.insert(keep, e)
            end
        end)
        if not ok then end
    end
    NL.open[page.player] = keep
end

-- arrow: only on the loot page, only on single-item rows (headers of groups keep the vanilla toggle)
function NL.rowItem(pane, idx)
    local v = pane.items and pane.items[idx]
    if v == nil then return nil end
    if instanceof(v, "InventoryItem") then return v end
    if type(v) == "table" and v.items and #v.items == 2 then return v.items[1] end
    return nil
end

local function arrowW(pane)
    local c2 = tonumber(pane.column2) or 16
    return math.max(8, math.min(14, c2 - 18))
end

function NL.arrowRow(pane, idx)
    if not enabled() or opt("NestLootArrow", true) ~= true then return nil end
    local page = pane.inventoryPage
    if page == nil or page.onCharacter then return nil end
    local it = NL.rowItem(pane, idx)
    if it == nil or it:getContainer() ~= pane.inventory then return nil end
    local playerObj = getSpecificPlayer(pane.player)
    if not NL.canOpen(it, playerObj) then return nil end
    return it
end

function NL.wrapPane()
    if NL.wrapped or not ISInventoryPane then return end
    NL.wrapped = true
    local origDown = ISInventoryPane.onMouseDown
    ISInventoryPane.onMouseDown = function(self, x, y, ...)
        local hit = false
        pcall(function()
            local idx = self.mouseOverOption
            if idx and idx ~= 0 and x >= 0 and x < arrowW(self) then
                local it = NL.arrowRow(self, idx)
                if it then
                    hit = NL.openContainer(getSpecificPlayer(self.player), it)
                end
            end
        end)
        if hit then return true end
        return origDown(self, x, y, ...)
    end
    local origRender = ISInventoryPane.renderdetails
    if origRender then
        ISInventoryPane.renderdetails = function(self, doDragged, ...)
            local r = origRender(self, doDragged, ...)
            if not doDragged then
                pcall(function()
                    local items = self.items
                    if items == nil then return end
                    local w, h = arrowW(self), self.itemHgt or 18
                    local hdr = self.headerHgt or 0
                    for i = 1, #items do
                        if NL.arrowRow(self, i) then
                            local yy = (i - 1) * h + hdr
                            local hot = self.mouseOverOption == i
                            self:drawRect(1, yy + 2, w, h - 4, hot and 0.9 or 0.6, 0.1, 0.1, 0.1)
                            self:drawText(">", 1 + (w - getTextManager():MeasureStringX(UIFont.Small, ">")) / 2,
                                yy + (h - getTextManager():getFontHeight(UIFont.Small)) / 2, 1, hot and 1 or 0.85, 0.3, 1, UIFont.Small)
                        end
                    end
                end)
            end
            return r
        end
    end
end

-- ------------------------------------------------------------------ part 2 ----
local function groupItems(container)
    local groups, order = {}, {}
    local list = container:getItems()
    for i = 0, list:size() - 1 do
        local it = list:get(i)
        local key = NL.isContainerItem(it) and ("bag#" .. tostring(it:getID())) or (it:getFullType() .. "|" .. it:getName())
        if groups[key] == nil then groups[key] = { name = it:getName(), items = {}, bag = NL.isContainerItem(it) }; table.insert(order, key) end
        table.insert(groups[key].items, it)
    end
    local out = {}
    for _, k in ipairs(order) do table.insert(out, groups[k]) end
    table.sort(out, function(a, b) return tostring(a.name) < tostring(b.name) end)
    return out
end

local function slice(t, n)
    local r = {}
    for i = 1, math.min(n, #t) do r[i] = t[i] end
    return r
end

-- marking: only for submenus built by us (marker option carries ikiNestSel; allocOption wipes it on reuse)
local function isOurs(menu)
    if menu == nil or menu.options == nil then return nil end
    for _, o in ipairs(menu.options) do if o.ikiNestSel then return o end end
    return nil
end

function NL.updateSelected(menu)
    local sel = isOurs(menu)
    if sel == nil then return 0 end
    local items = {}
    for _, o in ipairs(menu.options) do
        if o.checkMark and o.ikiItems then for _, it in ipairs(o.ikiItems) do table.insert(items, it) end end
    end
    sel.name = getText("ContextMenu_IKI_NestTakeSelected", tostring(#items))
    sel.param1 = items
    sel.notAvailable = #items == 0
    if menu.calcWidth and menu.setWidth then pcall(function() menu:setWidth(menu:calcWidth()) end) end
    return #items
end

local function onRightUp(self, x, y, ...)
    if isOurs(self) then
        local o = self.options[self.mouseOver or -1]
        if o and o.ikiItems and not o.notAvailable then
            o.checkMark = not o.checkMark
            NL.updateSelected(self)
        end
        return true
    end
    local f = ISContextMenu.onRightMouseUp
    if f then return f(self, x, y, ...) end
end
local function onRightDown(self, x, y, ...)
    if isOurs(self) then return true end
    local f = ISContextMenu.onRightMouseDown
    if f then return f(self, x, y, ...) end
end
NL.onRightUp = onRightUp

local function takeCb(playerObj, items) NL.take(playerObj, items) end

local function grey(o, key)
    o.notAvailable = true
    local tip = ISInventoryPaneContextMenu.addToolTip()
    tip.description = getText(key)
    o.toolTip = tip
end

function NL.fillMenu(context, parentOpt, playerObj, bag, level)
    local sub = context:getNew(context)
    context:addSubMenu(parentOpt, sub)
    sub.onRightMouseUp = onRightUp       -- per instance; pooled menus fall back via isOurs()
    sub.onRightMouseDown = onRightDown
    local inv = bag:getInventory()
    local okSrc, why = NL.takeCheck(inv, playerObj)
    local groups = groupItems(inv)
    if #groups == 0 then
        local o = sub:addOption(getText("ContextMenu_IKI_NestEmpty"))
        o.notAvailable = true
        return sub
    end
    local all = {}
    for _, g in ipairs(groups) do
        local n = #g.items
        local label = n > 1 and (g.name .. " (" .. n .. ")") or g.name
        local o
        if g.bag and level < NL.MAX_DEPTH_MENU then
            o = sub:addOption(label)
            local inner = NL.fillMenu(context, o, playerObj, g.items[1], level + 1)
            local self1 = inner:addOption(getText("ContextMenu_IKI_NestTakeBag"), playerObj, takeCb, { g.items[1] })
            self1.checkMark = false
            if not okSrc then grey(self1, why) end
        elseif n > 1 then
            o = sub:addOption(label)
            local s2 = context:getNew(context)
            context:addSubMenu(o, s2)
            s2:addOption(getText("ContextMenu_IKI_NestOne"), playerObj, takeCb, slice(g.items, 1))
            local half = math.max(1, math.floor(n / 2))
            s2:addOption(getText("ContextMenu_IKI_NestHalf", tostring(half)), playerObj, takeCb, slice(g.items, half))
            s2:addOption(getText("ContextMenu_IKI_NestAllOf", tostring(n)), playerObj, takeCb, slice(g.items, n))
            if not okSrc then for _, so in ipairs(s2.options) do grey(so, why) end end
        else
            o = sub:addOption(label, playerObj, takeCb, { g.items[1] })
        end
        o.checkMark = false
        o.ikiItems = g.items
        pcall(function() o.iconTexture = g.items[1]:getTex() end)
        if not okSrc then grey(o, why) else
            local tip = ISInventoryPaneContextMenu.addToolTip()
            tip.description = getText("Tooltip_IKI_NestTick")
            o.toolTip = tip
        end
        for _, it in ipairs(g.items) do table.insert(all, it) end
    end
    local sel = sub:addOption(getText("ContextMenu_IKI_NestTakeSelected", "0"), playerObj, takeCb, {})
    sel.ikiNestSel = true
    sel.notAvailable = true
    local ao = sub:addOption(getText("ContextMenu_IKI_NestTakeAll"), playerObj, takeCb, all)
    if not okSrc then grey(ao, why) end
    return sub
end

local function unwrap(items)
    if ISInventoryPane and ISInventoryPane.getActualItems then
        local ok, r = pcall(ISInventoryPane.getActualItems, items)
        if ok and r then return r end
    end
    local r = {}
    for _, v in ipairs(items or {}) do
        if instanceof(v, "InventoryItem") then table.insert(r, v) elseif type(v) == "table" and v.items then table.insert(r, v.items[1]) end
    end
    return r
end

function NL.onFillMenu(playerNum, context, items)
    if not enabled() or context == nil then return end
    local playerObj = getSpecificPlayer(playerNum)
    if playerObj == nil then return end
    local list = unwrap(items)
    if #list ~= 1 then return end
    local bag = list[1]
    if not NL.isContainerItem(bag) then return end
    -- Part 1 fallback: "Oeffnen"
    local page = pageFor(playerNum)
    if not NL.inPlayerInv(bag:getContainer(), playerObj) and not hasButton(page, bag:getInventory()) then
        local canO, whyO = NL.canOpen(bag, playerObj)
        if canO then
            context:addOption(getText("ContextMenu_IKI_NestOpen"), playerObj, NL.openContainer, bag)
        elseif whyO == "Tooltip_IKI_NestMPNoTab" or NL.depth(bag:getContainer()) >= 1 then
            local o = context:addOption(getText("ContextMenu_IKI_NestOpen"))
            grey(o, whyO or "Tooltip_IKI_NestOuterFirst")
        end
    end
    -- Part 2: "Inhalt nehmen"
    if opt("NestLootMenu", true) == true then
        local n = bag:getInventory():getItems():size()
        local o = context:addOption(getText("ContextMenu_IKI_NestTake", tostring(n)))
        NL.fillMenu(context, o, playerObj, bag, 1)
    end
end

-- -------------------------------------------------------------------- wiring ----
Events.OnRefreshInventoryWindowContainers.Add(function(page, stage) pcall(NL.onRefreshContainers, page, stage) end)
Events.OnFillInventoryObjectContextMenu.Add(function(pn, ctx, items)
    local ok, err = pcall(NL.onFillMenu, pn, ctx, items)
    if not ok and IKI.debug then print("IKnowIt nestloot: " .. tostring(err)) end
end)
Events.OnGameStart.Add(NL.wrapPane)
Events.OnServerCommand.Add(function(module, command, args)
    if module == "iknowit" and command == "nestFail" then
        local p = getPlayer()
        if p then say(p, "IGUI_IKI_NestFailed") end
    end
end)
