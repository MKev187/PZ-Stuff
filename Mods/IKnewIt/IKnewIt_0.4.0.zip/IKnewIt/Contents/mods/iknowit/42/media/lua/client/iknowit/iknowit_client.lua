--[[
    IKnowIt! 0.3.0  (mod id: iknowit)
    Author: MKev
    Optimized by Grok Bot in combination with Cursor

    Media tracker + icon overlay for inventory and container windows.
    Ball (bottom left) on ALL readable/listenable media, as before.
    Extra symbols only on media that TEACH something: skill books, recipe books/magazines,
    VHS/CD/other recorded media with skill/recipe lines.
    - top right    : XP-Boost (skill book, not read yet) / XP-Drop (read once -> study reward),
                     light bulb = teaches recipes
    - top left     : skill books only: "?" = not studied yet, "!" = already studied
    - bottom right : nothing from IKnowIt (0.3.0: red X / looted tracking removed, vanilla check only)
    - bottom left  : ball, same height as the vanilla check: red = not readable,
                     orange = readable but unread, green = read

    Storage is client side (one small text file per server + character in Zomboid/Lua/).
    "Read" always uses the vanilla truth of the character (synced by the game).
]]

IKnowIt = IKnowIt or {}
local IKI = IKnowIt
IKI.VERSION = "0.4.0"

local TEX_PATH = "media/textures/iknowit/"
local tex = {}
local function T(name)
    local t = tex[name]
    if t == nil then
        t = getTexture(TEX_PATH .. name .. ".png") or false
        tex[name] = t
    end
    return t or nil
end

-- --------------------------------------------------------------------------
-- settings
-- --------------------------------------------------------------------------
local function opt(name, default)
    local sv = SandboxVars and SandboxVars.IKnowIt
    if sv == nil or sv[name] == nil then return default end
    return sv[name]
end

-- --------------------------------------------------------------------------
-- storage (per server + character, client side)
-- --------------------------------------------------------------------------
IKI.data = nil       -- { seen = {key = itemId or true} }  (0.3.0: looted/held lines of older files are dropped)
IKI.dirty = false
IKI.fileName = nil

local function sanitize(s)
    s = tostring(s or "x")
    return (string.gsub(s, "[^%w%-]", "_"))
end

local function buildFileName(player)
    local srv = "sp"
    if isClient() then
        local ok, ip = pcall(getServerIP)
        local ok2, port = pcall(getServerPort)
        srv = "mp_" .. tostring(ok and ip or "srv") .. "_" .. tostring(ok2 and port or "0")
    else
        local ok, w = pcall(function() return getWorld():getWorld() end)
        if ok and w then srv = "sp_" .. tostring(w) end
    end
    local user = player:getUsername() or "player"
    local desc = player:getDescriptor()
    local who = user
    if desc then
        who = who .. "_" .. tostring(desc:getForename()) .. "_" .. tostring(desc:getSurname())
    end
    return "iknowit_" .. sanitize(srv) .. "_" .. sanitize(who) .. ".txt"
end

function IKI.load(player)
    IKI.data = { seen = {} }
    IKI.fileName = buildFileName(player)
    local reader = getFileReader(IKI.fileName, false)
    if reader == nil then return end
    local line = reader:readLine()
    while line ~= nil do
        local kind, key, id = string.match(line, "^(%a)\t([^\t]+)\t?(.*)$")
        if kind == "s" and key then
            IKI.data.seen[key] = tonumber(id) or true
        end
        line = reader:readLine()
    end
    reader:close()
end

function IKI.save()
    if not IKI.dirty or IKI.data == nil or IKI.fileName == nil then return end
    local writer = getFileWriter(IKI.fileName, true, false)
    if writer == nil then return end
    writer:write("# IKnowIt! " .. IKI.VERSION .. " data - do not edit while the game runs\n")
    for key, id in pairs(IKI.data.seen) do
        writer:write("s\t" .. key .. "\t" .. (type(id) == "number" and tostring(id) or "") .. "\n")
    end
    writer:close()
    IKI.dirty = false
end

-- --------------------------------------------------------------------------
-- item analysis
-- --------------------------------------------------------------------------
local MOOD_CODES = { BOR = true, UHP = true, STS = true, PAN = true, FEA = true, ANG = true,
    SAN = true, HUN = true, THI = true, FAT = true, END = true, PAI = true, SIC = true,
    DRU = true, WET = true, ANX = true, STR = true, RCP = true }

local function call(obj, fn, ...)
    if obj == nil then return nil end
    local f = obj[fn]
    if f == nil then return nil end
    local ok, res = pcall(f, obj, ...)
    if ok then return res end
    return nil
end

local function listSize(l)
    if l == nil then return 0 end
    local ok, n = pcall(function() return l:size() end)
    if ok and n then return n end
    return 0
end

local function getPerkFor(skill)
    if skill == nil or skill == "" then return nil end
    if SkillBook and SkillBook[skill] and SkillBook[skill].perk then return SkillBook[skill].perk end
    if Perks and Perks.FromString then
        local ok, p = pcall(Perks.FromString, skill)
        if ok and p ~= nil then return p end
    end
    return nil
end

IKI.getPerkFor = getPerkFor

function IKI.perkName(perk)
    if perk == nil then return nil end
    local ok, n = pcall(function() return PerkFactory.getPerkName(perk) end)
    if ok and n and n ~= "" then return n end
    ok, n = pcall(function() return perk:getName() end)
    if ok and n and n ~= "" then return tostring(n) end
    return nil
end

-- recorded media skill codes -> perk (first three letters of a media line code)
IKI.MEDIA_PERKS = { COO = "Cooking", CRP = "Woodwork", CAR = "Woodwork", ELC = "Electricity", ELE = "Electricity",
    FRM = "Farming", FAR = "Farming", DOC = "Doctor", FIS = "Fishing", MEC = "Mechanics", MTL = "MetalWelding",
    MET = "MetalWelding", TAI = "Tailoring", TRA = "Trapping", FOR = "PlantScavenging", PLA = "PlantScavenging",
    AIM = "Aiming", REL = "Reloading", FIT = "Fitness", STR = "Strength", SPR = "Sprinting", LIG = "Lightfoot",
    NIM = "Nimble", SNE = "Sneak", AXE = "Axe", BLU = "Blunt", SBL = "SmallBlunt", LBL = "LongBlade",
    SBA = "SmallBlade", SPE = "Spear", MAI = "Maintenance", HUS = "Husbandry", BUT = "Butchering",
    TRK = "Tracking", POT = "Pottery", MAS = "Masonry", CRV = "Carving", KNA = "FlintKnapping", GLA = "Glassmaking" }

local function isIlliterate(player)
    local ok, res = pcall(function()
        if CharacterTrait and CharacterTrait.ILLITERATE then
            return player:hasTrait(CharacterTrait.ILLITERATE)
        end
        return player:HasTrait("Illiterate")
    end)
    return ok and res == true
end

-- returns teachesSkill, firstSkillCode, teachesRecipe
local function mediaTeachesSkill(md)
    local n = call(md, "getLineCount") or 0
    local skill, code1, recipe = false, nil, false
    for i = 0, n - 1 do
        local line = call(md, "getLine", i)
        local codes = line and call(line, "getCodes")
        if codes and codes ~= "" then
            for _ in string.gmatch(string.upper(codes), "RCP") do recipe = (recipe or 0) + 1 end
            for code in string.gmatch(codes, "([%a]+)[%+%-]") do
                local c3 = string.upper(string.sub(code, 1, 3))
                if not MOOD_CODES[c3] then
                    skill = true
                    code1 = code1 or c3
                end
            end
        end
    end
    return skill, code1, recipe
end
IKI.mediaTeachesSkill = mediaTeachesSkill

-- returns nil for items IKnowIt does not track
function IKI.analyse(item, player)
    local isLit = call(item, "IsLiterature") == true
    local md = nil
    if call(item, "isRecordedMedia") == true then md = call(item, "getMediaData") end
    if not isLit and md == nil then return nil end

    local info = { teach = false, xp = false, hasRead = false, read = false, readable = true, outgrown = false }
    local modData = (call(item, "hasModData") == true) and item:getModData() or nil
    local fullType = item:getFullType()
    info.fullType = fullType

    if md ~= nil then
        info.key = "m:" .. tostring(call(md, "getId") or fullType)
        local sk, code, rcp = mediaTeachesSkill(md)
        info.media = true
        info.teach = sk or (rcp and true or false)
        info.nRecipes = rcp or 0
        info.mediaSkill = sk
        info.kind = sk and "media_skill" or (rcp and "media_recipe" or "media")
        if sk and code and IKI.MEDIA_PERKS[code] then
            info.perk = getPerkFor(IKI.MEDIA_PERKS[code])
        end
        info.hasRead = true
        local rm = getZomboidRadio and getZomboidRadio():getRecordedMedia()
        info.read = rm ~= nil and call(rm, "hasListenedToAll", player, md) == true
        return info
    end

    -- literature
    local title = modData and modData.literatureTitle
    local printMedia = modData and modData.printMedia
    local learned = modData and (modData.learnedRecipe or modData.teachedRecipe)
    if title then info.key = "t:" .. tostring(title)
    elseif printMedia and printMedia.title then info.key = "p:" .. tostring(printMedia.title)
    elseif learned then info.key = "r:" .. tostring(learned)
    else info.key = fullType end

    local recipes = call(item, "getLearnedRecipes")
    local nRecipes = listSize(recipes)
    if nRecipes > 0 or learned then info.teach = true end
    info.nRecipes = (nRecipes > 0) and nRecipes or (learned and 1 or 0)

    local skill = call(item, "getSkillTrained")
    local lvl = call(item, "getLvlSkillTrained") or -1
    local perk = (skill and skill ~= "" and lvl ~= -1) and getPerkFor(skill) or nil
    if perk then info.xp = true; info.skillBook = true; info.perk = perk end
    -- 0.4.0: documents of other mods with a verified one-time flat XP grant (display only, see iki_compat_docs)
    local docPerk = (perk == nil) and IKI.docXpOf and IKI.docXpOf(item) or nil
    if docPerk then
        info.docXp = true
        info.docPerkId = docPerk
        info.perk = getPerkFor(docPerk)
        info.hasRead = true
        info.read = IKI.docXpRead(player, item)
    end
    info.kind = perk and "skill" or (docPerk and "doc_xp" or (info.teach and "recipe" or "plain"))
    info.lvlMin = lvl
    info.lvlMax = call(item, "getMaxLevelTrained") or lvl

    local known = player:getKnownRecipes()
    -- read state (vanilla truth)
    if title then
        info.hasRead = true
        info.read = player:isLiteratureRead(title)
    elseif printMedia and printMedia.title then
        info.hasRead = true
        info.read = call(player, "isPrintMediaRead", printMedia.title) == true
    elseif learned and type(learned) == "string" then
        info.hasRead = true
        info.read = known:contains(learned)
    end
    local pages = call(item, "getNumberOfPages") or -1
    if docPerk then
        -- read state comes from the owning mod (set above); no level gating there
    elseif perk then
        info.hasRead = true
        local plvl = player:getPerkLevel(perk)
        local maxLvl = call(item, "getMaxLevelTrained") or lvl
        local readPages = player:getAlreadyReadPages(fullType)
        if pages > 0 and readPages >= pages then info.read = true end
        if maxLvl < plvl + 1 then
            info.outgrown = true          -- vanilla treats this as "already read"
            info.read = true
        end
        if lvl > plvl + 1 then info.readable = false end
    elseif nRecipes > 0 then
        info.hasRead = true
        if known:containsAll(recipes) then info.read = true end
    elseif pages > 0 and not info.hasRead then
        info.hasRead = true
        info.read = player:getAlreadyReadPages(fullType) >= pages
    end
    if isIlliterate(player) then info.readable = false end
    return info
end

-- --------------------------------------------------------------------------
-- tracking
-- --------------------------------------------------------------------------
function IKI.markSeen(key, id)
    if IKI.data and IKI.data.seen[key] == nil then
        IKI.data.seen[key] = id or true
        IKI.dirty = true
    end
end


local cache = {}
local cacheTime = 0
local CACHE_MS = 750

local function getInfo(item, player)
    local now = getTimestampMs()
    if now - cacheTime > 5000 then cache = {}; cacheTime = now end
    local id = item:getID()
    local c = cache[id]
    if c and (now - c.t) < CACHE_MS then return c.info end
    local ok, info = pcall(IKI.analyse, item, player)
    if not ok then info = nil end
    cache[id] = { t = now, info = info or false }
    return info or false
end

-- --------------------------------------------------------------------------
-- drawing
-- --------------------------------------------------------------------------
local function draw(pane, name, x, y, s, a)
    local t = T(name)
    if t then pane:drawTextureScaled(t, x, y, s, s, a or 1, 1, 1, 1) end
end

-- 0.3.0 layout, relative to the icon box (W x H) and the pane row height.
-- The vanilla check (media/ui/Tick_Mark-10.png, 10 px) is drawn at x+a, y+a-1 with
-- a = itemHgt-(itemHgt-W)/2-13 (ISInventoryPane:renderdetails).
function IKI.layout(W, H, itemHgt, k)
    k = k or 1
    local a = itemHgt and (itemHgt - (itemHgt - W) / 2 - 13) or (W - 12)
    local tickBottom = a - 1 + 10
    local function r(v) return math.floor(v + 0.5) end
    local b  = math.max(6, r(0.46 * W * k))
    local g  = math.max(6, r(0.50 * W * k))
    local e  = math.max(6, r(0.54 * W * k))
    return {
        ball  = { -4, tickBottom - b, b },
        glyph = { -3, -3, g },
        xp    = { W - e + 3, -3, e },
        bulb2 = { W - 2 * e + 5, -3, e },
        tick  = { a, a - 1, 10 },
    }
end

function IKI.xpIcon(info, player)
    if info.docXp then
        if info.read then return nil, 1 end              -- XP already granted by the owning mod
        return "iki_xp", 1
    end
    if not info.skillBook then return nil, 1 end
    if not info.read then return "iki_xp", 1 end
    local a = 1
    if IKI.studyInfo and IKI.studyCountClient then
        local ok, state = pcall(function()
            local st = IKI.studyInfo(player, info.item, IKI.studyCountClient(player, info.fullType))
            return st
        end)
        if ok and state ~= "ok" then a = 0.45 end
    end
    return "iki_xpdrop", a
end

function IKI.drawOverlay(pane, item, x, y, alpha, w, h)
    if IKI.data == nil then return end
    local player = getSpecificPlayer(type(pane.player) == "number" and pane.player or 0) or getPlayer()
    if player == nil then return end
    local info = getInfo(item, player)
    if not info then return end
    info.item = item

    local key = info.key
    IKI.markSeen(key, item:getID())

    w = w or 32
    h = h or w
    local a = alpha or 1
    local L = IKI.layout(w, h, pane.itemHgt, (opt("IconScale", 100) or 100) / 100)

    -- top right: XP-Boost / XP-Drop, bulb
    local xpName, xpA = nil, 1
    if opt("ShowXPIcon", true) then xpName, xpA = IKI.xpIcon(info, player) end
    if info.teach and opt("ShowTeachIcon", true) then
        local p = xpName and L.bulb2 or L.xp
        draw(pane, "iki_bulb", x + p[1], y + p[2], p[3], a)
    end
    if xpName then draw(pane, xpName, x + L.xp[1], y + L.xp[2], L.xp[3], a * xpA) end
    -- top left: study marker (skill books only)
    if info.skillBook and opt("StudyEnabled", true) and opt("ShowStudyMark", true) then
        local n = 0
        if IKI.studyCountClient then n = IKI.studyCountClient(player, info.fullType) or 0
        elseif IKI.studyCount then n = IKI.studyCount(player, info.fullType) or 0 end
        draw(pane, n >= 1 and "iki_exclaim" or "iki_question", x + L.glyph[1], y + L.glyph[2], L.glyph[3], a)
    end
    -- bottom left: ball
    if info.hasRead and opt("ShowTrafficLight", true) then
        draw(pane, IKI.ballColor(info), x + L.ball[1], y + L.ball[2], L.ball[3], a)
    end
end

-- red = not readable, orange = readable but not read yet, green = read (vanilla truth)
function IKI.ballColor(info)
    if info.read then return "iki_ball_green" end
    if not info.readable then return "iki_ball_red" end
    return "iki_ball_orange"
end

-- wrap (do not replace) the shared item icon renderer used by inventory + loot panes
function IKI.installHook()
    if IKI.hooked then return end
    if ISInventoryItem == nil or ISInventoryItem.renderItemIcon == nil then
        print("[IKnowIt] WARNING: ISInventoryItem.renderItemIcon not found - overlay disabled")
        return
    end
    local original = ISInventoryItem.renderItemIcon
    IKI.originalRenderItemIcon = original
    ISInventoryItem.renderItemIcon = function(self, item, x, y, alpha, w, h)
        local r = original(self, item, x, y, alpha, w, h)
        if self ~= nil and item ~= nil and self.inventory ~= nil and self.drawTextureScaled ~= nil then
            local ok, err = pcall(IKI.drawOverlay, self, item, x, y, alpha, w, h)
            if not ok and not IKI.errLogged then
                IKI.errLogged = true
                print("[IKnowIt] overlay error: " .. tostring(err))
            end
        end
        return r
    end
    IKI.hooked = true
end

-- --------------------------------------------------------------------------
-- periodic: "seen" scan of the main inventory (incl. bags) + save
-- --------------------------------------------------------------------------
local lastScan, lastSave = 0, 0
local function scanInventory(player)
    local inv = player:getInventory()
    if inv == nil then return end
    local items = inv:getItems()
    local function visit(list, depth)
        for i = 0, list:size() - 1 do
            local it = list:get(i)
            local info = getInfo(it, player)
            if info then
                IKI.markSeen(info.key, it:getID())
            end
            if depth < 2 and instanceof(it, "InventoryContainer") then
                local sub = it:getInventory()
                if sub then visit(sub:getItems(), depth + 1) end
            end
        end
    end
    pcall(visit, items, 0)
end

local function onTick()
    local now = getTimestampMs()
    local player = getPlayer()
    if player == nil or IKI.data == nil then return end
    if now - lastScan > 2000 then
        lastScan = now
        scanInventory(player)
    end
    if IKI.dirty and now - lastSave > 15000 then
        lastSave = now
        pcall(IKI.save)
    end
end

local function onGameStart()
    local player = getPlayer()
    if player then pcall(IKI.load, player) end
    IKI.installHook()
    print("[IKnowIt] version " .. IKI.VERSION .. " loaded (file " .. tostring(IKI.fileName) .. ")")
end

local function onCreatePlayer(_, player)
    if player and player == getPlayer() then
        IKI.save()
        pcall(IKI.load, player)
        cache = {}
    end
end

Events.OnGameStart.Add(onGameStart)
Events.OnCreatePlayer.Add(onCreatePlayer)
Events.OnTick.Add(onTick)
Events.OnSave.Add(function() pcall(IKI.save) end)
