--[[ IKnowIt! server commands. Author: MKev - Optimized by Grok Bot in combination with Cursor ]]
require "iknowit/iki_shared"
if isClient() then return end

local function onClientCommand(module, command, player, args)
    if module ~= "iknowit" or player == nil then return end
    if command == "getStudy" then
        local t = player:getModData().iki_study or {}
        local copy = {}
        for k, v in pairs(t) do copy[k] = v end
        sendServerCommand(player, "iknowit", "studyAll", { counts = copy })
    end
end

Events.OnClientCommand.Add(onClientCommand)
