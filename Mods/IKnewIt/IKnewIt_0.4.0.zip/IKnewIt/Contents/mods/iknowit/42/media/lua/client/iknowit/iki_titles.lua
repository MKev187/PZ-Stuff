--[[
    IKnowIt! 0.3.2 - title prefixes for teaching media: skill books "[Skillbuch] ..." (EN: [Skillbook]),
    training VHS/CD "[Elektrotechnik] ...", recipe media "[Rezept] ..." / "[Rezepte] ..." (EN: [Recipe] / [Recipes]).
    Author: MKev - Optimized by Grok Bot in combination with Cursor

    Display only: the prefix is set right before ISInventoryPane:renderdetails() draws the rows and the
    original name is restored right after (same frame). Item identity, saves, stacking and the
    sorting done in refreshContainer() never see the prefix.
]]
require "ISUI/ISInventoryPane"
require "iknowit/iki_shared"

local IKI = IKnowIt

function IKI.titlePrefix(item, player)
    if not IKI.opt("TitlePrefix", true) or IKI.analyse == nil then return nil end
    local lit = IKI.call(item, "IsLiterature") == true
    if not lit and IKI.call(item, "isRecordedMedia") ~= true then return nil end
    local ok, info = pcall(IKI.analyse, item, player)
    if not ok or not info then return nil end
    if info.skillBook then
        -- 0.3.2 (MKev): skill books only give an XP boost, their title already names the skill
        return "[" .. getText("IGUI_IKI_PrefixSkillBook") .. "] "
    end
    if info.mediaSkill or info.docXp then
        local n = IKI.perkName and IKI.perkName(info.perk)
        return "[" .. (n or getText("IGUI_IKI_PrefixSkill")) .. "] "
    end
    if info.teach then
        local key = ((info.nRecipes or 0) > 1) and "IGUI_IKI_PrefixRecipes" or "IGUI_IKI_PrefixRecipe"
        return "[" .. getText(key) .. "] "
    end
    return nil
end

local function wrap()
    if ISInventoryPane == nil or ISInventoryPane.renderdetails == nil or ISInventoryPane.iki_titles then return end
    ISInventoryPane.iki_titles = true
    local orig = ISInventoryPane.renderdetails
    ISInventoryPane.renderdetails = function(self, ...)
        local changed = nil
        if IKI.opt("TitlePrefix", true) and self.itemslist then
            pcall(function()
                local player = getSpecificPlayer(self.player or 0)
                if player == nil then return end
                for _, v in ipairs(self.itemslist) do
                    if v.items then
                        for _, it in ipairs(v.items) do
                            local pfx = IKI.titlePrefix(it, player)
                            if pfx then
                                local nm = it:getName()
                                if nm and string.sub(nm, 1, #pfx) ~= pfx then
                                    changed = changed or {}
                                    table.insert(changed, { it, nm })
                                    it:setName(pfx .. nm)
                                end
                            end
                        end
                    end
                end
            end)
        end
        local ok, err = pcall(orig, self, ...)
        if changed then
            for i = #changed, 1, -1 do pcall(function() changed[i][1]:setName(changed[i][2]) end) end
        end
        if not ok then error(err, 0) end
    end
end
Events.OnGameStart.Add(wrap)
