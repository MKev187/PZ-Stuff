--[[ IKnowIt! "Nachschlagen" (internal: study) timed action. Author: MKev - Optimized by Grok Bot in combination with Cursor
     Runs like every B42 action: client shows progress, complete() runs on the authority (SP / server). ]]
require "TimedActions/ISBaseTimedAction"
require "iknowit/iki_shared"
require "TimedActions/ISReadABook"
require "iknowit/iki_readspeed"
require "iknowit/iki_boredom"

IKIStudyAction = ISBaseTimedAction:derive("IKIStudyAction")

function IKIStudyAction:isValid()
    if self.character:tooDarkToRead() then
        HaloTextHelper.addBadText(self.character, getText("ContextMenu_TooDark"))
        return false
    end
    if isClient() and self.item then
        return self.character:getInventory():containsID(self.item:getID())
    end
    return self.character:getInventory():contains(self.item)
end

function IKIStudyAction:update()
    self.item:setJobDelta(self:getJobDelta())
    if IKnowIt.skillBookBoredomTick then pcall(IKnowIt.skillBookBoredomTick, self) end
end

function IKIStudyAction:start()
    if isClient() and self.item then
        self.item = self.character:getInventory():getItemById(self.item:getID())
    end
    self.item:setJobType(getText("ContextMenu_IKI_Study") .. " " .. self.item:getName())
    self.item:setJobDelta(0.0)
    self:setAnimVariable("ReadType", "book")
    self:setOverrideHandModels(nil, self.item)
    self:setActionAnim(CharacterActionAnims.Read)
    self.character:setReading(true)
    self.character:playSound("OpenBook")
end

function IKIStudyAction:stop()
    if IKnowIt.skillBookBoredomFlush then pcall(IKnowIt.skillBookBoredomFlush, self) end
    self.character:setReading(false)
    if self.item then self.item:setJobDelta(0.0) end
    ISBaseTimedAction.stop(self)
end

function IKIStudyAction:perform()
    if IKnowIt.skillBookBoredomFlush then pcall(IKnowIt.skillBookBoredomFlush, self) end
    self.character:setReading(false)
    self.character:playSound("CloseBook")
    ISBaseTimedAction.perform(self)
end

-- 0.3.2: B42 MP never calls update() on the dedicated server (NetTimedAction.update is empty); the
-- server only gets complete() at endTime and the anim events it emulates. The boredom tick therefore
-- runs from a periodic emulated event on the server; update() keeps doing it in SP.
IKIStudyAction.TICK_EVENT = "IKI_StudyTick"
IKIStudyAction.TICK_MS = 2000

function IKIStudyAction:serverStart()
    if emulateAnimEvent and self.netAction then
        emulateAnimEvent(self.netAction, IKIStudyAction.TICK_MS, IKIStudyAction.TICK_EVENT, nil)
    end
end

function IKIStudyAction:animEvent(event, parameter)
    if event == IKIStudyAction.TICK_EVENT and isServer() and IKnowIt.skillBookBoredomTick then
        pcall(IKnowIt.skillBookBoredomTick, self)
    end
end

-- 0.3.2: a refused look-up is no longer silent: one log line on the authority, a halo text for the player
function IKIStudyAction.reject(self, item, state)
    local chr = self.character
    local pages = IKnowIt.call(item, "getNumberOfPages") or -1
    local _, own, itemPages = 0, 0, 0
    if IKnowIt.pagesRead then _, own, itemPages = IKnowIt.pagesRead(chr, item) end
    print("[IKnowIt] Nachschlagen refused: state=" .. tostring(state) .. " book=" .. tostring(IKnowIt.call(item, "getFullType"))
        .. " pages(char/item/total)=" .. tostring(own) .. "/" .. tostring(itemPages) .. "/" .. tostring(pages)
        .. " server=" .. tostring(isServer()))
    if isServer() then
        sendServerCommand(chr, "iknowit", "studyFail", { s = tostring(state) })
    else
        HaloTextHelper.addBadText(chr, getText("IGUI_IKI_StudyFailed"))
    end
end

-- authority: validate again, remove the book, grant capped XP, count the copy
function IKIStudyAction:complete()
    local inv = self.character:getInventory()
    local item = self.item
    if item == nil or not inv:containsID(item:getID()) then return false end
    item = inv:getItemById(item:getID()) or item
    local state, xp = IKnowIt.studyInfo(self.character, item)
    if state ~= "ok" or xp <= 0 then
        IKIStudyAction.reject(self, item, state)
        return false
    end
    local perk = IKnowIt.skillBookPerk(item)
    local fullType = item:getFullType()
    local md = self.character:getModData()
    md.iki_study = md.iki_study or {}
    md.iki_study[fullType] = (tonumber(md.iki_study[fullType]) or 0) + 1
    inv:Remove(item)
    sendRemoveItemFromContainer(inv, item)
    addXpNoMultiplier(self.character, perk, xp)
    if isServer() then
        sendServerCommand(self.character, "iknowit", "studyCount", { t = fullType, n = md.iki_study[fullType], xp = xp })
    else
        HaloTextHelper.addGoodText(self.character, getText("IGUI_IKI_StudyDone", tostring(xp)))
    end
    return true
end

-- 0.3.0: "Nachschlagen" takes StudyTimeMultiplier (default 0.5 = half) of the vanilla duration of a
-- FULL read of this book by this character. ISReadABook.getDuration is evaluated on a side-effect-free
-- proxy (no page reset, no level check), so traits, FAST_READ, glasses, sitting and the IKnowIt
-- reading speed bonuses (iki_readspeed wraps ISReadABook.getDuration) are all included.
local function legacyFullRead(chr, item)
    local pages = item:getNumberOfPages()
    if pages <= 0 then pages = 100 end
    local mpp = 2.0
    local opt = getSandboxOptions():getOptionByName("MinutesPerPage")
    if opt then mpp = opt:getValue() or 2.0 end
    if mpp <= 0 then mpp = 2.0 end
    local f = 1 / getGameTime():getMinutesPerDay() / 2
    local time = pages * mpp / f
    if chr:hasTrait(CharacterTrait.FAST_READER) then time = time * 0.7 end
    if chr:hasTrait(CharacterTrait.SLOW_READER) then time = time * 1.3 end
    return time
end

function IKIStudyAction.fullReadDuration(chr, item)
    if ISReadABook and ISReadABook.getDuration then
        local ok, t = pcall(function()
            local mpp = 2.0
            local o = getSandboxOptions():getOptionByName("MinutesPerPage")
            if o then mpp = o:getValue() or 2.0 end
            if mpp < 0 then mpp = 2.0 end
            local proxy = {
                getNumberOfPages = function() return item:getNumberOfPages() end,
                hasTag = function(_, tag) return item:hasTag(tag) end,
                getFullType = function() return item:getFullType() end,
                getSkillTrained = function() return nil end,          -- skip vanilla checkLevel side effects
                getLvlSkillTrained = function() return -1 end,
                setAlreadyReadPages = function() end,
                getAlreadyReadPages = function() return 0 end,
                getType = function() return item:getType() end,
            }
            local fake = setmetatable({ character = chr, item = proxy, minutesPerPage = mpp }, { __index = ISReadABook })
            return ISReadABook.getDuration(fake)
        end)
        if ok and type(t) == "number" and t == t and t > 0 then return t end
    end
    return legacyFullRead(chr, item)
end

function IKIStudyAction:getDuration()
    if self.character:isTimedActionInstant() then return 1 end
    local mult = tonumber(IKnowIt and IKnowIt.opt and IKnowIt.opt("StudyTimeMultiplier", 0.5)) or 0.5
    if mult <= 0 then mult = 0.5 end
    return math.max(IKIStudyAction.fullReadDuration(self.character, self.item) * mult, 1)
end

function IKIStudyAction:new(character, item)
    local o = ISBaseTimedAction.new(self, character)
    o.character = character
    o.item = item
    o.ignoreHandsWounds = true
    o.caloriesModifier = 0.5
    o.forceProgressBar = true
    o.maxTime = o:getDuration()
    return o
end
