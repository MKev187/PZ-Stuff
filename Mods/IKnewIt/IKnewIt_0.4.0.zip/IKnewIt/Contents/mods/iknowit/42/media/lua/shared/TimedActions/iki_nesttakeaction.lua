--[[ I Knew It! 0.4.0 - take items out of a bag that the B42 server cannot address as a transfer source.
     Author: MKev - Optimized by Grok Bot in combination with Cursor

     Why: vanilla item transactions address source containers via ContainerID. ContainerID can resolve the
     player inventory (any depth), world/furniture containers, corpses, vehicle parts, a bag lying on the floor
     (WorldObject) and a bag directly in a vehicle part (ObjectInVehicle). A bag INSIDE furniture or a corpse,
     or a bag 2+ levels deep on the floor / in a vehicle, is not addressable (containerIndex -1 / null parent).
     For those - and only those - this action is used. The outer bag is never picked up or moved.

     Network: :new(character, root, chain, ids). `root` is the addressable world container (furniture, corpse,
     vehicle part or the floor), resolved by the engine on the server. `chain` = bag item IDs from root down to
     the bag that directly holds the items ("12/34"), `ids` = item IDs to take ("5,6,7"). complete() runs on the
     authority only (SP / server) and re-validates everything: reach, safehouse loot right, the exact ID chain
     (direct children only, no type/name lookup), every item still there, removable, allowed and fitting into the
     main inventory (per item, not the whole bag). Then it moves the items and syncs:
       - main inventory: sendAddItemToContainer
       - source bag: the deepest ADDRESSABLE ancestor receives sendReplaceItemInContainer of its child bag
         (re-sends that bag with its current contents) or, if the source itself is addressable, sendRemove...
     Items that changed meanwhile (other player, stale menu, repeated request) are skipped, never duplicated. ]]
require "TimedActions/ISBaseTimedAction"
require "iknowit/iki_shared"

IKINestTakeAction = ISBaseTimedAction:derive("IKINestTakeAction")

local NT = {}
IKnowIt.NestTake = NT
NT.REACH = 3.0          -- tiles from the root square (walkToContainer stands next to it)
NT.REACH_VEHICLE = 5.0  -- vanilla TransactionManager uses 5 for vehicles
NT.MAX_IDS = 200

local function splitNums(s, sep)
    local out, seen = {}, {}
    if type(s) ~= "string" then return out end
    for part in string.gmatch(s, "[^" .. sep .. "]+") do
        local n = tonumber(part)
        if n and n == math.floor(n) and not seen[n] then seen[n] = true; table.insert(out, n) end
        if #out >= NT.MAX_IDS then break end
    end
    return out
end
NT.splitNums = splitNums

local function isFloor(c)
    if c == nil then return true end
    local ok, t = pcall(function() return c:getType() end)
    return ok and t == "floor"
end

-- client: describe `src` (the bag inventory holding the items) as root + ID chain. nil if not a bag in the world.
function NT.addrOf(src)
    local bags, c, guard = {}, src, 0
    while c ~= nil and guard < 16 do
        local ci = c:getContainingItem()
        if ci == nil then break end
        table.insert(bags, 1, ci)
        local up = ci:getContainer()
        if up == nil then return nil end
        c = up
        guard = guard + 1
        if isFloor(c) then break end
    end
    if #bags == 0 or c == nil then return nil end
    local chr = nil
    pcall(function() chr = c:getCharacter() end)
    if chr ~= nil then return nil end                       -- player inventory: vanilla handles it
    local ids = {}
    for _, b in ipairs(bags) do table.insert(ids, tostring(b:getID())) end
    return c, table.concat(ids, "/"), #bags
end

-- both sides: walk root -> chain by exact item IDs (direct children only)
function NT.resolve(root, chain)
    local ids = splitNums(chain, "/")
    if root == nil or #ids == 0 then return nil end
    local bags, c = {}, root
    for _, id in ipairs(ids) do
        local it = c:getItemWithID(id)
        if it == nil or not instanceof(it, "InventoryContainer") then return nil end
        table.insert(bags, it)
        c = it:getInventory()
        if c == nil then return nil end
    end
    return c, bags
end

local function rootPos(root, bags)
    local sq = nil
    if isFloor(root) and bags and bags[1] then                -- floor: the square the outer bag really lies on
        pcall(function() sq = bags[1]:getWorldItem():getSquare() end)
    end
    if sq == nil then pcall(function() sq = root:getSquare() end) end
    if sq == nil then pcall(function() sq = root:getSourceGrid() end) end
    local par = nil
    pcall(function() par = root:getParent() end)
    if sq == nil and par ~= nil then pcall(function() sq = par:getSquare() end) end
    local vehicle = par ~= nil and instanceof(par, "BaseVehicle")
    return sq, par, vehicle
end

-- authority checks for the root container: reach + safehouse. returns ok, reason
function NT.rootAllowed(chr, root, bags)
    if root == nil then return false, "gone" end
    local owner = nil
    pcall(function() owner = root:getCharacter() end)
    if owner ~= nil then return false, "root" end
    local sq, par, vehicle = rootPos(root, bags)
    if sq == nil then return false, "gone" end
    local dx, dy
    if vehicle then
        dx, dy = chr:getX() - par:getX(), chr:getY() - par:getY()
    else
        if math.floor(chr:getZ()) ~= sq:getZ() then return false, "reach" end
        dx, dy = chr:getX() - (sq:getX() + 0.5), chr:getY() - (sq:getY() + 0.5)
    end
    local lim = vehicle and NT.REACH_VEHICLE or NT.REACH
    if dx * dx + dy * dy > lim * lim then return false, "reach" end
    if isServer() then
        local ok, allowed = pcall(function() return SafeHouse.isSafehouseAllowLoot(sq, chr) end)
        if not ok or allowed ~= true then return false, "safehouse" end
    end
    return true
end

-- which container/bag to re-send so every client sees the new source contents
-- addressable ancestors: root itself; on the floor / in a vehicle also the first bag's inventory
function NT.syncTarget(root, bags)
    local deep = isFloor(root)
    if not deep then
        local _, _, vehicle = rootPos(root)
        deep = vehicle
    end
    if deep then
        if #bags >= 2 then return bags[1]:getInventory(), bags[2] end
        return nil, nil                                   -- source bag itself is addressable
    end
    return root, bags[1]
end

function NT.depthAllowed(n)
    if n <= 1 then return true end
    return IKnowIt.opt("NestLootDeep", false) == true
end

function IKINestTakeAction:isValid()
    if IKnowIt.opt("NestLootEnabled", true) ~= true then return false end
    local src = NT.resolve(self.root, self.chain)
    if src == nil then return false end
    for _, id in ipairs(splitNums(self.ids, ",")) do
        if src:getItemWithID(id) ~= nil then return true end
    end
    return false
end

function IKINestTakeAction:start()
    self:setActionAnim("Loot")
    self:setAnimVariable("LootPosition", "Low")
    self.character:reportEvent("EventLootItem")
end

function IKINestTakeAction:perform()
    ISBaseTimedAction.perform(self)
end

function IKINestTakeAction.fail(chr, n)
    if n <= 0 then return end
    if isServer() then
        sendServerCommand(chr, "iknowit", "nestFail", { n = n })
    else
        pcall(function() HaloTextHelper.addBadText(chr, getText("IGUI_IKI_NestFailed")) end)
    end
end

function IKINestTakeAction:complete()
    local chr = self.character
    local ids = splitNums(self.ids, ",")
    if #ids == 0 then return false end
    local src, bags = NT.resolve(self.root, self.chain)
    if src ~= nil and not NT.rootAllowed(chr, self.root, bags) then src = nil end
    if src == nil or not NT.depthAllowed(#bags) or IKnowIt.opt("NestLootEnabled", true) ~= true then
        IKINestTakeAction.fail(chr, #ids)
        return false
    end
    local inv = chr:getInventory()
    local moved, failed = {}, 0
    for _, id in ipairs(ids) do
        local it = src:getItemWithID(id)
        local good = it ~= nil
        if good then
            local eq = false
            pcall(function() eq = it:isEquipped() end)
            good = not eq and src:isRemoveItemAllowed(it) and inv:isItemAllowed(it) and inv:hasRoomFor(chr, it)
        end
        if good then
            src:Remove(it)
            inv:AddItem(it)
            table.insert(moved, it)
        else
            failed = failed + 1
        end
    end
    if #moved > 0 and isServer() then
        for _, it in ipairs(moved) do sendAddItemToContainer(inv, it) end
        local c, bag = NT.syncTarget(self.root, bags)
        if c ~= nil then
            sendReplaceItemInContainer(c, bag, bag)
        else
            for _, it in ipairs(moved) do sendRemoveItemFromContainer(src, it) end
        end
    end
    IKINestTakeAction.fail(chr, failed)
    return #moved > 0
end

function IKINestTakeAction:getDuration()
    if self.character:isTimedActionInstant() then return 1 end
    local n = #splitNums(self.ids, ",")
    return math.min(20 + 15 * n, 400)
end

function IKINestTakeAction:new(character, root, chain, ids)
    local o = ISBaseTimedAction.new(self, character)
    o.character = character
    o.root = root
    o.chain = chain
    o.ids = ids
    o.stopOnWalk = true
    o.stopOnRun = true
    o.maxTime = o:getDuration()
    return o
end
