--[[
    IKnowIt! 0.3.0 - reading speed bonuses (own code; idea inspired by "Reading Tweaks", nothing copied)
    Author: MKev - Optimized by Grok Bot in combination with Cursor

    Additive bonuses, no trait needed (sandbox values in percent):
      reading glasses worn                     ReadBonusGlasses   (10)
      sitting on the floor                     ReadBonusFloor     (25)
      chair / couch / bench / stool            ReadBonusChair     (50)
      armchair (upholstered chair) or a bed    ReadBonusArmchair  (60)
      high comfort (good bed) or toilet        ReadBonusComfort   (70)
    Example: armchair + reading glasses = +70 % speed -> duration / 1.7.

    Furniture is classified by the real B42 tile properties of the object the character sits on
    (getSitOnFurnitureObject): CustomName "Toilet", "Bed", "Couch", "Chair", "Seat", "Bench", "Stool", ...
    and BedType goodBed / averageBed / badBed (upholstered chairs carry averageBed).

    Hook: wraps ISReadABook:getDuration() (B42.21). Vanilla already applies x0.9 for reading glasses
    and x0.9 for isSitting(); those two factors are taken out again so nothing counts twice.
    Fast/Slow Reader, FAST_READ tags and other mods' wrappers stay untouched.
    The file is shared, so client and server compute the same duration.
]]
require "TimedActions/ISReadABook"
require "iknowit/iki_shared"

IKnowIt = IKnowIt or {}
local IKI = IKnowIt

local function opt(name, default)
    local sv = SandboxVars and SandboxVars.IKnowIt
    if sv == nil or sv[name] == nil then return default end
    return sv[name]
end

local function call(obj, fn, ...)
    if obj == nil then return nil end
    local ok, f = pcall(function() return obj[fn] end)
    if not ok or f == nil then return nil end
    local ok2, res = pcall(f, obj, ...)
    if ok2 then return res end
    return nil
end

local function propVal(obj, key)
    local props = call(obj, "getProperties")
    if props == nil then
        local spr = call(obj, "getSprite")
        props = spr and call(spr, "getProperties")
    end
    if props == nil then return nil end
    local v = call(props, "Val", key)
    if v == nil or v == "" then return nil end
    return tostring(v)
end

-- returns category: "comfort", "armchair", "chair", "floor" or nil
function IKI.readSeatCategory(chr)
    local obj = call(chr, "getSitOnFurnitureObject")
    if obj == nil and call(chr, "isSittingOnFurniture") ~= true then
        obj = call(chr, "getBed")
    end
    if obj ~= nil or call(chr, "isSittingOnFurniture") == true then
        local name = string.lower(propVal(obj, "CustomName") or "")
        local bedType = propVal(obj, "BedType")
        if string.find(name, "toilet", 1, true) then return "comfort" end
        if string.find(name, "bed", 1, true) then
            if bedType == "goodBed" then return "comfort" end
            return "armchair"
        end
        if string.find(name, "couch", 1, true) or string.find(name, "sofa", 1, true) then return "chair" end
        if bedType == "goodBed" then return "comfort" end
        if bedType == "averageBed" then return "armchair" end
        return "chair"
    end
    if call(chr, "isSitOnGround") == true then return "floor" end
    return nil
end

local CAT_OPT = { comfort = { "ReadBonusComfort", 70 }, armchair = { "ReadBonusArmchair", 60 },
    chair = { "ReadBonusChair", 50 }, floor = { "ReadBonusFloor", 25 } }

function IKI.hasReadingGlasses(chr)
    local ok, res = pcall(function()
        local eye = chr:getWornItems():getItem(ItemBodyLocation.EYES)
        return eye ~= nil and eye:getType() == "Glasses_Reading"
    end)
    return ok and res == true
end

-- total bonus in percent and the vanilla factor that has to be removed
function IKI.readBonus(chr)
    local pct = 0
    local cat = IKI.readSeatCategory(chr)
    if cat then
        local o = CAT_OPT[cat]
        pct = pct + (tonumber(opt(o[1], o[2])) or o[2])
    end
    local glasses = IKI.hasReadingGlasses(chr)
    if glasses then pct = pct + (tonumber(opt("ReadBonusGlasses", 10)) or 10) end
    local vanilla = 1
    if glasses then vanilla = vanilla * 0.9 end
    if call(chr, "isSitting") == true then vanilla = vanilla * 0.9 end
    return pct, vanilla, cat, glasses
end

function IKI.readAdjust(action, time)
    if not opt("ReadBonusEnabled", true) then return time end
    if type(time) ~= "number" or time <= 1 then return time end
    local chr = action and action.character
    if chr == nil then return time end
    local pct, vanilla = IKI.readBonus(chr)
    if pct <= 0 and vanilla == 1 then return time end
    return (time / vanilla) / (1 + math.max(0, pct) / 100)
end

if ISReadABook and ISReadABook.getDuration and not ISReadABook.iki_readspeed then
    ISReadABook.iki_readspeed = true
    local orig = ISReadABook.getDuration
    ISReadABook.getDuration = function(self, ...)
        local t = orig(self, ...)
        local ok, nt = pcall(IKI.readAdjust, self, t)
        if ok and type(nt) == "number" and nt == nt then return math.max(nt, 1) end
        return t
    end
end
