--[[ IKnowIt! shared helpers. Author: MKev - Optimized by Grok Bot in combination with Cursor ]]
IKnowIt = IKnowIt or {}
local IKI = IKnowIt
IKI.VERSION = "0.4.0"

function IKI.opt(name, default)
    local sv = SandboxVars and SandboxVars.IKnowIt
    if sv == nil or sv[name] == nil then return default end
    return sv[name]
end

function IKI.call(obj, fn, ...)
    if obj == nil then return nil end
    local f = obj[fn]
    if f == nil then return nil end
    local ok, res = pcall(f, obj, ...)
    if ok then return res end
    return nil
end

function IKI.isAuthority()
    return not isClient()
end

function IKI.worldHours()
    local gt = getGameTime()
    return gt and gt:getWorldAgeHours() or 0
end

-- ---------------------------------------------------------------- study ----
function IKI.skillBookPerk(item)
    local skill = IKI.call(item, "getSkillTrained")
    if skill == nil or skill == "" then return nil end
    if SkillBook and SkillBook[skill] and SkillBook[skill].perk then return SkillBook[skill].perk end
    return nil
end

function IKI.studyCount(player, fullType)
    local md = player:getModData()
    local t = md.iki_study
    if t == nil then return 0 end
    return tonumber(t[fullType]) or 0
end

-- 0.3.2 study fix: "has this character fully read this book type?"
-- B42 MP: the dedicated server only learns read pages from the emulated "ReadAPage" anim events
-- (pagesRead = floor(pages * progress) with progress < 1.0 at the last event), and vanilla
-- ISReadABook:complete() only sets the ITEM to all pages and syncs it to the client. So the client map
-- says 220/220 while the server map stays at 219/220 (or a few pages less with server tick drift).
-- Client and SP keep the exact vanilla rule; the authority in MP accepts the highest of the character
-- map and the item counter, with a small slack (5 %, at least 1 page) for the anim-event rounding.
IKI.READ_SLACK = 0.05
function IKI.pagesRead(player, item)
    local fullType = IKI.call(item, "getFullType")
    local a = fullType and tonumber(IKI.call(player, "getAlreadyReadPages", fullType)) or 0
    local b = tonumber(IKI.call(item, "getAlreadyReadPages")) or 0
    return math.max(a, b), a, b
end

function IKI.isFullyRead(player, item, pages)
    pages = pages or IKI.call(item, "getNumberOfPages") or -1
    if pages <= 0 then return true end
    local fullType = IKI.call(item, "getFullType")
    local own = fullType and tonumber(IKI.call(player, "getAlreadyReadPages", fullType)) or 0
    if not isServer() then return own >= pages end
    local read = IKI.pagesRead(player, item)
    local slack = math.max(1, math.ceil(pages * IKI.READ_SLACK))
    return read >= pages - slack
end

-- returns state, xp   state: "ok" | "notread" | "level" | "maxed" | "done" | "disabled" | nil (not a skill book)
-- Rule 0.2.1 (MKev, final 31.10.2026):
--   * only after the book was fully read; only while the book is readable (vanilla range: LvlSkillTrained-1 .. MaxLevelTrained-1)
--   * every book type (FullType) can be studied ONCE per character, ever ("done" afterwards); the book is consumed
--   * FIXED XP per volume, independent of the current level: StudyPercent (default 50) % of the XP step at the
--     book's entry level (LvlSkillTrained-1). Vol.1 (entry level 0) = full step 75.
--     -> Vol1 75, Vol2 150, Vol3 750, Vol4 2250, Vol5 3750
--   * safeguards: never more than +1 level, never beyond the book's max level; overflow is kept as progress
function IKI.studyInfo(player, item, countOverride)
    local perk = IKI.skillBookPerk(item)
    if perk == nil then return nil, 0 end
    if not IKI.opt("StudyEnabled", true) then return "disabled", 0 end
    local pages = IKI.call(item, "getNumberOfPages") or -1
    local fullType = item:getFullType()
    if pages > 0 and not IKI.isFullyRead(player, item, pages) then return "notread", 0 end
    local n = countOverride or IKI.studyCount(player, fullType)
    if n >= 1 then return "done", 0 end
    local level = player:getPerkLevel(perk)
    local lvlMin = IKI.call(item, "getLvlSkillTrained") or 1
    local lvlMax = IKI.call(item, "getMaxLevelTrained") or lvlMin
    if level >= 10 or level >= lvlMax then return "maxed", 0 end
    if lvlMin > level + 1 then return "level", 0 end
    local xpNow = player:getXp():getXP(perk)
    local entry = math.max(0, math.min(lvlMin - 1, 9))      -- book's entry level
    local step = perk:getXpForLevel(entry + 1)               -- XP step at the entry level
    local gain
    if entry == 0 then
        gain = step                                         -- Vol.1: full 75 XP
    else
        local pct = math.min(math.max(IKI.opt("StudyPercent", 50) or 50, 1), 50) / 100
        gain = step * pct
    end
    -- cap: at most +1 level, never beyond the book's max level; overflow inside that level is kept
    local capLevel = math.min(level + 1, lvlMax, 10)
    local capTotal
    if capLevel >= 10 then
        capTotal = perk:getTotalXpForLevel(10)
    else
        capTotal = perk:getTotalXpForLevel(capLevel + 1) - 1
    end
    local cap = capTotal - xpNow
    if gain > cap then gain = cap end
    if gain < 1 then return "maxed", 0 end
    return "ok", math.floor(gain * 10 + 0.5) / 10
end

-- ----------------------------------------------------- foreign XP documents ----
-- 0.4.0: documents of other mods that grant a one-time flat XP when read (data in iki_compat_docs.lua).
-- Display only: the owning mod grants the XP; these items are NOT skill books (no Nachschlagen, no study XP).
require "iknowit/iki_compat_docs"
IKI.docActive = {}
local function modActive(id)
    if IKI.docActive[id] ~= nil then return IKI.docActive[id] end
    local ok, r = pcall(function()
        local list = getActivatedMods()
        return list:contains(id) or list:contains("\\" .. id)
    end)
    IKI.docActive[id] = (ok and r == true)
    return IKI.docActive[id]
end
IKI.modActive = modActive

-- returns perkId, readKeys, modId  or nil
function IKI.docXpOf(item)
    local fullType = IKI.call(item, "getFullType")
    if fullType == nil or IKI.COMPAT_DOCS == nil then return nil end
    local module, typ = string.match(fullType, "^([^%.]+)%.(.+)$")
    if typ == nil then return nil end
    for _, d in pairs(IKI.COMPAT_DOCS) do
        local perk = d.perks[typ]
        if perk and module == d.module and modActive(d.mod) then return perk, d.readKeys, d.mod, typ end
    end
    return nil
end

function IKI.docXpRead(player, item)
    local perk, keys, _, typ = IKI.docXpOf(item)
    if perk == nil then return false end
    local md = player:getModData()
    for _, k in ipairs(keys) do if md[k .. typ] then return true end end
    return false
end
