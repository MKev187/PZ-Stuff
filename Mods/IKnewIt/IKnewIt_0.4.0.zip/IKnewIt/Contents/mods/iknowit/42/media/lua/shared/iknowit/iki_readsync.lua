--[[
    IKnowIt! 0.3.2 - server read-page sync (fix for "Nachschlagen" in MP)
    Author: MKev - Optimized by Grok Bot in combination with Cursor

    B42.21 MP: the dedicated server learns read pages only from the emulated "ReadAPage" events
    (pagesRead = floor(pages * progress), progress < 1.0 at the last event). Vanilla ISReadABook:complete()
    then sets the ITEM to all pages and syncs it to the client, but never the server's per-character map.
    Result: client 220/220 (menu shows "Nachschlagen"), server 219/220 (complete() refused, no XP).
    Hook (method hook only, ISReadABook:new is NOT touched - NetTimedAction safety): after a finished
    read on the server the character map is set to all pages as well.
]]
require "TimedActions/ISReadABook"
require "iknowit/iki_shared"

IKnowIt = IKnowIt or {}
local IKI = IKnowIt

function IKI.syncReadPages(action)
    if action == nil or action.forceStopped then return false end
    local item, chr = action.item, action.character
    if item == nil or chr == nil then return false end
    local pages = tonumber(IKI.call(item, "getNumberOfPages")) or -1
    if pages <= 0 then return false end
    local itemPages = tonumber(IKI.call(item, "getAlreadyReadPages")) or 0
    if itemPages < pages then return false end
    local fullType = item:getFullType()
    local own = tonumber(chr:getAlreadyReadPages(fullType)) or 0
    if own >= pages then return false end
    chr:setAlreadyReadPages(fullType, pages)
    return true
end

if ISReadABook and ISReadABook.complete and not ISReadABook.iki_readsync then
    ISReadABook.iki_readsync = true
    local origComplete = ISReadABook.complete
    ISReadABook.complete = function(self)
        local r = origComplete(self)
        if isServer() then
            local ok, err = pcall(IKI.syncReadPages, self)
            if not ok then print("[IKnowIt] read sync error: " .. tostring(err)) end
        end
        return r
    end
end
