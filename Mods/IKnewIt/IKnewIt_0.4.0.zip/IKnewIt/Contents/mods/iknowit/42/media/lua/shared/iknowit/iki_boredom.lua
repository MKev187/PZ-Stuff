--[[
    IKnowIt! 0.3.2: reading skill books (and "Nachschlagen", also while walking) reduces boredom.
    Author: MKev - Optimized by Grok Bot in combination with Cursor

    Vanilla B42.21: skill books have no BoredomChange (novels/comics/magazines do, applied once when
    finished via BodyDamage.JustReadSomething); ISReadABook only guards unhappiness for non-skill literature.
    TV/radio: each broadcast line tagged BOR-1 removes 5 boredom (ISRadioInteractions, scale 0-100).
    Here: a steady, modest reduction per in-game hour while a skill book is read. Authority side only
    (SP or dedicated server); the server sends the boredom stat to the owning client.
    0.3.2 study fix: in MP the server ticks from the emulated anim events (ReadAPage for vanilla reading,
    IKI_StudyTick for Nachschlagen), because NetTimedAction never calls update() on the server.
]]
require "iknowit/iki_shared"
require "TimedActions/ISReadABook"

local IKI = IKnowIt

local function syncBoredom(chr)
    if not isServer() or syncPlayerStats == nil or SyncPlayerStatsPacket == nil then return end
    pcall(function()
        syncPlayerStats(chr, SyncPlayerStatsPacket.getBitMaskForStat(CharacterStat.BOREDOM))
    end)
end

-- returns the boredom actually removed this tick (for tests), never errors
function IKI.skillBookBoredomTick(action)
    if action == nil or isClient() then return 0 end
    if not IKI.opt("SkillBookBoredom", true) then return 0 end
    local chr, item = action.character, action.item
    if chr == nil or item == nil or IKI.skillBookPerk(item) == nil then return 0 end
    local now = IKI.worldHours()
    local last = action.iki_bt
    action.iki_bt = now
    if last == nil then return 0 end
    local dt = now - last
    if dt <= 0 or dt > 1 then return 0 end
    local rate = tonumber(IKI.opt("SkillBookBoredomPerHour", 10)) or 10
    if rate <= 0 then return 0 end
    local removed = 0
    local ok = pcall(function()
        local stats = chr:getStats()
        local cur = stats:get(CharacterStat.BOREDOM) or 0
        if cur <= 0 then return end
        local new = math.max(0, cur - rate * dt)
        stats:set(CharacterStat.BOREDOM, new)
        removed = cur - new
    end)
    if not ok then return 0 end
    action.iki_bsync = (action.iki_bsync or 0) + removed
    if action.iki_bsync >= 1 then
        action.iki_bsync = 0
        syncBoredom(chr)
    end
    return removed
end

function IKI.skillBookBoredomFlush(action)
    if action and (action.iki_bsync or 0) > 0 and not isClient() then
        action.iki_bsync = 0
        syncBoredom(action.character)
    end
end

if ISReadABook and not ISReadABook.iki_boredom_hooked then
    ISReadABook.iki_boredom_hooked = true
    local origUpdate = ISReadABook.update
    ISReadABook.update = function(self)
        local r = origUpdate(self)
        local ok, err = pcall(IKI.skillBookBoredomTick, self)
        if not ok then print("[IKnowIt] boredom tick error: " .. tostring(err)) end
        return r
    end
    -- B42 MP: the dedicated server never runs update(); it emulates "ReadAPage" events instead
    local origAnim = ISReadABook.animEvent
    ISReadABook.animEvent = function(self, event, parameter)
        local r = origAnim and origAnim(self, event, parameter)
        if event == "ReadAPage" and isServer() then
            local ok, err = pcall(IKI.skillBookBoredomTick, self)
            if not ok then print("[IKnowIt] boredom tick error: " .. tostring(err)) end
        end
        return r
    end
    local origPerform = ISReadABook.perform
    ISReadABook.perform = function(self)
        pcall(IKI.skillBookBoredomFlush, self)
        return origPerform(self)
    end
    local origStop = ISReadABook.stop
    ISReadABook.stop = function(self)
        pcall(IKI.skillBookBoredomFlush, self)
        return origStop(self)
    end
end
