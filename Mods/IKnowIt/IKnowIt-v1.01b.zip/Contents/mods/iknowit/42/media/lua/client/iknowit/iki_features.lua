--[[
    I Knew It! 0.4.0 client features: context menu (Nachschlagen),
    tooltip lines, server command receiver. (0.4.0: residue/rinse feature removed, archived outside the mod)
    Author: MKev - Optimized by Grok Bot in combination with Cursor
]]
require "iknowit/iki_shared"
require "ISUI/ISToolTipInv"

local IKI = IKnowIt
local call = IKI.call

IKI.clientStudy = IKI.clientStudy or {}

local function studyCountClient(player, fullType)
    if isClient() then return tonumber(IKI.clientStudy[fullType]) or 0 end
    return IKI.studyCount(player, fullType)
end
IKI.studyCountClient = studyCountClient

-- ------------------------------------------------------ server replies ----
Events.OnServerCommand.Add(function(module, command, args)
    if module ~= "iknowit" then return end
    local player = getPlayer()
    if command == "studyCount" and args then
        IKI.clientStudy[args.t] = args.n
        if player then HaloTextHelper.addGoodText(player, getText("IGUI_IKI_StudyDone", tostring(args.xp or 0))) end
    elseif command == "studyAll" and args and args.counts then
        IKI.clientStudy = {}
        for k, v in pairs(args.counts) do IKI.clientStudy[k] = v end
    elseif command == "studyFail" and player then
        HaloTextHelper.addBadText(player, getText("IGUI_IKI_StudyFailed"))
        if args and args.s == "done" and player then sendClientCommand("iknowit", "getStudy", {}) end
    end
end)

Events.OnGameStart.Add(function()
    if isClient() then sendClientCommand("iknowit", "getStudy", {}) end
end)

-- ---------------------------------------------------------- helpers ----
local function unwrapItems(items)
    local out = {}
    for _, v in ipairs(items) do
        if instanceof(v, "InventoryItem") then
            table.insert(out, v)
        elseif type(v) == "table" and v.items then
            -- stacked entry: first element is the "header" duplicate
            if v.items[1] then table.insert(out, v.items[1]) end
        end
    end
    return out
end

-- 0.3.3: every item of the selection, collapsed stacks expanded (header duplicate items[1] skipped by ID)
local function allSelected(items)
    local out, seen = {}, {}
    local function add(it)
        if it == nil or not instanceof(it, "InventoryItem") then return end
        local id = it:getID()
        if seen[id] then return end
        seen[id] = true
        table.insert(out, it)
    end
    for _, v in ipairs(items) do
        if instanceof(v, "InventoryItem") then
            add(v)
        elseif type(v) == "table" and v.items then
            for _, it in ipairs(v.items) do add(it) end
        end
    end
    return out
end
IKI.allSelected = allSelected

-- ------------------------------------------------------ context menu ----
local function onStudy(player, item)
    if luautils and luautils.haveToBeTransfered and luautils.haveToBeTransfered(player, item) then return end
    ISTimedActionQueue.add(IKIStudyAction:new(player, item))
end

-- insert right after the (last) vanilla "Read" option; CleanUI keeps the same option name.
-- Fallback: as high as possible (top) if no Read option exists or the API is missing.
function IKI.addAfterRead(context, name, target, fn, p1)
    if context == nil then return nil end
    local readName = getText("ContextMenu_Read")
    local found = false
    if context.options then
        for _, v in ipairs(context.options) do if v and v.name == readName then found = true end end
    end
    local opt
    if found and context.insertOptionAfter then
        opt = context:insertOptionAfter(readName, name, target, fn, p1)
    elseif context.addOptionOnTop then
        opt = context:addOptionOnTop(name, target, fn, p1)
    else
        opt = context:addOption(name, target, fn, p1)
    end
    if opt then opt.iconTexture = nil; opt.color = nil end
    return opt
end

-- 0.3.2: why "Nachschlagen" is greyed out (instead of an action that runs without effect)
function IKI.studyReason(player, item, state)
    if state == "done" then return getText("Tooltip_IKI_StudyDone") end
    local lvlMin = IKI.call(item, "getLvlSkillTrained") or 1
    local lvlMax = IKI.call(item, "getMaxLevelTrained") or lvlMin
    if state == "level" then return getText("Tooltip_IKI_StudyLevelLow", tostring(math.max(0, lvlMin - 1))) end
    if state == "notread" then
        local pages = IKI.call(item, "getNumberOfPages") or 0
        local read = tonumber(IKI.call(player, "getAlreadyReadPages", item:getFullType())) or 0
        return getText("Tooltip_IKI_StudyNotRead", tostring(math.min(read, pages)), tostring(pages))
    end
    return getText("Tooltip_IKI_StudyMaxed", tostring(lvlMax))
end

local function onFillMenu(playerNum, context, items)
    local player = getSpecificPlayer(playerNum)
    if player == nil then return end
    local list = unwrapItems(items)
    local item = list[1]
    if #list == 1 then
        -- Nachschlagen (internal: study), directly below vanilla "Lesen"/"Read"
        if IKI.studyOn() and IKI.skillBookPerk(item) and item:getContainer() == player:getInventory() then
            local state, xp = IKI.studyInfo(player, item, studyCountClient(player, item:getFullType()))
            if state == "ok" or state == "maxed" or state == "done" or state == "level" or state == "notread" then
                local opt = IKI.addAfterRead(context, getText("ContextMenu_IKI_Study"),
                    state == "ok" and player or nil, state == "ok" and onStudy or nil, item)
                if opt then
                    local tip = ISInventoryPaneContextMenu.addToolTip()
                    if state == "ok" then
                        tip.description = getText("Tooltip_IKI_Study", tostring(xp))
                    else
                        opt.notAvailable = true
                        tip.description = IKI.studyReason(player, item, state)
                    end
                    opt.toolTip = tip
                end
            end
        end
    end

end
Events.OnFillInventoryObjectContextMenu.Add(onFillMenu)

-- -------------------------------------------------------- tooltip lines ----
-- 0.3.0: legend of the icons shown on this item, with their current meaning
local function legendLines(item, player, lines)
    if IKI.analyse == nil or not IKI.opt("TooltipLegend", true) then return end
    local ok, info = pcall(IKI.analyse, item, player)
    if not ok or not info then return end
    local C = { 0.80, 0.88, 1.0 }
    local pname = IKI.perkName and IKI.perkName(info.perk)
    local typ = nil
    if info.skillBook then
        typ = getText("Tooltip_IKI_TypeSkillBook", pname or "?", tostring(info.lvlMin or "?"), tostring(info.lvlMax or "?"))
    elseif info.docXp then
        typ = getText("Tooltip_IKI_TypeDocXP", pname or tostring(info.docPerkId))
    elseif info.mediaSkill then
        typ = getText("Tooltip_IKI_TypeMediaSkill", pname or getText("IGUI_IKI_PrefixSkill"))
    elseif info.teach then
        typ = getText(((info.nRecipes or 0) > 1) and "Tooltip_IKI_TypeRecipes" or "Tooltip_IKI_TypeRecipe")
    end
    if typ then table.insert(lines, { typ, 1.0, 0.85, 0.45 }) end
    if info.hasRead and IKI.opt("ShowTrafficLight", true) then
        local b = IKI.ballColor(info)
        local t = (b == "iki_ball_green" and "Tooltip_IKI_BallGreen") or (b == "iki_ball_red" and "Tooltip_IKI_BallRed") or "Tooltip_IKI_BallOrange"
        table.insert(lines, { getText(t), C[1], C[2], C[3], icon = b })
    end
    if info.skillBook and IKI.studyOn() and IKI.opt("ShowStudyMark", true) then
        local n = studyCountClient(player, info.fullType) or 0
        table.insert(lines, { getText(n >= 1 and "Tooltip_IKI_MarkStudied" or "Tooltip_IKI_MarkNotStudied"), C[1], C[2], C[3],
            icon = n >= 1 and "iki_exclaim" or "iki_question" })
    end
    if IKI.opt("ShowXPIcon", true) and IKI.xpIcon then
        info.item = item
        local xn = IKI.xpIcon(info, player)
        if xn then
            local tk = (xn == "iki_xpdrop" and "Tooltip_IKI_XPDrop") or (info.docXp and "Tooltip_IKI_DocXP") or "Tooltip_IKI_XPBoost"
            table.insert(lines, { getText(tk), C[1], C[2], C[3], icon = xn })
        end
    end
    if info.teach and IKI.opt("ShowTeachIcon", true) then
        table.insert(lines, { getText(info.mediaSkill and "Tooltip_IKI_BulbSkill" or "Tooltip_IKI_BulbRecipe"), C[1], C[2], C[3], icon = "iki_bulb" })
    end
end

local function extraLines(item, player)
    local lines = {}
    legendLines(item, player, lines)
    if IKI.studyOn() and IKI.skillBookPerk(item) then
        local state, xp = IKI.studyInfo(player, item, studyCountClient(player, item:getFullType()))
        if state == "ok" then
            table.insert(lines, { getText("Tooltip_IKI_StudyLine", tostring(xp)), 0.55, 0.9, 1.0 })
        elseif state == "done" then
            table.insert(lines, { getText("Tooltip_IKI_StudyLineDone"), 0.7, 0.7, 0.7 })
        elseif state == "maxed" then
            table.insert(lines, { getText("Tooltip_IKI_StudyLineMaxed"), 0.7, 0.7, 0.7 })
        elseif state == "level" then
            table.insert(lines, { getText("Tooltip_IKI_StudyLineLevelLow"), 0.7, 0.7, 0.7 })
        end
    end
    return lines
end

local function wrapTooltip()
  if ISToolTipInv.iki_wrapped then return end
  ISToolTipInv.iki_wrapped = true
  local origTipRender = ISToolTipInv.render
  ISToolTipInv.render = function(self, ...)
    origTipRender(self, ...)
    if self.item == nil then return end
    local player = getSpecificPlayer(self.playerNum or 0) or getPlayer()
    if player == nil then return end
    local ok, lines = pcall(extraLines, self.item, player)
    if not ok or lines == nil or #lines == 0 then return end
    local font = UIFont.Small
    local lh = getTextManager():getFontHeight(font)
    local w = self.width
    local isz = math.max(10, lh - 2)
    for _, l in ipairs(lines) do w = math.max(w, getTextManager():MeasureStringX(font, l[1]) + 22 + (l.icon and isz + 4 or 0)) end
    local h = #lines * lh + 6
    local y = self.height
    self:drawRect(0, y, w, h, self.backgroundColor.a, self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b)
    self:drawRectBorder(0, y, w, h, self.borderColor.a, self.borderColor.r, self.borderColor.g, self.borderColor.b)
    for i, l in ipairs(lines) do
        local tx = 11
        if l.icon then
            local t = getTexture("media/textures/iknowit/" .. l.icon .. ".png")
            if t then self:drawTextureScaled(t, 9, y + 3 + (i - 1) * lh + (lh - isz) / 2, isz, isz, 1, 1, 1, 1) end
            tx = 9 + isz + 4
        end
        self:drawText(l[1], tx, y + 3 + (i - 1) * lh, l[2], l[3], l[4], 1, font)
    end
end
end
-- wrapped at game start so UI replacements (e.g. CleanUI) that load later are wrapped too
Events.OnGameStart.Add(wrapTooltip)
