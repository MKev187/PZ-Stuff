# Changelog - MKevServerBootPatch


## 1.1.1 (2026-11-10)
- F1-F3 are bundled again as fixed parts of the mod (`42/media/scripts/recipes/recipes_fletching.txt`,
  `42/media/scripts/recipes/recipes_MCR_1Handed.txt`, `42/media/scripts/sounds/LabSounds.txt`). The installer no longer
  has to build them, so the mod works on a Linux (or any) dedicated server by copying the folder. Reason: on a Linux
  server the Windows installer never ran, the mod only had placeholders and all F1-F3 boot messages stayed.
- Built from the current Workshop files (checked 2026-11-10, unchanged since 1.1.0): Archery Nexus [Fixed] 3731579266
  `common`, Mad Crafter 3418701509 `42.15`, Zombie Virus Vaccine 3615135168 `42.20`. Same transformation and the same
  SHA256 results as the installer build of 1.1.0 / the 1.0.2 overrides (byte-identical).
- Self-healing (same logic in ModPatchInstaller 1.2, `tools/check_upstream.ps1 -Fix` and `tools/check_upstream.sh --fix`,
  core `tools/bootfix.ps1`): per fix the file the game loads is found (highest `42.x` folder, `PZ_GAMEBUILD` cap, else
  `common`, case-insensitive). Original unchanged -> KEEP bundled file; changed with the error -> REBUILT by token edit
  (BOM/CRLF kept, checked: error tokens gone, only intended lines, braces balanced); error gone -> FIXED_UPSTREAM, override
  removed; file no longer loaded -> NOT_LOADED, override removed; mod missing -> bundled file stays; check failed -> FAIL,
  previous file stays, warning only. `MANIFEST.sha256` is rewritten after a change.
- Both tools are optional (no setup step for server admins: folder into `mods`, add to `Mods=`, done) and a dry run without `-Fix` / `--fix`
  (exit 2 = changes found, 3 = FAIL). `check_upstream.sh` added (needs only sh, awk, sha256sum).
- mod.info: versionMin=42.21, no versionMax.

## 1.1.0 (2026-11-06)
- F1-F3 no longer shipped as copies of third-party files. ModPatchInstaller 0.2.0 builds them from the installed
  Workshop originals (SHA256 of original and result checked, same bytes as 1.0.2 overrides).
- F4 removed: Sentry Turret Upgrade (WS 3633082678, id SentryTurret042) is not in the current pack (06.11.2026 list:
  381 mods / 328 WorkshopItems). loadModAfter without SentryTurret042. AUDIT.md removed from the release copy.
- tools/check_upstream.ps1: no private paths, Sentry checks removed, PZ_WORKSHOP override.

## 1.0.2 (2026-10-30, staged, not installed)
- F6 placeholders for ALL folders the 42.21 AdvancedAnimator scans per mod. Checked in the 42.21 server jar
  (`AdvancedAnimator.collectModFiles -> loadModMedia(commonDir) + loadModMedia(versionDir)`, each scans
  `media/AnimSets` and `media/actiongroups` with `Files.walkFileTree`; a missing folder ends in `visitFileFailed` ->
  NoSuchFileException in the log, boot continues). New: `42/media/AnimSets/`, `common/media/AnimSets/`,
  `common/media/actiongroups/` (each with `readme_placeholder.txt`); `42/media/actiongroups/` from 1.0.1 stays.
  Only `.xml` files are read and checksummed there (`endsWith(".xml")`), so the `.txt` is ignored. `anims_X` is not
  scanned by AdvancedAnimator and gets no placeholder.
- mod.info: modversion 1.0.2, name v1.0.2, description updated.

## 1.0.1 (2026-10-30)
- F5 empty `42/media/actiongroups/` folder with `readme_placeholder.txt`: AdvancedAnimator scans `media/actiongroups` of every mod at boot and
  logged a NoSuchFileException for this mod because the folder was missing. No game data inside.
- mod.info: modversion 1.0.1, name v1.0.1, description extended.

## 1.0 (2026-10-25)
- F1 Archery Nexus [Fixed]: recipe skill Carpentry -> Woodwork (recipes_fletching.txt override).
- F2 Mad Crafter: recipe skill Electrical -> Electricity in 2 recipes (recipes_MCR_1Handed.txt override, 42.15).
- F3 Zombie Virus Vaccine: LabSounds.txt `//` comment -> `/* */`, restores sound Injection_A (42.20).
- F4 Sentry Turret Upgrade: require path shim for ST_MP_TurretUtil (server only, guarded by mod active check).
- tools/check_upstream.ps1: read-only drift check for the overridden upstream files.
