# MKevServerBootPatch 1.1.1 (ID `mkevserverbootpatch`)

Autor: MKev. Kleiner lokaler Patch für das MKev-B42-Serverpaket (Spiel 42.21+, geprüftes Log 42.22). Behebt Boot-Log-Fehler anderer Mods.
Getrennt von `mkev_modpatcher`. Ganz ans ENDE von `Mods=` setzen, nach `mkev_modpatcher`.
Server und alle Clients brauchen dieselbe Version (Script-Checksummen).

| # | Mod (WS) | Fix | Datei in diesem Mod |
|---|---|---|---|
| F1 | Archery Nexus [Fixed] (3731579266) | Rezept-Skill `Carpentry:3` -> `Woodwork:3` | `42/media/scripts/recipes/recipes_fletching.txt` |
| F2 | Mad Crafter (3418701509, 42.15) | `Electrical:` -> `Electricity:` (6x, 2 Rezepte) | `42/media/scripts/recipes/recipes_MCR_1Handed.txt` |
| F3 | Zombie Virus Vaccine (3615135168, 42.20) | `//`-Kommentar -> `/* */`, Sound `Injection_A` wird wieder registriert | `42/media/scripts/sounds/LabSounds.txt` |
| F5/F6 | dieser Mod | leere Platzhalter `media/AnimSets` + `media/actiongroups` (common + 42) | Platzhalter |

Ab 1.1.1 sind F1-F3 fester Bestandteil des Mods. Ein Installer-Schritt ist nicht mehr nötig: den Ordner
`mkevserverbootpatch` in den `mods`-Ordner des Servers (Windows oder Linux) und jedes Clients kopieren. Die Dateien
überschreiben die Originale über den Dateinamen (gleicher relativer Pfad `media/scripts/...`, geladen nach den Original-Mods).
Workshop-Dateien werden nie verändert. SHA256-Werte von Original und Ergebnis stehen in `README.md`.

## Selbstheilung, wenn die Original-Mods updaten

Die mitgelieferten Dateien sind der Standard. Der ModPatchInstaller 1.2 (bei jeder Installation), `tools/check_upstream.ps1 -Fix`
(Windows) und `sh tools/check_upstream.sh --fix` (Linux) arbeiten mit derselben Logik und halten die Fixes ohne neue
BootPatch-Version aktuell. Pro Fix suchen sie die Datei, die das Spiel wirklich lädt: den höchsten `42.x`-Versionsordner
der Mod (begrenzt durch `PZ_GAMEBUILD`, z. B. `42.22`), sonst `common`. Ordner- und Dateinamen ohne Groß-/Kleinschreibung.

| Fall | Status | Was passiert |
|---|---|---|
| Original unverändert (bekannter SHA256) | `KEEP` | mitgelieferte Datei bleibt |
| Original geändert, Fehler noch drin | `REBUILT` | Fix wird aus dem neuen Original neu geschrieben: nur die Token-Änderung (F1 `Carpentry:` -> `Woodwork:`, F2 `Electrical:` -> `Electricity:` in SkillRequired/AutoLearnAll/AutoLearnAny/xpAward-Zeilen, F3 `//`-Zeilen auf oberster Ebene -> `/* */`). BOM und CRLF/LF bleiben. Geprüft: Fehler-Tokens weg, nur die gewollten Zeilen geändert, Klammern ausgeglichen. Dann in diesen Mod geschrieben. |
| Original geändert, Fehler weg | `FIXED_UPSTREAM` | der Autor hat es behoben: unser Override wird entfernt, das Original gilt |
| Mod gefunden, lädt die Datei aber nicht mehr | `NOT_LOADED` | unser Override wird entfernt |
| Mod nicht in den Workshop-Ordnern (z. B. anderer PC) | `MISSING` | mitgelieferte Datei bleibt, nur Hinweis |
| Neu geschriebene Datei besteht eine Prüfung nicht | `FAIL` | Warnung; die vorher installierte Datei bleibt, nichts Kaputtes wird geschrieben, die Installation bricht nie ab |

`MANIFEST.sha256` wird nach jeder Änderung neu geschrieben. Der Installer sichert vor dem Überschreiben (Wiederherstellen mit Modus 3).
Ohne `-Fix` / `--fix` sind beide Tools ein Probelauf und schreiben nichts. Workshop-Ordner: `-Workshop` / Argumente, sonst
`PZ_WORKSHOP`, sonst die Standard-Steam-Pfade. Exit-Code: 0 nichts zu tun bzw. erledigt, 2 Probelauf hat Änderungen gefunden, 3 ein FAIL.
**Server-Admins brauchen keinen Extra-Schritt:** Ordner `mkevserverbootpatch` nach `Zomboid/mods/` legen, in `Mods=` eintragen, fertig.
In kein Startskript muss etwas eingetragen werden. Die mitgelieferten Fixes wirken sofort.
`tools/check_upstream.sh` (Linux) und `tools/check_upstream.ps1` (Windows) sind optionale Werkzeuge für Admins, die die Fixes
nach einem Mod-Update selbst prüfen oder auffrischen wollen; einrichten muss sie niemand. Ändert ein Admin damit (`--fix`) einen Fix,
brauchen die Clients dieselben `mkevserverbootpatch`-Dateien (Script-Checksummen): Installer auf jedem Client oder Ordner kopieren.
