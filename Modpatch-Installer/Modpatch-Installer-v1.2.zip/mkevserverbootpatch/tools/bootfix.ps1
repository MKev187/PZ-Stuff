# bootfix.ps1 - MKevServerBootPatch 1.1.1 self-healing core (shared by ModPatchInstaller 1.2 and tools/check_upstream.ps1).
# Author: MKev. Windows PowerShell 5.1 or PowerShell 7. ASCII only. Dot-source it, then call Get-BfDecision / Set-BfFixes.
# Workshop folders are ONLY read. Files are written only into a mkevserverbootpatch folder (or a staging copy of it).
#
# Per fix: find the file the game really loads (highest 42.x version folder of the mod, else common; names compared
# case-insensitively; PZ_GAMEBUILD=42.22 caps the version folder), then:
#   KEEP           original unchanged (known SHA256)           -> bundled file stays
#   REBUILT        original changed and still has the error     -> fix rebuilt from it (token edit, BOM/CRLF kept, checked)
#   FIXED_UPSTREAM original changed and the error is gone       -> our override is removed
#   NOT_LOADED     mod found, but it no longer loads this file   -> our override is removed
#   MISSING        mod not found in any Workshop folder          -> bundled file stays
#   FAIL           rebuilt file did not pass the checks          -> previous file stays, nothing broken is written

$script:BootFixDefs = @(
    @{ Id = 'F1'; Label = 'Archery Nexus [Fixed]'; Ws = '3731579266'; Mod = 'ArcheryNexusFixed'
       Sub = 'media/scripts/recipes/recipes_fletching.txt'; Dst = '42/media/scripts/recipes/recipes_fletching.txt'
       Kind = 'skill'; From = 'Carpentry'; To = 'Woodwork'
       SrcSha = '68B87D921EAEB41D2799919BDB75446FB9EBCFAD98376174A7D89FAEF0096678' },
    @{ Id = 'F2'; Label = 'Mad Crafter'; Ws = '3418701509'; Mod = 'MadCrafter'
       Sub = 'media/scripts/recipes/recipes_MCR_1Handed.txt'; Dst = '42/media/scripts/recipes/recipes_MCR_1Handed.txt'
       Kind = 'skill'; From = 'Electrical'; To = 'Electricity'
       SrcSha = '7B4591967E8FC50B337E6C210D2BC0C28B9CC5ECBC565CE41DE2567FD437CFEF' },
    @{ Id = 'F3'; Label = 'Zombie Virus Vaccine'; Ws = '3615135168'; Mod = 'ZVirusVaccine42BETA'
       Sub = 'media/scripts/sounds/LabSounds.txt'; Dst = '42/media/scripts/sounds/LabSounds.txt'
       Kind = 'comment'; From = ''; To = ''
       SrcSha = '85F28B209C94105F597900691C92E8E52D277871175E9B36241C974309F18FCD' }
)
# Lines that hold perk ids in a B42 craftRecipe. Only there the perk token is replaced.
$script:BfSkillKeys = '^[ \t]*(SkillRequired|AutoLearnAll|AutoLearnAny|xpAward)[ \t]*='

function Get-BfSha([byte[]]$b) {
    $h = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($h.ComputeHash($b))).Replace('-', '') } finally { $h.Dispose() }
}

# case-insensitive child of a folder (file or folder)
function Get-BfChild([string]$dir, [string]$name, [bool]$wantDir) {
    if (-not $dir -or -not (Test-Path -LiteralPath $dir -PathType Container)) { return $null }
    $hit = @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -ieq $name -and ([bool]$_.PSIsContainer -eq $wantDir) } | Sort-Object Name)
    if ($hit.Count -gt 0) { return $hit[0].FullName }
    return $null
}
function Get-BfPath([string]$base, [string]$rel, [bool]$lastIsDir) {
    $parts = @($rel.Split('/') | Where-Object { $_ -ne '' })
    $p = $base
    for ($i = 0; $i -lt $parts.Count; $i++) {
        $isDir = $true
        if ($i -eq ($parts.Count - 1)) { $isDir = $lastIsDir }
        $p = Get-BfChild $p $parts[$i] $isDir
        if (-not $p) { return $null }
    }
    return $p
}
function ConvertTo-BfVersion([string]$n) {
    $a = @($n.Split('.'))
    while ($a.Count -lt 4) { $a += '0' }
    return New-Object System.Version ([int]$a[0]), ([int]$a[1]), ([int]$a[2]), ([int]$a[3])
}

# Where the game loads this file from. Found = 'file' | 'mod' (mod there, file not loaded) | 'none' (mod not found)
function Find-BfSource($fx, [string[]]$roots) {
    $cap = $null
    if ($env:PZ_GAMEBUILD -and $env:PZ_GAMEBUILD -match '^\d+(\.\d+){0,3}$') { $cap = ConvertTo-BfVersion $env:PZ_GAMEBUILD }
    foreach ($r in @($roots)) {
        if (-not $r) { continue }
        $m = Get-BfPath $r ($fx.Ws + '/mods/' + $fx.Mod) $true
        if (-not $m) { continue }
        $modRel = $fx.Ws + '/mods/' + (Split-Path -Leaf $m)
        $best = $null; $bestV = $null
        foreach ($d in @(Get-ChildItem -LiteralPath $m -Force -ErrorAction SilentlyContinue | Where-Object { $_.PSIsContainer })) {
            if ($d.Name -notmatch '^42(\.\d+){0,3}$') { continue }
            $v = ConvertTo-BfVersion $d.Name
            if ($cap -and $v -gt $cap) { continue }
            if ((-not $bestV) -or $v -gt $bestV) { $best = $d; $bestV = $v }
        }
        if ($best) {
            $p = Get-BfPath $best.FullName $fx.Sub $false
            if ($p) { return @{ Found = 'file'; Path = $p; Rel = ($modRel + '/' + $best.Name + '/' + $fx.Sub) } }
        }
        $c = Get-BfChild $m 'common' $true
        if ($c) {
            $p = Get-BfPath $c $fx.Sub $false
            if ($p) { return @{ Found = 'file'; Path = $p; Rel = ($modRel + '/' + (Split-Path -Leaf $c) + '/' + $fx.Sub) } }
        }
        return @{ Found = 'mod'; Path = $null; Rel = $modRel }
    }
    return @{ Found = 'none'; Path = $null; Rel = '' }
}

function Get-BfBlockState([string]$s, [bool]$in) {
    $i = 0
    while ($i -lt ($s.Length - 1)) {
        $two = $s.Substring($i, 2)
        if ((-not $in) -and $two -eq '/*') { $in = $true; $i += 2; continue }
        if ($in -and $two -eq '*/') { $in = $false; $i += 2; continue }
        $i++
    }
    return $in
}

# Token edit on text (latin-1, 1 byte = 1 char). Returns @{ Text; Edits; Lines; Changed (line indexes) }
function Invoke-BfEdit($fx, [string]$t) {
    $bom = ''
    if ($t.Length -ge 3 -and $t.Substring(0, 3) -eq ([string][char]0xEF + [char]0xBB + [char]0xBF)) { $bom = $t.Substring(0, 3); $t = $t.Substring(3) }
    $lines = $t.Split([char]10)
    $out = New-Object 'System.Collections.Generic.List[string]'
    $changed = New-Object 'System.Collections.Generic.List[int]'
    $inBlock = $false
    $ws = [char[]]@([char]32, [char]9)
    for ($i = 0; $i -lt $lines.Length; $i++) {
        $body = $lines[$i]; $cr = ''
        if ($body.EndsWith([string][char]13)) { $cr = [string][char]13; $body = $body.Substring(0, $body.Length - 1) }
        $new = $body
        if ($fx.Kind -eq 'skill') {
            if ($body -match $script:BfSkillKeys) { $new = [regex]::Replace($body, ('(?<![A-Za-z0-9_])' + $fx.From + ':'), ($fx.To + ':')) }
        } else {
            $mm = [regex]::Match($body, '^([ \t]*)//(.*)$')
            if ((-not $inBlock) -and $mm.Success) {
                $rest = $mm.Groups[2].Value.Trim($ws).Replace('*/', '* /')
                $new = $mm.Groups[1].Value + '/* ' + $rest + ' */'
            } else { $inBlock = Get-BfBlockState $body $inBlock }
        }
        if ($new -cne $body) { $changed.Add($i) }
        $out.Add($new + $cr)
    }
    return @{ Text = ($bom + ($out -join [string][char]10)); Edits = $changed.Count; Lines = $lines.Length; Changed = $changed }
}

function Test-BfBraces([string]$t) {
    $d = 0
    foreach ($ch in $t.ToCharArray()) {
        if ($ch -eq '{') { $d++ } elseif ($ch -eq '}') { $d--; if ($d -lt 0) { return $false } }
    }
    return ($d -eq 0)
}

# Returns @{ Status = 'OK'|'CLEAN'|'FAIL'; Bytes; Why }  (Why: braces | tokens | changes)
function Invoke-BfTransform($fx, [byte[]]$src) {
    $lat = [System.Text.Encoding]::GetEncoding(28591)
    $t = $lat.GetString($src)
    $e = Invoke-BfEdit $fx $t
    if ($e.Edits -eq 0) { return @{ Status = 'CLEAN'; Bytes = $null; Why = '' } }
    if (-not (Test-BfBraces $t)) { return @{ Status = 'FAIL'; Bytes = $null; Why = 'braces' } }
    $o = $e.Text
    $again = Invoke-BfEdit $fx $o
    if ($again.Edits -ne 0) { return @{ Status = 'FAIL'; Bytes = $null; Why = 'tokens' } }
    # only the intended lines changed, nothing else (same line count, same braces, same BOM/line ends)
    $a = $t.Split([char]10); $b = $o.Split([char]10)
    if ($a.Length -ne $b.Length) { return @{ Status = 'FAIL'; Bytes = $null; Why = 'changes' } }
    $diff = 0
    for ($i = 0; $i -lt $a.Length; $i++) {
        if ($a[$i] -cne $b[$i]) {
            $diff++
            if (-not $e.Changed.Contains($i)) { return @{ Status = 'FAIL'; Bytes = $null; Why = 'changes' } }
            if ($a[$i].EndsWith([string][char]13) -ne $b[$i].EndsWith([string][char]13)) { return @{ Status = 'FAIL'; Bytes = $null; Why = 'changes' } }
        }
    }
    if ($diff -ne $e.Edits) { return @{ Status = 'FAIL'; Bytes = $null; Why = 'changes' } }
    if ((-not (Test-BfBraces $o)) -or (($o.Split('{').Length) -ne ($t.Split('{').Length)) -or (($o.Split('}').Length) -ne ($t.Split('}').Length))) { return @{ Status = 'FAIL'; Bytes = $null; Why = 'braces' } }
    return @{ Status = 'OK'; Bytes = $lat.GetBytes($o); Why = '' }
}

# Decision for one fix. Status: KEEP | REBUILT | FIXED_UPSTREAM | NOT_LOADED | MISSING | FAIL
function Get-BfDecision($fx, [string[]]$roots) {
    try {
        $s = Find-BfSource $fx $roots
        if ($s.Found -eq 'none') { return @{ Fx = $fx; Status = 'MISSING'; Src = ''; Why = ''; Bytes = $null } }
        if ($s.Found -eq 'mod')  { return @{ Fx = $fx; Status = 'NOT_LOADED'; Src = $s.Rel; Why = ''; Bytes = $null } }
        $b = [System.IO.File]::ReadAllBytes($s.Path)
        if ((Get-BfSha $b) -eq $fx.SrcSha) { return @{ Fx = $fx; Status = 'KEEP'; Src = $s.Rel; Why = ''; Bytes = $null } }
        $r = Invoke-BfTransform $fx $b
        if ($r.Status -eq 'CLEAN') { return @{ Fx = $fx; Status = 'FIXED_UPSTREAM'; Src = $s.Rel; Why = ''; Bytes = $null } }
        if ($r.Status -eq 'FAIL')  { return @{ Fx = $fx; Status = 'FAIL'; Src = $s.Rel; Why = $r.Why; Bytes = $null } }
        return @{ Fx = $fx; Status = 'REBUILT'; Src = $s.Rel; Why = ''; Bytes = $r.Bytes }
    } catch {
        return @{ Fx = $fx; Status = 'FAIL'; Src = ''; Why = 'read'; Bytes = $null }
    }
}

function Get-BfDecisions([string[]]$roots) {
    $res = @()
    foreach ($fx in $script:BootFixDefs) { $res += ,(Get-BfDecision $fx $roots) }
    return $res
}

# Apply decisions to a mkevserverbootpatch folder ($modRoot). FAIL keeps the file from $prevRoot (installed copy) if
# that folder exists, otherwise the file already in $modRoot. Then MANIFEST.sha256 is brought in line.
function Set-BfFixes([string]$modRoot, $decisions, [string]$prevRoot) {
    foreach ($d in @($decisions)) {
        $dst = Join-Path $modRoot ($d.Fx.Dst.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        switch ($d.Status) {
            'REBUILT' {
                $dir = Split-Path -Parent $dst
                if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
                [System.IO.File]::WriteAllBytes($dst, [byte[]]$d.Bytes)
            }
            { $_ -eq 'FIXED_UPSTREAM' -or $_ -eq 'NOT_LOADED' } {
                if (Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Force }
            }
            'FAIL' {
                if ($prevRoot -and ($prevRoot -ne $modRoot) -and (Test-Path -LiteralPath $prevRoot -PathType Container)) {
                    $prev = Join-Path $prevRoot ($d.Fx.Dst.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
                    if (Test-Path -LiteralPath $prev) {
                        $dir = Split-Path -Parent $dst
                        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
                        [System.IO.File]::WriteAllBytes($dst, [System.IO.File]::ReadAllBytes($prev))
                    } elseif (Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Force }
                }
            }
        }
    }
    Update-BfManifest $modRoot
}

function Update-BfManifest([string]$modRoot) {
    $mf = Join-Path $modRoot 'MANIFEST.sha256'
    if (-not (Test-Path -LiteralPath $mf)) { return }
    $dsts = @($script:BootFixDefs | ForEach-Object { $_.Dst })
    $keep = New-Object 'System.Collections.Generic.List[string]'
    foreach ($l in [System.IO.File]::ReadAllLines($mf)) {
        if ($l -eq '') { continue }
        $m = [regex]::Match($l, '^[0-9a-fA-F]{64}  (.+)$')
        if ($m.Success -and ($dsts -ccontains $m.Groups[1].Value)) { continue }
        $keep.Add($l)
    }
    foreach ($rel in $dsts) {
        $p = Join-Path $modRoot ($rel.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (Test-Path -LiteralPath $p) { $keep.Add((Get-BfSha ([System.IO.File]::ReadAllBytes($p))).ToLower() + '  ' + $rel) }
    }
    $arr = $keep.ToArray()
    $keys = @($arr | ForEach-Object { $_.Substring(66) })
    [Array]::Sort([string[]]$keys, [string[]]$arr, [System.StringComparer]::Ordinal)
    [System.IO.File]::WriteAllText($mf, (($arr -join "`n") + "`n"), (New-Object System.Text.UTF8Encoding($false)))
}
