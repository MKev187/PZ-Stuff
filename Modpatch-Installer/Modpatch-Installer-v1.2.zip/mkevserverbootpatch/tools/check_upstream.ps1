# MKevServerBootPatch v1.1.1 - check / self-heal (Windows; also PowerShell 7 on Linux). Author: MKev.
# Same logic as ModPatchInstaller 1.2 and tools/check_upstream.sh (core: tools/bootfix.ps1).
#
#   powershell -ExecutionPolicy Bypass -File check_upstream.ps1          dry run, shows what would happen, writes NOTHING
#   powershell -ExecutionPolicy Bypass -File check_upstream.ps1 -Fix     writes only into THIS mod folder (above tools\)
# Workshop folders: -Workshop <path[;path]>, else PZ_WORKSHOP, else the default Steam library.
# PZ_GAMEBUILD=42.22 caps the version folder the game would load (default: highest 42.x folder of the mod).
# Exit code: 0 nothing to do / done, 2 dry run found changes to apply, 3 at least one FAIL.
param([switch]$Fix, [string]$Workshop = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
. (Join-Path $PSScriptRoot 'bootfix.ps1')
$modRoot = Split-Path -Parent $PSScriptRoot
if ($modRoot -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { Write-Output 'Safety stop: this mod folder is inside a Workshop folder.'; exit 1 }
$list = $Workshop
if (-not $list) { $list = $env:PZ_WORKSHOP }
if (-not $list) { $list = 'C:\Program Files (x86)\Steam\steamapps\workshop\content\108600' }
$roots = @($list.Split(';') | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Container) })
if ($roots.Count -eq 0) { Write-Output 'Note: no Workshop folder found (use -Workshop or set PZ_WORKSHOP).' }
$pending = $false; $failed = $false; $wrote = $false
foreach ($fx in $script:BootFixDefs) {
    $d = Get-BfDecision $fx $roots
    $dst = Join-Path $modRoot ($fx.Dst.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
    $have = Test-Path -LiteralPath $dst
    $tag = $fx.Id + ' ' + $fx.Label + ': ' + $d.Status + ' - '
    switch ($d.Status) {
        'MISSING' { Write-Output ($tag + 'mod not found in the Workshop folders, bundled fix stays.') }
        { $_ -eq 'NOT_LOADED' -or $_ -eq 'FIXED_UPSTREAM' } {
            $what = 'the mod author fixed it'
            if ($d.Status -eq 'NOT_LOADED') { $what = 'the mod no longer loads this file' }
            if (-not $have) { Write-Output ($tag + $what + ' (' + $d.Src + '), no override present.') }
            elseif ($Fix) { Remove-Item -LiteralPath $dst -Force; $wrote = $true; Write-Output ($tag + $what + ' (' + $d.Src + '), override removed.') }
            else { $pending = $true; Write-Output ($tag + $what + ' (' + $d.Src + '), override would be removed.') }
        }
        'FAIL' { $failed = $true; Write-Output ('WARNING ' + $tag + 'original changed (' + $d.Src + '), but the rebuilt file failed the check (' + $d.Why + '). Current file kept, nothing written. Please report to MKev.') }
        default {
            # KEEP: the bundled file is the transform of the unchanged original; REBUILT: transform of the new original
            $src = Find-BfSource $fx $roots
            $out = (Invoke-BfTransform $fx ([System.IO.File]::ReadAllBytes($src.Path))).Bytes
            $same = $have -and ((Get-BfSha ([System.IO.File]::ReadAllBytes($dst))) -eq (Get-BfSha $out))
            $txt = 'original changed (' + $d.Src + '), '
            if ($d.Status -eq 'KEEP') { $txt = 'original unchanged (' + $d.Src + '), ' }
            if ($same) { if ($d.Status -eq 'KEEP') { Write-Output ($tag + $txt + 'bundled fix fits.') } else { Write-Output ($tag + $txt + 'override already up to date.') } }
            elseif ($Fix) {
                $dir = Split-Path -Parent $dst
                if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
                [System.IO.File]::WriteAllBytes($dst, [byte[]]$out); $wrote = $true
                if ($d.Status -eq 'KEEP') { Write-Output ($tag + $txt + 'bundled fix restored.') } else { Write-Output ($tag + $txt + 'fix rebuilt and written.') }
            } else {
                $pending = $true
                if ($d.Status -eq 'KEEP') { Write-Output ($tag + $txt + 'bundled fix would be restored.') } else { Write-Output ($tag + $txt + 'fix would be rebuilt.') }
            }
        }
    }
}
if ($wrote) { Update-BfManifest $modRoot }
if ($failed) { Write-Output 'RESULT WARN - see WARNING lines'; exit 3 }
if ($pending) { Write-Output 'RESULT CHANGES - run again with -Fix to apply (server stopped, same files on all clients)'; exit 2 }
if ($Fix -and $wrote) { Write-Output 'RESULT FIXED - restart the server; clients need the same mkevserverbootpatch files'; exit 0 }
Write-Output 'RESULT OK - nothing to change'; exit 0
