# MKev's Modpatch Installer v1.33 - README

Autor: MKev.

*English version: [ReadMe_EN.md](ReadMe_EN.md)*

**Inhalt:** `mkev_modpatcher` 1.3.2, `mkevserverbootpatch` 1.1.2, `Linux-Guard` 1.0.0 (optional, Linux-Server), `MKevServer_setup` (Server-Dateien + Preset, Stand MKev-Server 09.11.2026).
**Basis:** Build 42.22.2, Collection 3827894199 "MKev Zomboid Modlist B42.22": 375 Mods / 324 WorkshopItems, Map `Muldraugh, KY`.
I Know It! wird nicht mitgeliefert. Es kommt wie alle Collection-Mods aus dem Steam Workshop (3836594593).

## Benutzung

1. Spiel und Server komplett beenden. Sonst bricht der Installer ab.
2. Zip komplett entpacken und `ModPatchInstaller.bat` doppelklicken.
3. **Frage 1 – Sprache:** Taste `1` für English oder `2` für Deutsch. (Traditionelles Chinesisch ist in diesem Installer nicht enthalten.)
4. **Frage 2 – Installationsoption** wie bisher: `1` Installieren & Einrichten, `2` Installieren & nicht Einrichten (dazu Menüpunkte 3 Wiederherstellen, 4 Beenden, 5 Probelauf).
5. **Frage 3 – Arbeitsspeicher (nur Windows-Spielclient):** erscheint nach Option 1, 2 oder 5. Standard ist **7) Keine Änderung**. `8) Zurück` geht zu Frage 2 zurück, ohne etwas zu schreiben. Fragen mit `J` oder `N` beantworten; `Y` gilt auch als „ja“.


## Die zwei Modi

| Punkt | Was passiert |
|---|---|
| **1** Installieren & Einrichten | **Bestehende Server-Dateien anpassen.** Zeigt erst alle Änderungen, fragt J/N und sichert vorher alles. Logins und Ports bleiben erhalten. |
| **2** Installieren & nicht Einrichten | **Separater Ordner.** Nur die zwei Patches und fertige Vorlagen nach `Zomboid\MKevServer_setup` (Modliste, WorkshopItems, Map, SandboxVars, Preset, Anleitung). Keine Einstellung wird geändert. |
| **3** Backup wiederherstellen | Stellt den Zustand vor einem Lauf wieder her. |
| **4** Beenden | |
| **5** Probelauf | Zeigt nur an, was Punkt 1 ändern würde. Schreibt nichts. |

### Was Punkt 1 genau macht

- Kopiert `mkev_modpatcher` und `mkevserverbootpatch` nach `Zomboid\mods`.
- `Zomboid\Server\servertest.ini`: Es werden NUR die Zeilen `Mods=`, `WorkshopItems=` und `Map=` ersetzt. Passwörter, Ports, Servername und alle anderen Zeilen bleiben unverändert.
- `servertest_SandboxVars.lua` wird durch die Einstellungen des MKev-Servers ersetzt. Die alte Datei liegt im Backup.
- Fügt das Mod-Preset „MKevServer“ in `Zomboid\Lua\pz_modlist_settings.cfg` hinzu. Eigene Presets bleiben.
- Trägt `mkev_modpatcher` in `Zomboid\mods\default.txt` ein.


## Optional: Arbeitsspeicher des Spiel-Clients

Der Installer kann – nur wenn du es in Frage 3 bewusst wählst – die Datei `ProjectZomboid64.json` im **Windows-Spielordner** anpassen (Steam-Bibliothek wird automatisch gesucht, so wie der Installer auch die Workshop-Ordner findet). Geändert werden nur die Werte `-Xms` (Grundzuteilung) und `-Xmx` (oberes Limit / Headroom). Alle anderen Einträge in der Datei bleiben erhalten; vorhandene `-Xms`/`-Xmx` werden ersetzt, keine Duplikate.

**Das gilt nicht für den Server.** Der dedizierte Server hat eine eigene JSON-Datei und wird vom Installer nicht angefasst. Die RAM-Option läuft nur auf einem Windows-Client mit grafischer Oberfläche.

| Auswahl | -Xms | -Xmx | Hinweis im Installer |
|---|---|---|---|
| 1) 8 GB | 8 GB | 8 GB | auf eigenes Risiko, keine optimale Performance garantiert |
| 2) 12 GB | 12 GB | 12 GB | auf eigenes Risiko, keine optimale Performance garantiert |
| 3) 16 GB | 16 GB | 16 GB | auf eigenes Risiko, keine optimale Performance garantiert |
| 4) 8 GB + 12 GB Headroom | 8 GB | 12 GB | **Mindestempfehlung** |
| 5) 8 GB + 16 GB Headroom | 8 GB | 16 GB | auf eigenes Risiko, keine optimale Performance garantiert |
| 6) 12 GB + 16 GB Headroom | 12 GB | 16 GB | **ausdrücklich empfohlen** |
| 7) Keine Änderung | – | – | **Standard.** Die JSON-Datei wird nicht verändert. |
| 8) Zurück | – | – | zurück zu Frage 2, nichts wird geschrieben |

Vor einer Änderung legt der Installer ein Backup der JSON-Datei mit Zeitstempel unter `Zomboid\mkev_patch_backups\` an. Zurückholen geht über Menüpunkt 3 (wie bei den anderen Dateien).

Wenn die gewählte `-Xmx`-Menge größer ist als der sinnvolle Anteil des eingebauten Speichers (Richtwert: nicht mehr als installierter RAM minus 4 GB), erscheint ein Hinweis und du kannst abbrechen und neu wählen.

Steam-Spielupdates können `ProjectZomboid64.json` wieder auf den Standard zurücksetzen. Dann den Installer einfach erneut ausführen und in Frage 3 dieselbe (oder eine andere) Option wählen.

## Dedicated Server

- Die Ordner `mkev_modpatcher` und `mkevserverbootpatch` aus dem Zip in den `Zomboid/mods/`-Ordner deines Servers kopieren (der Ordner mit `Server/` und `Saves/`) und `mkev_modpatcher;mkevserverbootpatch` in die `Mods=`-Zeile der Server-.ini eintragen.
- **Nur Linux-Server, optional:** `Linux-Guard/` behebt Mod-Dateien, die Linux wegen Groß- und Kleinschreibung nicht findet (kleingeschriebene Verknüpfungen, nichts wird umbenannt). Welcher der 3 Fälle zu deinem Host passt: `Linux-Guard/Guide.txt`. Nichts muss bearbeitet werden.

## Hinweise

- **Boot-Patch:** Die 3 Skript-Fixes sind ab BootPatch 1.1.1 fester Bestandteil des Mods, deshalb läuft der Mod auch auf Linux-Servern ohne Installer (Ordner `mkevserverbootpatch` nach `Zomboid/mods/` kopieren). Bei jeder Installation vergleicht der Installer die Fixes mit deinen Workshop-Originalen (nur gelesen): unverändert → mitgelieferte Datei bleibt; nach einem Mod-Update wird der Fix neu geschrieben und geprüft; hat der Autor den Fehler behoben, wird unser Override entfernt. Besteht ein neu geschriebener Fix die Prüfung nicht, bleibt die bisherige Datei und es kommt eine „WARNUNG“; die Installation läuft trotzdem. Details: `mkevserverbootpatch/README_DE.md`.
- **Andere Steam-Bibliothek (für den Abgleich der Boot-Fixes):** Setz die Umgebungsvariable `PZ_WORKSHOP` auf `...\steamapps\workshop\content\108600`.
- **Backups:** liegen unter `Zomboid\mkev_patch_backups\<Datum_Uhrzeit>\` (Menüpunkt 3). Eine geänderte `ProjectZomboid64.json` liegt dort mit dabei und wird beim Wiederherstellen ebenfalls zurückgeholt.
- **Spielordner in einer anderen Steam-Bibliothek (RAM-Option):** Setz `PZ_GAME` auf `...\steamapps\common\ProjectZomboid`.
- **Sprachabfrage überspringen:** Setz `PZ_LANG=en` oder `PZ_LANG=de`, oder starte `ModPatchInstaller_en.ps1` bzw. `ModPatchInstaller_de.ps1` direkt.
- Änderungen (v1.33, v1.32, v1.31, v1.3b, v1.3, v1.2, v1.1b, v1.1 und v1.0) stehen in `CHANGELOG.md`.
