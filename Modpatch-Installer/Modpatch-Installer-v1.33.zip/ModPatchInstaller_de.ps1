# ModPatchInstaller.ps1 - MKev's Modpatch Installer 1.33 for players
# Installs mkev_modpatcher 1.3.2 + mkevserverbootpatch 1.1.2 and (option 1) the MKev server setup. Optional client RAM (question 3).
# I Know It! is not installed by this installer (it comes from the Steam Workshop like every other collection mod).
# Author: MKev..
# Started by ModPatchInstaller.bat. Windows PowerShell 5.1 or newer. ASCII only.
#
# Test switches (environment variables, normally not set):
#   PZ_ZOMBOID          Zomboid folder (default %USERPROFILE%\Zomboid)
#   PZ_WORKSHOP         ';'-list of ...\steamapps\workshop\content\108600 folders (default: found via Steam)
#   PZ_SKIP_PROCCHECK   1 = do not check for a running game/server
#   PZ_CHOICE           menu choice 1..5, or a ';'-list (tests; no menu prompt)
#   PZ_CONFIRM          Y or N (answer for every Y/N question)
#   PZ_RESTORE_PICK     number of the backup to restore (1 = newest)
#   PZ_STAMP            fixed backup time stamp (tests only)
#   PZ_GAME             Client game folder (...\steamapps\common\ProjectZomboid). Default: found via Steam libraries (same way as the Workshop folders).
#   PZ_RAM_CHOICE       RAM menu 1..8, or a ';'-list (tests). 7 = no change, 8 = back to question 2. If PZ_CHOICE is set and this is empty, 7 is chosen automatically.
#   PZ_PHYSICAL_RAM_GB  Installed RAM in GB (tests). Otherwise read from the PC.

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$script:Version   = '1.33'
$script:Src       = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:SetupSrc  = Join-Path $script:Src 'MKevServer_setup'
$script:Zomboid   = if ($env:PZ_ZOMBOID) { $env:PZ_ZOMBOID } else { Join-Path $env:USERPROFILE 'Zomboid' }
$script:Zomboid   = $script:Zomboid.TrimEnd('\','/')
$script:BackupRoot = Join-Path $script:Zomboid 'mkev_patch_backups'
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:DryRun    = $false
$script:Log       = New-Object System.Collections.Generic.List[string]
$script:Bak       = $null
$script:BakDone   = @{}
$script:Changes   = 0

# mod folders in this package: name, required
$script:ModSlots = @(
    @{ Name = 'mkev_modpatcher';     Required = $true; Stage = $false },
    @{ Name = 'mkevserverbootpatch'; Required = $true; Stage = $true  }
)
$script:PresetName = 'MKevServer'
$script:DefaultTxtMod = 'mkev_modpatcher'

# ------------------------------------------------------------------ helpers
function Say([string]$t) { Write-Host $t; $script:Log.Add($t) }
function Rel([string]$p) { if ($p.StartsWith($script:Zomboid)) { return $p.Substring($script:Zomboid.Length).TrimStart('\','/') } return $p }
function P([string]$rel) { return Join-Path $script:Zomboid $rel }

function Ask([string]$q) {
    if ($env:PZ_CONFIRM) { $a = $env:PZ_CONFIRM; Say ("  " + $q + " [J/N]: " + $a + " (automatisch)") }
    else { $a = Read-Host ("  " + $q + " [J/N]") ; $script:Log.Add("  " + $q + " -> " + $a) }
    return ($a -match '^\s*[JjYy]')
}

function Assert-SafePath([string]$p) {
    $full = [System.IO.Path]::GetFullPath($p)
    if ($full -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { throw ("Sicherheitsstopp: Workshop-Ordner wird nie veraendert: " + $full) }
    $root = [System.IO.Path]::GetFullPath($script:Zomboid)
    if (-not $full.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) { throw ("Sicherheitsstopp: Ziel liegt ausserhalb von Zomboid: " + $full) }
}

function Read-Text([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $bom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $text = $script:Utf8NoBom.GetString($bytes)
    if ($bom) { $text = $text.Substring(1) }
    $nl = if ($text.Contains("`r`n")) { "`r`n" } elseif ($text.Contains("`n")) { "`n" } else { "`r`n" }
    $endsNl = $text.EndsWith("`n")
    $lines = @($text -split "`r?`n")
    if ($endsNl) { if ($lines.Count -le 1) { $lines = @() } else { $lines = @($lines[0..($lines.Count - 2)]) } }
    return @{ Lines = $lines; Nl = $nl; Bom = $bom }
}

function Write-TextLines([string]$path, $lines, [string]$nl, [bool]$bom) {
    Assert-SafePath $path
    $dir = Split-Path -Parent $path
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $text = ($lines -join $nl) + $nl
    $enc = if ($bom) { New-Object System.Text.UTF8Encoding($true) } else { $script:Utf8NoBom }
    [System.IO.File]::WriteAllText($path, $text, $enc)
}

function Read-ListFile([string]$name, [string]$key) {
    $f = Join-Path $script:SetupSrc $name
    if (-not (Test-Path -LiteralPath $f)) { throw ("Datei fehlt im Paket: MKevServer_setup\" + $name) }
    foreach ($l in (Read-Text $f).Lines) { if ($l.StartsWith($key + '=')) { return $l.Substring($key.Length + 1) } }
    throw ("Zeile " + $key + "= fehlt in MKevServer_setup\" + $name)
}

function Split-List([string]$v, [string]$sep) { return ,@($v.Split($sep) | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }) }

function Get-DirSig([string]$dir) {
    if (-not (Test-Path -LiteralPath $dir)) { return '' }
    $base = (Get-Item -LiteralPath $dir).FullName.TrimEnd('\','/')
    $items = Get-ChildItem -LiteralPath $dir -Recurse -File -Force | Sort-Object FullName | ForEach-Object {
        $_.FullName.Substring($base.Length).Replace('\','/') + '|' + (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash
    }
    return ($items -join "`n")
}

function Get-ModVersion([string]$dir) {
    foreach ($mi in @((Join-Path $dir '42\mod.info'), (Join-Path $dir 'mod.info'))) {
        if (Test-Path -LiteralPath $mi) {
            foreach ($l in (Read-Text $mi).Lines) { if ($l -match '^modversion=(.*)$') { return $Matches[1].Trim() } }
        }
    }
    return 'unbekannt'
}

# ------------------------------------------------------------------ backup
function New-BackupSession([string]$action) {
    $stamp = if ($env:PZ_STAMP) { $env:PZ_STAMP } else { Get-Date -Format 'yyyy-MM-dd_HHmmss' }
    $name = $stamp + '_' + $action
    $dir = Join-Path $script:BackupRoot $name
    $i = 2
    while (Test-Path -LiteralPath $dir) { $dir = Join-Path $script:BackupRoot ($name + '_' + $i); $i++ }
    $script:Bak = $dir
    $script:BakDone = @{}
}

function Ensure-BackupDir {
    if (-not (Test-Path -LiteralPath $script:Bak)) {
        Assert-SafePath $script:Bak
        New-Item -ItemType Directory -Force -Path (Join-Path $script:Bak 'files') | Out-Null
    }
}

# Back up a file or folder (relative to Zomboid) once per session, before it is changed.
function Backup-Item([string]$rel) {
    if ($script:DryRun) { return }
    if ($script:BakDone.ContainsKey($rel.ToLower())) { return }
    Ensure-BackupDir
    $src = P $rel
    $idx = Join-Path $script:Bak 'backup_index.txt'
    if (Test-Path -LiteralPath $src) {
        $dst = Join-Path (Join-Path $script:Bak 'files') $rel
        $parent = Split-Path -Parent $dst
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
        [System.IO.File]::AppendAllText($idx, ("existed`t" + $rel + "`r`n"), $script:Utf8NoBom)
        Say ("    Backup: " + $rel)
    } else {
        [System.IO.File]::AppendAllText($idx, ("created`t" + $rel + "`r`n"), $script:Utf8NoBom)
    }
    $script:BakDone[$rel.ToLower()] = $true
}

function Save-Log {
    if ($script:DryRun) { return }
    try {
        if (-not (Test-Path -LiteralPath $script:BackupRoot)) { New-Item -ItemType Directory -Force -Path $script:BackupRoot | Out-Null }
        $txt = ($script:Log -join "`r`n") + "`r`n"
        if ($script:Bak -and (Test-Path -LiteralPath $script:Bak)) { [System.IO.File]::WriteAllText((Join-Path $script:Bak 'installer_log.txt'), $txt, $script:Utf8NoBom) }
        $hdr = "==== " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + " ModPatchInstaller " + $script:Version + "`r`n"
        [System.IO.File]::AppendAllText((Join-Path $script:BackupRoot 'installer_log.txt'), ($hdr + $txt), $script:Utf8NoBom)
    } catch { Write-Host ("  Hinweis: Log konnte nicht gespeichert werden: " + $_.Exception.Message) }
}

# ------------------------------------------------------------------ checks
function Test-PzRunning {
    if ($env:PZ_SKIP_PROCCHECK) { Say "  Prozess-Pruefung uebersprungen (Testmodus)."; return $false }
    $hit = @()
    foreach ($n in @('ProjectZomboid64', 'ProjectZomboid32', 'ProjectZomboidServer')) {
        if (Get-Process -Name $n -ErrorAction SilentlyContinue) { $hit += ($n + '.exe') }
    }
    $javas = @()
    try { $javas = @(Get-CimInstance Win32_Process -Filter "Name='java.exe' OR Name='javaw.exe'" -ErrorAction Stop) }
    catch { $javas = @(Get-Process -Name java, javaw -ErrorAction SilentlyContinue | ForEach-Object { New-Object PSObject -Property @{ Name = $_.ProcessName + '.exe'; CommandLine = $null } }) }
    foreach ($j in $javas) {
        $cl = $j.CommandLine
        if ((-not $cl) -or ($cl -match '(?i)zomboid|zombie\.network|zombie\.gameStates|ProjectZomboid')) { $hit += ($j.Name + ' (vermutlich PZ-Server)') }
    }
    if ($hit.Count -gt 0) {
        Say "  ABBRUCH: Project Zomboid oder der PZ-Server laeuft noch:"
        foreach ($h in ($hit | Select-Object -Unique)) { Say ("    - " + $h) }
        Say "  Bitte Spiel UND Server komplett schliessen (Server mit 'quit') und neu starten."
        return $true
    }
    Say "  OK: Spiel und Server laufen nicht."
    return $false
}

function Test-Package {
    $ok = $true
    foreach ($s in $script:ModSlots) {
        $d = Join-Path $script:Src $s.Name
        if ((-not (Test-Path -LiteralPath $d)) -and $s.Required) { Say ("  FEHLER: Ordner fehlt im Paket: " + $s.Name); $ok = $false }
    }
    if (-not (Test-Path -LiteralPath $script:BootFixCore)) { Say "  FEHLER: mkevserverbootpatch\tools\bootfix.ps1 fehlt im Paket."; $ok = $false }
    if (-not (Test-Path -LiteralPath $script:SetupSrc)) { Say "  FEHLER: Ordner MKevServer_setup fehlt im Paket."; $ok = $false }
    return $ok
}

# ------------------------------------------------------------------ boot patch: self-healing fixes (F1-F3)
# mkevserverbootpatch 1.1.2 ships the 3 fixed script files. At install time they are checked against YOUR installed
# Workshop originals (read only): unchanged -> bundled file; mod updated -> fix rebuilt from the new file and checked;
# fixed by the author / file no longer loaded -> our override removed; check failed -> previous file kept + warning.
# Logic: mkevserverbootpatch\tools\bootfix.ps1 (same as tools\check_upstream.ps1 / .sh). Workshop folders are never written.
$script:BootFixCore = Join-Path (Join-Path (Join-Path $script:Src 'mkevserverbootpatch') 'tools') 'bootfix.ps1'
if (Test-Path -LiteralPath $script:BootFixCore) { . $script:BootFixCore }
$script:BootFixResult = @()

# Workshop content folders (108600 = Project Zomboid) of all Steam libraries. PZ_WORKSHOP overrides (';'-list).
function Get-WorkshopRoots {
    if ($env:PZ_WORKSHOP) { return @($env:PZ_WORKSHOP.Split(';') | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) }
    $libs = New-Object System.Collections.Generic.List[string]
    $steam = $null
    try { $steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
    if ($steam) { $libs.Add($steam.Replace('/', '\')) }
    foreach ($d in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) { if ($d) { $libs.Add((Join-Path $d 'Steam')) } }
    foreach ($l in @($libs)) {
        $vdf = Join-Path $l 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in [System.IO.File]::ReadAllLines($vdf)) { if ($line -match '^\s*"path"\s*"(.+)"\s*$') { $libs.Add($Matches[1].Replace('\\', '\')) } }
        }
    }
    $roots = @()
    foreach ($l in $libs) {
        $r = Join-Path $l 'steamapps\workshop\content\108600'
        if ((Test-Path -LiteralPath $r) -and ($roots -notcontains $r)) { $roots += $r }
    }
    return $roots
}

function Format-BootFix($d) {
    $n = '    ' + $d.Fx.Id + ' ' + $d.Fx.Label + ': '
    switch ($d.Status) {
        'KEEP'           { return ($n + 'Original unveraendert - mitgelieferter Fix wird verwendet.') }
        'REBUILT'        { return ($n + ('Original wurde aktualisiert ({0}) - Fix neu geschrieben und geprueft.' -f $d.Src)) }
        'FIXED_UPSTREAM' { return ($n + ('vom Mod-Autor behoben ({0}) - unsere Ersetzung wird entfernt.' -f $d.Src)) }
        'NOT_LOADED'     { return ($n + 'die Mod laedt diese Datei nicht mehr - unsere Ersetzung wird entfernt.') }
        'MISSING'        { return ($n + 'Mod nicht in deinen Workshop-Ordnern gefunden - mitgelieferter Fix wird verwendet.') }
    }
    $why = (@{ braces = 'Klammern { } passen nicht'; tokens = 'Fehler nicht ganz behoben'; changes = 'unerwartete Aenderungen'; read = 'Datei nicht lesbar' })[$d.Why]
    return ('    WARNUNG {0}: Original wurde aktualisiert ({1}), aber der neue Fix hat die Sicherheitspruefung nicht bestanden ({2}). Bisherige Datei bleibt, nichts Kaputtes geschrieben. Bitte MKev Bescheid geben.' -f ($d.Fx.Id + ' ' + $d.Fx.Label), $d.Src, $why)
}

# Copy the package folder to a temp stage and bring F1-F3 in line with the user's Workshop files.
function New-BootPatchStage([string]$from) {
    $stage = Join-Path ([System.IO.Path]::GetTempPath()) ('mkev_bootpatch_stage_' + [guid]::NewGuid().ToString('N'))
    Copy-Item -LiteralPath $from -Destination $stage -Recurse -Force
    $script:BootFixResult = @()
    $roots = @()
    try {
        $roots = @(Get-WorkshopRoots)
        $dec = @(Get-BfDecisions $roots)
        Set-BfFixes $stage $dec (Join-Path (P 'mods') 'mkevserverbootpatch')
        foreach ($d in $dec) { $script:BootFixResult += (Format-BootFix $d) }
    } catch {
        $script:BootFixResult += ('    WARNUNG: Pruefung der Boot-Fixes fehlgeschlagen (' + $_.Exception.Message + ') - mitgelieferte Dateien werden unveraendert installiert.')
        Remove-Item -LiteralPath $stage -Recurse -Force
        Copy-Item -LiteralPath $from -Destination $stage -Recurse -Force
    }
    if ($roots.Count -eq 0) { $script:BootFixResult += '    Hinweis: kein Steam-Workshop-Ordner gefunden (PZ_WORKSHOP setzen, falls woanders). Mitgelieferte Fixes werden verwendet.' }
    return $stage
}


# ------------------------------------------------------------------ steps
function Install-Mods {
    Say ""
    Say "  [Mods] Ziel: Zomboid\mods"
    $modsDir = P 'mods'
    if (-not (Test-Path -LiteralPath $modsDir)) {
        if ($script:DryRun) { Say "    (wuerde Ordner Zomboid\mods anlegen)" }
        else { Assert-SafePath $modsDir; New-Item -ItemType Directory -Force -Path $modsDir | Out-Null }
    }
    foreach ($s in $script:ModSlots) {
        $n = $s.Name
        $from = Join-Path $script:Src $n
        $stage = $null
        if ($s.Stage) {
            $stage = New-BootPatchStage $from
            $from = $stage
            Say ("    " + $n + " - Boot-Fixes mit deinen Workshop-Dateien abgeglichen:")
            foreach ($l in $script:BootFixResult) { Say $l }
        }
        try {
            $to = Join-Path $modsDir $n
            Assert-SafePath $to
            $newVer = Get-ModVersion $from
            if ((Get-DirSig $from) -eq (Get-DirSig $to)) { Say ("    " + $n + " " + $newVer + ": bereits aktuell, nichts geaendert."); continue }
            $oldVer = if (Test-Path -LiteralPath $to) { Get-ModVersion $to } else { 'nicht installiert' }
            if ($script:DryRun) { Say ("    " + $n + ": wuerde installiert (" + $oldVer + " -> " + $newVer + ")."); $script:Changes++; continue }
            Backup-Item ('mods\' + $n)
            if (Test-Path -LiteralPath $to) { Remove-Item -LiteralPath $to -Recurse -Force }
            Copy-Item -LiteralPath $from -Destination $to -Recurse -Force
            if ((Get-DirSig $from) -ne (Get-DirSig $to)) { throw ("Kopie von " + $n + " ist nicht identisch.") }
            Say ("    " + $n + ": installiert (" + $oldVer + " -> " + $newVer + ").")
            $script:Changes++
        } finally {
            if ($stage -and (Test-Path -LiteralPath $stage)) { Remove-Item -LiteralPath $stage -Recurse -Force }
        }
    }
}


# Replace Mods= / WorkshopItems= / Map= in servertest.ini, keep every other line byte-identical.
function Merge-ServerIni {
    Say ""
    Say "  [Server-Einstellungen] Zomboid\Server\servertest.ini (nur Mods=, WorkshopItems=, Map=)"
    $want = [ordered]@{
        'Mods'          = (Read-ListFile 'MKevServer_modlist.txt' 'Mods')
        'WorkshopItems' = (Read-ListFile 'MKevServer_workshopitems.txt' 'WorkshopItems')
        'Map'           = (Read-ListFile 'MKevServer_map.txt' 'Map')
    }
    $path = P 'Server\servertest.ini'
    $exists = Test-Path -LiteralPath $path
    if ($exists) { $t = Read-Text $path; $lines = New-Object System.Collections.Generic.List[string]; foreach ($l in $t.Lines) { $lines.Add($l) }; $nl = $t.Nl; $bom = $t.Bom }
    else { $lines = New-Object System.Collections.Generic.List[string]; $nl = "`r`n"; $bom = $false; Say "    Datei fehlt -> wird neu angelegt (nur diese drei Zeilen; das Spiel ergaenzt den Rest beim ersten Serverstart)." }
    $changed = $false
    foreach ($k in $want.Keys) {
        $sep = ';'
        $newLine = $k + '=' + $want[$k]
        $idx = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i].StartsWith($k + '=')) { $idx = $i; break } }
        if ($idx -ge 0) {
            $oldVal = $lines[$idx].Substring($k.Length + 1)
            if ($lines[$idx] -ceq $newLine) { Say ("    " + $k + "=: schon richtig (" + (Split-List $want[$k] $sep).Count + " Eintraege)."); continue }
            $old = Split-List $oldVal $sep; $new = Split-List $want[$k] $sep
            $removed = @($old | Where-Object { $new -notcontains $_ })
            $added = @($new | Where-Object { $old -notcontains $_ })
            Say ("    " + $k + "=: wird ersetzt (" + $old.Count + " -> " + $new.Count + " Eintraege, neu: " + $added.Count + ", entfernt: " + $removed.Count + ", Reihenfolge wie MKev-Server).")
            if ($removed.Count -gt 0) { Say ("      entfernt (eigene Eintraege des Spielers): " + ($removed -join ', ')) }
            $lines[$idx] = $newLine
            # remove duplicate later lines of the same key (game uses one)
            for ($j = $lines.Count - 1; $j -gt $idx; $j--) { if ($lines[$j].StartsWith($k + '=')) { $lines.RemoveAt($j); Say ("      doppelte " + $k + "=-Zeile entfernt.") } }
        } else {
            Say ("    " + $k + "=: fehlt -> wird hinzugefuegt (" + (Split-List $want[$k] $sep).Count + " Eintraege).")
            $lines.Add($newLine)
        }
        $changed = $true
    }
    if (-not $changed) { return }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben; alle anderen Zeilen bleiben unveraendert)"; return }
    Backup-Item 'Server\servertest.ini'
    Write-TextLines $path $lines $nl $bom
    Say "    gespeichert. Alle anderen Einstellungen (Passwoerter, Ports, Namen ...) unveraendert."
}

function Install-FileCopy([string]$fromName, [string]$rel, [string]$label) {
    $from = Join-Path $script:SetupSrc $fromName
    $to = P $rel
    Say ""
    Say ("  [" + $label + "] Zomboid\" + $rel)
    if (-not (Test-Path -LiteralPath $from)) { throw ("Datei fehlt im Paket: MKevServer_setup\" + $fromName) }
    Assert-SafePath $to
    if ((Test-Path -LiteralPath $to) -and ((Get-FileHash -Algorithm SHA256 -LiteralPath $from).Hash -eq (Get-FileHash -Algorithm SHA256 -LiteralPath $to).Hash)) { Say "    schon identisch, nichts geaendert."; return }
    $script:Changes++
    if ($script:DryRun) { Say ("    wuerde " + $(if (Test-Path -LiteralPath $to) { 'ersetzt' } else { 'neu angelegt' }) + " (Inhalt: MKevServer_setup\" + $fromName + ")."); return }
    Backup-Item $rel
    $dir = Split-Path -Parent $to
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    Copy-Item -LiteralPath $from -Destination $to -Force
    Say "    gespeichert."
}

# pz_modlist_settings.cfg: add or replace only the line of our preset, keep every other preset.
function Merge-Preset {
    Say ""
    Say ("  [Mod-Preset] Zomboid\Lua\pz_modlist_settings.cfg (Preset '" + $script:PresetName + "')")
    $f = Join-Path $script:SetupSrc 'MKevServer_preset.txt'
    $our = $null
    foreach ($l in (Read-Text $f).Lines) { if ($l.StartsWith($script:PresetName + ':')) { $our = $l } }
    if (-not $our) { throw "Preset-Zeile fehlt in MKevServer_setup\MKevServer_preset.txt" }
    $path = P 'Lua\pz_modlist_settings.cfg'
    $lines = New-Object System.Collections.Generic.List[string]; $nl = "`r`n"; $bom = $false
    if (Test-Path -LiteralPath $path) { $t = Read-Text $path; foreach ($l in $t.Lines) { $lines.Add($l) }; $nl = $t.Nl; $bom = $t.Bom }
    else { $lines.Add('!fav!:') }
    $idx = -1
    for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i].StartsWith($script:PresetName + ':')) { $idx = $i; break } }
    $foreign = @($lines | Where-Object { $_ -match '^[^:]+:' -and -not $_.StartsWith('!fav!:') -and -not $_.StartsWith($script:PresetName + ':') } | ForEach-Object { $_.Split(':')[0] })
    if ($idx -ge 0 -and $lines[$idx] -ceq $our) { Say "    schon aktuell, nichts geaendert."; return }
    if ($idx -ge 0) { $lines[$idx] = $our; Say "    vorhandenes Preset wird aktualisiert." } else { $lines.Add($our); Say "    Preset wird hinzugefuegt." }
    if ($foreign.Count -gt 0) { Say ("    eigene Presets bleiben erhalten: " + ($foreign -join ', ')) }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben)"; return }
    Backup-Item 'Lua\pz_modlist_settings.cfg'
    Write-TextLines $path $lines $nl $bom
    Say "    gespeichert."
}

# mods\default.txt: add mkev_modpatcher to the mods block, nothing else.
function Merge-DefaultTxt {
    Say ""
    Say ("  [Lokale Mod-Liste] Zomboid\mods\default.txt (" + $script:DefaultTxtMod + " eintragen)")
    $path = P 'mods\default.txt'
    $id = $script:DefaultTxtMod
    if (-not (Test-Path -LiteralPath $path)) {
        $lines = @('VERSION = 1,', '', 'mods', '{', ('    mod = ' + $id + ','), '}', '', 'maps', '{', '}')
        $nl = "`r`n"; $bom = $false
        Say "    Datei fehlt -> wird neu angelegt."
    } else {
        $t = Read-Text $path; $nl = $t.Nl; $bom = $t.Bom
        $lines = New-Object System.Collections.Generic.List[string]; foreach ($l in $t.Lines) { $lines.Add($l) }
        $inMods = $false; $close = -1; $found = $false; $start = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $s = $lines[$i].Trim()
            if (-not $inMods -and $s -eq 'mods') { $start = $i; continue }
            if ($start -ge 0 -and -not $inMods -and $close -lt 0 -and $s -eq '{') { $inMods = $true; continue }
            if ($inMods) {
                if ($s -eq '}') { $close = $i; $inMods = $false; break }
                if ($s -match '^mod\s*=\s*\\?([^,]+?)\s*,?\s*$' -and $Matches[1] -eq $id) { $found = $true }
            }
        }
        if ($found) { Say "    schon eingetragen, nichts geaendert."; return }
        if ($close -lt 0) { Say "    WARNUNG: Aufbau von default.txt unbekannt, nicht geaendert. (Die Mod traegt sich beim Beitreten selbst ein.)"; return }
        $lines.Insert($close, ('    mod = ' + $id + ','))
        Say "    wird am Ende der Mod-Liste angehaengt (sonst keine Aenderung)."
    }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben)"; return }
    Backup-Item 'mods\default.txt'
    Write-TextLines $path $lines $nl $bom
    Say "    gespeichert."
}

# Option 2: ready-made files for the player, no existing config is touched.
function Write-SetupFolder {
    $dst = P 'MKevServer_setup'
    Say ""
    Say "  [Vorlagen] Zomboid\MKevServer_setup\"
    Assert-SafePath $dst
    $files = @('MKevServer_modlist.txt', 'MKevServer_workshopitems.txt', 'MKevServer_map.txt', 'MKevServer_SandboxVars.lua', 'MKevServer_preset.txt', 'MKevServer_LIESMICH.txt')
    $same = $true
    foreach ($f in $files) {
        $a = Join-Path $script:SetupSrc $f; $b = Join-Path $dst $f
        if (-not (Test-Path -LiteralPath $b) -or (Get-FileHash -Algorithm SHA256 -LiteralPath $a).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $b).Hash) { $same = $false }
    }
    if ($same) { Say "    schon aktuell, nichts geaendert."; return }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben)"; return }
    Backup-Item 'MKevServer_setup'
    if (-not (Test-Path -LiteralPath $dst)) { New-Item -ItemType Directory -Force -Path $dst | Out-Null }
    foreach ($f in $files) { Copy-Item -LiteralPath (Join-Path $script:SetupSrc $f) -Destination (Join-Path $dst $f) -Force; Say ("    " + $f) }
}

# ------------------------------------------------------------------ restore
function Get-Backups {
    if (-not (Test-Path -LiteralPath $script:BackupRoot)) { return @() }
    return @(Get-ChildItem -LiteralPath $script:BackupRoot -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'backup_index.txt') } | Sort-Object Name -Descending)
}

function Invoke-Restore {
    $list = @(Get-Backups)
    if ($list.Count -eq 0) { Say "  Keine Backups gefunden in Zomboid\mkev_patch_backups."; return }
    Say "  Vorhandene Backups (neueste zuerst):"
    for ($i = 0; $i -lt $list.Count; $i++) { Say ("    " + ($i + 1) + ") " + $list[$i].Name) }
    $pick = if ($env:PZ_RESTORE_PICK) { $env:PZ_RESTORE_PICK } else { Read-Host "  Nummer waehlen (leer = abbrechen)" }
    $n = 0
    if (-not [int]::TryParse(("" + $pick).Trim(), [ref]$n) -or $n -lt 1 -or $n -gt $list.Count) { Say "  Abgebrochen."; return }
    $b = $list[$n - 1].FullName
    $entries = @()
    foreach ($l in (Read-Text (Join-Path $b 'backup_index.txt')).Lines) { if ($l -match "^(existed|created)`t(.+)$") { $entries += ,@($Matches[1], $Matches[2]) } }
    Say ("  Backup " + $list[$n - 1].Name + " stellt den Zustand VOR diesem Lauf wieder her:")
    foreach ($e in $entries) { Say ("    " + $(if ($e[0] -eq 'existed') { 'zurueck: ' } else { 'entfernen (war neu): ' }) + $e[1]) }
    if (-not (Ask "Wiederherstellen?")) { Say "  Abgebrochen, nichts geaendert."; return }
    New-BackupSession 'vor_wiederherstellung'
    foreach ($e in $entries) {
        $rel = $e[1]
        if ($rel.StartsWith('gamejson:')) {
            $target = $rel.Substring('gamejson:'.Length)
            if (-not (Test-IsClientGameJson $target)) {
                if (Test-Path -LiteralPath $target) { Say (($script:RamT.RestoreSkip -f $target)); continue }
            }
            if ($e[0] -eq 'existed' -and (Test-Path -LiteralPath $target)) { Backup-GameJson $target }
            if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
            if ($e[0] -eq 'existed') {
                $srcJson = Join-Path (Join-Path (Join-Path $b 'files') '_gamejson') 'ProjectZomboid64.json'
                $parent = Split-Path -Parent $target
                if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
                Copy-Item -LiteralPath $srcJson -Destination $target -Force
            }
            Say ("    erledigt: " + $target)
            continue
        }
        $target = P $rel
        Assert-SafePath $target
        Backup-Item $rel
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
        if ($e[0] -eq 'existed') {
            $parent = Split-Path -Parent $target
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
            Copy-Item -LiteralPath (Join-Path (Join-Path $b 'files') $rel) -Destination $target -Recurse -Force
        }
        Say ("    erledigt: " + $rel)
    }
    Say ("  Wiederhergestellt. Der Zustand davor liegt in: " + (Rel $script:Bak))
}


$script:RamT = @{
    MenuPrompt        = '  Auswahl [1]'
    MenuAuto          = '  Auswahl [1]: {0} (automatisch)'
    RamPrompt         = '  Auswahl Arbeitsspeicher [7]'
    RamAuto           = '  Auswahl Arbeitsspeicher [7]: {0} (automatisch)'
    Q3title           = '  Frage 3 - Arbeitsspeicher des Spiel-Clients (Windows, nur ProjectZomboid64.json):'
    Q3onlyClient      = '  Dies betrifft nur den Windows-Spielclient mit grafischer Oberflaeche, nicht den Server.'
    Q3default         = '  Standard: keine Aenderung. Du kannst diese Frage jederzeit mit 7 ueberspringen.'
    Opt1              = '   1) 8 GB  (auf eigenes Risiko, keine optimale Performance garantiert)'
    Opt2              = '   2) 12 GB  (auf eigenes Risiko, keine optimale Performance garantiert)'
    Opt3              = '   3) 16 GB  (auf eigenes Risiko, keine optimale Performance garantiert)'
    Opt4              = '   4) 8 GB + 12 GB Headroom  (Mindestempfehlung)'
    Opt5              = '   5) 8 GB + 16 GB Headroom  (auf eigenes Risiko, keine optimale Performance garantiert)'
    Opt6              = '   6) 12 GB + 16 GB Headroom  (ausdruecklich empfohlen)'
    Opt7              = '   7) Keine Aenderung'
    Opt8              = '   8) Zurueck'
    Q3xmsEqual        = '  Ohne Headroom gilt: -Xms und -Xmx bekommen denselben Wert.'
    Q3headroom        = '  Mit Headroom ist -Xms die Grundzuteilung und -Xmx der hoehere Wert.'
    Q3steam           = '  Steam-Spielupdates koennen ProjectZomboid64.json zuruecksetzen; den Installer dann erneut ausfuehren.'
    Label1            = '8 GB'
    Label2            = '12 GB'
    Label3            = '16 GB'
    Label4            = '8 GB + 12 GB Headroom (Mindestempfehlung)'
    Label5            = '8 GB + 16 GB Headroom'
    Label6            = '12 GB + 16 GB Headroom (ausdruecklich empfohlen)'
    BadRamChoice      = '  Ungueltige Auswahl, bitte 1 bis 8 waehlen.'
    BackToQ2          = '  Zurueck zur Installationsoption (Frage 2).'
    NoChange          = '  Arbeitsspeicher: keine Aenderung.'
    WarnOver          = '  HINWEIS RAM: Die gewaehlte Zuteilung (-Xmx {0} GB) ist groesser als der sinnvolle Anteil des eingebauten Arbeitsspeichers ({1} GB, Richtwert: nicht mehr als {2} GB).'
    WarnOverAsk       = 'Trotzdem verwenden?'
    WarnOverNo        = '  Auswahl verworfen, bitte erneut waehlen.'
    RamOk             = '  Erkannter Arbeitsspeicher: {0} GB (Richtwert eingehalten).'
    RamUnknown        = '  HINWEIS RAM: Der eingebaute Arbeitsspeicher konnte nicht gelesen werden. Bitte selbst pruefen, dass -Xmx nicht den Rechner knapp macht.'
    Chosen            = '  Gewaehlt: {0}  (-Xms{1}m -Xmx{2}m)'
    BadPzGame         = '  HINWEIS RAM: PZ_GAME ist kein Windows-Spielclient (ProjectZomboid64.json mit mainClass MainScreenState): {0}'
    MultiGame         = '  HINWEIS RAM: mehrere Spielordner gefunden, es wird der erste verwendet:'
    NoGame            = '  HINWEIS RAM: Kein Windows-Spielclient gefunden (ProjectZomboid64.json). Die RAM-Option wird uebersprungen, alles andere laeuft weiter.'
    NoGameTip         = '  Tipp: Steam-Bibliothek pruefen oder PZ_GAME auf den Ordner ...\steamapps\common\ProjectZomboid setzen.'
    NotClient         = '  HINWEIS RAM: Datei ist kein Spielclient oder fehlt, keine Aenderung: {0}'
    BadJson           = '  HINWEIS RAM: ProjectZomboid64.json ist kein gueltiges JSON, keine Aenderung: {0}'
    BadMain           = '  HINWEIS RAM: mainClass ist nicht der Spielclient, keine Aenderung.'
    Already           = '  Arbeitsspeicher ist bereits gesetzt: -Xms{0}m -Xmx{1}m (Datei unveraendert).'
    DryRam            = '  PROBELAUF RAM: wuerde in {0} setzen: -Xms{1}m -Xmx{2}m'
    WriteFail         = '  HINWEIS RAM: Pruefung der neuen Datei fehlgeschlagen, Original bleibt: {0}'
    Written           = '  Arbeitsspeicher gesetzt in {0}: -Xms{1}m -Xmx{2}m'
    Backup            = '    Backup: {0}'
    RestoreSkip       = '    uebersprungen (keine Client-Datei): {0}'
    Info6             = '   6. Optional: Arbeitsspeicher des Windows-Spielclients in ProjectZomboid64.json (Frage 3, Standard: keine Aenderung).'
}

# ------------------------------------------------------------------ client RAM (Windows GUI client only; never the dedicated server)
# Question 3 after install option 1 or 2. Default is no change. Choice 8 returns to the install menu (question 2).
$script:TestMode = [bool]$env:PZ_CHOICE
$script:MenuAnswers = New-Object System.Collections.Generic.Queue[string]
$script:RamAnswers = New-Object System.Collections.Generic.Queue[string]
if ($env:PZ_CHOICE) { foreach ($x in @($env:PZ_CHOICE -split '[;,\s]+' | Where-Object { $_ -ne '' })) { $script:MenuAnswers.Enqueue($x) } }
if ($env:PZ_RAM_CHOICE) { foreach ($x in @($env:PZ_RAM_CHOICE -split '[;,\s]+' | Where-Object { $_ -ne '' })) { $script:RamAnswers.Enqueue($x) } }

function Next-MenuChoice {
    if ($script:MenuAnswers.Count -gt 0) {
        $a = $script:MenuAnswers.Dequeue()
        Say (($script:RamT.MenuAuto -f $a))
        return $a
    }
    $a = Read-Host $script:RamT.MenuPrompt
    $a = ("" + $a).Trim()
    if ($a -eq '') { $a = '1' }
    $script:Log.Add("  Auswahl: " + $a)
    return $a
}

function Next-RamChoice {
    if ($script:RamAnswers.Count -gt 0) {
        $a = $script:RamAnswers.Dequeue()
        Say (($script:RamT.RamAuto -f $a))
        return ("" + $a).Trim()
    }
    if ($script:TestMode) {
        Say (($script:RamT.RamAuto -f '7'))
        return '7'
    }
    $a = Read-Host $script:RamT.RamPrompt
    $a = ("" + $a).Trim()
    if ($a -eq '') { $a = '7' }
    $script:Log.Add("  RAM: " + $a)
    return $a
}

function Get-SteamLibraries {
    $libs = New-Object System.Collections.Generic.List[string]
    $steam = $null
    try { $steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
    if ($steam) { $libs.Add($steam.Replace('/', '\')) }
    foreach ($d in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) { if ($d) { $libs.Add((Join-Path $d 'Steam')) } }
    foreach ($l in @($libs)) {
        $vdf = Join-Path $l 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in [System.IO.File]::ReadAllLines($vdf)) { if ($line -match '^\s*"path"\s*"(.+)"\s*$') { $libs.Add($Matches[1].Replace('\\', '\')) } }
        }
    }
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($l in $libs) {
        $n = $l.TrimEnd('\', '/')
        if ($n -and ($out -notcontains $n)) { $out.Add($n) }
    }
    return @($out)
}

function Get-JsonMainClass([string]$path) {
    try {
        $raw = [System.IO.File]::ReadAllText($path)
        $obj = $raw | ConvertFrom-Json
        if ($null -eq $obj) { return $null }
        if ($obj.PSObject.Properties.Name -notcontains 'mainClass') { return $null }
        return [string]$obj.mainClass
    } catch { return $null }
}

function Test-IsClientGameJson([string]$path) {
    if (-not $path) { return $false }
    $full = $null
    try { $full = [System.IO.Path]::GetFullPath($path) } catch { return $false }
    $leaf = [System.IO.Path]::GetFileName($full)
    if ($leaf -ne 'ProjectZomboid64.json') { return $false }
    if ($full -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { return $false }
    if (-not (Test-Path -LiteralPath $full)) { return $false }
    $mc = Get-JsonMainClass $full
    if (-not $mc) { return $false }
    if ($mc -match '(?i)GameServer') { return $false }
    if ($mc -notmatch '(?i)MainScreenState') { return $false }
    return $true
}

function Find-ClientGameDir {
    if ($env:PZ_GAME) {
        $g = $env:PZ_GAME.TrimEnd('\', '/')
        $j = Join-Path $g 'ProjectZomboid64.json'
        if (Test-IsClientGameJson $j) { return $g }
        Say (($script:RamT.BadPzGame -f $g))
        return $null
    }
    $hits = New-Object System.Collections.Generic.List[string]
    foreach ($lib in @(Get-SteamLibraries)) {
        $g = Join-Path $lib 'steamapps\common\ProjectZomboid'
        $j = Join-Path $g 'ProjectZomboid64.json'
        if ((Test-IsClientGameJson $j) -and ($hits -notcontains $g)) { $hits.Add($g) }
    }
    if ($hits.Count -eq 0) { return $null }
    if ($hits.Count -gt 1) {
        $withExe = @($hits | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'ProjectZomboid64.exe') })
        if ($withExe.Count -ge 1) { $hits = New-Object System.Collections.Generic.List[string]; foreach ($h in $withExe) { $hits.Add($h) } }
        Say $script:RamT.MultiGame
        foreach ($h in $hits) { Say ("    " + $h) }
    }
    return $hits[0]
}

function Get-PhysicalRamGB {
    if ($env:PZ_PHYSICAL_RAM_GB) {
        $n = 0
        if ([int]::TryParse(("" + $env:PZ_PHYSICAL_RAM_GB).Trim(), [ref]$n) -and $n -gt 0) { return $n }
    }
    try {
        $bytes = [int64](Get-CimInstance -ClassName Win32_ComputerSystem -ErrorAction Stop).TotalPhysicalMemory
        if ($bytes -gt 0) { return [int][math]::Floor($bytes / 1GB) }
    } catch { }
    try {
        $bytes = [int64](Get-WmiObject -Class Win32_ComputerSystem -ErrorAction Stop).TotalPhysicalMemory
        if ($bytes -gt 0) { return [int][math]::Floor($bytes / 1GB) }
    } catch { }
    return 0
}

function Set-VmArgsMemory($argsIn, [int]$xmsMb, [int]$xmxMb) {
    $list = New-Object System.Collections.Generic.List[string]
    $insertAt = -1
    foreach ($a in @($argsIn)) {
        $s = [string]$a
        if ($s -match '^\s*-Xm[sx]') {
            if ($insertAt -lt 0) { $insertAt = $list.Count }
            continue
        }
        $list.Add($s)
    }
    if ($insertAt -lt 0) { $insertAt = $list.Count }
    $list.Insert($insertAt, ('-Xms' + $xmsMb + 'm'))
    $list.Insert(($insertAt + 1), ('-Xmx' + $xmxMb + 'm'))
    return @($list)
}

function Get-VmArgsArray($obj) {
    if ($obj.PSObject.Properties.Name -notcontains 'vmArgs') { return @() }
    if ($null -eq $obj.vmArgs) { return @() }
    return @($obj.vmArgs)
}

function Json-Escape([string]$s) {
    if ($null -eq $s) { return '' }
    $t = $s.Replace('\', '\\').Replace('"', '\"')
    $t = $t.Replace("`r", '\r').Replace("`n", '\n').Replace("`t", '\t')
    return $t
}

function Json-StringArray($arr) {
    $parts = @()
    foreach ($x in @($arr)) { $parts += ('"' + (Json-Escape ([string]$x)) + '"') }
    if ($parts.Count -eq 0) { return '[]' }
    return ('[ ' + ($parts -join ', ') + ' ]')
}

function Write-ClientJsonText($obj, [string]$nl) {
    $lines = New-Object System.Collections.Generic.List[string]
    $lines.Add('{')
    $lines.Add('  "mainClass" : "' + (Json-Escape ([string]$obj.mainClass)) + '",')
    $cp = @()
    if ($obj.PSObject.Properties.Name -contains 'classpath') { $cp = @($obj.classpath) }
    $lines.Add('  "classpath" : ' + (Json-StringArray $cp) + ',')
    $va = Get-VmArgsArray $obj
    $winLine = $null
    if ($obj.PSObject.Properties.Name -contains 'windows' -and $null -ne $obj.windows) {
        $wobj = $obj.windows
        $wk = @($wobj.PSObject.Properties.Name)
        $wparts = New-Object System.Collections.Generic.List[string]
        $wparts.Add('{')
        for ($i = 0; $i -lt $wk.Count; $i++) {
            $k = [string]$wk[$i]
            $child = $wobj.$k
            $childArgs = @()
            if ($null -ne $child -and $child.PSObject.Properties.Name -contains 'vmArgs') { $childArgs = @($child.vmArgs) }
            $comma = if ($i -lt $wk.Count - 1) { ',' } else { '' }
            $wparts.Add('    "' + (Json-Escape $k) + '" : {')
            $wparts.Add('      "vmArgs" : ' + (Json-StringArray $childArgs))
            $wparts.Add('    }' + $comma)
        }
        $wparts.Add('  }')
        $winLine = ($wparts -join $nl)
    }
    if ($winLine) {
        $lines.Add('  "vmArgs" : ' + (Json-StringArray $va) + ',')
        $lines.Add('  "windows" : ' + $winLine)
    } else {
        $lines.Add('  "vmArgs" : ' + (Json-StringArray $va))
    }
    $lines.Add('}')
    return (($lines -join $nl) + $nl)
}

function Backup-GameJson([string]$jsonPath) {
    if ($script:DryRun) { return }
    if (-not $script:Bak) { return }
    $key = ('gamejson:' + $jsonPath)
    if ($script:BakDone.ContainsKey($key.ToLower())) { return }
    Ensure-BackupDir
    $idx = Join-Path $script:Bak 'backup_index.txt'
    $dstDir = Join-Path (Join-Path $script:Bak 'files') '_gamejson'
    if (-not (Test-Path -LiteralPath $dstDir)) { New-Item -ItemType Directory -Force -Path $dstDir | Out-Null }
    $dst = Join-Path $dstDir 'ProjectZomboid64.json'
    Copy-Item -LiteralPath $jsonPath -Destination $dst -Force
    [System.IO.File]::AppendAllText($idx, ("existed`tgamejson:" + $jsonPath + "`r`n"), $script:Utf8NoBom)
    $script:BakDone[$key.ToLower()] = $true
    Say (($script:RamT.Backup -f $jsonPath))
}

function Show-RamQuestion {
    Say ""
    Say $script:RamT.Q3title
    Say $script:RamT.Q3onlyClient
    Say $script:RamT.Q3default
    Say ""
    Say $script:RamT.Opt1
    Say $script:RamT.Opt2
    Say $script:RamT.Opt3
    Say $script:RamT.Opt4
    Say $script:RamT.Opt5
    Say $script:RamT.Opt6
    Say $script:RamT.Opt7
    Say $script:RamT.Opt8
    Say ""
    Say $script:RamT.Q3xmsEqual
    Say $script:RamT.Q3headroom
    Say $script:RamT.Q3steam
}

function Parse-RamChoice([string]$c) {
    switch ($c) {
        '1' { return @{ Kind = 'set'; Xms = 8192;  Xmx = 8192;  Label = $script:RamT.Label1 } }
        '2' { return @{ Kind = 'set'; Xms = 12288; Xmx = 12288; Label = $script:RamT.Label2 } }
        '3' { return @{ Kind = 'set'; Xms = 16384; Xmx = 16384; Label = $script:RamT.Label3 } }
        '4' { return @{ Kind = 'set'; Xms = 8192;  Xmx = 12288; Label = $script:RamT.Label4 } }
        '5' { return @{ Kind = 'set'; Xms = 8192;  Xmx = 16384; Label = $script:RamT.Label5 } }
        '6' { return @{ Kind = 'set'; Xms = 12288; Xmx = 16384; Label = $script:RamT.Label6 } }
        '7' { return @{ Kind = 'skip' } }
        '8' { return @{ Kind = 'back' } }
        default { return $null }
    }
}

function Ask-Ram {
    while ($true) {
        Show-RamQuestion
        $c = Next-RamChoice
        $sel = Parse-RamChoice $c
        if ($null -eq $sel) { Say $script:RamT.BadRamChoice; continue }
        if ($sel.Kind -eq 'back') { Say $script:RamT.BackToQ2; return @{ Kind = 'back' } }
        if ($sel.Kind -eq 'skip') { Say $script:RamT.NoChange; return @{ Kind = 'skip' } }
        $ram = Get-PhysicalRamGB
        $xmxGb = [int][math]::Ceiling($sel.Xmx / 1024.0)
        if ($ram -gt 0) {
            $limitGb = $ram - 4
            if ($limitGb -lt 0) { $limitGb = 0 }
            if ($xmxGb -gt $limitGb) {
                Say (($script:RamT.WarnOver -f $xmxGb, $ram, $limitGb))
                if (-not (Ask $script:RamT.WarnOverAsk)) { Say $script:RamT.WarnOverNo; continue }
            } else {
                Say (($script:RamT.RamOk -f $ram))
            }
        } else {
            Say $script:RamT.RamUnknown
        }
        Say (($script:RamT.Chosen -f $sel.Label, $sel.Xms, $sel.Xmx))
        return $sel
    }
}

function Invoke-ClientRam($sel) {
    if ($null -eq $sel -or $sel.Kind -eq 'skip' -or $sel.Kind -eq 'back') { return }
    $game = Find-ClientGameDir
    if (-not $game) {
        Say $script:RamT.NoGame
        Say $script:RamT.NoGameTip
        return
    }
    $jsonPath = Join-Path $game 'ProjectZomboid64.json'
    if (-not (Test-IsClientGameJson $jsonPath)) {
        Say (($script:RamT.NotClient -f $jsonPath))
        return
    }
    $bytes = [System.IO.File]::ReadAllBytes($jsonPath)
    $bom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $text = $script:Utf8NoBom.GetString($bytes)
    if ($bom) { $text = $text.Substring(1) }
    $nl = if ($text.Contains("`r`n")) { "`r`n" } elseif ($text.Contains("`n")) { "`n" } else { "`r`n" }
    try { $obj = $text | ConvertFrom-Json } catch {
        Say (($script:RamT.BadJson -f $_.Exception.Message))
        return
    }
    if ($obj.PSObject.Properties.Name -notcontains 'mainClass' -or ([string]$obj.mainClass -match '(?i)GameServer') -or ([string]$obj.mainClass -notmatch '(?i)MainScreenState')) {
        Say $script:RamT.BadMain
        return
    }
    $oldArgs = Get-VmArgsArray $obj
    $newArgs = Set-VmArgsMemory $oldArgs ([int]$sel.Xms) ([int]$sel.Xmx)
    $already = $true
    if ($oldArgs.Count -ne $newArgs.Count) { $already = $false }
    else {
        for ($i = 0; $i -lt $oldArgs.Count; $i++) { if ([string]$oldArgs[$i] -ne [string]$newArgs[$i]) { $already = $false; break } }
    }
    if ($already) {
        Say (($script:RamT.Already -f $sel.Xms, $sel.Xmx))
        return
    }
    # Assign via a new object field; PS 5.1 allows setting .vmArgs on PSCustomObject from ConvertFrom-Json
    $obj.vmArgs = $newArgs
    $outText = Write-ClientJsonText $obj $nl
    if ($script:DryRun) {
        Say (($script:RamT.DryRam -f $jsonPath, $sel.Xms, $sel.Xmx))
        $script:Changes++
        return
    }
    Backup-GameJson $jsonPath
    $tmp = $jsonPath + '.mkevtmp'
    $outBytes = $script:Utf8NoBom.GetBytes($outText)
    if ($bom) {
        $buf = New-Object byte[] ($outBytes.Length + 3)
        $buf[0] = 0xEF; $buf[1] = 0xBB; $buf[2] = 0xBF
        [System.Array]::Copy($outBytes, 0, $buf, 3, $outBytes.Length)
        $outBytes = $buf
    }
    [System.IO.File]::WriteAllBytes($tmp, $outBytes)
    try {
        if ($bom) { $chk = $script:Utf8NoBom.GetString($outBytes, 3, $outBytes.Length - 3) } else { $chk = $script:Utf8NoBom.GetString($outBytes) }
        $chkObj = $chk | ConvertFrom-Json
        if ([string]$chkObj.mainClass -notmatch '(?i)MainScreenState') { throw 'mainClass after write is not the client' }
    } catch {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force }
        Say (($script:RamT.WriteFail -f $_.Exception.Message))
        return
    }
    Move-Item -LiteralPath $tmp -Destination $jsonPath -Force
    $script:Changes++
    Say (($script:RamT.Written -f $jsonPath, $sel.Xms, $sel.Xmx))
}

# ------------------------------------------------------------------ menu
function Show-Info1 {
    Say ""
    Say "  INSTALLIEREN & EINRICHTEN - das passiert genau:"
    Say "   1. Mods nach Zomboid\mods kopieren: mkev_modpatcher, mkevserverbootpatch."
    Say "      Der Boot-Patch bringt seine 3 Skript-Fixes mit. Wurde eine Mod aktualisiert,"
    Say "      werden sie aus deinen Workshop-Dateien neu geschrieben (nur gelesen)."
    Say "   2. Zomboid\Server\servertest.ini: die Zeilen Mods=, WorkshopItems= und Map="
    Say "      werden KOMPLETT durch die Liste des MKev-Servers ersetzt (Ladereihenfolge)."
    Say "      Deine bisherigen Eintraege in diesen drei Zeilen verschwinden."
    Say "      Alle anderen Einstellungen (Passwoerter, Ports, Servername ...) bleiben."
    Say "      Fehlt die Datei, wird sie mit nur diesen drei Zeilen angelegt."
    Say "   3. Zomboid\Server\servertest_SandboxVars.lua wird durch die Einstellungen des"
    Say "      MKev-Servers ersetzt."
    Say "   4. Zomboid\Lua\pz_modlist_settings.cfg: Mod-Preset 'MKevServer' wird"
    Say "      hinzugefuegt/aktualisiert, deine eigenen Presets bleiben."
    Say "   5. Zomboid\mods\default.txt: mkev_modpatcher wird angehaengt (sonst nichts)."
    Say "   Vorher wird alles gesichert nach Zomboid\mkev_patch_backups\<Datum_Uhrzeit>\"
    Say "   (zurueckholen mit Menuepunkt 3)."
    Say $script:RamT.Info6
}

function Run-Setup([bool]$dry) {
    $script:DryRun = $dry
    if (-not $dry) { New-BackupSession 'einrichten' }
    Install-Mods
    Merge-ServerIni
    Install-FileCopy 'MKevServer_SandboxVars.lua' 'Server\servertest_SandboxVars.lua' 'Sandbox-Einstellungen'
    Merge-Preset
    Merge-DefaultTxt
}

function Main {
    Say ""
    Say ("  MKev's Modpatch Installer " + $script:Version + "  (Autor MKev)")
    Say "  ================================================================"
    Say ("  Paket   : " + $script:Src)
    Say ("  Zomboid : " + $script:Zomboid)
    Say ""
    Say "   1) Installieren & Einrichten   (empfohlen)"
    Say "   2) Installieren & nicht Einrichten (nur Patch + Vorlagen-Dateien)"
    Say "   3) Backup wiederherstellen"
    Say "   4) Beenden"
    Say "   5) Probelauf: nur anzeigen, was 1) aendern wuerde"
    while ($true) {
    $c = Next-MenuChoice
    $c = ("" + $c).Trim(); if ($c -eq '') { $c = '1' }
    $script:Log.Add("  Auswahl: " + $c)
    if ($c -eq '4') { Say "  Beendet, nichts geaendert."; return 0 }
    if (@('1', '2', '3', '5') -notcontains $c) { Say "  Ungueltige Auswahl, nichts geaendert."; return 1 }
    Say ""
    if (Test-PzRunning) { return 1 }
    if (-not (Test-Path -LiteralPath $script:Zomboid)) {
        Say ("  ABBRUCH: Zomboid-Ordner nicht gefunden: " + $script:Zomboid)
        Say "  Bitte Project Zomboid einmal starten und wieder schliessen."
        return 1
    }
    if ($script:Zomboid -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { Say "  ABBRUCH (Sicherheitsstopp): Zomboid-Ordner liegt in einem Workshop-Ordner."; return 1 }
    if ($c -eq '3') { Invoke-Restore; Save-Log; return 0 }
    if (-not (Test-Package)) { return 1 }
    if ($c -eq '5') {
        $ram = Ask-Ram
        if ($ram.Kind -eq 'back') { continue }
        Say "  PROBELAUF - es wird nichts geschrieben:"
        Run-Setup $true
        Invoke-ClientRam $ram
        Say ""
        Say ("  Probelauf fertig: " + $script:Changes + " Aenderung(en) wuerden gemacht.")
        return 0
    }
    if ($c -eq '1') {
        Show-Info1
        $ram = Ask-Ram
        if ($ram.Kind -eq 'back') { continue }
        Say ""
        if (-not (Ask "Einverstanden? Jetzt installieren und einrichten?")) { Say "  Abgebrochen, nichts geaendert."; return 0 }
        Run-Setup $false
        Invoke-ClientRam $ram
    } else {
        $ram = Ask-Ram
        if ($ram.Kind -eq 'back') { continue }
        Say "  INSTALLIEREN & NICHT EINRICHTEN: nur die Patches werden kopiert,"
        Say "  keine bestehende Einstellung wird geaendert."
        $script:DryRun = $false
        New-BackupSession 'nur_installieren'
        Install-Mods
        Write-SetupFolder
        Say ""
        Say "  Fertige Dateien zum Selbst-Einrichten liegen in Zomboid\MKevServer_setup\ :"
        Say "    MKevServer_modlist.txt        -> Zeile Mods= (Ladereihenfolge) fuer deine servertest.ini"
        Say "    MKevServer_workshopitems.txt  -> Zeile WorkshopItems= fuer deine servertest.ini"
        Say "    MKevServer_map.txt            -> Zeile Map= fuer deine servertest.ini"
        Say "    MKevServer_SandboxVars.lua    -> Sandbox-Einstellungen (als <servername>_SandboxVars.lua nutzen)"
        Say "    MKevServer_preset.txt         -> Zeile fuer Zomboid\Lua\pz_modlist_settings.cfg"
        Say "    MKevServer_LIESMICH.txt       -> Anleitung"
        Invoke-ClientRam $ram
    }
    Say ""
    Say "  Installierte Versionen:"
    foreach ($s in $script:ModSlots) { $d = P ('mods\' + $s.Name); if (Test-Path -LiteralPath $d) { Say ("    " + $s.Name + ": " + (Get-ModVersion $d)) } }
    Say ""
    if ($script:Bak -and (Test-Path -LiteralPath $script:Bak)) { Say ("  FERTIG. Backup: " + $script:Bak) } else { Say "  FERTIG. Es war schon alles aktuell, nichts geaendert." }
    Say "  Zum Spielen: Workshop-Kollektion abonniert lassen, Spiel starten, Server beitreten."
    Save-Log
    return 0
    }
}

try { $rc = Main } catch { Say ("  FEHLER: " + $_.Exception.Message); if ($script:Bak) { Say ("  Backup zum Zurueckholen (Menuepunkt 3): " + $script:Bak) }; Save-Log; $rc = 1 }
exit $rc
