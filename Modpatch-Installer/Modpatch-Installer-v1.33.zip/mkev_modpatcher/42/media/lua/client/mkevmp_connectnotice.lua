-- MKev-ModPatcher: connect notice window (client only, 0.1.11; timeout hint added in 1.3; texts and blinking title in 1.3.2).
-- Author: MKev. Optimized by Grok Bot in combination with Cursor. Own code, written from scratch.
--
-- Shows a short loading notice (German if the game language is DE, English for every other language)
-- that the player has to confirm with OK.
--   1) Main menu, before the connect starts: wraps ConnectToServer.connect (dedicated server join from the
--      server list, direct IP and password dialogs all end there). The connect only starts after OK.
--      Works when mkev_modpatcher is active in the local mod list of the client (mods\default.txt).
--   2) Fallback in game (OnGameStart, MP client only): if the notice was not confirmed before this connect,
--      it is shown once over the world, clicks into the world are swallowed and the character cannot walk
--      until OK. A multiplayer game cannot be paused.
-- Once per connect: the confirm time is kept in Zomboid/Lua/mkev_connectnotice.txt, because the game resets
-- all Lua state while connecting. Single player, coop host and the dedicated server never see it.
-- Everything runs in pcall; on any error the notice is skipped and the vanilla connect runs unchanged.
-- 3) Local mod list (MP client only, once per session at OnGameStart): if mkev_modpatcher is not yet in the
--    player's local default mod list (mods\default.txt), it is ADDED there with the vanilla API that the mod
--    selector uses (ActiveMods.getById("default"):setModActive(id, true) + saveModsFile()). Nothing else in the
--    list is removed, reordered or changed; the map list stays as it is. The game re-reads that file when the
--    player leaves the server to the main menu, so the main-menu notice (1) works from then on.

MKevModPatcher = MKevModPatcher or {}
local M = MKevModPatcher
local CN = M.connectNotice or {}
M.connectNotice = CN

CN.FILE = "mkev_connectnotice.txt"
CN.MENU_REPEAT_MS = 10 * 60 * 1000   -- menu: no second window within 10 min after OK (retry after a failed connect)
CN.INGAME_VALID_MS = 60 * 60 * 1000  -- game: a menu OK counts for this connect if it is younger than 60 min
CN.BOX_W = 560
CN.TITLE_BLINK_HALF_MS = 500  -- 1.3.2: title on/off every 500 ms (one full blink per second)

local function log(msg, onlyVerbose, onceKey)
    local text = "connectnotice: " .. tostring(msg)
    if M.log then
        M.log(text, onlyVerbose, onceKey)
    elseif not onlyVerbose then
        print("[MKev-ModPatcher] " .. text)
    end
end
CN.log = log

local function call(f, ...)
    if type(f) ~= "function" then return false, nil end
    return pcall(f, ...)
end

-- ---------------------------------------------------------------- language and texts
function CN.languageCode()
    local code
    pcall(function()
        if Translator and Translator.getLanguage then
            local lang = Translator.getLanguage()
            if lang ~= nil then
                local okName, name = pcall(function() return lang:name() end)
                if okName and name ~= nil then code = tostring(name) else code = tostring(lang) end
            end
        end
    end)
    if code == nil or code == "" then
        pcall(function()
            local core = getCore()
            if core and core.getOptionLanguageName then code = tostring(core:getOptionLanguageName()) end
        end)
    end
    if code == nil or code == "" then return "EN" end
    return string.upper(code)
end

function CN.lang()
    if CN.languageCode() == "DE" then return "de" end
    return "en"
end

-- ASCII-only fallbacks, used when the translation key is missing. The real texts with umlauts are in
-- Translate/EN/UI.json (both languages live in EN so they are always loaded; the language is picked here).
CN.FALLBACK = {
    de = {
        title = "HINWEIS",
        p1 = "Dies ist ein Warnhinweis von MKev's Modpatcher!",
        p2 = "Beim Laden dieser grossen Mod-Collection kann es zu Verzoegerungen kommen, die sich wie folgt bemerkbar machen: Windows kann die Sanduhr oder den drehenden Ladekreis anzeigen. Waehrenddessen bitte keine Tasten druecken und nicht ins Spielfenster klicken. Einfach warten, das Spiel arbeitet noch.",
        p3 = "Dies tritt vorwiegend nach der Charaktererstellung auf, wenn die Welt generiert wird (\"{click}\"), kann aber auch schon beim Verbinden mit dem Server auftreten.",
        p4head = "ACHTUNG!",
        p4 = " - In seltenen Faellen kann es beim ersten Verbinden zu einem Verbindungs-Timeout kommen, der eine Fehlermeldung anzeigt:",
        err = "Leider ist ein unerwarteter Fehler aufgetreten.",
        p5 = "In dem Fall einfach den Client neu starten und neu verbinden.",
        ok = "OK, verstanden",
        click = "Zum Starten klicken",
    },
    en = {
        title = "CAUTION",
        p1 = "This is a warning from MKev's Modpatcher!",
        p2 = "Loading this large mod collection can cause delays that show up like this: Windows may show the hourglass or the spinning loading circle. While that happens, please don't press any keys and don't click into the game window. Just wait, the game is still working.",
        p3 = "This mostly happens after character creation, while the world is being generated (\"{click}\"), but it can also happen while connecting to the server.",
        p4head = "ATTENTION!",
        p4 = " - In rare cases, the first connection can hit a connection timeout that shows an error message:",
        err = "Sorry, an unexpected error occurred.",
        p5 = "If that happens, just restart the client and connect again.",
        ok = "OK, got it",
        click = "Click to Start",
    },
}

function CN.text(lang, field)
    local fb = CN.FALLBACK[lang] or CN.FALLBACK.en
    local key = "UI_mkevmp_cn_" .. field .. "_" .. lang
    local ok, s = call(getText, key)
    if ok and type(s) == "string" and s ~= "" and s ~= key then return s end
    return fb[field] or CN.FALLBACK.en[field] or ""
end

-- The exact "Click to start" label the loading screen shows (vanilla key UI_ClickToSkip).
function CN.clickLabel(lang)
    local ok, s = call(getText, "UI_ClickToSkip")
    if ok and type(s) == "string" and s ~= "" and s ~= "UI_ClickToSkip" then return s end
    return (CN.FALLBACK[lang] or CN.FALLBACK.en).click
end

-- Exact game wording of UI_GameLoad_UnexpectedError1, wrapped in typographic quotes.
-- DE quotes U+201E/U+201C, EN quotes U+201C/U+201D. The quoted text itself stays unchanged.
function CN.quotedError(lang)
    local s = CN.text(lang, "err")
    if lang == "de" then
        return "\226\128\158" .. s .. "\226\128\156"
    end
    return "\226\128\156" .. s .. "\226\128\157"
end

function CN.texts()
    local lang = CN.lang()
    -- {click} is our own placeholder (a %1 in the json would make the game log a format warning)
    local label = string.gsub(CN.clickLabel(lang), "%%", "%%%%")
    local p3 = string.gsub(CN.text(lang, "p3"), "{click}", label)
    return {
        lang = lang,
        title = CN.text(lang, "title"),
        paragraphs = { CN.text(lang, "p1"), CN.text(lang, "p2"), p3 },
        p4head = CN.text(lang, "p4head"),
        p4rest = CN.text(lang, "p4"),
        quote = CN.quotedError(lang),
        after = { CN.text(lang, "p5") },
        ok = CN.text(lang, "ok"),
    }
end

-- Word wrap. measure(s) -> pixel width. A single word wider than maxW gets its own line.
function CN.wrap(text, maxW, measure)
    local lines, cur = {}, nil
    for word in string.gmatch(tostring(text or ""), "%S+") do
        if cur == nil then
            cur = word
        else
            local test = cur .. " " .. word
            local okM, w = pcall(measure, test)
            if okM and type(w) == "number" and w <= maxW then
                cur = test
            else
                lines[#lines + 1] = cur
                cur = word
            end
        end
    end
    if cur ~= nil then lines[#lines + 1] = cur end
    return lines
end

-- Word wrap for a red prefix plus normal rest on the same paragraph (1.3.2, p4).
-- First line is "PREFIX" (red) + rest words that still fit; later lines are rest only.
-- Leading spaces of rest are kept on the first line (so " - " / " – " stays after the prefix).
function CN.wrapMixed(prefix, rest, maxW, measure)
    local lines = {}
    local pre = tostring(prefix or "")
    local restText = tostring(rest or "")
    local function width(s)
        local okM, w = pcall(measure, s)
        if okM and type(w) == "number" then return w end
        return 0
    end
    local preW = 0
    if pre ~= "" then preW = width(pre) end
    if pre ~= "" and (restText == "" or preW >= maxW) then
        lines[#lines + 1] = { { text = pre, red = true } }
        pre, preW = "", 0
        if restText == "" then return lines end
    end
    local leading, body = string.match(restText, "^(%s*)(.*)$")
    if leading == nil then leading, body = "", restText end
    local first, cur = true, nil
    local function cap()
        if first and preW > 0 then return maxW - preW end
        return maxW
    end
    local function emit()
        local parts = {}
        if first and pre ~= "" then
            parts[#parts + 1] = { text = pre, red = true }
        end
        local text = ""
        if first then text = leading end
        if cur ~= nil then text = text .. cur end
        if text ~= "" then
            parts[#parts + 1] = { text = text, red = false }
        end
        if #parts > 0 then lines[#lines + 1] = parts end
        first = false
        cur = nil
    end
    for word in string.gmatch(body, "%S+") do
        if cur == nil then
            local trial = word
            if first then trial = leading .. word end
            if width(trial) <= cap() then
                cur = word
            else
                if first and pre ~= "" then emit() end
                cur = word
            end
        else
            local trial = cur .. " " .. word
            local shown = trial
            if first then shown = leading .. trial end
            if width(shown) <= cap() then
                cur = trial
            else
                emit()
                cur = word
            end
        end
    end
    if cur ~= nil or (first and pre ~= "") then emit() end
    return lines
end


-- ---------------------------------------------------------------- state file (survives the Lua reset of the connect)
function CN.now()
    local ok, t = call(getTimestampMs)
    if ok and type(t) == "number" then return t end
    return nil
end

function CN.readState()
    local st = {}
    local okR, r = call(getFileReader, CN.FILE, false)
    if not okR or r == nil then return st end
    pcall(function()
        for _ = 1, 10 do
            local line = r:readLine()
            if line == nil then break end
            local k, v = string.match(tostring(line), "^%s*(%a+)%s*=%s*(%d+)%s*$")
            if k and v then st[k] = tonumber(v) end
        end
    end)
    pcall(function() r:close() end)
    return st
end

function CN.writeState(st)
    local okW, w = call(getFileWriter, CN.FILE, true, false)
    if not okW or w == nil then return false end
    local okWrite = pcall(function()
        w:write("# MKev-ModPatcher connect notice, times in ms (getTimestampMs)\n")
        if st.confirmed then w:write("confirmed=" .. string.format("%d", st.confirmed) .. "\n") end
        if st.consumed then w:write("consumed=" .. string.format("%d", st.consumed) .. "\n") end
    end)
    pcall(function() w:close() end)
    return okWrite
end

local function recentlyConfirmed(st, now, maxAge)
    if not now or not st.confirmed then return false end
    local age = now - st.confirmed
    if age < 0 or age >= maxAge then return false end
    if st.consumed and st.consumed >= st.confirmed then return false end
    return true
end

-- Main menu: show unless OK was clicked shortly before and that OK was not used by a game yet.
function CN.shouldShowMenu(st, now)
    return not recentlyConfirmed(st or {}, now, CN.MENU_REPEAT_MS)
end

-- In game: skip if the menu OK belongs to this connect.
function CN.menuConfirmedForThisConnect(st, now)
    return recentlyConfirmed(st or {}, now, CN.INGAME_VALID_MS)
end

-- ---------------------------------------------------------------- window
local function screenSize()
    local w, h = 1280, 720
    pcall(function()
        local core = getCore()
        w = core:getScreenWidth()
        h = core:getScreenHeight()
    end)
    return w, h
end

local function measureFn(font)
    return function(s)
        return getTextManager():MeasureStringX(font, s)
    end
end

local function fontHeight(font, default)
    local ok, h = pcall(function() return getTextManager():getFontHeight(font) end)
    if ok and type(h) == "number" and h > 0 then return h end
    return default
end

local function titleAlpha()
    -- 1 Hz blink: 500 ms visible, 500 ms hidden. Gold colour stays; only alpha changes.
    -- prerender already runs once per UI frame, so this is just two arithmetic ops.
    local ok, now = pcall(getTimestampMs)
    if not ok or type(now) ~= "number" then return 1 end
    local half = CN.TITLE_BLINK_HALF_MS or 500
    if math.floor(now / half) % 2 == 0 then return 1 end
    return 0
end

local function drawPanel(self)
    local L = self.mkevLayout
    if not L then return end
    self:drawRect(0, 0, self.width, self.height, 0.55, 0, 0, 0)
    self:drawRect(L.bx, L.by, L.bw, L.bh, 0.96, 0.09, 0.09, 0.10)
    self:drawRectBorder(L.bx, L.by, L.bw, L.bh, 1, 0.75, 0.62, 0.25)
    self:drawTextCentre(L.title, L.bx + L.bw / 2, L.by + L.pad, 1, 0.85, 0.4, titleAlpha(), L.titleFont)
    local y = L.textTop
    for i = 1, #L.lines do
        local line = L.lines[i]
        local parts = line.parts
        if not parts then
            parts = { { text = line.text or line, red = line.red } }
        end
        local x = L.bx + L.pad
        for p = 1, #parts do
            local part = parts[p]
            local text = part.text or ""
            if text ~= "" then
                local r, g, b = 0.92, 0.92, 0.92
                if part.red then
                    r, g, b = 1.0, 0.22, 0.18
                end
                self:drawText(text, x, y, r, g, b, 1, L.bodyFont)
                local w = part.w
                if type(w) ~= "number" then
                    local okM, mw = pcall(function() return getTextManager():MeasureStringX(L.bodyFont, text) end)
                    w = (okM and type(mw) == "number") and mw or 0
                end
                x = x + w
            end
        end
        y = y + L.lineH
    end
end


function CN.getClass()
    if CN.cls then return CN.cls end
    local base = ISPanelJoypad or ISPanel
    if type(base) ~= "table" or type(base.derive) ~= "function" then return nil end
    local C = base:derive("MKevConnectNotice")
    function C:prerender()
        local ok, err = pcall(drawPanel, self)
        if not ok then log("draw error " .. tostring(err), false, "drawerr") end
    end
    function C.render() end
    -- swallow clicks outside the OK button, so nothing behind the notice gets them
    function C.onMouseDown() return true end
    function C.onMouseUp() return true end
    function C.onRightMouseDown() return true end
    function C.onRightMouseUp() return true end
    function C.onMouseWheel() return true end
    function C.onJoypadDown(_, button)
        pcall(function()
            if Joypad and button == Joypad.AButton then CN.confirm() end
        end)
    end
    CN.cls = C
    return C
end

local function layout(t)
    local sw, sh = screenSize()
    local titleFont = UIFont and UIFont.Medium
    local bodyFont = UIFont and UIFont.Small
    local pad = 16
    local bw = math.min(CN.BOX_W, sw - 40)
    local lineH = fontHeight(bodyFont, 16) + 2
    local titleH = fontHeight(titleFont, 22)
    local measure = measureFn(bodyFont)

    local function measurePart(s)
        local okM, w = pcall(measure, s)
        if okM and type(w) == "number" then return w end
        return 0
    end

    local function stampWidths(parts)
        for j = 1, #parts do
            parts[j].w = measurePart(parts[j].text or "")
        end
        return { parts = parts }
    end

    local function add_para(lines, text, red, maxW)
        if #lines > 0 then lines[#lines + 1] = stampWidths({ { text = "", red = false } }) end
        local wrapped = CN.wrap(text, maxW, measure)
        for j = 1, #wrapped do
            lines[#lines + 1] = stampWidths({ { text = wrapped[j], red = red and true or false } })
        end
    end

    local function add_mixed(lines, prefix, rest, maxW)
        if #lines > 0 then lines[#lines + 1] = stampWidths({ { text = "", red = false } }) end
        local wrapped = CN.wrapMixed(prefix, rest, maxW, measure)
        for j = 1, #wrapped do
            lines[#lines + 1] = stampWidths(wrapped[j])
        end
    end

    local function build(usePad, useLineH)
        local lines = {}
        local maxW = bw - 2 * usePad
        for i = 1, #t.paragraphs do
            add_para(lines, t.paragraphs[i], false, maxW)
        end
        if (t.p4head and t.p4head ~= "") or (t.p4rest and t.p4rest ~= "") then
            add_mixed(lines, t.p4head or "", t.p4rest or "", maxW)
        end
        if t.quote and t.quote ~= "" then
            add_para(lines, t.quote, true, maxW)
        end
        if t.after then
            for i = 1, #t.after do
                add_para(lines, t.after[i], false, maxW)
            end
        end
        local btnH = fontHeight(bodyFont, 16) + 10
        local bh = usePad + titleH + usePad + #lines * useLineH + usePad + btnH + usePad
        local bx = math.floor((sw - bw) / 2)
        local by = math.floor(math.max(10, (sh - bh) / 2))
        return {
            sw = sw, sh = sh, bx = bx, by = by, bw = bw, bh = bh, pad = usePad,
            title = t.title, titleFont = titleFont, bodyFont = bodyFont,
            lines = lines, lineH = useLineH, textTop = by + usePad + titleH + usePad,
            btnH = btnH, btnW = 160, btnY = by + bh - usePad - btnH,
        }
    end

    local bodyH = fontHeight(bodyFont, 16)
    local L = build(pad, lineH)
    -- Keep the full text visible on short screens (e.g. 1280x720): tighten padding, then line gap.
    if L.bh > sh - 20 then
        L = build(12, lineH)
    end
    if L.bh > sh - 20 then
        L = build(10, bodyH + 1)
    end
    if L.bh > sh - 20 then
        L = build(8, bodyH)
    end
    if L.bh > sh - 20 then
        L = build(6, bodyH)
    end
    return L
end


local function setPlayerBlocked(on)
    pcall(function()
        local p = getPlayer and getPlayer()
        if not p then return end
        if on then
            local okPrev, prev = pcall(function() return p:isBlockMovement() end)
            CN.prevBlock = okPrev and prev == true
            p:setBlockMovement(true)
            CN.blocked = true
        elseif CN.blocked then
            p:setBlockMovement(CN.prevBlock == true)
            CN.blocked = false
        end
    end)
end

-- Safety net: if the window is gone without OK (UI reset, error), never leave the character blocked.
local function watchdog()
    pcall(function()
        CN.wdTicks = (CN.wdTicks or 0) + 1
        if CN.wdTicks < 30 then return end
        CN.wdTicks = 0
        local p = CN.panel
        local alive = false
        if p ~= nil then
            local okV, vis = pcall(function() return p:getIsVisible() end)
            alive = (not okV) or vis ~= false
        end
        if not alive then
            if CN.blocked then setPlayerBlocked(false) end
            if Events and Events.OnTick then Events.OnTick.Remove(watchdog) end
            CN.wdOn = false
        end
    end)
end

-- show(mode, onOk): mode "menu" or "game". Returns true if the window is open.
function CN.show(mode, onOk)
    if CN.panel then return true end
    local C = CN.getClass()
    if not C or type(ISButton) ~= "table" then return false end
    local t = CN.texts()
    local L = layout(t)
    local panel = C:new(0, 0, L.sw, L.sh)
    panel.mkevLayout = L
    panel.mkevMode = mode
    panel.background = false
    panel.moveWithMouse = false
    panel:initialise()
    local btn = ISButton:new(L.bx + math.floor((L.bw - L.btnW) / 2), L.btnY, L.btnW, L.btnH, t.ok, panel,
        function() CN.confirm() end)
    btn:initialise()
    if btn.instantiate then btn:instantiate() end
    if btn.enableAcceptColor then btn:enableAcceptColor() end
    panel:addChild(btn)
    panel.mkevOk = btn
    panel:addToUIManager()
    if panel.setAlwaysOnTop then panel:setAlwaysOnTop(true) end
    if panel.bringToTop then panel:bringToTop() end
    CN.panel = panel
    CN.onOk = onOk
    CN.mode = mode
    pcall(function()
        local jd = JoypadState and JoypadState.getMainMenuJoypad and JoypadState.getMainMenuJoypad()
        if mode == "menu" and jd then
            CN.prevJoyFocus = jd.focus
            jd.focus = panel
            if updateJoypadFocus then updateJoypadFocus(jd) end
        end
    end)
    if mode == "game" then
        setPlayerBlocked(true)
        if not CN.wdOn and Events and Events.OnTick then
            Events.OnTick.Add(watchdog)
            CN.wdOn = true
        end
    end
    log("shown (" .. tostring(mode) .. ", language " .. tostring(t.lang) .. ")", false, nil)
    return true
end

function CN.confirm()
    local p = CN.panel
    if not p then return false end
    CN.panel = nil
    pcall(function() p:setVisible(false) end)
    pcall(function() p:removeFromUIManager() end)
    pcall(function()
        local jd = JoypadState and JoypadState.getMainMenuJoypad and JoypadState.getMainMenuJoypad()
        if jd and jd.focus == p then
            jd.focus = CN.prevJoyFocus
            if updateJoypadFocus then updateJoypadFocus(jd) end
        end
    end)
    CN.prevJoyFocus = nil
    if CN.mode == "game" then setPlayerBlocked(false) end
    local now = CN.now()
    if now then
        local st = { confirmed = now }
        if CN.mode == "game" then st.consumed = now end
        pcall(CN.writeState, st)
    end
    log("confirmed (" .. tostring(CN.mode) .. ")", false, nil)
    local cb = CN.onOk
    CN.onOk = nil
    if cb then
        local ok, err = pcall(cb)
        if not ok then log("continue error " .. tostring(err), false, nil) end
    end
    return true
end

-- ---------------------------------------------------------------- 1) main menu: before the connect
-- Returns true when the connect was deferred (window open), false when the vanilla connect should run now.
function CN.preConnect(self, args, orig)
    if CN.panel then return true end -- a second click on Join while the notice is open: ignore
    local st = CN.readState()
    if not CN.shouldShowMenu(st, CN.now()) then return false end
    return CN.show("menu", function()
        orig(self, args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11])
    end) == true
end

function CN.installMenuHook()
    if CN.hooked then return true end
    if type(isClient) == "function" and isClient() then return false end -- already in a MP game
    if type(ConnectToServer) ~= "table" or type(ConnectToServer.connect) ~= "function" then return false end
    local orig = ConnectToServer.connect
    CN.origConnect = orig
    ConnectToServer.connect = function(self, previousScreen, serverName, userName, password, IP, localIP, port,
                                       serverPassword, useSteamRelay, doHash, authType)
        local args = { previousScreen, serverName, userName, password, IP, localIP, port,
                       serverPassword, useSteamRelay, doHash, authType }
        local ok, deferred = pcall(CN.preConnect, self, args, orig)
        if ok and deferred then return end
        if not ok then log("error, connecting without notice: " .. tostring(deferred), false, "prefail") end
        return orig(self, previousScreen, serverName, userName, password, IP, localIP, port,
            serverPassword, useSteamRelay, doHash, authType)
    end
    CN.hooked = true
    log("menu hook active", true, "menuhook")
    return true
end

-- ---------------------------------------------------------------- 2) in game: fallback after loading
-- Local mod list: add only our own id to ActiveMods "default" and save it like the vanilla mod selector does.
CN.MOD_ID = "mkev_modpatcher"

-- Context check for the mod list step. Returns nil if allowed, otherwise the reason (no-op).
function CN.modlistContext()
    if type(isServer) == "function" and isServer() then return "server" end
    if type(isClient) ~= "function" or not isClient() then return "single player" end
    if type(isCoopHost) == "function" and isCoopHost() then return "coop host" end
    return nil
end

-- Returns "added", "already" or "failed", plus a reason for "failed". Never throws.
function CN.ensureLocalModlist()
    if CN.modlistDone then return CN.modlistResult, CN.modlistReason end
    local skip = CN.modlistContext()
    if skip then return "skip", skip end
    CN.modlistDone = true -- once per session
    local result, reason
    local ok, err = pcall(function()
        if type(ActiveMods) ~= "table" and type(ActiveMods) ~= "userdata" then
            result, reason = "failed", "ActiveMods missing"
            return
        end
        if type(saveModsFile) ~= "function" then
            result, reason = "failed", "saveModsFile missing"
            return
        end
        local core = type(getCore) == "function" and getCore() or nil
        if core and core.getOptionModsEnabled and core:getOptionModsEnabled() == false then
            result, reason = "failed", "mods disabled in the game options"
            return
        end
        local am = ActiveMods.getById("default")
        if am == nil then
            result, reason = "failed", "default mod list not found"
            return
        end
        local id = CN.MOD_ID
        if am:isModActive(id) or am:isModActive("\\" .. id) then
            result = "already"
            return
        end
        am:setModActive(id, true)
        if not am:isModActive(id) then
            result, reason = "failed", "setModActive had no effect"
            return
        end
        local okSave, errSave = pcall(saveModsFile)
        if not okSave then
            pcall(function() am:setModActive(id, false) end) -- keep memory and file in step (only our own id)
            result, reason = "failed", "saveModsFile: " .. tostring(errSave)
            return
        end
        result = "added"
    end)
    if not ok then result, reason = "failed", tostring(err) end
    CN.modlistResult, CN.modlistReason = result, reason
    if result == "added" then
        log("added to local modlist", false, "modlist")
    elseif result == "already" then
        log("already active", false, "modlist")
    else
        log("failed: " .. tostring(reason), false, "modlist")
    end
    return result, reason
end

function CN.onGameStart()
    if CN.ingameDone then return end
    CN.ingameDone = true -- once per session, whatever happens below
    if type(isClient) ~= "function" or not isClient() then return end -- single player / server: never
    if type(isCoopHost) == "function" and isCoopHost() then return end
    pcall(CN.ensureLocalModlist)
    local now = CN.now()
    local st = CN.readState()
    if CN.menuConfirmedForThisConnect(st, now) then
        st.consumed = now
        pcall(CN.writeState, st)
        log("already confirmed before connect", true, "skipgame")
        return
    end
    CN.show("game", nil)
end

local function safeInstall()
    local ok, err = pcall(CN.installMenuHook)
    if not ok then log("hook error " .. tostring(err), false, "hookerr") end
end

local function safeGameStart()
    local ok, err = pcall(CN.onGameStart)
    if not ok then
        log("error " .. tostring(err), false, "gameerr")
        if CN.blocked then setPlayerBlocked(false) end
    end
end

if not CN.loaded then
    CN.loaded = true
    safeInstall()
    if Events then
        if Events.OnGameBoot then Events.OnGameBoot.Add(safeInstall) end
        if Events.OnMainMenuEnter then Events.OnMainMenuEnter.Add(safeInstall) end
        if Events.OnGameStart then Events.OnGameStart.Add(safeGameStart) end
    end
end
