-- UPSTREAM-WORKAROUND: vanilla B42 ISReloadWeaponAction.setReloadSpeed (UPSTREAM.md U16).
-- Remove once TIS nil-checks strap:getClothingItemName() at lines 100 and 102.
--
-- Problem (B42 42.21, client and server, shared function):
--   setReloadSpeed reads character:getWornItem(ItemBodyLocation.AMMO_STRAP) and then, when a
--   RELOAD_FAST_* tag is equipped or worn and the primary item is not a shotgun or a
--   magazine-fed gun, calls strap:getClothingItemName() without a nil check.
--   Kahlua: "attempted index: getClothingItemName of non-table: null".
--   The timed action then dies in start() (endless reload). Seen 12.11.2026 ~20:59 in
--   console.txt: vanilla ISLoadBulletsInMagazine:initVars -> Doberman wrapper
--   (CompanionDogsDob_Moodle.lua:95, pass-through plus optional multiplier) -> vanilla line 102.
--   Vanilla SHA256 (client and dedicated server, identical):
--   AC1248AE26A62BBF9E3D25C34773987334ADCD9EB7033291F579DA1B925C224B
--
-- Fix: a 1:1 copy of the current vanilla function, with only
--   `strap and strap:getClothingItemName() == ...` at the two unguarded calls.
--   This file is shared, so it runs on the dedicated server and on clients.
--   Shared Lua loads before all client Lua, so later client wrappers (Doberman) capture
--   the already-guarded function. This mod loads last among the pack, so earlier
--   *shared* wrappers or overrides (BritasArmorPackB42, and on the VFE list VFExpansion)
--   have already replaced the slot. A hard replace would drop those wrappers.
--   Therefore the live slot is wrapped: existing wrappers stay in the chain, and if the
--   captured vanilla (or VFE's still-unguarded copy) throws the nil-strap error, the
--   nil-safe vanilla body sets ReloadSpeed and the error is not logged.
--   BritasArmorReloadCompat.OriginalSetReloadSpeed is retargeted the same way when present.
--
-- Scope: shared, server and client. No new log errors for this crash path.

require "TimedActions/ISReloadWeaponAction"

local function log(m, v, k)
	local M = MKevModPatcher
	if M and M.log then
		M.log(m, v, k)
	elseif not v then
		print("[MKev-ModPatcher] " .. m)
	end
end

-- Exact vanilla B42 42.21 body (ISReloadWeaponAction.lua lines 75-114), with only
-- the two strap:getClothingItemName() calls made nil-safe.
local function setReloadSpeedSafe(character, rack)
	local baseReloadSpeed = 0.8;
	if rack then
		-- reloading skill has less impact on racking, panic does nothing
		baseReloadSpeed = baseReloadSpeed + (character:getPerkLevel(Perks.Reloading) * 0.04);
	else
		baseReloadSpeed = baseReloadSpeed + (character:getPerkLevel(Perks.Reloading) * 0.10);
		baseReloadSpeed = baseReloadSpeed - (character:getMoodles():getMoodleLevel(MoodleType.PANIC) * 0.05);
	end

	-- check for ammo straps
	local gun = character:getPrimaryHandItem();
	local strap = character:getWornItem(ItemBodyLocation.AMMO_STRAP);
	local reloadFast = character:hasEquippedTag(ItemTag.RELOAD_FAST_SHELLS) or character:hasEquippedTag(ItemTag.RELOAD_FAST_BULLETS) or character:hasEquippedTag(ItemTag.RELOAD_FAST_MAGAZINES)
	local strapFound = false;
	if gun and (reloadFast or character:hasWornTag(ItemTag.RELOAD_FAST_MAGAZINES) or (strap and strap:getClothingItem())) then
		local shell = false;
		local magazine = false;
		if gun:getAmmoType() == AmmoType.SHOTGUN_SHELLS then
			shell = true;
		elseif gun:getMagazineType() then
			magazine = true;
		end
		if magazine and (character:hasEquippedTag(ItemTag.RELOAD_FAST_MAGAZINES) or character:hasWornTag(ItemTag.RELOAD_FAST_MAGAZINES)) then
			strapFound = true;
		elseif shell and (character:hasEquippedTag(ItemTag.RELOAD_FAST_SHELLS) or character:hasWornTag(ItemTag.RELOAD_FAST_SHELLS) or strap and strap:getClothingItemName() == "AmmoStrap_Shells") then
			strapFound = true;
		elseif not shell and not magazine and (character:hasEquippedTag(ItemTag.RELOAD_FAST_BULLETS) or character:hasWornTag(ItemTag.RELOAD_FAST_BULLETS) or strap and strap:getClothingItemName() == "AmmoStrap_Bullets") then
			strapFound = true;
		end
	end
	if strapFound then
		baseReloadSpeed = baseReloadSpeed * 1.15;
	end
	-- vehicles driver take bit longer to reload their weapon
	if character:getVehicle() and character:getVehicle():getDriver() == character then
		baseReloadSpeed = baseReloadSpeed * 0.8;
	end
	character:setVariable("ReloadSpeed", baseReloadSpeed);
end

local function isNilStrapError(err)
	return string.find(tostring(err), "getClothingItemName", 1, true) ~= nil
end

local recovered = false

local function guardExisting(fn)
	return function(character, rack, ...)
		local ok, err = pcall(fn, character, rack, ...)
		if ok then
			return err
		end
		if isNilStrapError(err) then
			setReloadSpeedSafe(character, rack)
			if not recovered then
				recovered = true
				log("setReloadSpeed: recovered a nil ammo-strap call", false, "reloadspeed")
			end
			return
		end
		error(err)
	end
end

if type(ISReloadWeaponAction) ~= "table" then
	return
end
if ISReloadWeaponAction.mkevmpReloadSpeedGuard then
	return
end

if type(ISReloadWeaponAction.setReloadSpeed) ~= "function" then
	ISReloadWeaponAction.setReloadSpeed = setReloadSpeedSafe
else
	if type(BritasArmorReloadCompat) == "table" and type(BritasArmorReloadCompat.OriginalSetReloadSpeed) == "function" then
		BritasArmorReloadCompat.OriginalSetReloadSpeed = guardExisting(BritasArmorReloadCompat.OriginalSetReloadSpeed)
	end
	ISReloadWeaponAction.setReloadSpeed = guardExisting(ISReloadWeaponAction.setReloadSpeed)
end
ISReloadWeaponAction.mkevmpReloadSpeedGuard = true
ISReloadWeaponAction.mkevmpSetReloadSpeedSafe = setReloadSpeedSafe
log("setReloadSpeed nil-strap guard installed", false, "reloadspeed")
