-- MKev-ModPatcher: version marker. Grep logs for "[MKev-ModPatcher] version" to confirm which build is loaded.
-- Always logged (also in quiet mode), at most once per process. Server and all clients must show the same version.
MKEV_MODPATCHER_VERSION = "1.3.2"
local function hello()
    local m = "version " .. tostring(MKEV_MODPATCHER_VERSION) .. " loaded"
    local M = MKevModPatcher
    if M and M.log then M.log(m, false, "version") else print("[MKev-ModPatcher] " .. m) end
end
if Events and Events.OnGameBoot then Events.OnGameBoot.Add(hello) end
if Events and Events.OnServerStarted then Events.OnServerStarted.Add(hello) end
