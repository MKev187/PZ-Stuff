MKevServer_setup - ready-made files for setting up yourself
===========================================================
Author: MKev.

The ModPatchInstaller (option 2 "Install only, do not set up") put these files
here. NONE of your settings was changed. No passwords or other secrets are
included.

MKevServer_modlist.txt        Mods= line of the MKev server in load order.
                              In your Zomboid\Server\<name>.ini replace the
                              Mods= line with this line.
MKevServer_workshopitems.txt  WorkshopItems= line (same as above).
MKevServer_map.txt            Map= line (same as above).
MKevServer_SandboxVars.lua    Sandbox settings of the MKev server. For your own
                              server save it as Zomboid\Server\<name>_SandboxVars.lua
                              (back up your own file first).
MKevServer_preset.txt         Mod preset "MKevServer" for the Mods menu: append
                              the line to the end of Zomboid\Lua\pz_modlist_settings.cfg
                              (close the game first).

Everything automatic (with backup): ModPatchInstaller.bat -> option 1.
To play on the MKev server the installed mods are enough;
you only need these files for your own server or for single player.

State: 375 mods / 324 WorkshopItems, Map=Muldraugh, KY (MKev server, build 42.22.2, list refresh 2026-11-13).
I Know It! (iknowit, WS 3836594593) is in Mods= and WorkshopItems=; its files come from the Steam Workshop (collection 3838844490) and are not shipped.
