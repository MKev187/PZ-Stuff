# MKev Modpatch Installer - CHANGELOG

## 1.0 (09.11.2026) - Installer zum Collection-Release

Neues Versionsschema: 1.0 folgt auf 0.3.0 (Release `modcollection-installer-v0.3.0`).
Basis ist die zweisprachige Fassung **0.3.0multi** (EN/DE, Sprachwahl in der `.bat`). Chinesisch folgt später.
Architektur unverändert: ModPatcher, Server-Boot-Patch, Server-Dateien, Preset, Modus 1 (bestehende Server-Dateien anpassen, Logins/Ports bleiben) und Modus 2 (nur Vorlagen nach `Zomboid\MKevServer_setup`).

### Basis
- Spielversion: Build **42.22.2**. Collection **3827894199** "MKev Zomboid Modlist B42.22 (v1.0)": 325 Einträge, als Menge identisch mit den 325 WorkshopItems dieses Pakets (inkl. I Know It! 3836594593).
- Quelle der Daten: `servertest.ini` des MKev-Servers (Mods= und Map= unverändert, WorkshopItems= plus I Know It!, siehe unten), `servertest_SandboxVars.lua` (byteidentisch, SHA256 86ce6f4f…f833, Stand 09.11.2026 18:56), Preset `GrokList42-22` (identisch mit Mods=).

### Mods und WorkshopItems
- Mods: **381 → 376**, WorkshopItems: **329 → 325**, Map unverändert `Muldraugh, KY`.
- Entfernt (Mod-IDs): `Trucksmith`, `RKCLAV25`, `HEMTTM978Tanker`, `GanydeBielovzki's Frockin Stompers! VFR`, `KnoxNetworkTacticalGear`, `ICanClimbLaddersNow`, `IKnewIt`.
- Neu (Mod-IDs): `M13ReadingTweaks` (M-13's Reading Tweaks), `iknowit` (I Know It!, ersetzt I Knew It!).
- Entfernt (Workshop-IDs): 3812497744, 3829093936, 3816356507, 3825638448, 3787667088, 3834998997 (altes I Knew It!).
- Neu (Workshop-IDs): 2776874515 (M-13's Reading Tweaks), 3836594593 (I Know It!).
- I Know It! 3836594593 ist nur im Paket ergänzt (in der Server-`servertest.ini` fehlte sie), an der Stelle von `iknowit` in Mods=: `…;2776874515;3836594593;3736629791;…` (M13ReadingTweaks → I Know It! → Tempo_PerfKit). Damit laden Server der Downloader I Know It! automatisch.
- WorkshopItems= entspricht als Menge exakt den 325 IDs der Collection 3827894199 (Stand 09.11.2026).

### Ladereihenfolge (aus servertest.ini übernommen)
- `NoVanillaVehicles/NoVanillaProf/NoVanillaStoriesKI5/NoVanillaDuplicates` jetzt direkt nach `VVR` (vorher vor den KI5-Fahrzeugen).
- Waffenblock neu sortiert: `SwapIt` vor `LowConditionGuns`; `ImprovisedSilencers`, `ImprovisedSilencersVFEPatch`, `HBAmmoCraft`, `HBTacReload` direkt nach den VFE-Erweiterungen; `ArcheryNexusFixed` nach `AluminumBat`.
- Wissen/Medien: `GydeTraitMags`, `WorkingKnowledge`, `FirstAidVHSTapes`, `NamedSkillVHSTapes` direkt nach `SkillBookExpansionB42`; `AftermathRadio` nach `NewMusicGravesAll`.
- Strom/Wetter/Medizin neu gruppiert (`UsefulBarrelsMP`, `PFR`, `PWS`, `ImmersiveSnow`, `UnseasonalWeather`, `Proper_Infected_Wounds_b42`, `PainkillersRemoveMuscleStrain`, `TheOnlyCurePlus*`).
- `RebalancedPropMoving`, `dustinguished_bolt_cutters`, `ProperPickaxe`, `DynamicGearRattling` in den Gameplay-Block verschoben; `ProjectALifeNPCs/ProjectALifeJimmy` jetzt nach `ReactiveSE`.
- Ende unverändert: `… M13ReadingTweaks;iknowit;Tempo_PerfKit;LetMeDrive;mkev_modpatcher;mkevserverbootpatch`.

### Sandbox (servertest_SandboxVars.lua)
- Geändert: `WaterShutModifier` 18 → 3, `ElecShutModifier` 15 → 22.
- Entfernt: Optionen von Trucksmith, LAV-25 (`LAV25W`), `HEMTT978`, `KnoxNetworkTacticalGear`, die `WQS_*`-Optionen (Wolf Extraction Quest) sowie 20 alte I Knew It!-Optionen (Lese- und Anzeigeoptionen).
- Neu: Project A-Life (`ALife`, `ALifeJimmy`), `M13ReadingTweaks`, `IKnowIt.SkillBookFeature`, `ImmersiveSnow.BloodyFootprintsNoSnow`, `EnteBaseAutosorter`, `WhoseKeyIsThis`.

### Versionen
- Installer (`.bat`, `ModPatchInstaller_en.ps1`, `ModPatchInstaller_de.ps1`): 0.3.0 → **1.0** (interne Version `$script:Version = '1.0'`). Sonst keine Codeänderung.
- `mkev_modpatcher` 0.1.11 und `mkevserverbootpatch` 1.1.0: unverändert, byteidentisch zu 0.3.0.
- Neu im Paket: `CHANGELOG.md`; `ReadMe_DE.md`/`ReadMe_EN.md` und `MKevServer_setup`-Anleitungen aktualisiert.
- Zip-Name neu: `MKev-Modpatch-Installer-v1.0.zip`.

### Sicherheit
- Keine `servertest.ini` im Paket, nur die Zeilen Mods=, WorkshopItems=, Map=. Build-Prüfung: keine Passwörter, RCON, Ports, PublicName, Discord-Token in `MKevServer_setup`.
- Modus 1 ersetzt in `servertest.ini` weiterhin NUR Mods=, WorkshopItems=, Map=. Passwörter, Ports und Logins werden nie überschrieben.

---

## English summary

1.0 (2026-11-09), the installer for the collection release. It replaces 0.3.0 and is based on the bilingual 0.3.0multi edition (EN/DE). The architecture is unchanged.
- Base: build 42.22.2, collection 3827894199 (325 items, identical as a set to the package's 325 WorkshopItems).
- Mods 381 → 376, WorkshopItems 329 → 325. Removed: Trucksmith, RKCLAV25, HEMTTM978Tanker, Frockin Stompers! VFR, KnoxNetworkTacticalGear, ICanClimbLaddersNow, IKnewIt. Added: M13ReadingTweaks, iknowit (WS +2776874515, +3836594593 inserted between M13ReadingTweaks and Tempo_PerfKit, −6 IDs).
- Load order taken 1:1 from the server's servertest.ini. There are several block moves (NoVanilla* after VVR, weapons, skills/VHS, weather/medical, A-Life after ReactiveSE).
- Sandbox: WaterShutModifier 18→3 and ElecShutModifier 15→22. Options of removed mods were dropped. A-Life, M-13 Reading Tweaks, I Know It! and others were added.
- Installer version 1.0. mkev_modpatcher 0.1.11 and mkevserverbootpatch 1.1.0 are unchanged. No credentials are shipped, and mode 1 never touches passwords or ports.
