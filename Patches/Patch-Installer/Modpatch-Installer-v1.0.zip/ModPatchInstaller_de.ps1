# ModPatchInstaller.ps1 - MKev Modpatch Installer 1.0 for players
# Installs mkev_modpatcher 0.1.11 + mkevserverbootpatch 1.1.0 and (option 1) the MKev server setup.
# I Know It! is not installed by this installer (it comes from the Steam Workshop like every other collection mod).
# Author: MKev..
# Started by ModPatchInstaller.bat. Windows PowerShell 5.1 or newer. ASCII only.
#
# Test switches (environment variables, normally not set):
#   PZ_ZOMBOID          Zomboid folder (default %USERPROFILE%\Zomboid)
#   PZ_WORKSHOP         ';'-list of ...\steamapps\workshop\content\108600 folders (default: found via Steam)
#   PZ_SKIP_PROCCHECK   1 = do not check for a running game/server
#   PZ_CHOICE           menu choice 1..5 (no menu prompt)
#   PZ_CONFIRM          Y or N (answer for every Y/N question)
#   PZ_RESTORE_PICK     number of the backup to restore (1 = newest)
#   PZ_STAMP            fixed backup time stamp (tests only)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$script:Version   = '1.0'
$script:Src       = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:SetupSrc  = Join-Path $script:Src 'MKevServer_setup'
$script:Zomboid   = if ($env:PZ_ZOMBOID) { $env:PZ_ZOMBOID } else { Join-Path $env:USERPROFILE 'Zomboid' }
$script:Zomboid   = $script:Zomboid.TrimEnd('\','/')
$script:BackupRoot = Join-Path $script:Zomboid 'mkev_patch_backups'
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:DryRun    = $false
$script:Log       = New-Object System.Collections.Generic.List[string]
$script:Bak       = $null
$script:BakDone   = @{}
$script:Changes   = 0
$script:FixWhy    = ''

# mod folders in this package: name, required
$script:ModSlots = @(
    @{ Name = 'mkev_modpatcher';     Required = $true; Stage = $false },
    @{ Name = 'mkevserverbootpatch'; Required = $true; Stage = $true  }
)
$script:PresetName = 'MKevServer'
$script:DefaultTxtMod = 'mkev_modpatcher'

# ------------------------------------------------------------------ helpers
function Say([string]$t) { Write-Host $t; $script:Log.Add($t) }
function Rel([string]$p) { if ($p.StartsWith($script:Zomboid)) { return $p.Substring($script:Zomboid.Length).TrimStart('\','/') } return $p }
function P([string]$rel) { return Join-Path $script:Zomboid $rel }

function Ask([string]$q) {
    if ($env:PZ_CONFIRM) { $a = $env:PZ_CONFIRM; Say ("  " + $q + " [J/N]: " + $a + " (automatisch)") }
    else { $a = Read-Host ("  " + $q + " [J/N]") ; $script:Log.Add("  " + $q + " -> " + $a) }
    return ($a -match '^\s*[JjYy]')
}

function Assert-SafePath([string]$p) {
    $full = [System.IO.Path]::GetFullPath($p)
    if ($full -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { throw ("Sicherheitsstopp: Workshop-Ordner wird nie veraendert: " + $full) }
    $root = [System.IO.Path]::GetFullPath($script:Zomboid)
    if (-not $full.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) { throw ("Sicherheitsstopp: Ziel liegt ausserhalb von Zomboid: " + $full) }
}

function Read-Text([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $bom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $text = $script:Utf8NoBom.GetString($bytes)
    if ($bom) { $text = $text.Substring(1) }
    $nl = if ($text.Contains("`r`n")) { "`r`n" } elseif ($text.Contains("`n")) { "`n" } else { "`r`n" }
    $endsNl = $text.EndsWith("`n")
    $lines = @($text -split "`r?`n")
    if ($endsNl) { if ($lines.Count -le 1) { $lines = @() } else { $lines = @($lines[0..($lines.Count - 2)]) } }
    return @{ Lines = $lines; Nl = $nl; Bom = $bom }
}

function Write-TextLines([string]$path, $lines, [string]$nl, [bool]$bom) {
    Assert-SafePath $path
    $dir = Split-Path -Parent $path
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $text = ($lines -join $nl) + $nl
    $enc = if ($bom) { New-Object System.Text.UTF8Encoding($true) } else { $script:Utf8NoBom }
    [System.IO.File]::WriteAllText($path, $text, $enc)
}

function Read-ListFile([string]$name, [string]$key) {
    $f = Join-Path $script:SetupSrc $name
    if (-not (Test-Path -LiteralPath $f)) { throw ("Datei fehlt im Paket: MKevServer_setup\" + $name) }
    foreach ($l in (Read-Text $f).Lines) { if ($l.StartsWith($key + '=')) { return $l.Substring($key.Length + 1) } }
    throw ("Zeile " + $key + "= fehlt in MKevServer_setup\" + $name)
}

function Split-List([string]$v, [string]$sep) { return ,@($v.Split($sep) | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }) }

function Get-DirSig([string]$dir) {
    if (-not (Test-Path -LiteralPath $dir)) { return '' }
    $base = (Get-Item -LiteralPath $dir).FullName.TrimEnd('\','/')
    $items = Get-ChildItem -LiteralPath $dir -Recurse -File -Force | Sort-Object FullName | ForEach-Object {
        $_.FullName.Substring($base.Length).Replace('\','/') + '|' + (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash
    }
    return ($items -join "`n")
}

function Get-ModVersion([string]$dir) {
    foreach ($mi in @((Join-Path $dir '42\mod.info'), (Join-Path $dir 'mod.info'))) {
        if (Test-Path -LiteralPath $mi) {
            foreach ($l in (Read-Text $mi).Lines) { if ($l -match '^modversion=(.*)$') { return $Matches[1].Trim() } }
        }
    }
    return 'unbekannt'
}

# ------------------------------------------------------------------ backup
function New-BackupSession([string]$action) {
    $stamp = if ($env:PZ_STAMP) { $env:PZ_STAMP } else { Get-Date -Format 'yyyy-MM-dd_HHmmss' }
    $name = $stamp + '_' + $action
    $dir = Join-Path $script:BackupRoot $name
    $i = 2
    while (Test-Path -LiteralPath $dir) { $dir = Join-Path $script:BackupRoot ($name + '_' + $i); $i++ }
    $script:Bak = $dir
    $script:BakDone = @{}
}

function Ensure-BackupDir {
    if (-not (Test-Path -LiteralPath $script:Bak)) {
        Assert-SafePath $script:Bak
        New-Item -ItemType Directory -Force -Path (Join-Path $script:Bak 'files') | Out-Null
    }
}

# Back up a file or folder (relative to Zomboid) once per session, before it is changed.
function Backup-Item([string]$rel) {
    if ($script:DryRun) { return }
    if ($script:BakDone.ContainsKey($rel.ToLower())) { return }
    Ensure-BackupDir
    $src = P $rel
    $idx = Join-Path $script:Bak 'backup_index.txt'
    if (Test-Path -LiteralPath $src) {
        $dst = Join-Path (Join-Path $script:Bak 'files') $rel
        $parent = Split-Path -Parent $dst
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
        [System.IO.File]::AppendAllText($idx, ("existed`t" + $rel + "`r`n"), $script:Utf8NoBom)
        Say ("    Backup: " + $rel)
    } else {
        [System.IO.File]::AppendAllText($idx, ("created`t" + $rel + "`r`n"), $script:Utf8NoBom)
    }
    $script:BakDone[$rel.ToLower()] = $true
}

function Save-Log {
    if ($script:DryRun) { return }
    try {
        if (-not (Test-Path -LiteralPath $script:BackupRoot)) { New-Item -ItemType Directory -Force -Path $script:BackupRoot | Out-Null }
        $txt = ($script:Log -join "`r`n") + "`r`n"
        if ($script:Bak -and (Test-Path -LiteralPath $script:Bak)) { [System.IO.File]::WriteAllText((Join-Path $script:Bak 'installer_log.txt'), $txt, $script:Utf8NoBom) }
        $hdr = "==== " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + " ModPatchInstaller " + $script:Version + "`r`n"
        [System.IO.File]::AppendAllText((Join-Path $script:BackupRoot 'installer_log.txt'), ($hdr + $txt), $script:Utf8NoBom)
    } catch { Write-Host ("  Hinweis: Log konnte nicht gespeichert werden: " + $_.Exception.Message) }
}

# ------------------------------------------------------------------ checks
function Test-PzRunning {
    if ($env:PZ_SKIP_PROCCHECK) { Say "  Prozess-Pruefung uebersprungen (Testmodus)."; return $false }
    $hit = @()
    foreach ($n in @('ProjectZomboid64', 'ProjectZomboid32', 'ProjectZomboidServer')) {
        if (Get-Process -Name $n -ErrorAction SilentlyContinue) { $hit += ($n + '.exe') }
    }
    $javas = @()
    try { $javas = @(Get-CimInstance Win32_Process -Filter "Name='java.exe' OR Name='javaw.exe'" -ErrorAction Stop) }
    catch { $javas = @(Get-Process -Name java, javaw -ErrorAction SilentlyContinue | ForEach-Object { New-Object PSObject -Property @{ Name = $_.ProcessName + '.exe'; CommandLine = $null } }) }
    foreach ($j in $javas) {
        $cl = $j.CommandLine
        if ((-not $cl) -or ($cl -match '(?i)zomboid|zombie\.network|zombie\.gameStates|ProjectZomboid')) { $hit += ($j.Name + ' (vermutlich PZ-Server)') }
    }
    if ($hit.Count -gt 0) {
        Say "  ABBRUCH: Project Zomboid oder der PZ-Server laeuft noch:"
        foreach ($h in ($hit | Select-Object -Unique)) { Say ("    - " + $h) }
        Say "  Bitte Spiel UND Server komplett schliessen (Server mit 'quit') und neu starten."
        return $true
    }
    Say "  OK: Spiel und Server laufen nicht."
    return $false
}

function Test-Package {
    $ok = $true
    foreach ($s in $script:ModSlots) {
        $d = Join-Path $script:Src $s.Name
        if ((-not (Test-Path -LiteralPath $d)) -and $s.Required) { Say ("  FEHLER: Ordner fehlt im Paket: " + $s.Name); $ok = $false }
    }
    if (-not (Test-Path -LiteralPath $script:SetupSrc)) { Say "  FEHLER: Ordner MKevServer_setup fehlt im Paket."; $ok = $false }
    return $ok
}

# ------------------------------------------------------------------ boot patch: build at install time
# The 3 script fixes of mkevserverbootpatch are NOT shipped as file copies (the originals belong to their
# authors). The installer reads the file from YOUR installed Workshop copy, checks it is exactly the version
# the fix was made for (SHA256), changes only the listed text and checks the result (SHA256) again.
# Workshop folders are only read, never written.
$script:BootFixes = @(
    @{ Id = 'F1'; Label = 'Archery Nexus [Fixed]: Carpentry -> Woodwork'
       Src = '3731579266\mods\ArcheryNexusFixed\common\media\scripts\recipes\recipes_fletching.txt'
       Dst = '42\media\scripts\recipes\recipes_fletching.txt'
       SrcSha = '68B87D921EAEB41D2799919BDB75446FB9EBCFAD98376174A7D89FAEF0096678'
       OutSha = '05A17570A07265A578E893CB6E0CF70A5DF61EF9ECC0304C791B0F24A7FFB251'
       Edits = @( ,@('Carving:5;Carpentry:3', 'Carving:5;Woodwork:3', 1) )
       NewerBase = ''; Pinned = '' },
    @{ Id = 'F2'; Label = 'Mad Crafter: Electrical -> Electricity'
       Src = '3418701509\mods\MadCrafter\42.15\media\scripts\recipes\recipes_MCR_1Handed.txt'
       Dst = '42\media\scripts\recipes\recipes_MCR_1Handed.txt'
       SrcSha = '7B4591967E8FC50B337E6C210D2BC0C28B9CC5ECBC565CE41DE2567FD437CFEF'
       OutSha = '2D8F91B399309286738C33745A4960B5F0A851DF134C1704FFC5875E667E1209'
       Edits = @( ,@('Electrical:', 'Electricity:', 6) )
       NewerBase = '3418701509\mods\MadCrafter'; Pinned = '42.15' },
    @{ Id = 'F3'; Label = 'Zombie Virus Vaccine: Injection_A sound'
       Src = '3615135168\mods\ZVirusVaccine42BETA\42.20\media\scripts\sounds\LabSounds.txt'
       Dst = '42\media\scripts\sounds\LabSounds.txt'
       SrcSha = '85F28B209C94105F597900691C92E8E52D277871175E9B36241C974309F18FCD'
       OutSha = '5B674938425FB04DFC6FA85419D2678C57778B32F4ED4FE6EC63F1B02DDBF1FE'
       Edits = @( ,@('//Royalty-free injection sound from pixabay', '/* Royalty-free injection sound from pixabay */', 1) )
       NewerBase = '3615135168\mods\ZVirusVaccine42BETA'; Pinned = '42.20' }
)
$script:BootFixResult = @()

function Get-Sha([byte[]]$b) {
    $h = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($h.ComputeHash($b))).Replace('-', '') } finally { $h.Dispose() }
}

# Workshop content folders (108600 = Project Zomboid) of all Steam libraries. PZ_WORKSHOP overrides (';'-list).
function Get-WorkshopRoots {
    if ($env:PZ_WORKSHOP) { return @($env:PZ_WORKSHOP.Split(';') | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) }
    $libs = New-Object System.Collections.Generic.List[string]
    $steam = $null
    try { $steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
    if ($steam) { $libs.Add($steam.Replace('/', '\')) }
    foreach ($d in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) { if ($d) { $libs.Add((Join-Path $d 'Steam')) } }
    foreach ($l in @($libs)) {
        $vdf = Join-Path $l 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in [System.IO.File]::ReadAllLines($vdf)) { if ($line -match '^\s*"path"\s*"(.+)"\s*$') { $libs.Add($Matches[1].Replace('\\', '\')) } }
        }
    }
    $roots = @()
    foreach ($l in $libs) {
        $r = Join-Path $l 'steamapps\workshop\content\108600'
        if ((Test-Path -LiteralPath $r) -and ($roots -notcontains $r)) { $roots += $r }
    }
    return $roots
}

# Returns the patched bytes, or $null with a reason in $script:FixWhy.
function Invoke-BootFix($fx, [string[]]$roots) {
    $script:FixWhy = 'Original-Datei nicht gefunden (Workshop-Mod nicht abonniert?)'
    $lat = [System.Text.Encoding]::GetEncoding(28591)   # 1 byte = 1 char, lossless round trip
    foreach ($r in $roots) {
        $p = Join-Path $r $fx.Src
        if (-not (Test-Path -LiteralPath $p)) { continue }
        if ($fx.NewerBase) {
            $b = Join-Path $r $fx.NewerBase
            $newer = @(Get-ChildItem -LiteralPath $b -Directory | Where-Object { $_.Name -match '^\d+(\.\d+)*$' -and ([version]($_.Name + '.0')) -gt ([version]($fx.Pinned + '.0')) })
            if ($newer.Count -gt 0) { $script:FixWhy = ('neuer Versionsordner ' + $newer[0].Name + ' beim Original (Mod-Update) - Fix passt nicht mehr'); continue }
        }
        $bytes = [System.IO.File]::ReadAllBytes($p)
        if ((Get-Sha $bytes) -ne $fx.SrcSha) { $script:FixWhy = 'Original wurde geaendert (Mod-Update) - Fix passt nicht mehr'; continue }
        $t = $lat.GetString($bytes)
        $ok = $true
        foreach ($e in $fx.Edits) {
            $n = ([regex]::Matches($t, [regex]::Escape($e[0]))).Count
            if ($n -ne $e[2]) { $ok = $false; break }
            $t = $t.Replace($e[0], $e[1])
        }
        if (-not $ok) { $script:FixWhy = 'Textstelle nicht wie erwartet'; continue }
        $out = $lat.GetBytes($t)
        if ((Get-Sha $out) -ne $fx.OutSha) { $script:FixWhy = 'Ergebnis-Pruefsumme stimmt nicht'; continue }
        return ,$out
    }
    return $null
}

# Copy the package folder to a temp stage and add the fix files built from the user's Workshop files.
function New-BootPatchStage([string]$from) {
    $stage = Join-Path ([System.IO.Path]::GetTempPath()) ('mkev_bootpatch_stage_' + [guid]::NewGuid().ToString('N'))
    Copy-Item -LiteralPath $from -Destination $stage -Recurse -Force
    $roots = @(Get-WorkshopRoots)
    $script:BootFixResult = @()
    foreach ($fx in $script:BootFixes) {
        $out = Invoke-BootFix $fx $roots
        if ($null -eq $out) { $script:BootFixResult += ('    ' + $fx.Id + ' ' + $fx.Label + ': NICHT gebaut - ' + $script:FixWhy); continue }
        $dst = Join-Path $stage $fx.Dst
        $dir = Split-Path -Parent $dst
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        [System.IO.File]::WriteAllBytes($dst, $out)
        $script:BootFixResult += ('    ' + $fx.Id + ' ' + $fx.Label + ': ok')
    }
    if ($roots.Count -eq 0) { $script:BootFixResult += '    Hinweis: kein Steam-Workshop-Ordner gefunden (PZ_WORKSHOP setzen, falls woanders).' }
    return $stage
}


# ------------------------------------------------------------------ steps
function Install-Mods {
    Say ""
    Say "  [Mods] Ziel: Zomboid\mods"
    $modsDir = P 'mods'
    if (-not (Test-Path -LiteralPath $modsDir)) {
        if ($script:DryRun) { Say "    (wuerde Ordner Zomboid\mods anlegen)" }
        else { Assert-SafePath $modsDir; New-Item -ItemType Directory -Force -Path $modsDir | Out-Null }
    }
    foreach ($s in $script:ModSlots) {
        $n = $s.Name
        $from = Join-Path $script:Src $n
        $stage = $null
        if ($s.Stage) {
            $stage = New-BootPatchStage $from
            $from = $stage
            Say ("    " + $n + " - Fixes aus deinen Workshop-Dateien:")
            foreach ($l in $script:BootFixResult) { Say $l }
        }
        try {
            $to = Join-Path $modsDir $n
            Assert-SafePath $to
            $newVer = Get-ModVersion $from
            if ((Get-DirSig $from) -eq (Get-DirSig $to)) { Say ("    " + $n + " " + $newVer + ": bereits aktuell, nichts geaendert."); continue }
            $oldVer = if (Test-Path -LiteralPath $to) { Get-ModVersion $to } else { 'nicht installiert' }
            if ($script:DryRun) { Say ("    " + $n + ": wuerde installiert (" + $oldVer + " -> " + $newVer + ")."); $script:Changes++; continue }
            Backup-Item ('mods\' + $n)
            if (Test-Path -LiteralPath $to) { Remove-Item -LiteralPath $to -Recurse -Force }
            Copy-Item -LiteralPath $from -Destination $to -Recurse -Force
            if ((Get-DirSig $from) -ne (Get-DirSig $to)) { throw ("Kopie von " + $n + " ist nicht identisch.") }
            Say ("    " + $n + ": installiert (" + $oldVer + " -> " + $newVer + ").")
            $script:Changes++
        } finally {
            if ($stage -and (Test-Path -LiteralPath $stage)) { Remove-Item -LiteralPath $stage -Recurse -Force }
        }
    }
}


# Replace Mods= / WorkshopItems= / Map= in servertest.ini, keep every other line byte-identical.
function Merge-ServerIni {
    Say ""
    Say "  [Server-Einstellungen] Zomboid\Server\servertest.ini (nur Mods=, WorkshopItems=, Map=)"
    $want = [ordered]@{
        'Mods'          = (Read-ListFile 'MKevServer_modlist.txt' 'Mods')
        'WorkshopItems' = (Read-ListFile 'MKevServer_workshopitems.txt' 'WorkshopItems')
        'Map'           = (Read-ListFile 'MKevServer_map.txt' 'Map')
    }
    $path = P 'Server\servertest.ini'
    $exists = Test-Path -LiteralPath $path
    if ($exists) { $t = Read-Text $path; $lines = New-Object System.Collections.Generic.List[string]; foreach ($l in $t.Lines) { $lines.Add($l) }; $nl = $t.Nl; $bom = $t.Bom }
    else { $lines = New-Object System.Collections.Generic.List[string]; $nl = "`r`n"; $bom = $false; Say "    Datei fehlt -> wird neu angelegt (nur diese drei Zeilen; das Spiel ergaenzt den Rest beim ersten Serverstart)." }
    $changed = $false
    foreach ($k in $want.Keys) {
        $sep = ';'
        $newLine = $k + '=' + $want[$k]
        $idx = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i].StartsWith($k + '=')) { $idx = $i; break } }
        if ($idx -ge 0) {
            $oldVal = $lines[$idx].Substring($k.Length + 1)
            if ($lines[$idx] -ceq $newLine) { Say ("    " + $k + "=: schon richtig (" + (Split-List $want[$k] $sep).Count + " Eintraege)."); continue }
            $old = Split-List $oldVal $sep; $new = Split-List $want[$k] $sep
            $removed = @($old | Where-Object { $new -notcontains $_ })
            $added = @($new | Where-Object { $old -notcontains $_ })
            Say ("    " + $k + "=: wird ersetzt (" + $old.Count + " -> " + $new.Count + " Eintraege, neu: " + $added.Count + ", entfernt: " + $removed.Count + ", Reihenfolge wie MKev-Server).")
            if ($removed.Count -gt 0) { Say ("      entfernt (eigene Eintraege des Spielers): " + ($removed -join ', ')) }
            $lines[$idx] = $newLine
            # remove duplicate later lines of the same key (game uses one)
            for ($j = $lines.Count - 1; $j -gt $idx; $j--) { if ($lines[$j].StartsWith($k + '=')) { $lines.RemoveAt($j); Say ("      doppelte " + $k + "=-Zeile entfernt.") } }
        } else {
            Say ("    " + $k + "=: fehlt -> wird hinzugefuegt (" + (Split-List $want[$k] $sep).Count + " Eintraege).")
            $lines.Add($newLine)
        }
        $changed = $true
    }
    if (-not $changed) { return }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben; alle anderen Zeilen bleiben unveraendert)"; return }
    Backup-Item 'Server\servertest.ini'
    Write-TextLines $path $lines $nl $bom
    Say "    gespeichert. Alle anderen Einstellungen (Passwoerter, Ports, Namen ...) unveraendert."
}

function Install-FileCopy([string]$fromName, [string]$rel, [string]$label) {
    $from = Join-Path $script:SetupSrc $fromName
    $to = P $rel
    Say ""
    Say ("  [" + $label + "] Zomboid\" + $rel)
    if (-not (Test-Path -LiteralPath $from)) { throw ("Datei fehlt im Paket: MKevServer_setup\" + $fromName) }
    Assert-SafePath $to
    if ((Test-Path -LiteralPath $to) -and ((Get-FileHash -Algorithm SHA256 -LiteralPath $from).Hash -eq (Get-FileHash -Algorithm SHA256 -LiteralPath $to).Hash)) { Say "    schon identisch, nichts geaendert."; return }
    $script:Changes++
    if ($script:DryRun) { Say ("    wuerde " + $(if (Test-Path -LiteralPath $to) { 'ersetzt' } else { 'neu angelegt' }) + " (Inhalt: MKevServer_setup\" + $fromName + ")."); return }
    Backup-Item $rel
    $dir = Split-Path -Parent $to
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    Copy-Item -LiteralPath $from -Destination $to -Force
    Say "    gespeichert."
}

# pz_modlist_settings.cfg: add or replace only the line of our preset, keep every other preset.
function Merge-Preset {
    Say ""
    Say ("  [Mod-Preset] Zomboid\Lua\pz_modlist_settings.cfg (Preset '" + $script:PresetName + "')")
    $f = Join-Path $script:SetupSrc 'MKevServer_preset.txt'
    $our = $null
    foreach ($l in (Read-Text $f).Lines) { if ($l.StartsWith($script:PresetName + ':')) { $our = $l } }
    if (-not $our) { throw "Preset-Zeile fehlt in MKevServer_setup\MKevServer_preset.txt" }
    $path = P 'Lua\pz_modlist_settings.cfg'
    $lines = New-Object System.Collections.Generic.List[string]; $nl = "`r`n"; $bom = $false
    if (Test-Path -LiteralPath $path) { $t = Read-Text $path; foreach ($l in $t.Lines) { $lines.Add($l) }; $nl = $t.Nl; $bom = $t.Bom }
    else { $lines.Add('!fav!:') }
    $idx = -1
    for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i].StartsWith($script:PresetName + ':')) { $idx = $i; break } }
    $foreign = @($lines | Where-Object { $_ -match '^[^:]+:' -and -not $_.StartsWith('!fav!:') -and -not $_.StartsWith($script:PresetName + ':') } | ForEach-Object { $_.Split(':')[0] })
    if ($idx -ge 0 -and $lines[$idx] -ceq $our) { Say "    schon aktuell, nichts geaendert."; return }
    if ($idx -ge 0) { $lines[$idx] = $our; Say "    vorhandenes Preset wird aktualisiert." } else { $lines.Add($our); Say "    Preset wird hinzugefuegt." }
    if ($foreign.Count -gt 0) { Say ("    eigene Presets bleiben erhalten: " + ($foreign -join ', ')) }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben)"; return }
    Backup-Item 'Lua\pz_modlist_settings.cfg'
    Write-TextLines $path $lines $nl $bom
    Say "    gespeichert."
}

# mods\default.txt: add mkev_modpatcher to the mods block, nothing else.
function Merge-DefaultTxt {
    Say ""
    Say ("  [Lokale Mod-Liste] Zomboid\mods\default.txt (" + $script:DefaultTxtMod + " eintragen)")
    $path = P 'mods\default.txt'
    $id = $script:DefaultTxtMod
    if (-not (Test-Path -LiteralPath $path)) {
        $lines = @('VERSION = 1,', '', 'mods', '{', ('    mod = ' + $id + ','), '}', '', 'maps', '{', '}')
        $nl = "`r`n"; $bom = $false
        Say "    Datei fehlt -> wird neu angelegt."
    } else {
        $t = Read-Text $path; $nl = $t.Nl; $bom = $t.Bom
        $lines = New-Object System.Collections.Generic.List[string]; foreach ($l in $t.Lines) { $lines.Add($l) }
        $inMods = $false; $close = -1; $found = $false; $start = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $s = $lines[$i].Trim()
            if (-not $inMods -and $s -eq 'mods') { $start = $i; continue }
            if ($start -ge 0 -and -not $inMods -and $close -lt 0 -and $s -eq '{') { $inMods = $true; continue }
            if ($inMods) {
                if ($s -eq '}') { $close = $i; $inMods = $false; break }
                if ($s -match '^mod\s*=\s*\\?([^,]+?)\s*,?\s*$' -and $Matches[1] -eq $id) { $found = $true }
            }
        }
        if ($found) { Say "    schon eingetragen, nichts geaendert."; return }
        if ($close -lt 0) { Say "    WARNUNG: Aufbau von default.txt unbekannt, nicht geaendert. (Die Mod traegt sich beim Beitreten selbst ein.)"; return }
        $lines.Insert($close, ('    mod = ' + $id + ','))
        Say "    wird am Ende der Mod-Liste angehaengt (sonst keine Aenderung)."
    }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben)"; return }
    Backup-Item 'mods\default.txt'
    Write-TextLines $path $lines $nl $bom
    Say "    gespeichert."
}

# Option 2: ready-made files for the player, no existing config is touched.
function Write-SetupFolder {
    $dst = P 'MKevServer_setup'
    Say ""
    Say "  [Vorlagen] Zomboid\MKevServer_setup\"
    Assert-SafePath $dst
    $files = @('MKevServer_modlist.txt', 'MKevServer_workshopitems.txt', 'MKevServer_map.txt', 'MKevServer_SandboxVars.lua', 'MKevServer_preset.txt', 'MKevServer_LIESMICH.txt')
    $same = $true
    foreach ($f in $files) {
        $a = Join-Path $script:SetupSrc $f; $b = Join-Path $dst $f
        if (-not (Test-Path -LiteralPath $b) -or (Get-FileHash -Algorithm SHA256 -LiteralPath $a).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $b).Hash) { $same = $false }
    }
    if ($same) { Say "    schon aktuell, nichts geaendert."; return }
    $script:Changes++
    if ($script:DryRun) { Say "    (Probelauf: nichts geschrieben)"; return }
    Backup-Item 'MKevServer_setup'
    if (-not (Test-Path -LiteralPath $dst)) { New-Item -ItemType Directory -Force -Path $dst | Out-Null }
    foreach ($f in $files) { Copy-Item -LiteralPath (Join-Path $script:SetupSrc $f) -Destination (Join-Path $dst $f) -Force; Say ("    " + $f) }
}

# ------------------------------------------------------------------ restore
function Get-Backups {
    if (-not (Test-Path -LiteralPath $script:BackupRoot)) { return @() }
    return @(Get-ChildItem -LiteralPath $script:BackupRoot -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'backup_index.txt') } | Sort-Object Name -Descending)
}

function Invoke-Restore {
    $list = @(Get-Backups)
    if ($list.Count -eq 0) { Say "  Keine Backups gefunden in Zomboid\mkev_patch_backups."; return }
    Say "  Vorhandene Backups (neueste zuerst):"
    for ($i = 0; $i -lt $list.Count; $i++) { Say ("    " + ($i + 1) + ") " + $list[$i].Name) }
    $pick = if ($env:PZ_RESTORE_PICK) { $env:PZ_RESTORE_PICK } else { Read-Host "  Nummer waehlen (leer = abbrechen)" }
    $n = 0
    if (-not [int]::TryParse(("" + $pick).Trim(), [ref]$n) -or $n -lt 1 -or $n -gt $list.Count) { Say "  Abgebrochen."; return }
    $b = $list[$n - 1].FullName
    $entries = @()
    foreach ($l in (Read-Text (Join-Path $b 'backup_index.txt')).Lines) { if ($l -match "^(existed|created)`t(.+)$") { $entries += ,@($Matches[1], $Matches[2]) } }
    Say ("  Backup " + $list[$n - 1].Name + " stellt den Zustand VOR diesem Lauf wieder her:")
    foreach ($e in $entries) { Say ("    " + $(if ($e[0] -eq 'existed') { 'zurueck: ' } else { 'entfernen (war neu): ' }) + $e[1]) }
    if (-not (Ask "Wiederherstellen?")) { Say "  Abgebrochen, nichts geaendert."; return }
    New-BackupSession 'vor_wiederherstellung'
    foreach ($e in $entries) {
        $rel = $e[1]; $target = P $rel
        Assert-SafePath $target
        Backup-Item $rel
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
        if ($e[0] -eq 'existed') {
            $parent = Split-Path -Parent $target
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
            Copy-Item -LiteralPath (Join-Path (Join-Path $b 'files') $rel) -Destination $target -Recurse -Force
        }
        Say ("    erledigt: " + $rel)
    }
    Say ("  Wiederhergestellt. Der Zustand davor liegt in: " + (Rel $script:Bak))
}

# ------------------------------------------------------------------ menu
function Show-Info1 {
    Say ""
    Say "  INSTALLIEREN & EINRICHTEN - das passiert genau:"
    Say "   1. Mods nach Zomboid\mods kopieren: mkev_modpatcher, mkevserverbootpatch."
    Say "      Die 3 Skript-Fixes des Boot-Patches werden aus deinen Workshop-Dateien gebaut"
    Say "      (nur gelesen). Workshop-Ordner werden nie veraendert."
    Say "   2. Zomboid\Server\servertest.ini: die Zeilen Mods=, WorkshopItems= und Map="
    Say "      werden KOMPLETT durch die Liste des MKev-Servers ersetzt (Ladereihenfolge)."
    Say "      Deine bisherigen Eintraege in diesen drei Zeilen verschwinden."
    Say "      Alle anderen Einstellungen (Passwoerter, Ports, Servername ...) bleiben."
    Say "      Fehlt die Datei, wird sie mit nur diesen drei Zeilen angelegt."
    Say "   3. Zomboid\Server\servertest_SandboxVars.lua wird durch die Einstellungen des"
    Say "      MKev-Servers ersetzt."
    Say "   4. Zomboid\Lua\pz_modlist_settings.cfg: Mod-Preset 'MKevServer' wird"
    Say "      hinzugefuegt/aktualisiert, deine eigenen Presets bleiben."
    Say "   5. Zomboid\mods\default.txt: mkev_modpatcher wird angehaengt (sonst nichts)."
    Say "   Vorher wird alles gesichert nach Zomboid\mkev_patch_backups\<Datum_Uhrzeit>\"
    Say "   (zurueckholen mit Menuepunkt 3)."
}

function Run-Setup([bool]$dry) {
    $script:DryRun = $dry
    if (-not $dry) { New-BackupSession 'einrichten' }
    Install-Mods
    Merge-ServerIni
    Install-FileCopy 'MKevServer_SandboxVars.lua' 'Server\servertest_SandboxVars.lua' 'Sandbox-Einstellungen'
    Merge-Preset
    Merge-DefaultTxt
}

function Main {
    Say ""
    Say ("  MKev ModPatchInstaller " + $script:Version + "  (Autor MKev)")
    Say "  ================================================================"
    Say ("  Paket   : " + $script:Src)
    Say ("  Zomboid : " + $script:Zomboid)
    Say ""
    Say "   1) Installieren & Einrichten   (empfohlen)"
    Say "   2) Installieren & nicht Einrichten (nur Patch + Vorlagen-Dateien)"
    Say "   3) Backup wiederherstellen"
    Say "   4) Beenden"
    Say "   5) Probelauf: nur anzeigen, was 1) aendern wuerde"
    $c = if ($env:PZ_CHOICE) { $env:PZ_CHOICE } else { Read-Host "  Auswahl [1]" }
    $c = ("" + $c).Trim(); if ($c -eq '') { $c = '1' }
    $script:Log.Add("  Auswahl: " + $c)
    if ($c -eq '4') { Say "  Beendet, nichts geaendert."; return 0 }
    if (@('1', '2', '3', '5') -notcontains $c) { Say "  Ungueltige Auswahl, nichts geaendert."; return 1 }
    Say ""
    if (Test-PzRunning) { return 1 }
    if (-not (Test-Path -LiteralPath $script:Zomboid)) {
        Say ("  ABBRUCH: Zomboid-Ordner nicht gefunden: " + $script:Zomboid)
        Say "  Bitte Project Zomboid einmal starten und wieder schliessen."
        return 1
    }
    if ($script:Zomboid -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { Say "  ABBRUCH (Sicherheitsstopp): Zomboid-Ordner liegt in einem Workshop-Ordner."; return 1 }
    if ($c -eq '3') { Invoke-Restore; Save-Log; return 0 }
    if (-not (Test-Package)) { return 1 }
    if ($c -eq '5') {
        Say "  PROBELAUF - es wird nichts geschrieben:"
        Run-Setup $true
        Say ""
        Say ("  Probelauf fertig: " + $script:Changes + " Aenderung(en) wuerden gemacht.")
        return 0
    }
    if ($c -eq '1') {
        Show-Info1
        Say ""
        if (-not (Ask "Einverstanden? Jetzt installieren und einrichten?")) { Say "  Abgebrochen, nichts geaendert."; return 0 }
        Run-Setup $false
    } else {
        Say "  INSTALLIEREN & NICHT EINRICHTEN: nur die Patches werden kopiert,"
        Say "  keine bestehende Einstellung wird geaendert."
        $script:DryRun = $false
        New-BackupSession 'nur_installieren'
        Install-Mods
        Write-SetupFolder
        Say ""
        Say "  Fertige Dateien zum Selbst-Einrichten liegen in Zomboid\MKevServer_setup\ :"
        Say "    MKevServer_modlist.txt        -> Zeile Mods= (Ladereihenfolge) fuer deine servertest.ini"
        Say "    MKevServer_workshopitems.txt  -> Zeile WorkshopItems= fuer deine servertest.ini"
        Say "    MKevServer_map.txt            -> Zeile Map= fuer deine servertest.ini"
        Say "    MKevServer_SandboxVars.lua    -> Sandbox-Einstellungen (als <servername>_SandboxVars.lua nutzen)"
        Say "    MKevServer_preset.txt         -> Zeile fuer Zomboid\Lua\pz_modlist_settings.cfg"
        Say "    MKevServer_LIESMICH.txt       -> Anleitung"
    }
    Say ""
    Say "  Installierte Versionen:"
    foreach ($s in $script:ModSlots) { $d = P ('mods\' + $s.Name); if (Test-Path -LiteralPath $d) { Say ("    " + $s.Name + ": " + (Get-ModVersion $d)) } }
    Say ""
    if ($script:Bak -and (Test-Path -LiteralPath $script:Bak)) { Say ("  FERTIG. Backup: " + $script:Bak) } else { Say "  FERTIG. Es war schon alles aktuell, nichts geaendert." }
    Say "  Zum Spielen: Workshop-Kollektion abonniert lassen, Spiel starten, Server beitreten."
    Save-Log
    return 0
}

try { $rc = Main } catch { Say ("  FEHLER: " + $_.Exception.Message); if ($script:Bak) { Say ("  Backup zum Zurueckholen (Menuepunkt 3): " + $script:Bak) }; Save-Log; $rc = 1 }
exit $rc
