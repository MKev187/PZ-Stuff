# Changelog - MKevServerBootPatch


## 1.1.0 (2026-11-06)
- F1-F3 no longer shipped as copies of third-party files. ModPatchInstaller 0.2.0 builds them from the installed
  Workshop originals (SHA256 of original and result checked, same bytes as 1.0.2 overrides).
- F4 removed: Sentry Turret Upgrade (WS 3633082678, id SentryTurret042) is not in the current pack (06.11.2026 list:
  381 mods / 328 WorkshopItems). loadModAfter without SentryTurret042. AUDIT.md removed from the release copy.
- tools/check_upstream.ps1: no private paths, Sentry checks removed, PZ_WORKSHOP override.

## 1.0.2 (2026-10-30, staged, not installed)
- F6 placeholders for ALL folders the 42.21 AdvancedAnimator scans per mod. Checked in the 42.21 server jar
  (`AdvancedAnimator.collectModFiles -> loadModMedia(commonDir) + loadModMedia(versionDir)`, each scans
  `media/AnimSets` and `media/actiongroups` with `Files.walkFileTree`; a missing folder ends in `visitFileFailed` ->
  NoSuchFileException in the log, boot continues). New: `42/media/AnimSets/`, `common/media/AnimSets/`,
  `common/media/actiongroups/` (each with `readme_placeholder.txt`); `42/media/actiongroups/` from 1.0.1 stays.
  Only `.xml` files are read and checksummed there (`endsWith(".xml")`), so the `.txt` is ignored. `anims_X` is not
  scanned by AdvancedAnimator and gets no placeholder.
- mod.info: modversion 1.0.2, name v1.0.2, description updated.

## 1.0.1 (2026-10-30)
- F5 empty `42/media/actiongroups/` folder with `readme_placeholder.txt`: AdvancedAnimator scans `media/actiongroups` of every mod at boot and
  logged a NoSuchFileException for this mod because the folder was missing. No game data inside.
- mod.info: modversion 1.0.1, name v1.0.1, description extended.

## 1.0 (2026-10-25)
- F1 Archery Nexus [Fixed]: recipe skill Carpentry -> Woodwork (recipes_fletching.txt override).
- F2 Mad Crafter: recipe skill Electrical -> Electricity in 2 recipes (recipes_MCR_1Handed.txt override, 42.15).
- F3 Zombie Virus Vaccine: LabSounds.txt `//` comment -> `/* */`, restores sound Injection_A (42.20).
- F4 Sentry Turret Upgrade: require path shim for ST_MP_TurretUtil (server only, guarded by mod active check).
- tools/check_upstream.ps1: read-only drift check for the overridden upstream files.
