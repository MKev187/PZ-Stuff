# MKevServerBootPatch v1.1.0 - drift check (READ-ONLY, changes nothing)
# Run before install and after Workshop updates. If any line says DRIFT, do NOT use this patch version
# until the override has been rebuilt from the new upstream file.
$roots = if ($env:PZ_WORKSHOP) { @($env:PZ_WORKSHOP.Split(';')) } else { @('C:\Program Files (x86)\Steam\steamapps\workshop\content\108600') }
$expected = [ordered]@{
  '3731579266\mods\ArcheryNexusFixed\common\media\scripts\recipes\recipes_fletching.txt'            = '68B87D921EAEB41D2799919BDB75446FB9EBCFAD98376174A7D89FAEF0096678'
  '3418701509\mods\MadCrafter\42.15\media\scripts\recipes\recipes_MCR_1Handed.txt'                  = '7B4591967E8FC50B337E6C210D2BC0C28B9CC5ECBC565CE41DE2567FD437CFEF'
  '3615135168\mods\ZVirusVaccine42BETA\42.20\media\scripts\sounds\LabSounds.txt'                   = '85F28B209C94105F597900691C92E8E52D277871175E9B36241C974309F18FCD'
}
# Newer version folders would replace the patched files (B42 picks the highest folder <= game version).
$newerDirs = @(
  @{ base = '3418701509\mods\MadCrafter'; pinned = '42.15' },
  @{ base = '3615135168\mods\ZVirusVaccine42BETA'; pinned = '42.20' }
)
$bad = 0
foreach ($root in $roots) {
  if (-not (Test-Path -LiteralPath $root)) { Write-Output "SKIP  $root (not found)"; continue }
  foreach ($rel in $expected.Keys) {
    $p = Join-Path $root $rel
    if (-not (Test-Path -LiteralPath $p)) { Write-Output "DRIFT missing  $p"; $bad++; continue }
    $h = (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash
    if ($h -ne $expected[$rel]) { Write-Output "DRIFT changed  $p"; $bad++ } else { Write-Output "OK    $p" }
  }
  foreach ($n in $newerDirs) {
    $b = Join-Path $root $n.base
    if (Test-Path -LiteralPath $b) {
      Get-ChildItem -LiteralPath $b -Directory | Where-Object { $_.Name -match '^\d+(\.\d+)*$' -and ([version]($_.Name + '.0')) -gt ([version]($n.pinned + '.0')) } |
        ForEach-Object { Write-Output "DRIFT new version folder $($_.FullName) (patched file is from $($n.pinned))"; $bad++ }
    }
  }
}
if ($bad -eq 0) { Write-Output 'RESULT OK - patch matches the installed Workshop files' } else { Write-Output "RESULT DRIFT ($bad) - rebuild the patch before using it" }
