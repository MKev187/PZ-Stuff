# MKevServerBootPatch 1.1.0 (id `mkevserverbootpatch`)

Small local patch for the MKev B42 server pack (game 42.21). Fixes boot-log errors of other mods.
Separate from `mkev_modpatcher`. Load it at the very END of `Mods=`, after `mkev_modpatcher`.
Server and every client need the same version (script checksums).

| # | Mod (WS) | Fix | How it is delivered |
|---|---|---|---|
| F1 | Archery Nexus [Fixed] (3731579266) | recipe skill `Carpentry:3` -> `Woodwork:3` | built by ModPatchInstaller from your installed `recipes_fletching.txt` |
| F2 | Mad Crafter (3418701509, 42.15) | `Electrical:` -> `Electricity:` (6x, 2 recipes) | built from your installed `recipes_MCR_1Handed.txt` |
| F3 | Zombie Virus Vaccine (3615135168, 42.20) | `//` comment -> `/* */`, restores sound `Injection_A` | built from your installed `LabSounds.txt` |
| F5/F6 | this mod | empty `media/AnimSets` + `media/actiongroups` placeholders (common + 42) | shipped (own files) |

F1-F3: this package ships NO copies of the original files (they belong to their authors). The installer reads your
Workshop copy (read-only), checks its SHA256 is exactly the version the fix was made for, changes only the listed
text and checks the result SHA256. If a mod was updated or is missing, that one fix is skipped and the installer says so.
F4 (Sentry Turret Upgrade 3633082678 shim) was removed in 1.1.0: that mod (SentryTurret042) is no longer in the pack.

`tools\check_upstream.ps1` (read-only) reports DRIFT when an original changed. Set `PZ_WORKSHOP` for other Steam libraries.
