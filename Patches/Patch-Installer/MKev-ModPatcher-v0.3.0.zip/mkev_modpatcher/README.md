# MKev-ModPatcher (private) - mod id `mkev_modpatcher`

Current build: **0.1.11** (2026-10-31). Install with `ModPatchInstaller.bat` from the patch folder (players and server; refuses to run while the game
or the server runs, makes a backup first; see installieren.txt). Check in the log: `[MKev-ModPatcher] version 0.1.11 loaded` and, on the client,
`[MKev-PDG] aktiv (...)`. The install steps below are the original 1.x notes (version numbers in them are historic).

Private compatibility patch for MKev's B42 modpack (game 42.20). It replaces MKevPackPatches 2.5.0.
It never edits Workshop files. Load it LAST.

Main menu and single player (0.1.11): since the mod adds itself to the players' local default mod list, it also loads in the main
menu and in new single player games. There it only does the main-menu connect notice; spawn monitor and post-death guard are MP-only,
everything else checks for its target mod first or is MP/server-only. Players can switch it off in the mod list like any mod; it adds
itself again on the next MP join (it never touches any other entry).

## Install (only after MKev approves)
1. Server: copy the folder `mkev_modpatcher/` (the whole folder: common/ + 42/) to `%USERPROFILE%\Zomboid\mods\` (server user).
2. Server config: in `Mods=` replace `MKevPackPatches` with `mkev_modpatcher`, as the LAST entry (no WorkshopItems entry, local mod).
3. Clients and friends: the same folder in their `Zomboid\mods\`, same version.
4. Remove or disable MKevPackPatches everywhere. The two must not run together (mod.info declares them incompatible, and the
   patcher logs a WARNING if both are active).
5. Check: the log shows `[MKev-ModPatcher] version 1.6 loaded`, and there are no `template "..." not found` lines for the 18 names
   and no Translator warnings for Sandbox_TrueSmoking_*Chance*_tooltip / Sandbox_WeightReduction_ReductionPercent*.

## Contents (`42/`)
| File | Purpose | Target mods |
|---|---|---|
| media/lua/client/mkevmp_alifewindowhands.lua | empties A-Life NPC hands before engine window climbs (MP client, only if A-Life is active) | ProjectALifeNPCs |
| media/lua/client/mkevmp_primitivebow_anm.lua | Primitive Bow drawn model (REX5_MD_BOW) while an arrow is nocked; only if ArcheryNexusFixed AND ArcheryNexus_RB are active | ArcheryNexusFixed, ArcheryNexus_RB |
| media/lua/client/mkevmp_postdeathguard.lua | death screen guard (0.1.10, MP client only since 0.1.11): keeps ISPostDeathUI on top, logs `[MKev-PDG]` diagnostics (MainScreen flag, always-on-top elements, element under each click), wrapped button handlers, fallback window after 10 s | vanilla |
| media/lua/client/mkevmp_connectnotice.lua | connect notice (0.1.11): loading notice DE/EN with OK, in the main menu before the connect (local mod list) or once in game after loading; never SP / coop host. MP client: adds only `mkev_modpatcher` to the player's local default mod list (vanilla `ActiveMods.getById("default"):setModActive` + `saveModsFile()`, add-only, once) so the menu window works after the next return to the main menu | vanilla |
| media/lua/shared/Translate/EN/UI.json | texts of the connect notice (DE + EN keys) | - |
| media/lua/client/mkevmp_insertmagguard.lua | keeps the magazine reference in ISInsertMagazine:start() when the client lookup fails (MP client) | vanilla (seen via The Only Cure+, Hot Brass Tactical Reload, VFE reloads) |
| media/lua/shared/mkevmp_00_config.lua | settings, log helper, isModActive, clash warning | - |
| media/lua/shared/mkevmp_jp82guard.lua | fills missing JP82 SpareTire functions (only if 82jeepJ10 is active) | 82jeepJ10 |
| media/lua/shared/mkevmp_purserverguard.lua | PUR table on dedicated servers (only if PUR is active) | PUR |
| media/lua/shared/mkevmp_sodacanalias.lua | old soda OnCreate name (only if FA2/Authentic Z is active) | FunctionalAppliances2, Authentic Z |
| media/lua/shared/mkevmp_version.lua | version line in the log | - |
| media/lua/shared/Translate/EN/Sandbox.json | % fixes (file name as the game requires); the WeightReduction keys are unused since 1.6 (mod removed), harmless | TrueSmoking |
| media/scripts/vehicles/mkevmp_template_ki5_gunracks.txt | SSP93Gunrack, SUB87Gunrack | 93mustangSSP, 87chevySuburban |
| media/scripts/vehicles/mkevmp_template_jp82_sparetires_restore.txt | JP82SpareTires restore | 82jeepJ10 (vs 84jeepXJ) |
| media/scripts/vehicles/mkevmp_template_stubs.txt | P19A / DAMN67 empty stubs | 86oshkoshP19A, 67commando |
| media/scripts/vehicles/mkevmp_template_stubs_stale_refs.txt | 12 empty stubs | KI5 vehicle mods |
| media/scripts/mkevmp_brita_nv_legacy.txt | 6 legacy NV names as full items (Obsolete=false), no dictionary warning on join | BritasArmorPackB42 |
| media/clothing/clothingItems/*.xml (3) | stand-ins for missing Realistic Army Zombies clothing files | realisticarmyzombiesb42 |

Case rule: everything new is lowercase. Exceptions required by the game are `Translate/EN/Sandbox.json`, `Translate/EN/UI.json`, override files that must match the original path (the 3 clothing XMLs), the in-game template
names, and the mod ids in mod.info.
See CHANGELOG.md, UPSTREAM.md and AUDIT.md.

## Zombie spawn monitor (0.1.9, debug; 0.1.10: CET/CEST times, A-Life/skeleton filter, line AUSGEFILTERT)
File `42/media/lua/shared/mkevmp_zedmonitor.lua`, Sandbox `MKevMP.ZedMonitor` (default on during tests).
Logs in `Zomboid/Lua/mkev_zedmonitor_server.log` (server) and `mkev_zedmonitor_client.log` (client), 2 MB cap + one `.1.log`. Since 0.1.11 not in single player.
Line types: START, LUA_AUFRUF, SPAWN quelle=..., LADEN, ZAEHLUNG, RAUM_GESEHEN (client), WIEDERHOLT, LIMIT, ROTATION.
