-- UPSTREAM-WORKAROUND (UPSTREAM.md U14): Vanilla Vehicles Replacer (KI5) on a dedicated server (tracker T37/T38).
-- VVR swaps every vanilla vehicle in its OnSpawnVehicleStart handler. For a vehicle that already exists in the
-- world (vehicle:isCreated() == true, e.g. loaded again with its chunk) it changes the script name and then calls
-- vehicle:scriptReloaded(true). On the dedicated server that ends in BaseVehicle.scriptReloaded ->
-- Bullet.removeVehicle, a native the server does not have (UnsatisfiedLinkError, VVR Replace.lua:188). The swap
-- stops half way: the server keeps the old seat layout while clients build the new KI5 script, and the client log
-- then fills with VehicleUpdatePacket / VehiclePassengers BufferUnderflowException (about 2 per second).
-- Fix: ONLY on a dedicated server (isServer() and not isClient()) and ONLY for the handler registered from
-- VVR's server/VVR/Replace.lua, calls for vehicles that already exist are skipped, so they keep their current
-- script. Brand-new vehicles (isCreated() == false) are still replaced as before. Clients, host and single player
-- are not touched. If the VVR handler is never seen, nothing is changed and one line is logged.
-- Own code (MKev-ModPatcher). No VVR file is copied or modified.
local M = MKevModPatcher or {}

local function say(msg, onceKey)
    if M.log then M.log(msg, false, onceKey) else print("[MKev-ModPatcher] " .. tostring(msg)) end
end

local function isDedicated()
    return type(isServer) == "function" and type(isClient) == "function" and isServer() and not isClient()
end

-- True if fn was defined in VVR's server Replace.lua (path compared case-insensitive, / and \ both accepted).
local function isVvrHandler(fn)
    if type(getFilenameOfClosure) ~= "function" then return false end
    local ok, file = pcall(getFilenameOfClosure, fn)
    if not ok or type(file) ~= "string" then return false end
    file = string.lower(string.gsub(file, "\\", "/"))
    return string.find(file, "/lua/server/vvr/replace.lua", 1, true) ~= nil
end

local state = { hooked = 0, skipped = 0 }
MKevModPatcherVvrGuard = state -- read-only status for debugging

local function install()
    if not isDedicated() then return end
    if not (Events and Events.OnSpawnVehicleStart) then
        say("VVR spawn guard: event OnSpawnVehicleStart missing, guard not active.", "vvrguard_noevent")
        return
    end
    local ev = Events.OnSpawnVehicleStart
    if ev._mkevmpVvrGuard then return end
    local origAdd, origRemove = ev.Add, ev.Remove
    if type(origAdd) ~= "function" then
        say("VVR spawn guard: OnSpawnVehicleStart.Add not found, guard not active.", "vvrguard_noadd")
        return
    end
    local wrapped = {}
    ev.Add = function(fn, ...)
        if type(fn) ~= "function" or not isVvrHandler(fn) then return origAdd(fn, ...) end
        local w = wrapped[fn]
        if not w then
            w = function(vehicle, ...)
                local okC, created = pcall(function() return vehicle ~= nil and vehicle:isCreated() end)
                if okC and created then
                    state.skipped = state.skipped + 1
                    if state.skipped == 1 then
                        say("VVR spawn guard: kept an existing vehicle unchanged (dedicated server, T37).", "vvrguard_first")
                    end
                    return
                end
                return fn(vehicle, ...)
            end
            wrapped[fn] = w
            state.hooked = state.hooked + 1
        end
        return origAdd(w, ...)
    end
    if type(origRemove) == "function" then
        ev.Remove = function(fn, ...)
            local w = wrapped[fn]
            if w then
                wrapped[fn] = nil
                return origRemove(w, ...)
            end
            return origRemove(fn, ...)
        end
    end
    ev._mkevmpVvrGuard = true
end

-- After all Lua is loaded: report once if VVR is active but its handler was not caught.
local function report()
    if not isDedicated() then return end
    local active = M.isModActive and M.isModActive("VVR")
    if not active then return end
    if state.hooked > 0 then
        if M.log then M.log("VVR spawn guard active (dedicated server).", true, "vvrguard_on") end
    else
        say("VVR spawn guard: VVR is active but its spawn handler was not found - guard not active, nothing changed.",
            "vvrguard_miss")
    end
end

install()
if Events and Events.OnServerStarted then Events.OnServerStarted.Add(report) end
