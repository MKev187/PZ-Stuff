@echo off
setlocal EnableExtensions
title MKev ModPatchInstaller
rem ==================================================================
rem  MKev ModPatchInstaller - fuer Spieler des MKev-Servers
rem  Autor: MKev.
rem  Einfach doppelklicken. Die eigentliche Arbeit macht
rem  ModPatchInstaller.ps1 im selben Ordner (Menue, Backup, Pruefungen).
rem ==================================================================
if not exist "%~dp0ModPatchInstaller.ps1" (
  echo  FEHLER: ModPatchInstaller.ps1 fehlt. Bitte das Zip komplett entpacken.
  if not defined PZ_NOPAUSE pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ModPatchInstaller.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not defined PZ_NOPAUSE pause
endlocal & exit /b %RC%
