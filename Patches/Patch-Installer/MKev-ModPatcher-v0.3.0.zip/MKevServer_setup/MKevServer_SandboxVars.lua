SandboxVars = {
    VERSION = 6,
    -- Dies ändert den Bevölkerungsdichte-Multiplikator unter "Erweiterte Zombie-Einstellungen". Standard=Normal
    -- 1 = Verrückt
    -- 2 = Sehr Viele
    -- 3 = Viele
    -- 4 = Normal
    -- 5 = Wenige
    -- 6 = Keine
    Zombies = 4,
    -- Steuert, wie Zombies auf der Karte verteilt werden. Standard=Mehr in Städten
    -- 1 = Mehr in Städten
    -- 2 = Gleichmäßig
    Distribution = 1,
    -- Steuert, ob ein unregelmäßiges organisches Muster für die Zombieverteilung angewendet wird.
    ZombieVoronoiNoise = true,
    -- Damit die Zombies wiederkehren, muss die Zone für den ausgewählten Zeitpunkt ungesehen sein. Standard=Keine
    -- 1 = Oft
    -- 2 = Normal
    -- 3 = Selten
    -- 4 = Keine
    ZombieRespawn = 4,
    -- Zombies wird erlaubt, in leere Zellen einzuwandern.
    ZombieMigrate = true,
    -- Standard=1 Stunde, 30 Minuten
    -- 1 = 15 Minuten
    -- 2 = 30 Minuten
    -- 3 = 1 Stunde
    -- 4 = 1 Stunde, 30 Minuten
    -- 5 = 2 Stunden
    -- 6 = 3 Stunden
    -- 7 = 4 Stunden
    -- 8 = 5 Stunden
    -- 9 = 6 Stunden
    -- 10 = 7 Stunden
    -- 11 = 8 Stunden
    -- 12 = 9 Stunden
    -- 13 = 10 Stunden
    -- 14 = 11 Stunden
    -- 15 = 12 Stunden
    -- 16 = 13 Stunden
    -- 17 = 14 Stunden
    -- 18 = 15 Stunden
    -- 19 = 16 Stunden
    -- 20 = 17 Stunden
    -- 21 = 18 Stunden
    -- 22 = 19 Stunden
    -- 23 = 20 Stunden
    -- 24 = 21 Stunden
    -- 25 = 22 Stunden
    -- 26 = 23 Stunden
    -- 27 = Echtzeit
    DayLength = 4,
    StartYear = 1,
    -- Monat, in dem das Spiel beginnt. Standard=Juli
    -- 1 = Januar
    -- 2 = Februar
    -- 3 = März
    -- 4 = April
    -- 5 = Mai
    -- 6 = Juni
    -- 7 = Juli
    -- 8 = August
    -- 9 = September
    -- 10 = Oktober
    -- 11 = November
    -- 12 = Dezember
    StartMonth = 7,
    -- Tag des Monats, an dem das Spiel beginnt.
    StartDay = 9,
    -- Stunde des Tages, an dem Spiel beginnt. Standard=9 Uhr
    -- 1 = 7 Uhr
    -- 2 = 9 Uhr
    -- 3 = 12 Uhr
    -- 4 = 13 Uhr
    -- 5 = 15 Uhr
    -- 6 = 21 Uhr
    -- 7 = 0 Uhr
    -- 8 = 2 Uhr
    -- 9 = 5 Uhr
    StartTime = 9,
    -- Ob sich die Tageszeit auf natürliche Weise ändert oder ob es immer Tag/Nacht ist. Standard=Normal
    -- 1 = Normal
    -- 2 = Immer Tag
    -- 3 = Immer Nacht
    DayNightCycle = 1,
    -- Bestimmt ob sich das Wetter verändert oder dauerhaft in einem festen Zustand bleibt. Standard=Normal
    -- 1 = Normal
    -- 2 = Kein Wetter
    -- 3 = Immer Regen
    -- 4 = Immer Sturm
    -- 5 = Immer Schnee
    -- 6 = Immer Schneesturm
    ClimateCycle = 1,
    -- Bestimmt ob Nebel natürlich auftritt, niemals erscheint oder dauerhaft vorhanden ist. Standard=Normal
    -- 1 = Normal
    -- 2 = Kein Nebel
    -- 3 = Immer Nebel
    FogCycle = 1,
    -- Lege fest, wie lange nach dem Standard-Startdatum (9. Juli 1993) Sanitäranlagen (z.B. Waschbecken) aufhören sollen, unendlichen Wasserquellen zu sein. Standard=0 - 30 Tage
    -- 1 = Sofort
    -- 2 = 0 - 30 Tage
    -- 3 = 0 - 2 Monate
    -- 4 = 0 - 6 Monate
    -- 5 = 0 - 1 Jahr
    -- 6 = 0 - 5 Jahre
    -- 7 = 2 - 6 Monate
    -- 8 = 6 - 12 Monate
    -- 9 = Deaktiviert
    WaterShut = 2,
    -- Lege fest, wie lange nach dem Standard-Startdatum (9. Juli 1993) der Strom endgültig abgeschaltet wird. Standard=14-30 Tage
    -- 1 = Sofort
    -- 2 = 14-30 Tage
    -- 3 = 14 Tage - 2 Monate
    -- 4 = 14 Tage - 6 Monate
    -- 5 = 14 Tage - 1 Jahr
    -- 6 = 14 Tage - 5 Jahre
    -- 7 = 2-6 Monate
    -- 8 = 6-12 Monate
    -- 9 = Deaktiviert
    ElecShut = 2,
    -- Steuert, wie lange Alarmbatterien halten, nachdem der Strom abgeschaltet wird. Standard=0 - 30 Tage
    -- 1 = Sofort
    -- 2 = 0 - 30 Tage
    -- 3 = 0 - 2 Monate
    -- 4 = 0 - 6 Monate
    -- 5 = 0 - 1 Jahr
    -- 6 = 0 - 5 Jahre
    AlarmDecay = 2,
    -- Lege fest, wie lange nach dem Standard-Startdatum (9. Juli 1993) Sanitäranlagen (z.B. Waschbecken) aufhören sollen, unendlichen Wasserquellen zu sein. Minimum=-1 Maximum=2147483647 Standard=14
    WaterShutModifier = 18,
    -- Lege fest, wie lange nach dem Standard-Startdatum (9. Juli 1993) der Strom endgültig abgeschaltet wird. Minimum=-1 Maximum=2147483647 Standard=14
    ElecShutModifier = 15,
    -- Steuert, wie lange Alarmbatterien halten, nachdem der Strom abgeschaltet wird. Minimum=-1 Maximum=2147483647 Standard=14
    AlarmDecayModifier = 14,
    -- Alle Lebensmittel, die verderben oder verfaulen können. Minimum=0,00 Maximum=4,00 Standard=0,80
    FoodLootNew = 0.8,
    -- Alle Gegenstände, die man lesen kann, wie Bücher, Flugblätter und Zeitungen. Minimum=0,00 Maximum=4,00 Standard=0,60
    LiteratureLootNew = 0.6,
    -- Bücher, die Skill-EP-Multiplikatoren bieten. Minimum=0,00 Maximum=4,00 Standard=0,60
    SkillBookLoot = 0.6,
    -- Gegenstände, mit denen man Rezepte lernt. Minimum=0,00 Maximum=4,00 Standard=0,60
    RecipeResourceLoot = 0.6,
    -- Medikamente, Verbandsmaterial und Erste-Hilfe-Ausrüstung. Minimum=0,00 Maximum=4,00 Standard=0,60
    MedicalLootNew = 0.6,
    -- Angeln, Zelte, Campingausrüstung usw. Minimum=0,00 Maximum=4,00 Standard=0,60
    SurvivalGearsLootNew = 0.6,
    -- Konserven, Trockenlebensmittel, Getränke. Minimum=0,00 Maximum=4,00 Standard=0,60
    CannedFoodLootNew = 0.6,
    -- Reine Waffen, die nicht als Werkzeuge in anderen Kategorien vorkommen. Minimum=0,00 Maximum=4,00 Standard=0,60
    WeaponLootNew = 0.6,
    -- Beinhaltet auch Waffenaufsätze. Minimum=0,00 Maximum=4,00 Standard=1,20
    RangedWeaponLootNew = 1.2,
    -- Lose Munition, Schachteln und Magazine. Minimum=0,00 Maximum=4,00 Standard=0,60
    AmmoLootNew = 0.6,
    -- Fahrzeugteile und Werkzeuge, die zu deren Einbau benötigt werden. Minimum=0,00 Maximum=4,00 Standard=0,60
    MechanicsLootNew = 0.6,
    -- Alles andere. Bezieht sich auch auf die Nahrungssuche in Stadt- und Straßenzonen. Minimum=0,00 Maximum=4,00 Standard=0,80
    OtherLootNew = 0.8,
    -- Alle anziehbaren Kleidungsstücke, die keine Behälter für Gegenstände bieten. Minimum=0,00 Maximum=4,00 Standard=0,60
    ClothingLootNew = 0.6,
    -- Rucksäcke und andere tragbare/ausrüstbare Behälter, z. B. Koffer. Minimum=0,00 Maximum=4,00 Standard=0,60
    ContainerLootNew = 0.6,
    -- Schlüssel für Gebäude/Autos, Schlüsselanhänger und Schlösser. Minimum=0,00 Maximum=4,00 Standard=0,40
    KeyLootNew = 0.4,
    -- VHS-Kasetten und CDs. Minimum=0,00 Maximum=4,00 Standard=0,60
    MediaLootNew = 0.6,
    -- Spiffo-Artikel, Plüschtiere und andere Andenken zum Sammeln, z. B. Fotos. Minimum=0,00 Maximum=4,00 Standard=0,60
    MementoLootNew = 0.6,
    -- Gegenstände, die beim Kochen zum Einsatz kommen, einschließlich solcher, die als Waffen verwendet werden können (z. B. Messer). Keine Lebensmittel. Einschließlich brauchbarer und unbrauchbarer Gegenstände. Minimum=0,00 Maximum=4,00 Standard=0,60
    CookwareLootNew = 0.6,
    -- Gegenstände und Waffen, die als Zutaten zum Basteln oder Bauen verwendet werden. Allgemeine Kategorie, die keine zu anderen Kategorien wie Kochen und Medizin gehörenden Gegenstände umfasst. Keine Werkzeuge. Minimum=0,00 Maximum=4,00 Standard=0,60
    MaterialLootNew = 0.6,
    -- Gegenstände und potenzielle Waffen, die sowohl in der Tier- als auch in der Pflanzenzucht verwendet werden, wie z. B. Saatgut, Kellen oder Schaufeln. Minimum=0,00 Maximum=4,00 Standard=0,60
    FarmingLootNew = 0.6,
    -- Gegenstände und Waffen, die zu Werkzeugen gehören, aber nicht in andere Kategorien wie Kfz-Mechanik oder Landwirtschaft passen. Minimum=0,00 Maximum=4,00 Standard=0,60
    ToolLootNew = 0.6,
    -- <BHC> [!] Es wird empfohlen, diese Einstellung NICHT zu ändern. [!] <RGB:1,1,1>   Kann verwendet werden, um die Chance auf Beute anzupassen, wenn die Beute gespawnt wird. Kann Anzahl der Würfe nicht unter 1 reduzieren. Kann sich bei hohen Werten negativ auf die Leistung auswirken. Es wird dringend empfohlen, diese Einstellung nicht zu ändern. Minimum=0,10 Maximum=100,00 Standard=1,00
    RollsMultiplier = 1.0,
    -- Eine durch Kommas getrennte Liste von Gegenstandstypen, die nicht als gewöhnliche Beute spawnen werden.
    LootItemRemovalList = "",
    -- Wenn diese Option aktiviert ist, spawnen Gegenstände, die auf der Entfernungsliste von Beutegegenständen stehen oder deren Seltenheit auf 'Keine' eingestellt ist, nicht in zufälligen Weltgeschichten.
    RemoveStoryLoot = false,
    -- Wenn diese Option aktiviert ist, spawnen Gegenstände, die auf der Entfernungsliste von Beutegegenständen stehen oder deren Seltenheit auf 'Keine' eingestellt ist, nicht an oder auf Zombies.
    RemoveZombieLoot = false,
    -- Ist der Wert größer als 0, wird das Spawnen von Beute im Verhältnis zur Anzahl der Zombies in der Nähe erhöht,  wobei der Effekt mit dieser Zahl multipliziert wird. Minimum=0 Maximum=20 Standard=0
    ZombiePopLootEffect = 0,
    -- Minimum=0,00 Maximum=0,20 Standard=0,05
    InsaneLootFactor = 0.05,
    -- Minimum=0,05 Maximum=0,60 Standard=0,20
    ExtremeLootFactor = 0.2,
    -- Minimum=0,20 Maximum=1,00 Standard=0,60
    RareLootFactor = 0.6,
    -- Minimum=0,60 Maximum=2,00 Standard=1,00
    NormalLootFactor = 1.0,
    -- Minimum=1,00 Maximum=3,00 Standard=2,00
    CommonLootFactor = 2.0,
    -- Minimum=2,00 Maximum=4,00 Standard=3,00
    AbundantLootFactor = 3.0,
    -- Steuert die globale Temperatur. Standard=Normal
    -- 1 = Sehr kalt
    -- 2 = Kalt
    -- 3 = Normal
    -- 4 = Heiß
    -- 5 = Sehr heiß
    Temperature = 3,
    -- Steuert wie oft es regnet. Standard=Normal
    -- 1 = Sehr trocken
    -- 2 = Trocken
    -- 3 = Normal
    -- 4 = Regnerisch
    -- 5 = Sehr regnerisch
    Rain = 3,
    -- Anzahl der Tage, bis das Erosionssystem (Das fügt der Welt Ranken, hohes Gras, neue Bäume usw. hinzu) 100 % erreicht hat. Standard=Langsam (200 Tage)
    -- 1 = Sehr schnell (20 Tage)
    -- 2 = Schnell (50 Tage)
    -- 3 = Normal (100 Tage)
    -- 4 = Langsam (200 Tage)
    -- 5 = Sehr langsam (500 Tage)
    ErosionSpeed = 4,
    -- Eine benutzerdefinierte Erosionsgeschwindigkeit festlegen. Null bedeutet, dass die Erosionsgeschwindigkeitsoption verwendet wird. Der Maximalwert beträgt 36.500 Tage (etwa 100 Jahre). Minimum=-1 Maximum=36500 Standard=0
    ErosionDays = 0,
    -- Steuert die Geschwindigkeit des Pflanzenwachstums. Standard=Normal
    -- 1 = Sehr schnell
    -- 2 = Schnell
    -- 3 = Normal
    -- 4 = Langsam
    -- 5 = Sehr langsam
    Farming = 3,
    -- Steuert die Zeit, die es braucht, bis Lebensmittel in einem Komposter zerfallen. Standard=2 Wochen
    -- 1 = 1 Woche
    -- 2 = 2 Wochen
    -- 3 = 3 Wochen
    -- 4 = 4 Wochen
    -- 5 = 6 Wochen
    -- 6 = 8 Wochen
    -- 7 = 10 Wochen
    -- 8 = 12 Wochen
    CompostTime = 2,
    -- Wie schnell der Hunger, Durst und die Müdigkeit des Charakters abnimmt. Standard=Normal
    -- 1 = Sehr schnell
    -- 2 = Schnell
    -- 3 = Normal
    -- 4 = Langsam
    -- 5 = Sehr langsam
    StatsDecrease = 3,
    -- Wirkt sich auf die Schwierigkeit von Fischen/Futtersuche aus. Standard=Normal
    -- 1 = Sehr schlecht
    -- 2 = Schlecht
    -- 3 = Normal
    -- 4 = Reichlich
    -- 5 = Sehr reichlich
    NatureAbundance = 3,
    -- Die Chance beim ersten Einbruch, den Hausalarm auszulösen. Standard=Manchmal
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    Alarm = 4,
    -- Definiere hier, wie oft die Türen/Fenster der Häuser gesperrt sein sollen. Standard=Sehr oft
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    LockedHouses = 6,
    -- Beginne mit einer Tasche und ein paar nützlichen Werkzeugen.
    StarterKit = false,
    -- Nährwert von Lebensmitteln wirkt sich auf den Zustand des Spielers aus.
    Nutrition = true,
    -- Definiere hier, wie schnell das Essen außerhalb eines Kühlschranks verderben soll. Standard=Normal
    -- 1 = Sehr schnell
    -- 2 = Schnell
    -- 3 = Normal
    -- 4 = Langsam
    -- 5 = Sehr langsam
    FoodRotSpeed = 3,
    -- Definiere hier, wie wirksam ein Kühlschrank kühlen kann. Standard=Normal
    -- 1 = Sehr wenig
    -- 2 = Wenig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Sehr hoch
    -- 6 = Kein Verfall
    FridgeFactor = 3,
    -- Wenn der Wert größer als 0 ist, wird die Beute, die gesehen wurde, nicht vor Ablauf dieser Zeit (in Stunden) respawnen. Minimum=0 Maximum=2147483647 Standard=0
    SeenHoursPreventLootRespawn = 0,
    -- Wenn der Wert größer als 0 ist, wird nach X Stunden in allen Behältern der Welt Beute respawnen. Um Beute spawnen zu können, muss ein Behälter mindestens einmal geplündert worden sein. Beute-Respawn wird nicht durch die Sichtbarkeit oder nachfolgendes Plündern beeinflusst. Minimum=0 Maximum=2147483647 Standard=0
    HoursForLootRespawn = 0,
    -- Behälter mit dieser oder höheren Gegenstandsanzahl, werden keine neue Beute bekommen. Minimum=0 Maximum=2147483647 Standard=5
    MaxItemsForLootRespawn = 5,
    -- Gegenstände erscheinen nicht in Zonen, die Spieler verbarrikadiert oder bebaut haben.
    ConstructionPreventsLootRespawn = true,
    -- Eine durch Komma getrennte Liste von Gegenstandstypen, die nach der bestimmten Anzahl an Stunden ("Stunden für die Lösch-Liste") entfernt werden.
    WorldItemRemovalList = "Base.Hat, Base.Glasses, Base.Maggots, Base.Slug, Base.Slug2, Base.Snail, Base.Worm, Base.Dung_Mouse, Base.Dung_Rat",
    -- Anzahl der Stunden, die vergehen, bevor ein Gegenstand, der auf den Boden gefallen ist, entfernt wird.  Gegenstände werden entfernt, sobald dieser Teil der Karte das nächste Mal geladen wird.  Nulll bedeutet, dass Gegenstände nie entfernt werden. Minimum=0,00 Maximum=2147483647,00 Standard=24,00
    HoursForWorldItemRemoval = 24.0,
    -- Wenn aktiv, werden alle Elemente, die *nicht* in der Lösch-Liste enthalten sind, entfernt.
    ItemRemovalListBlacklistToggle = false,
    -- Wie lange nach dem Ende der Welt soll es losgehen? Dies wirkt sich auf den Beginn der Welterosion und des Verderbs von Lebensmitteln aus. Hat keinen Einfluss auf das Startdatum. Standard=0
    -- 1 = 0
    -- 2 = 1
    -- 3 = 2
    -- 4 = 3
    -- 5 = 4
    -- 6 = 5
    -- 7 = 6
    -- 8 = 7
    -- 9 = 8
    -- 10 = 9
    -- 11 = 10
    -- 12 = 11
    -- 13 = 12
    TimeSinceApo = 1,
    -- Hat einfluss auf den täglichen Wasserverbrauch der Pflanzenanlagen, sowie die Resistenz gegenüber Krankheiten. Standard=Normal
    -- 1 = Sehr hoch
    -- 2 = Hoch
    -- 3 = Normal
    -- 4 = Niedrig
    -- 5 = Sehr niedrig
    PlantResilience = 3,
    -- Beeinflusst den Ertrag der Pflanzenanlagen. Standard=Normal
    -- 1 = Sehr schlecht
    -- 2 = Schlecht
    -- 3 = Normal
    -- 4 = Reichlich
    -- 5 = Sehr reichlich
    PlantAbundance = 3,
    -- Erholung von der Ermüdung durch das Ausführen von Handlungen. Standard=Normal
    -- 1 = Sehr schnell
    -- 2 = Schnell
    -- 3 = Normal
    -- 4 = Langsam
    -- 5 = Sehr langsam
    EndRegen = 3,
    -- Regelt wie oft Hubschrauber über die Event-Zone fliegen. Standard=Einmal
    -- 1 = Nie
    -- 2 = Einmal
    -- 3 = Manchmal
    -- 4 = Oft
    Helicopter = 2,
    -- Regelt wie oft Zombies angezogen werden. Wenn Meta-Ereignisse wie Hubschrauber und ferne Schüsse auftreten. Standard=Manchmal
    -- 1 = Nie
    -- 2 = Manchmal
    -- 3 = Oft
    MetaEvent = 2,
    -- Regelt die Ereignisse in der Nachtzeit, während der Spieler schläft. Standard=Nie
    -- 1 = Nie
    -- 2 = Manchmal
    -- 3 = Oft
    SleepingEvent = 2,
    -- Beeinflusst wie viel Kraftstoff von Generatoren verbraucht wird. Ein Generator der keinen Kraftstoff benötigt, sollte auf 0,0 eingestellt werden. Minimum=0,00 Maximum=100,00 Standard=0,10
    GeneratorFuelConsumption = 0.1,
    -- Erhöht/Verringert die Wahrscheinlichkeit zum Erscheinen von Stromgeneratoren in der Welt. Standard=Selten
    -- 1 = Nie (nicht empfohlen)
    -- 2 = Absurd Selten
    -- 3 = Manchmal
    -- 4 = Selten
    -- 5 = Normal
    -- 6 = Häufig
    -- 7 = Reichlich
    GeneratorSpawning = 4,
    -- Hat Auswirkungen darauf, wieviel Anmerkungen eine geplünderte Karte haben wird, die von einem verstorbenen Überlebenden gezeichnet wurden. Standard=Manchmal
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    AnnotatedMapChance = 4,
    -- Fügt bei der Charakter-Erstellung freie Punkte hinzu. Minimum=-100 Maximum=100 Standard=0
    CharacterFreePoints = 0,
    -- Verleiht von Spielern errichteten Bauwerken zusätzliche Trefferpunkte, sodass sie  widerstandsfähiger gegen Schaden durch Zombies sind. Standard=Normal
    -- 1 = Sehr niedrig
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Sehr hoch
    ConstructionBonusPoints = 3,
    -- Regelt die Umgebungsbeleuchtung bei Nacht. Standard=Normal
    -- 1 = Pechschwarz
    -- 2 = Dunkel
    -- 3 = Normal
    -- 4 = Hell
    NightDarkness = 3,
    -- Regelt die Zeit von der Abenddämmerung bis zum Morgengrauen. Standard=Normal
    -- 1 = Immer Nacht
    -- 2 = Lang
    -- 3 = Normal
    -- 4 = Kurz
    -- 5 = Immer Tag
    NightLength = 3,
    -- Aktiviert/Deaktiviert gebrochene Gliedmaßen, wenn Überlebende Verletzungen von Stößen, Zombie-Schäden und Stürzen erhalten.
    BoneFracture = true,
    -- Erhöht/Verringert die Auswirkungen von Verletzungen auf den Körper und die Heilungszeit. Standard=Normal
    -- 1 = Niedrig
    -- 2 = Normal
    -- 3 = Hoch
    InjurySeverity = 2,
    -- Anzahl der Spielstunden bis Zombie-Leichen automatisch aus der Welt entfernt werden.  Bei einem Wert von 0 entstehen keine Maden auf den Leichen. Minimum=-1,00 Maximum=2147483647,00 Standard=216,00
    HoursForCorpseRemoval = 216.0,
    -- Beeinflusst die Wirkung der Gesundheit und Emotionen des Spielers in der Nähe verfaulender Körper. Standard=Normal
    -- 1 = Keine
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Absurd hoch
    DecayingCorpseHealthImpact = 3,
    -- Bestimmt, ob in der Nähe befindliche „lebende“ Zombies die gleichen Auswirkungen auf die Gesundheit und die Emotionen des Spielers haben.
    ZombieHealthImpact = false,
    -- Wie viel Blut wird auf Boden und Wände gespritzt. Standard=Normal
    -- 1 = Keine
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Blutregen
    BloodLevel = 3,
    -- Steuert wie schnell Kleidung abnutzt, schmutzig oder blutig wird. Standard=Normal
    -- 1 = Deaktiviert
    -- 2 = Langsam
    -- 3 = Normal
    -- 4 = Schnell
    ClothingDegradation = 3,
    -- Bestimmt, ob Feuer sich ausbreiten kann.
    FireSpread = true,
    -- Anzahl der Tage im Spiel, bevor verrottetes Essen von der Karte entfernt wird.  Der Wert -1 bedeutet, dass faules Essen niemals entfernt wird. Minimum=-1 Maximum=2147483647 Standard=-1
    DaysForRottenFoodRemoval = -1,
    -- Wenn diese Option aktiviert ist, funktionieren Generatoren auf Außenkacheln.  Dadurch können beispielsweise Zapfsäulen mit Strom versorgt werden.
    AllowExteriorGenerator = true,
    -- Steuert die maximale Intensität des Nebels. Standard=Normal
    -- 1 = Normal
    -- 2 = Mäßig
    -- 3 = Niedrig
    -- 4 = Keine
    MaxFogIntensity = 1,
    -- Steuert die maximale Intensität des Regens. Standard=Normal
    -- 1 = Normal
    -- 2 = Mäßig
    -- 3 = Niedrig
    MaxRainFxIntensity = 1,
    -- Ob sich Schnee auf dem Boden ansammelt.  Wenn diese Option deaktiviert ist, wird Schnee trotzdem auf Vegetation und Dächern zu sehen sein.
    EnableSnowOnGround = true,
    -- Dekativiere um während eines Nahkampfangriffs ungehindert laufen zu können.
    AttackBlockMovements = true,
    -- Die Wahrscheinlichkeit von zufällig Generierten Häusern (z. B. Ausgebrannt,  mit versteckter Beute oder mit Leichen). Standard=Selten
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    -- 7 = Immer versuchen
    SurvivorHouseChance = 3,
    -- Wahrscheinlichkeit, mit der Straßengeschichten auftauchen (z.B. Straßensperren). Standard=Selten
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    -- 7 = Immer versuchen
    VehicleStoryChance = 3,
    -- Wahrscheinlichkeit, mit der Geschichten auftauchen, die für Kartenzonen spezifisch sind (z.B. Lagerfeuer im Wald). Standard=Selten
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    -- 7 = Immer versuchen
    ZoneStoryChance = 3,
    -- Ermöglicht es dir, bei der Anpassung deines Charakters aus allen Kleidungsstücken im Spiel zu wählen
    AllClothesUnlocked = false,
    -- Sollte das Wasser verunreinigt sein, wird dies durch eine entsprechende Warnung angezeigt.
    EnableTaintedWaterText = true,
    -- Ermöglicht das Spawnen von Fahrzeugen.
    EnableVehicles = true,
    -- Regelt wie oft Autos auf der Karte gefunden werden können. Standard=Wenig
    -- 1 = Keine
    -- 2 = Sehr wenig
    -- 3 = Wenig
    -- 4 = Normal
    -- 5 = Hoch
    CarSpawnRate = 3,
    -- Verwende dies, um die allgemeine Lautstärke des Motors zu reduzieren oder zu erhöhen. Minimum=0,00 Maximum=100,00 Standard=1,00
    ZombieAttractionMultiplier = 1.0,
    -- Regelt, ob Autos verschlossen sind, Schlüssel zum Starten benötigen usw.
    VehicleEasyUse = false,
    -- Regelt den Kraftstofffüllstand von entdeckten Autos. Standard=Niedrig
    -- 1 = Sehr niedrig
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Sehr hoch
    -- 6 = Voll
    InitialGas = 2,
    -- Wenn aktiv, geht den Zapfsäulen nie der Kraftstoff aus
    FuelStationGasInfinite = false,
    -- Gibt die Mindestmenge an Benzin an, die in den Zapfsäulen auftauchen kann. Aktiviere die Fortgeschritten-Option unten, um eine benutzerdefinierte Menge zu verwenden. Minimum=0,00 Maximum=1,00 Standard=0,00
    FuelStationGasMin = 0.0,
    -- Gibt die Höchstmenge an Benzin an, die in den Zapfsäulen auftauchen kann. Aktiviere die Fortgeschritten-Option unten, um eine benutzerdefinierte Menge zu verwenden. Minimum=0,00 Maximum=1,00 Standard=0,80
    FuelStationGasMax = 0.8,
    -- Gibt die Wahrscheinlichkeit in Prozent an, dass einzelne Zapfsäulen beim Start leer sind. Minimum=0 Maximum=100 Standard=20
    FuelStationGasEmptyChance = 20,
    -- Regelt die Wahrscheinlich, dass Autos verschlossen sind Standard=Manchmal
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    LockedCar = 4,
    -- Steuert wie sprithungrig die Fahrzeuge auf der Karte sind. Minimum=0,00 Maximum=100,00 Standard=1,00
    CarGasConsumption = 1.0,
    -- In welchem Zustand wird das neue Auto erscheinen. Standard=Normal
    -- 1 = Sehr niedrig
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Sehr hoch
    CarGeneralCondition = 2,
    -- Steuert den Schaden, der den verunfallenden Fahrzeugen zugefügt wird. Standard=Normal
    -- 1 = Sehr niedrig
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Sehr hoch
    CarDamageOnImpact = 3,
    -- Schaden den der Spieler bei einer Kollision vom Auto erhält. Standard=Keine
    -- 1 = Keine
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    -- 5 = Sehr hoch
    DamageToPlayerFromHitByACar = 1,
    -- Ob sich auf Hauptstraßen Staus  aus zerstörten Fahrzeugen bilden.
    TrafficJam = true,
    -- Wie oft werden Autos mit einem Alarm gefunden. Standard=Selten
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    CarAlarm = 3,
    -- Aktiviere/Deaktiviere, Spielerschäden durch einen Autounfall.
    PlayerDamageFromCrash = true,
    -- Anzahl der Stunden bevor der Sirenenton aufhört zu spielen. Minimum=0,00 Maximum=168,00 Standard=0,00
    SirenShutoffHours = 0.0,
    -- Regelt die Chancen für Fahrzeuge mit Kraftstoff im Tank zu finden. Standard=Normal
    -- 1 = Niedrig
    -- 2 = Normal
    -- 3 = Hoch
    ChanceHasGas = 2,
    -- Legt fest, ob der Spieler ein Auto entdecken kann,  das nach der Infektion gewartet und gepflegt wurde. Standard=Niedrig
    -- 1 = Keine
    -- 2 = Niedrig
    -- 3 = Normal
    -- 4 = Hoch
    RecentlySurvivorVehicles = 2,
    -- Wenn aktiviert, gewisse Nahkampfwaffen können mehrere Zombies mit einem Schlag treffen.
    MultiHitZombies = true,
    -- Chance gebissen zu werden, wenn ein Zombie von hinten angreift. Standard=Hoch
    -- 1 = Niedrig
    -- 2 = Mittel
    -- 3 = Hoch
    RearVulnerability = 2,
    -- Bestimmt, ob Zombies sich auf den Klang von Fahrzeugsirenen zubewegen.
    SirenEffectsZombies = true,
    -- Geschwindigkeit, mit der Tierstatistiken (Hunger, Durst, usw.) abnehmen. Standard=Normal
    -- 1 = Ultra schnell
    -- 2 = Sehr schnell
    -- 3 = Schnell
    -- 4 = Normal
    -- 5 = Langsam
    -- 6 = Sehr langsam
    AnimalStatsModifier = 4,
    -- Geschwindigkeit, mit der Tierstatistiken (Hunger, Durst, usw.) im Meta-Modus abnehmen. Standard=Normal
    -- 1 = Ultra schnell
    -- 2 = Sehr schnell
    -- 3 = Schnell
    -- 4 = Normal
    -- 5 = Langsam
    -- 6 = Sehr langsam
    AnimalMetaStatsModifier = 4,
    -- Wie lange Tiere trächtig sind, bevor sie Junge gebären. Standard=Normal
    -- 1 = Ultra schnell
    -- 2 = Sehr schnell
    -- 3 = Schnell
    -- 4 = Normal
    -- 5 = Langsam
    -- 6 = Sehr langsam
    AnimalPregnancyTime = 4,
    -- Geschwindigkeit, mit der Tiere altern. Standard=Normal
    -- 1 = Ultra schnell
    -- 2 = Sehr schnell
    -- 3 = Schnell
    -- 4 = Normal
    -- 5 = Langsam
    -- 6 = Sehr langsam
    AnimalAgeModifier = 4,
    -- Standard=Normal
    -- 1 = Ultra schnell
    -- 2 = Sehr schnell
    -- 3 = Schnell
    -- 4 = Normal
    -- 5 = Langsam
    -- 6 = Sehr langsam
    AnimalMilkIncModifier = 4,
    -- Standard=Normal
    -- 1 = Ultra schnell
    -- 2 = Sehr schnell
    -- 3 = Schnell
    -- 4 = Normal
    -- 5 = Langsam
    -- 6 = Sehr langsam
    AnimalWoolIncModifier = 4,
    -- Bestimmt die Chance, Tiere auf Farmen zu finden. Standard=Oft
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    -- 7 = Immer
    AnimalRanchChance = 5,
    -- Anzahl der Stunden, nach deren Ablauf Gras nachwächst,  das von Tieren gefressen oder vom Spieler gemäht wurde. Minimum=1 Maximum=9999 Standard=240
    AnimalGrassRegrowTime = 240,
    -- Bestimmt, ob ein Meta-Fuchs (d.h. ein im Spiel nicht sichtbarer) deine  Hühner angreifen kann, wenn die Stalltür nachts aufgelassen wird.
    AnimalMetaPredator = false,
    -- Bei aktivierter Option beachten betroffene Tierarten ihren Fortpflanzungszirkus.  Ansonsten können sie sich das ganze Jahr über fortpflanzen bzw. Eier legen.
    AnimalMatingSeason = true,
    -- Wie lange es dauert, bis Küken aus Eiern schlüpfen. Standard=Normal
    -- 1 = Ultra schnell
    -- 2 = Sehr schnell
    -- 3 = Schnell
    -- 4 = Normal
    -- 5 = Langsam
    -- 6 = Sehr langsam
    AnimalEggHatch = 4,
    -- Wenn aktiviert, ziehen Tierlaute in der Nähe befindliche Zombies an.
    AnimalSoundAttractZombies = true,
    -- Die Chance, dass Tiere Spuren hinterlassen. Standard=Manchmal
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    AnimalTrackChance = 4,
    -- Die Chance, einen Pfad für zu jagende Tiere zu erschaffen. Standard=Manchmal
    -- 1 = Nie
    -- 2 = Extrem selten
    -- 3 = Selten
    -- 4 = Manchmal
    -- 5 = Oft
    -- 6 = Sehr oft
    AnimalPathChance = 4,
    -- Häufigkeit und Intensität von Befall durch Ratten und Ungeziefer in betroffenen Gebäuden. Minimum=0 Maximum=50 Standard=25
    MaximumRatIndex = 25,
    -- Wie lange es dauert, bis die maximale Ungezieferdichte erreicht ist. Minimum=0 Maximum=365 Standard=90
    DaysUntilMaximumRatIndex = 90,
    -- Wenn ein Medium nicht vollständig gesehen oder gelesen wurde, bestimmt diese Einstellung, ob es vollständig angezeigt, als "???" angezeigt oder komplett ausgeblendet wird. Standard=Komplett ausgeblendet
    -- 1 = Vollständig angezeigt
    -- 2 = Als ??? angezeigt
    -- 3 = Komplett ausgeblendet
    MetaKnowledge = 3,
    -- Wenn aktiv kannst du alle Rezepte sehen, die an einer Station hergestellt werden können, auch wenn sie noch nicht bekannt sind.
    SeeNotLearntRecipe = true,
    -- Wenn ein Gebäude mehr Räumen hat, als hier festgelegt, wird es nicht geplündert. Minimum=0 Maximum=200 Standard=50
    MaximumLootedBuildingRooms = 50,
    -- Regelt, ob das Vergiften von Lebensmitteln aktiviert ist. Standard=Ja
    -- 1 = Ja
    -- 2 = Nein
    -- 3 = Nur die Bleichmittelvergiftung ist deaktiviert
    EnablePoisoning = 1,
    -- Bestimmt, ob und wann Maden in Leichen spawnen können. Standard=In und um Körper
    -- 1 = In und um Körper
    -- 2 = Nur in Körpern
    -- 3 = Niemals
    MaggotSpawn = 1,
    -- Je höher der Wert, desto länger halten Glühbirnen, bevor sie kaputt gehen.  Bei 0 gehen Glühbirnen niemals kaputt.  Hat keinen Einfluss auf die Scheinwerfer des Fahrzeugs. Minimum=0,00 Maximum=1000,00 Standard=2,00
    LightBulbLifespan = 2.0,
    -- Fischreichtum in Flüssen und Seen. Standard=Schlecht
    -- 1 = Sehr schlecht
    -- 2 = Schlecht
    -- 3 = Normal
    -- 4 = Reichlich
    -- 5 = Sehr reichlich
    FishAbundance = 2,
    -- Steht eine Fähigkeit auf dieser Stufe oder höher, bringen Fernsehen/VHS/andere Medien  keine EP ein. Minimum=0 Maximum=10 Standard=3
    LevelForMediaXPCutoff = 3,
    -- Steht eine Fähigkeit auf dieser Stufe oder höher, bringt das Zerlegen von Möbeln keine EP für ein. Gilt nicht für Elektrotechnik. Minimum=0 Maximum=10 Standard=0
    LevelForDismantleXPCutoff = 0,
    -- Anzahl der Tage, bevor alte Blutspritzer entfernt werden. Entfernung erfolgt, wenn Kartenteile geladen werden. Bei 0 werden sie nie entfernt. Minimum=0 Maximum=365 Standard=0
    BloodSplatLifespanDays = 0,
    -- Anzahl der Tage, bis wieder von bereits gelesener Literatur profitiert werden kann. Minimum=1 Maximum=365 Standard=45
    LiteratureCooldown = 45,
    -- Bestimmt, ob sich der Bonus auf Eigenschaftspunkte bei der Auswahl mehrerer negativer Eigenschaften verringert. Standard=Keine
    -- 1 = Keine
    -- 2 = 1 Punkt Strafe pro 3 gewählte negative Eigenschaften
    -- 3 = 1 Punkt Strafe pro 2 gewählte negative Eigenschaften
    -- 4 = 1 Punkt Strafe für jede gewählte negative Eigenschaft nach der ersten
    NegativeTraitsPenalty = 1,
    -- Dauer in Spielwelt-Minuten, die zum Lesen einer Seite benötigt wird. Minimum=0,00 Maximum=60,00 Standard=2,00
    MinutesPerPage = 0.2,
    -- Wenn aktiv, sterben Nutzpflanzen und Kräuter, die in Gebäuden wachsen. Gilt nicht für Hauspflanzen.
    KillInsideCrops = true,
    -- Wenn aktiv, wird der Pflanzenwachstum von Jahreszeiten beeinflusst.
    PlantGrowingSeasons = true,
    -- <BHC> [!] Es wird empfohlen, diese Einstellung NICHT zu ändern. Eine Änderung dieser Einstellung kann zu Performance-Problemen führen. [!] <RGB:1,1,1>   Wenn aktiviert, kann Erde auch auf anderen Ebenen als der Bodenebene platziert und bewirtschaftet werden.
    PlaceDirtAboveground = false,
    -- Die Geschwindigkeit des Pflanzenwachstums. Minimum=0,10 Maximum=100,00 Standard=1,00
    FarmingSpeedNew = 1.0,
    -- Bestimmt den Ernteertrag. Minimum=0,10 Maximum=10,00 Standard=1,00
    FarmingAmountNew = 1.0,
    -- Die Wahrscheinlichkeit, dass ein Gebäude bereits geplündert ist, wenn es gefunden wird. Aktiviere die Fortgeschritten-Option unten, um eine benutzerdefinierten Wert zu verwenden. Minimum=0 Maximum=200 Standard=25
    MaximumLooted = 25,
    -- Wie lange es dauert, bis die maximale Wahrscheinlichkeit auf das Vorfinden geplünderter Häuser erreicht ist. Minimum=0 Maximum=3650 Standard=90
    DaysUntilMaximumLooted = 90,
    -- Die Chance, dass ein Gebäude auf dem Land bereits geplündert ist, wenn es gefunden wird. Aktiviere die Fortgeschritten-Option unten, um eine benutzerdefinierten Wert zu verwenden. Minimum=0,00 Maximum=2,00 Standard=0,50
    RuralLooted = 0.5,
    -- Die maximale Beute, die nicht spawnen wird, wenn der Tag der maximal verringerten Beute erreicht ist. Aktiviere die Fortgeschritten-Option unten, um eine exakte Prozentzahl zu verwenden. Minimum=0 Maximum=100 Standard=20
    MaximumDiminishedLoot = 20,
    -- Tage, bis die maximal verringerten Beute erreicht wird. Minimum=0 Maximum=3650 Standard=3650
    DaysUntilMaximumDiminishedLoot = 3650,
    -- Wirkt als Multiplikator bei der Belastung der Muskeln durch das Schwingen von Waffen oder das Tragen schwerer Lasten. Minimum=0,00 Maximum=10,00 Standard=0,70
    MuscleStrainFactor = 0.7,
    -- Wirkt als Multiplikator für Unwohlsein durch getragener Gegenstände. Minimum=0,00 Maximum=10,00 Standard=0,80
    DiscomfortFactor = 0.8,
    -- Wenn größer als Null, kann Schaden durch schwere Wundinfektionen verursacht werden. Minimum=0,00 Maximum=10,00 Standard=1,00
    WoundInfectionFactor = 1.0,
    -- Wenn aktiviert, wird Kleidung mit zufälligen Farbtönen nicht so dunkel sein, dass sie praktisch schwarz ist.
    NoBlackClothes = true,
    -- Deaktiviert die Wahrscheinlichkeit, beim Klettern an Seilen oder über Mauern hinweg zu scheitern.
    EasyClimbing = false,
    -- Die maximale Brenndauer an Material, die in ein Lagerfeuer, einen Holzofen usw. eingelegt werden kann. Minimum=1 Maximum=168 Standard=8
    MaximumFireFuelHours = 8,
    -- Ersetzt die Trefferchance-Mechanik durch die Berechnung der Schadenschance. In diesem Modus wird das Zielen durch den Spieler bevorzugt. Standard=Nur Zombies
    -- 1 = Deaktiviert
    -- 2 = Nur Zombies
    -- 3 = Alle Arten von Zielen
    FirearmUseDamageChance = 2,
    -- Ein Multiplikator für die Entfernung, aus der Zombies Schüsse hören können. Minimum=0,20 Maximum=2,00 Standard=1,00
    FirearmNoiseMultiplier = 1.0,
    -- Multiplikator für die Wahrscheinlichkeit, mit der Schusswaffen klemmen. 0 deaktiviert Klemmen. Minimum=0,00 Maximum=10,00 Standard=1,00
    FirearmJamMultiplier = 1.0,
    -- Multiplikator für Zustandseffekte auf Trefferchance. 0 deaktiviert Zustandsstrafe. Minimum=0,00 Maximum=10,00 Standard=1,00
    FirearmMoodleMultiplier = 1.0,
    -- Multiplikator für Wettereffekte (Wind, Regen und Nebel) bei Trefferchance. 0 deaktiviert Wettereffekte. Minimum=0,00 Maximum=10,00 Standard=1,00
    FirearmWeatherMultiplier = 1.0,
    -- Aktivieren, damit Kopfbedeckungen wie Schweißmasken die Trefferchance beeinflussen
    FirearmHeadGearEffect = true,
    -- Chance wie oft Erdboden an Seen aus Lehm besteht. Minimum=0,00 Maximum=1,00 Standard=0,05
    ClayLakeChance = 0.05,
    -- Chance wie oft Erdboden an Flüssen aus Lehm besteht. Minimum=0,00 Maximum=1,00 Standard=0,05
    ClayRiverChance = 0.05,
    -- Minimum=1 Maximum=100 Standard=20
    GeneratorTileRange = 1,
    -- Wie viele Stockwerke sowohl oberhalb als auch unterhalb eines Generators mit Strom versorgt werden können. Minimum=1 Maximum=15 Standard=3
    GeneratorVerticalPowerRange = 1,
    -- Maximum number of game days (after the radio becomes active) to reach the extraction point.   0 to disable the deadline. Minimum=0 Maximum=180 Standard=0
    WQS_DeadlineDays_opt = 0,
    -- Duration of the extraction event in game hours.   Recommended 3 or 4 hours Minimum=3 Maximum=48 Standard=3
    WQS_ExtractionEventHoursDuration_opt = 3,
    -- Governs the overall difficulty of the extraction event. Minimum=0,10 Maximum=4,00 Standard=1,00
    WQS_ExtractionEventDifficulty_opt = 1.0,
    -- Number of game days that must pass before the radio signal becomes active.  0 to disable this option and have signal already active at start. Minimum=0 Maximum=365 Standard=0
    WQS_WaitForSignalDuration_opt = 0,
    -- How many repeater antennas you must build in various places of the map to get enough radio signal strength.  0 to disable this option and have full signal strength from the start. Minimum=0 Maximum=4 Standard=0
    WQS_RepeatersModeHowMany_opt = 0,
    -- Multiplier to the chance of finding mod related items in the loot of zombie bodies.(walkie talkie, map fragment of repeater location, etc.) Minimum=0,10 Maximum=5,00 Standard=1,00
    WQS_ItemInZombieLootMultiplier_opt = 1.0,
    -- Start with the item needed for extraction, you don't need to find it
    WQS_StartWithExtractionItem_opt = false,
    -- If selected you must stay near the extraction point during the entire duration of the extraction event.
    WQS_ConfinedMode_opt = false,
    -- If selected, the quest will NOT be active at the beginning and can only be started after crafting the antenna.
    WQS_GameModeExtended_opt = true,
    -- Select the extraction zone Standard=Random
    -- 1 = Random
    -- 2 = Louisville Bridge Road
    -- 3 = Louisville Ohio Mall
    -- 4 = Louisville Central Hospital
    -- 5 = Louisville Fossoil Factory
    -- 6 = Louisville Orio Offices
    -- 7 = Muldraugh Mass-Genfac
    -- 8 = Muldraugh Soccer Field
    -- 9 = March Ridge Cinema
    -- 10 = Rosewood Penitentiary
    -- 11 = Louisville Bruiser
    WQS_ZoneMap_opt = 1,
    -- If a random extraction zone is chosen allows you to select which zones (even those of modded maps) include in the random pick list.   If a fixed extraction zone is selected this parameter is ignored. Standard=Random including all zones
    -- 1 = Random including all zones
    -- 2 = Random only Louisville zones
    -- 3 = Random excluding Louisville zones
    WQS_ZoneMap_random_opt = 1,
    -- Parts with a success chance below this value will be skipped during training. <LINE> At '-1' this setting is not enforced, any value over '-1' is enforced server-wide. <LINE>  <LINE> 0% -> All parts will be worked on. Parts will break at lower skill levels. <LINE> 30% -> Default setting for a good balance. <LINE> 100% -> Only parts that are guaranteed to succeed will be worked on. Completely safe at all skill levels. Minimum=-1 Maximum=100 Standard=-1
    BAM_Server_MinSuccessChance = -1,
    -- Base XP awarded by Simple practice recipes. Minimum=0,00 Maximum=500,00 Standard=30,00
    CSP_XPSimpleBase = 30.0,
    -- Base XP awarded by Intermediate practice recipes. Minimum=0,00 Maximum=500,00 Standard=60,00
    CSP_XPIntermediateBase = 60.0,
    -- Base XP awarded by Advanced practice recipes. Minimum=0,00 Maximum=500,00 Standard=100,00
    CSP_XPAdvancedBase = 100.0,
    Basement = {
        -- Bestimmt, wie häufig Keller an zufälligen Orten spawnen. Standard=Manchmal
        -- 1 = Nie
        -- 2 = Extrem selten
        -- 3 = Selten
        -- 4 = Manchmal
        -- 5 = Oft
        -- 6 = Sehr oft
        -- 7 = Immer
        SpawnFrequency = 4,
    },
    Map = {
        -- Wenn diese Option aktiviert ist, wird ein Minikartenfenster angezeigt.
        AllowMiniMap = true,
        -- Wenn diese Option aktiviert ist, kann auf die Weltkarte zugegriffen werden.
        AllowWorldMap = true,
        -- Wenn diese Option aktiviert ist, wird die Weltkarte beim Spielstart komplett bekannt sein.
        MapAllKnown = false,
        -- Bei aktivierter Funktion können die Karten nur gelesen werden, wenn eine Lichtquelle vorhanden ist.
        MapNeedsLight = true,
    },
    ZombieLore = {
        -- Steuert die Zombie-Bewegungsrate. Standard=zufällig
        -- 1 = Sprinter
        -- 2 = Schnelle Schlurfer
        -- 3 = Schlurfer
        -- 4 = zufällig
        Speed = 4,
        -- Wenn zufällige Geschwindigkeit aktiviert ist, wird hier festgesetzt, wie viel Prozent der Zombies Sprinter sind. Aktiviere die Fortgeschritten-Option unten, um einen benutzerdefinierten Prozentsatz zu verwenden. Minimum=0 Maximum=100 Standard=0
        SprinterPercentage = 2,
        -- Steuert den Schaden den Zombies pro Angriff verursachen. Standard=Normal
        -- 1 = Übermenschlich
        -- 2 = Normal
        -- 3 = Schwach
        -- 4 = zufällig
        Strength = 4,
        -- Steuert die Schwierigkeit, Zombies zu töten. Standard=zufällig
        -- 1 = Zäh
        -- 2 = Normal
        -- 3 = Zerbrechlich
        -- 4 = zufällig
        Toughness = 4,
        -- Steuert wie sich der Zombievirus ausbreitet. Standard=Blut + Speichel
        -- 1 = Blut + Speichel
        -- 2 = Nur Speichel
        -- 3 = Jeder ist Infiziert
        -- 4 = Keine
        Transmission = 2,
        -- Steuert wie schnell die Infektion wirksam wird. Standard=2-3 Tage
        -- 1 = Sofort
        -- 2 = 0-30 Sekunden
        -- 3 = 0-1 Minute
        -- 4 = 0-12 Stunden
        -- 5 = 2-3 Tage
        -- 6 = 1-2 Wochen
        -- 7 = Nie
        Mortality = 4,
        -- Steuert wie schnell sich Leichen als Zombies erheben. Standard=0-1 Minute
        -- 1 = Sofort
        -- 2 = 0-30 Sekunden
        -- 3 = 0-1 Minute
        -- 4 = 0-12 Stunden
        -- 5 = 2-3 Tage
        -- 6 = 1-2 Wochen
        Reanimate = 3,
        -- Steuert die Zombie-Intelligenz. Standard=Einfache Navigation
        -- 1 = Navigieren + Verwendung von Türen
        -- 2 = Navigieren
        -- 3 = Einfache Navigation
        -- 4 = zufällig
        Cognition = 3,
        -- Minimum=0 Maximum=100 Standard=0
        DoorOpeningPercentage = 0,
        -- Steuert welche Zombies unter Fahrzeuge kriechen können. Standard=Oft
        -- 1 = Nie
        -- 2 = Sehr selten
        -- 3 = Selten
        -- 4 = Manchmal
        -- 5 = Oft
        -- 6 = Sehr oft
        -- 7 = Immer
        CrawlUnderVehicle = 5,
        -- Steuert wie lange sich Zombies an Spieler erinnern, nachdem sie sie gesehen oder gehört haben. Standard=Normal
        -- 1 = Lang
        -- 2 = Normal
        -- 3 = Kurz
        -- 4 = Keine
        -- 5 = Zufällig
        -- 6 = Zufällig zwischen Normal und Keine
        Memory = 2,
        -- Steuert den Sichtradius von Zombies. Standard=Zufällig zwischen Normal und Schlecht
        -- 1 = Adleraugen
        -- 2 = Normal
        -- 3 = Schlecht
        -- 4 = Zufällig
        -- 5 = Zufällig zwischen Normal und Schlecht
        Sight = 5,
        -- Steuert den Hörradius von Zombies. Standard=Zufällig zwischen Normal und Schlecht
        -- 1 = Sehr gut
        -- 2 = Normal
        -- 3 = Schlecht
        -- 4 = Zufällig
        -- 5 = Zufällig zwischen Normal und Schlecht
        Hearing = 5,
        -- Aktiviert die neue fortschrittliche Tarnungsmechanik, die es dir ermöglicht, dich vor Zombies hinter Autos zu verstecken, Eigenschaften und Wetter zu berücksichtigen uvm.
        SpottedLogic = true,
        -- Zombies greifen Türen und Konstruktionen an während sie umherwandern, wenn keine Spieler zu Sehen/Hören sind.
        ThumpNoChasing = false,
        -- Bestimmt ob Zombies, Spieler-Konstruktionen und Verteidigungen zerstören können oder nicht.
        ThumpOnConstruction = true,
        -- Ob Zombies tagsüber oder nachts "aktiver" sind.  "Aktive" Zombies bewegen sich mit der in der Einstellung "Geschwindigkeit" festgelegtem Tempo.  "Inaktive" Zombies sind langsamer und neigen dazu, nicht zu verfolgen. Standard=Beides
        -- 1 = Beides
        -- 2 = Nacht
        -- 3 = Tag
        ActiveOnly = 1,
        -- Ermöglicht Zombies, Hausalarme auszulösen, wenn sie durch Fenster und Türen brechen.
        TriggerHouseAlarm = true,
        -- Ob mehrere angreifende Zombies dich zu Boden ziehen und töten können. Abhängig von der Stärke der Zombies.
        ZombiesDragDown = true,
        -- Bestimmt, ob Kriecher-Zombies in der Nähe eines Spielers dazu beitragen, von einer Zombiegruppe heruntergezogen und getötet zu werden.
        ZombiesCrawlersDragDown = false,
        -- Ob Zombies dich angreifen können, nachdem sie über einen Zaun oder durch ein  Fenster geklettert sind, wenn du zu nah bist.
        ZombiesFenceLunge = true,
        -- Dient als Multiplikator bei der Bestimmung der Wirksamkeit der von Zombies getragenen Rüstung. Minimum=0,00 Maximum=100,00 Standard=2,00
        ZombiesArmorFactor = 2.0,
        -- Der maximale Verteidigungsprozentsatz, den eine getragene Schutzbekleidung einem Zombie bieten kann. Minimum=0 Maximum=100 Standard=85
        ZombiesMaxDefense = 85,
        -- Prozentuale Chance, eine zufällig angebrachte Waffe zu haben. Minimum=0 Maximum=100 Standard=6
        ChanceOfAttachedWeapon = 6,
        -- Wie viel Schaden Zombies nehmen, wenn sie aus der Höhe fallen. Minimum=0,00 Maximum=100,00 Standard=1,00
        ZombiesFallDamage = 1.0,
        -- Bestimmt, ob einige tot aussehende Zombies wiederbelebt werden und den Spieler angreifen. Standard=Einige Zombies auf der Welt werden vorgeben, tot zu sein
        -- 1 = Einige Zombies auf der Welt werden vorgeben, tot zu sein
        -- 2 = Einige Zombies auf der Welt, sowie einige, die Sie „töten“, können vorgeben, tot zu sein
        -- 3 = Zombies werden niemals vorgeben, tot zu sein
        DisableFakeDead = 1,
        -- Zombies werden nicht dort spawnen, wo Spieler spawnen. Standard=Im Gebäude und drumherum
        -- 1 = Im Gebäude und drumherum
        -- 2 = Im Gebäude
        -- 3 = Im Raum
        -- 4 = Zombies können überall spawnen
        PlayerSpawnZombieRemoval = 2,
        -- Wie viele Zombies es braucht, um einen hohen Zaun zu beschädigen. Minimum=-1 Maximum=100 Standard=25
        FenceThumpersRequired = 25,
        -- Wie schnell Zombies hohe Zäune beschädigen. Minimum=0,01 Maximum=100,00 Standard=1,00
        FenceDamageMultiplier = 1.0,
    },
    ZombieConfig = {
        -- Wird durch die Populationsoption "Zombie-Anzahl" oder durch eine hier eingegebene benutzerdefinierte Zahl festgelegt. Verrückt = 2.5, Sehr Viele = 1.6, Viele = 1.2, Normal = 0.65, Wenige = 0.15, Keine = 0.0. Minimum=0,00 Maximum=4,00 Standard=0,65
        PopulationMultiplier = 0.65,
        -- Ein Multiplikator für die gewünschte Zombie-Population zu Beginn des Spiels. Verrückt = 3, Sehr Viele = 2, Viele = 1.5, Normal = 1, Wenige = 0.5, Keine = 0.0. Minimum=0,00 Maximum=4,00 Standard=1,00
        PopulationStartMultiplier = 1.0,
        -- Ein Multiplikator für die gewünschte Zombie-Population am einem Tag mit dem höchsten Aufkommen. Verrückt = 3, Sehr Viele = 2, Viele = 1.5, Normal = 1.0, Wenige = 0.5, Keine = 0.0. Minimum=0,00 Maximum=4,00 Standard=1,50
        PopulationPeakMultiplier = 1.5,
        -- Der Tag, an dem die Bevölkerungsdichte ihren Höhepunkt erreicht. Minimum=1 Maximum=365 Standard=28
        PopulationPeakDay = 28,
        -- Anzahl der Stunden die verstreichen müssen, bevor Zombies in einer Zelle respawnen. Null bedeutet, deaktiviert. Minimum=0,00 Maximum=8760,00 Standard=0,00
        RespawnHours = 0.0,
        -- Anzahl der Stunden in der eine Zelle ungesehen bleiben muss, bevor Zombies wiedererscheinen. Minimum=0,00 Maximum=8760,00 Standard=0,00
        RespawnUnseenHours = 0.0,
        -- Der Bruchteil einer Zelle mit der gewünschten Bevölkerungsdichte, die alle 'Wiedererschein-Stunden' aufgestellt werden können. Minimum=0,00 Maximum=1,00 Standard=0,00
        RespawnMultiplier = 0.0,
        -- Die Anzahl der Stunden, die vergehen müssen, bevor Zombies  in leere Bereiche derselben Zelle wandern. Bei 0 ist die Wanderung deaktiviert. Minimum=0,00 Maximum=8760,00 Standard=12,00
        RedistributeHours = 12.0,
        -- Der Abstand zum letzten gehörten Geräusch zu dem virtuelle Zombies wandern. Minimum=10 Maximum=1000 Standard=100
        FollowSoundDistance = 100,
        -- Die Gruppenstärke von echten Zombies die sich im Leerlauf bilden. Null bedeutet, Zombies bilden keine Gruppen. Gruppen bilden sich nicht innerhalb von Gebäuden oder Waldzonen. Minimum=0 Maximum=1000 Standard=20
        RallyGroupSize = 20,
        -- Prozentsatz, um den die Größe von Zombie-Gruppen von der Standardgröße abweichen kann (sowohl größer als auch kleiner).   Bei einer Varianz von 50 % und einer Standardgruppengröße von 20 variiert die Gruppengröße beispielsweise zwischen 10 und 30. Minimum=0 Maximum=100 Standard=50
        RallyGroupSizeVariance = 50,
        -- Entfernungen die echte Zombies im Leerlauf reisen um Gruppen zu bilden. Minimum=5 Maximum=50 Standard=20
        RallyTravelDistance = 20,
        -- Der Abstand zwischen den Zombiegruppen. Minimum=5 Maximum=25 Standard=15
        RallyGroupSeparation = 15,
        -- Die Distanz zwischen Mitglieder und dem Anführer der Gruppe. Minimum=1 Maximum=10 Standard=3
        RallyGroupRadius = 3,
        -- Legt die maximale Anzahl an Zombies fest, die vorhanden sind, bevor eine Bereinigung erfolgt. Der Wert 0 bedeutet, dass keine Zombies bereinigt werden. Der Standardwert (300) wird dringend empfohlen! Eine Erhöhung dieses Werts oder die Einstellung auf 0 kann zu erheblichen Leistungsproblemen führen. Bitte reproduziere bei Fehlern das jeweilige Problem nochmal mit der Standardeinstellung, bevor du uns einen Fehlerbericht zusendest. Minimum=0 Maximum=5000 Standard=300
        ZombiesCountBeforeDelete = 300,
    },
    MultiplierConfig = {
        -- Bestimmt die Rate, mit der sich alle Fähigkeiten entwickeln. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Global = 1.0,
        -- Wenn diese Option aktiviert wird, werden alle Fähigkeiten den globalen Multiplikator verwenden.
        GlobalToggle = true,
        -- Bestimmt die Rate, mit der sich die Fitness-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Fitness = 1.0,
        -- Bestimmt die Rate, mit der sich die Stärke-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Strength = 1.0,
        -- Bestimmt die Rate, mit der sich die Sprint-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Sprinting = 1.0,
        -- Bestimmt die Rate, mit der sich die Leichtfüßig-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Lightfoot = 1.0,
        -- Bestimmt die Rate, mit der sich die Flink-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Nimble = 1.0,
        -- Bestimmt die Rate, mit der sich die Schleichen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Sneak = 1.0,
        -- Bestimmt die Rate, mit der sich die Axt-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Axe = 1.0,
        -- Bestimmt die Rate, mit der sich die Stumpfwaffen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Blunt = 1.0,
        -- Bestimmt die Rate, mit der sich die Kurze-Stumpfwaffe-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        SmallBlunt = 1.0,
        -- Bestimmt die Rate, mit der sich die Lange-Klingenwaffe-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        LongBlade = 1.0,
        -- Bestimmt die Rate, mit der sich die Kurze-Klingenwaffe-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        SmallBlade = 1.0,
        -- Bestimmt die Rate, mit der sich die Speer-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Spear = 1.0,
        -- Bestimmt die Rate, mit der sich die Instandhaltungs-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Maintenance = 1.0,
        -- Bestimmt die Rate, mit der sich die Tischlerei-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Woodwork = 1.0,
        -- Bestimmt die Rate, mit der sich die Kochen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Cooking = 1.0,
        -- Bestimmt die Rate, mit der sich die Landwirtschaft-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Farming = 1.0,
        -- Bestimmt die Rate, mit der sich die Erste-Hilfe-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Doctor = 1.0,
        -- Bestimmt die Rate, mit der sich die Elektrotechnik-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Electricity = 1.0,
        -- Bestimmt die Rate, mit der sich die Schweißen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        MetalWelding = 1.0,
        -- Bestimmt die Rate, mit der sich die Kfz-Mechanik-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Mechanics = 1.0,
        -- Bestimmt die Rate, mit der sich die Schneidern-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Tailoring = 1.0,
        -- Bestimmt die Rate, mit der sich die Zielen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Aiming = 1.0,
        -- Bestimmt die Rate, mit der sich die Nachladen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Reloading = 1.0,
        -- Bestimmt die Rate, mit der sich die Angeln-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Fishing = 1.0,
        -- Bestimmt die Rate, mit der sich die Fallenstellen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Trapping = 1.0,
        -- Bestimmt die Rate, mit der sich die Nahrungssuche-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        PlantScavenging = 1.0,
        -- Bestimmt die Rate, mit der sich die Steinbearbeitung-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        FlintKnapping = 1.0,
        -- Bestimmt die Rate, mit der sich das Maurerhandwerk entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Masonry = 1.0,
        -- Bestimmt die Rate, mit der sich die Töpferei-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Pottery = 1.0,
        -- Bestimmt die Rate, mit der sich die Schnitzen-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Carving = 1.0,
        -- Bestimmt die Rate, mit der sich die Tierpflege-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Husbandry = 1.0,
        -- Bestimmt die Rate, mit der sich die Spurensuche-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Tracking = 1.0,
        -- Bestimmt die Rate, mit der sich die Metallbearbeitung-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Blacksmith = 1.0,
        -- Bestimmt die Rate, mit der sich die Schlachtung-Fähigkeit entwickelt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Butchering = 1.0,
        -- Rate, mit der die Fertigkeit "Glasherstellung" steigt. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Glassmaking = 1.0,
        -- Multiplies the XP gained in the Archery skill from landing bow hits. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Archery = 1.0,
        -- Multiplies the XP gained in the Fletching skill from cutting fletching, carving shafts, binding them and fitting a head. Minimum=0,00 Maximum=1000,00 Standard=1,00
        Fletching = 1.0,
        -- Minimum=0,00 Maximum=1000,00 Standard=1,00
        Side_L = 1.0,
        -- Minimum=0,00 Maximum=1000,00 Standard=1,00
        Side_R = 1.0,
        -- Minimum=0,00 Maximum=1000,00 Standard=1,00
        ProstFamiliarity = 1.0,
        -- Rate at which the Lockpicking skill levels up. Default 1. Same scale as the other skill multipliers (0 to 1000). Minimum=0,00 Maximum=1000,00 Standard=1,00
        Lockpicking = 1.0,
    },
    Trucksmith = {
        -- Zombie breakthrough: heavy RKC vehicles (HEMTT trucks, LAV-25 and others) plough through crowds of zombies and keep their speed, instead of being slowed down like a light car. On by default. If the vehicle physics act strangely (bouncing, jumping), turning it off is recommended.
        ZombieBreakthrough = true,
        -- How badly the people inside an RKC vehicle (HEMTT trucks, LAV-25 and others) get hurt when it crashes. Normal (default): no worse than the safest vanilla cars - the armoured LAV-25 protects best. Low: half of that. Off: no crash injuries in RKC vehicles. High: 1.5 x Normal. The game's own crash settings still apply. Only the injuries change - not the physics or the vehicle damage. Standard=Normal
        -- 1 = Off
        -- 2 = Low
        -- 3 = Normal
        -- 4 = High
        CrashInjury = 3,
        -- How tracked RKC vehicles (the Bradley and others) steer while backing up. Tank (default): the left key always turns the vehicle left (counter-clockwise), as a tank's steering. Car: backing up, the left key swings the rear to the left, as a car. Turning in place is the same in both. Standard=Tank
        -- 1 = Tank
        -- 2 = Car
        ReverseSteer = 1,
    },
    HB = {
        -- Casings will stay in the floor after landing. Turn this off to make casings only visible while active.
        PermanentCasings = true,
        -- Enable custom icons for casings and bullets.
        CustomIcons = true,
        -- Enable sounds for casings hitting the floor.
        CasingSounds = true,
        -- Bandits will drop casings when shooting their guns.
        BanditsCasings = false,
        -- Racking will be required to be done by the player, no longer automatic. Recommended to be used only in Singleplayer only.
        ManualRacking = false,
    },
    SVUC = {
        -- How long it takes to install and uninstall light armor. Minimum=10 Maximum=50 Standard=15
        timeLight = 15,
        -- How long it takes to install and uninstall heavy armor. Minimum=10 Maximum=50 Standard=30
        timeHeavy = 30,
        -- How long it takes to install and uninstall reinforced armor. Minimum=10 Maximum=50 Standard=45
        timeReinforced = 45,
        -- Minimum=10 Maximum=50 Standard=15
        timeMods = 15,
        -- How long it takes to install and uninstall wheel chains. Minimum=10 Maximum=50 Standard=15
        timeWheels = 15,
        -- The part HP has to drop below this number to be repaired. Minimum=50 Maximum=80 Standard=80
        protectionHealthTriger = 80,
        -- How much damage to deal to light armor when it repairs a part. Minimum=1 Maximum=10 Standard=5
        protectionLightHealthDelta = 5,
        -- How much damage to deal to heavy armor when it repairs a part. Minimum=1 Maximum=10 Standard=4
        protectionHeavyHealthDelta = 4,
        -- How much damage to deal to reinforced armor when it repairs a part. Minimum=1 Maximum=10 Standard=3
        protectionReinforcedHealthDelta = 3,
        -- How much damage to deal to small bullbars when they repair a part. Minimum=1 Maximum=10 Standard=6
        protectionBullbarSmallHealthDelta = 6,
        -- How much damage to deal to medium bullbars when they repair a part. Minimum=1 Maximum=10 Standard=5
        protectionBullbarMediumHealthDelta = 5,
        -- How much damage to deal to large bullbars when they repair a part. Minimum=1 Maximum=10 Standard=4
        protectionBullbarLargeHealthDelta = 4,
        -- How much damage to deal to plows when they repair a part. Minimum=1 Maximum=10 Standard=3
        protectionPlowHealthDelta = 3,
        -- How much damage to deal to wheel chains when they repair a part. Minimum=1 Maximum=10 Standard=1
        protectionWheelsHealthDelta = 1,
        -- How much horsepower to add when a small air scoop's installed. Minimum=0 Maximum=50 Standard=10
        protectionEngineSmallPowerIncrease = 10,
        -- How much horsepower to add when a medium air scoop's installed. Minimum=0 Maximum=50 Standard=20
        protectionEngineMediumPowerIncrease = 20,
        -- How much horsepower to add when a large air scoop's installed. Minimum=0 Maximum=50 Standard=35
        protectionEngineLargePowerIncrease = 35,
        -- How much horsepower to add when a piped air scoop's installed. Minimum=0 Maximum=50 Standard=50
        protectionEnginePipedPowerIncrease = 50,
        -- How much horsepower to add when a snorkel's installed. Minimum=0 Maximum=50 Standard=15
        protectionEngineSnorkelPowerIncrease = 15,
        -- Multiplier for extra gas to use when light armor's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=10
        protectionLightGasUsage = 10,
        -- Multiplier for extra gas to use when heavy armor's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=20
        protectionHeavyGasUsage = 20,
        -- Multiplier for extra gas to use when reinforced armor's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=40
        protectionReinforcedGasUsage = 40,
        -- Multiplier for extra gas to use when modifications are installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=0
        protectionModsGasUsage = 0,
        -- Multiplier for extra gas to use when a small bullbar's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=1
        protectionBullbarSmallGasUsage = 1,
        -- Multiplier for extra gas to use when a medium bullbar's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=5
        protectionBullbarMediumGasUsage = 5,
        -- Multiplier for extra gas to use when a large bullbar's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=10
        protectionBullbarLargeGasUsage = 10,
        -- Multiplier for extra gas to use when a plow's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=20
        protectionPlowGasUsage = 20,
        -- Multiplier for extra gas to use when a small air scoop's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=2
        protectionEngineSmallGasUsage = 2,
        -- Multiplier for extra gas to use when a medium air scoop's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=3
        protectionEngineMediumGasUsage = 3,
        -- Multiplier for extra gas to use when a large air scoop's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=4
        protectionEngineLargeGasUsage = 4,
        -- Multiplier for extra gas to use when a piped air scoop's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=5
        protectionEnginePipedGasUsage = 5,
        -- Multiplier for extra gas to use when a snorkel's installed. Set to 0 to disable. Minimum=0 Maximum=100 Standard=1
        protectionEngineSnorkelGasUsage = 1,
    },
    NewMusic = {
        -- Legt fest, wie weit die Ortung aktiver Geräte von jedem Client beibehalten wird. Der Wert 0 bedeutet unendliche Reichweite. Minimum=0 Maximum=36000 Standard=1500
        MaxTrackingRange = 1500,
        -- Feste Obergrenze für die Anzahl der aktiv synchronisierten/wiedergabeverwalteten Geräte pro Client. Minimum=4 Maximum=50 Standard=10
        ActiveDeviceLimit = 10,
        -- Wie schnell sich der Akku im realen Gebrauch entlädt. Minimum=0,02 Maximum=1000,00 Standard=24,00
        BatteryDrainRate = 24.0,
        -- Wie weit, in Kacheln ausgedrückt, sind Wiedergabegeräte weltweit bei maximaler Lautstärke hörbar. Minimum=9 Maximum=500 Standard=35
        AudioMaxRadius = 35,
        -- Wie weit (in Kacheln) Zombies von Geräten mit maximaler Lautstärke angezogen werden. Die Anziehungsreichweite verringert sich mit zunehmender Lautstärke. Minimum=9 Maximum=200 Standard=105
        ZombieAttractionRadius = 105,
        -- Ermöglicht die Demontage und das Ausschlachten von New Music-Geräten.
        Disassembly = true,
        -- Ermöglicht das Erscheinen von Gegenständen aus dem Zomboid-OST-Basismod. Deaktivieren Sie diese Option, um sie zu deaktivieren.
        ZomboidOST = true,
        -- Wenn diese Option aktiviert ist, werden Standard-CDs und CD-Player durch New Music-Versionen ersetzt.
        ConvertVanillaCDsAndCDPlayers = true,
        -- Wenn diese Option aktiviert ist, können Kassetten, Schallplatten und CDs in ihren Hüllen, Covern oder Covern erscheinen (sofern vorhanden).
        MediaSpawnsWithCases = true,
        -- Steuert die Intensität der Kassettenmedien-Erzeugung. 0,00 deaktiviert. Minimum=0,00 Maximum=4,00 Standard=0,60
        CassettesSpawnRate = 0.21,
        -- Steuert die Intensität der Vinylmedienerzeugung. 0,00 deaktiviert. Minimum=0,00 Maximum=4,00 Standard=0,30
        VinylRecordsSpawnRate = 0.09,
        -- Steuert die Intensität der CD-Medienerzeugung. 0,00 deaktiviert. Minimum=0,00 Maximum=4,00 Standard=0,60
        CDsSpawnRate = 0.05,
        -- Steuert die Walkman-Spawn-Intensität. Minimum=0,00 Maximum=4,00 Standard=0,60
        WalkmanSpawnRate = 0.2,
        -- Steuert die Häufigkeit des Ghettoblaster-Erscheinens. Minimum=0,00 Maximum=4,00 Standard=0,60
        BoomboxSpawnRate = 0.2,
        -- Steuert die Häufigkeit des Auftretens von CD-Playern. Minimum=0,00 Maximum=4,00 Standard=0,60
        CDPlayerSpawnRate = 0.1,
        -- Steuert die Spawn-Intensität von Rekordspielern. Minimum=0,00 Maximum=4,00 Standard=0,60
        RecordPlayerSpawnRate = 0.1,
        -- Steuert die Spawn-Intensität von Zombie-Musikgeräten. Minimum=0,00 Maximum=4,00 Standard=0,60
        MusicalZombiesSpawnRate = 0.1,
    },
    PagerMod = {
        -- Quick bundles of the options below.
        -- Custom: nothing is overridden - every option on this page applies as you set it (the default).
        -- Convenient: the relaxed defaults - map-wide signal, full two-way paging and every feature on.
        -- Almost Realistic: a barely-functional pocket pager - 1 saved page, 16 characters, no location, no read receipts, no SOS, no blocking, no broadcast (still map-wide).
        -- Ultra Realistic: everything in Almost Realistic, plus pagers can only receive (not send), and the network is map-wide only until the power dies, then needs a built, powered pager tower.
        -- A preset overrides the matching options below. Standard=Custom (use options below)
        -- 1 = Custom (use options below)
        -- 2 = Convenient
        -- 3 = Almost Realistic
        -- 4 = Ultra Realistic
        Preset = 1,
        -- How far pages travel.
        -- Map-wide: pagers reach anywhere on the map (the default - pagers are your long-range tier, with walkie-talkies for medium range and voice chat up close).
        -- Limited range: a page only arrives if the recipient is within the distance set below.
        -- Powered tower only (after power dies): pages reach map-wide while the electricity grid is still on, but once the power goes out the network only works through a built, powered pager tower's coverage - so the pager network dies with the grid unless someone keeps a tower running on a generator.
        -- Powered tower only: the network ALWAYS needs a built, powered pager tower in range, even while the grid is up. Standard=Map-wide (anywhere)
        -- 1 = Map-wide (anywhere)
        -- 2 = Limited range
        -- 3 = Powered tower only (after power dies)
        -- 4 = Powered tower only
        SignalMode = 1,
        -- What pagers can do.
        -- Send and receive: normal two-way paging (the default).
        -- Receive only: pagers can only receive pages - the compose, reply and group features are hidden. Standard=Send and receive
        -- 1 = Send and receive
        -- 2 = Receive only
        PagerMode = 1,
        -- The reach distance in tiles (1 tile is about 1 metre), used by two signal modes: in Limited range it's the furthest a page can travel between sender and recipient; in Powered tower mode it's each tower's coverage radius (both ends of a page must be within it). Minimum=50 Maximum=100000 Standard=7000
        SignalRange = 7000,
        -- Lets a player send one page to every pager on the network with the Broadcast button. Turn this off on busy servers to cut down on spam.
        AllowBroadcast = true,
        -- How many pages a single pager keeps. Once it is full, the oldest page is dropped to make room for a new one. Minimum=1 Maximum=500 Standard=50
        MaxMessages = 50,
        -- The longest message a player can put in one page, counted in characters. Minimum=1 Maximum=500 Standard=140
        MessageMaxLength = 140,
        -- Play a beep and show an on-screen alert (with a preview of the message) whenever a new page comes in.
        NotifySound = true,
        -- How loud the pager's notification beep plays. Applies to every beep the pager makes. Standard=50% (default)
        -- 1 = 25% (quiet)
        -- 2 = 50% (default)
        -- 3 = 75%
        -- 4 = 100% (loud)
        BeepVolume = 2,
        -- Whether a page can include where the sender is standing. The recipient then sees the coordinates plus distance and a compass bearing.
        -- Off: location is never shared.
        -- Ask each time: the sender ticks a box per page (the default).
        -- Always on: every page carries the sender's location.
        -- An SOS still shares location unless this is set to Off. Standard=Ask each time
        -- 1 = Off
        -- 2 = Ask each time
        -- 3 = Always on
        LocationSharing = 2,
        -- Minimum number of seconds a player must wait between sending pages. Helps stop spam and griefing on PvP servers. Set to 0 for no limit (the default). Minimum=0 Maximum=600 Standard=0
        SendCooldown = 0,
        -- Notifies the sender once the person they paged has opened and read the message.
        ReadReceipts = true,
        -- Controls who can reach who.
        -- Anyone: any pager can page any other (the default).
        -- Same faction only: members of different factions cannot page each other, so rival groups can't eavesdrop or spam. Players who are not in a faction can always be reached. Standard=Anyone can page anyone
        -- 1 = Anyone can page anyone
        -- 2 = Same faction only
        FactionScope = 1,
        -- Enables the emergency SOS button, which pages everyone on the network at once and attaches the sender's location (unless location sharing is Off).
        AllowSOS = true,
        -- Lets players block a pager number so its pages never reach them. Useful against griefers in PvP.
        AllowBlocking = true,
        -- How long a fresh battery powers a pager before it dies and must be replaced. Measured in in-game time. Replace batteries from the pager's right-click menu using a Battery item. Standard=3 months
        -- 1 = 1 month
        -- 2 = 3 months
        -- 3 = 6 months
        -- 4 = 1 year
        -- 5 = Never dies
        BatteryLife = 2,
        -- What the tower base station (000-0001) itself can do.
        -- Send and receive: the tower can send pages and be paged - its console has an inbox.
        -- Send only: the tower can only send pages; it cannot be paged. Standard=Send and receive
        -- 1 = Send and receive
        -- 2 = Send only
        TowerComms = 1,
        -- The most pager towers a single player may have set up at once. Each tower is its own node with its own number and coverage circle. Set to 0 for no limit. Admins are exempt. Minimum=0 Maximum=999 Standard=0
        TowerLimit = 0,
        -- Adds a town-wide GLOBAL tab to every pager: a shared channel anyone with a pager can read and post to, reaching everyone regardless of saved contacts or faction. It still obeys the signal mode, receive-only mode, send cooldown and per-person blocking.
        GlobalChat = false,
        -- What a deployed pager tower needs to run (Powered tower mode).
        -- Grid or generator: mains electricity OR a running generator nearby (the default).
        -- Generator only: only a running, fuelled generator beside it (ignores the power grid).
        -- None: towers always work, no power needed. Standard=Grid or generator
        -- 1 = Grid or generator
        -- 2 = Generator only
        -- 3 = None (always on)
        TowerPower = 1,
        -- Pages may contain digits, spaces and dashes only - all letters are stripped out. Turns pagers into a numeric-code device.
        NumericOnly = false,
        -- What the Illiterate trait does to pagers.
        -- No effect: illiterate characters use pagers normally.
        -- Cannot read pages: page text and sender names appear as ??? for an illiterate character, and the pages they send can only contain digits, spaces and dashes - a numeric-code device. Their pager still beeps and shows numbers.
        -- Cannot use a pager: an illiterate character cannot open a pager or a tower console at all. The pager still beeps in their pocket, and they can still set up or pack away a tower. Standard=No effect
        -- 1 = No effect
        -- 2 = Cannot read pages (shown as ???)
        -- 3 = Cannot use a pager at all
        Illiteracy = 1,
        -- How much pager loot the world has, as a multiplier on the weights pagers already carry in electronics, police, comms and vehicle containers - so they still turn up where they make sense, there are just more or fewer of them.
        -- Vanilla (unchanged) is the default and touches no loot table at all. In Build 41, where the pager is not a vanilla item, the higher settings are also what puts it into electronics loot in the first place.
        -- Only affects containers the world has not generated yet. Standard=Vanilla (unchanged)
        -- 1 = Rare (half as common)
        -- 2 = Vanilla (unchanged)
        -- 3 = More common (x2)
        -- 4 = Common (x4)
        -- 5 = Everywhere (x8)
        SpawnAbundance = 2,
        -- Appends every routed page (sender, recipient, text, delivered/queued/blocked) to PagerMod_PageLog.txt in the server's Zomboid folder. For admins/moderation.
        LogPages = false,
    },
    RainCleansBlood = {
        -- Wie viele zufällige Kacheln pro Spielminute gereinigt werden. Minimum=10 Maximum=2000 Standard=300
        TilesPerMinuteNearPlayer = 300,
        -- Wie stark Regen oder Schnee sein muss, bevor Blut weggewaschen wird. Höher = stärkeres Wetter erforderlich. Minimum=0,05 Maximum=0,95 Standard=0,25
        WeatherThreshold = 0.25,
        -- Reinigt auch die Asche verbrannter Leichen.
        AlsoCleanAsh = true,
        -- Reinigt auch Tierkot (Dung), der auf dem Boden liegt.
        AlsoCleanDroppings = true,
        -- Reinigt auch Blut in Gebäuden.
        AlsoCleanInside = false,
        -- Reinigt auch allmählich Blut von Fahrzeugen.
        AlsoCleanVehicles = true,
        -- Wie viel Blut pro Minute von Fahrzeugen entfernt wird. Minimum=0,10 Maximum=1,00 Standard=0,10
        VehicleCleanSpeed = 0.1,
        -- Reinigt auch allmählich Blut und Schmutz von der getragenen Kleidung der Spieler.
        AlsoCleanClothes = true,
        -- Wie viel Blut und Schmutz pro Minute von der Kleidung entfernt wird. Minimum=1,00 Maximum=10,00 Standard=1,00
        ClothesCleanSpeed = 1.0,
        -- Reinigt immer, unabhängig vom Wetter.
        AlwaysClean = false,
    },
    VisibleDoorDamage = {
        EnableTestMenu = false,
    },
    LAV25W = {
        -- How often the LAV-25 turns up: in army areas, now and then in parking lots, traffic jams and yards (it follows the HEMTT trucks' spawns). The default (Rare) is about 9 on the vanilla map at normal vehicle spawn - pick Normal or Common to see more. Army areas keep a higher chance. It also follows the vehicle spawn rate. A change only affects ground nobody has explored yet. Standard=Rare
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnRate = 3,
        -- How often 25mm rounds and ammo cans turn up in military storage: army storage buildings, the old bunker and the storage inside military areas. Normal = the default (30, 15 and 12 percent), Common x2, Very common x3, Rare x0.5, Very rare x0.25, None: never. The amounts stay the same. Only containers looted from now on; each LAV's own ammo store (32 cans) is not affected. Standard=Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        AmmoSpawn = 4,
        -- On: the gun runs only while the LAV has a charged battery (a flat or missing battery shuts it down). Off: it works without one.
        RequireBattery = false,
        -- On: only the gunner and the commander (the two turret seats) can run the gun, and there is no automatic fire - the Auto button is hidden and the crew aims and fires by hand. Off (default): the driver can run the gun too and auto mode is there.
        FireRealism = false,
        -- What the M242's auto mode may shoot. On (default): zombies, plus the players and NPCs the LAV's list marks hostile (guard mode: everyone but friends) - as before. Zombies only: it keeps defending against zombies but never auto-targets players or NPCs (hostile marks and guard mode are ignored). Off: auto mode cannot be switched on (the Auto button is greyed out). Manual fire works the same in every setting. On a server, the server's setting counts. Standard=On
        -- 1 = On
        -- 2 = Zombies only
        -- 3 = Off
        AutoFire = 1,
        -- How the M242 treats a Stay With Me companion (that mod's NPC). Full protection: never a target and never hit, in auto and manual mode - the rounds pass. Auto fire only: auto mode never aims at the companion, manual fire hits it under the crosshair. Off: a target like any zombie. In every mode a companion that has died, has been let go by its mod or has turned (it can attack) is shot as a normal zombie. Standard=Full protection
        -- 1 = Full protection
        -- 2 = From auto fire only
        -- 3 = Off
        CompanionProtect = 1,
        -- The chevron painted on both sides of the LAV-25 (all three camos): an inverted V (default), a V, pointing forward (toward the nose), pointing back, or none. Every LAV-25 shows it, the ones already in the world too. Standard=Inverted V
        -- 1 = Inverted V
        -- 2 = V
        -- 3 = Pointing forward
        -- 4 = Pointing back
        -- 5 = None
        Chevron = 1,
        -- Once a minute the server log gets a line on the time the LAV-25 guns took (in all and the most in one tick), how many were updated and how many zombies the target searches read. For server owners checking performance; off by default.
        PerfLog = false,
    },
    HEMTT978 = {
        -- How much fuel or water the M978's tank holds. The real truck: 9,460 L (2,500 gal). Minimum=500 Maximum=10000 Standard=2000
        TankCapacity = 2000,
        -- How often the HEMTT M978 (fuel and water) turns up in parking lots, traffic jams and yards. The default (Normal) is low, as more RKC trucks share the roads - pick Common or Very common to see more. Army areas keep a higher chance. It also follows the vehicle spawn rate. A change only affects ground nobody has explored yet. Standard=Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnRate = 4,
    },
    DAMN = {
        AllowPowerChadSpawns = true,
        AllowBabySpawns = true,
        AllowPro440Spawns = true,
        AllowDemonChildSpawns = false,
        AllowEV6spawns = true,
        AllowTBCspawns = true,
        AllowUBCspawns = true,
        AllowWreckyMcChevySpawns = true,
        AllowShitSpawns = true,
        AllowOinkerSpawns = true,
        AlLAV300Spawns = true,
        AllowMrBusSpawns = true,
        AllowChonkerSpawns = true,
        AllowCashcowSpawns = true,
        AllowMcBoxySpawns = true,
        AllowContainerSpawns = true,
    },
    AMGeneralTankerFunctionality = {
        -- Multiplikator für die Geschwindigkeit von Tanker-Pumpvorgängen. 1 entspricht der Standardgeschwindigkeit. Minimum=1 Maximum=20 Standard=5
        PumpSpeedMultiplier = 5,
        -- Kapazität des M49A2C-Kraftstoffladetanks in Litern. Gilt für neu geladene Fahrzeuge. Minimum=500 Maximum=6000 Standard=850
        M49A2CCargoTankCapacity = 850,
        -- Kapazität des M50A3-Wasserladetanks in Litern. Gilt für neu geladene Fahrzeuge. Minimum=500 Maximum=6000 Standard=850
        M50A3CargoTankCapacity = 850,
        -- Kapazität des M967-Kraftstoffladetanks in Litern. Gilt für neu geladene Fahrzeuge. Minimum=1000 Maximum=10000 Standard=2000
        M967CargoTankCapacity = 2000,
    },
    rSemiTruck = {
        -- Multipliziert die Spawnchance aller W900-Militärfahrzeuge in jeder Zone.
        -- 0,5 = Standard, 0,0 = erscheint nie, 2,0 = doppelte Chance. Minimum=0,00 Maximum=10,00 Standard=0,50
        MilSpawnMultiplier = 0.5,
        -- Wenn aktiviert, werden die festen W900-Militärfahrzeug-Spawns erzeugt. Wenn deaktiviert, bleiben nur die normalen zonenbasierten Militär-Spawns aktiv.
        GuaranteedMilitarySpawns = true,
        -- Steuert die Menge an dynamisch hinzugefügten Waffen, Munition und Waffenteilen in der W900-Militärfahrzeug-Beute.
        -- Hoch = volle Menge (Standard), Mittel = 50%, Niedrig = 25%, Keine = keine zusätzliche Beute. Standard=Hoch (Standard)
        -- 1 = Keine
        -- 2 = Niedrig (25%)
        -- 3 = Mittel (50%)
        -- 4 = Hoch (Standard)
        MilitaryLootLevel = 4,
        -- Wenn aktiviert, können Autotrailer sowohl in normalen als auch in festen Fahrzeugzonen spawnen. Wenn deaktiviert, erscheinen keine Autotrailer.
        CarTrailerSpawns = true,
        -- Wenn aktiviert, können Container-Trailer sowohl in normalen als auch in festen Fahrzeugzonen spawnen. Wenn deaktiviert, erscheinen keine Container-Trailer.
        ContainerTrailerSpawns = true,
        -- Wenn aktiviert, können Container sowohl in normalen als auch in festen Fahrzeugzonen spawnen. Wenn deaktiviert, erscheinen keine Container.
        ContainerSpawns = true,
    },
    MSW = {
        -- Legt fest, wie viele Fahrzeuge der MultiWrecker gleichzeitig transportieren kann.
        -- Ein niedrigerer Wert blockiert nur neue Ladungen in höheren Slots; bereits geladene Fahrzeuge können weiter entladen werden. Standard=5 Fahrzeuge
        -- 1 = 3 Fahrzeuge
        -- 2 = 4 Fahrzeuge
        -- 3 = 5 Fahrzeuge
        Slots = 3,
    },
    VMZ = {
        -- Determines whether military road stories will spawn in the game.
        RoadStories = true,
        -- Allows you to edit the chances of military road stories appearing. Minimum=0,00 Maximum=5,00 Standard=1,00
        RoadStoriesMultiplier = 1.0,
        -- Minimum amout of days (since start of apocalypse) after which road stories will begin to spawn. Minimum=0 Maximum=1000 Standard=5
        RoadStoriesMinDay = 5,
        -- Maximum amout of days (since start of apocalypse) after which road stories will stop spawning. Minimum=0 Maximum=1000 Standard=90
        RoadStoriesMaxDay = 90,
        -- Determines whether a vehicle can spawn in a regular parking stall (near shops, houses) as police and fire department cars occasionally do.
        SpecCar = false,
        -- Set spawn rate for vehicles in military zone. Minimum=0 Maximum=100 Standard=16
        SpawnRate = 16,
        -- Set condition of vehicle parts (should be 'damaged') that spawn in military zone. Recommend use it in pair with 'Chance of having a damaged part'. So if you want ~100% vehicle set 'Vehicles condition' = 100 and 'Chance of having a damaged part' = 100. Minimum=0 Maximum=100 Standard=50
        VehiCond = 50,
        -- Set chance of having a 'damaged' part for vehicles in military zone (the part's condition applies specifically to 'damaged' parts, so if the chance is 100 and the durability is 100, the overall condition indicator of the car will also be ~100%). Minimum=0 Maximum=100 Standard=0
        PartDamage = 0,
        -- Set chance to spawn a key in vehicle and near it (zombies, floor, buildings). Minimum=0 Maximum=100 Standard=70
        KeySpawn = 70,
    },
    KI5GF = {
        -- Raises the MAN KAT1's suspension travel and rest length so it climbs back out of the ground instead of staying sunk, and stiffens it so the extra travel does not turn into a bounce. Turn off to leave the truck exactly as KI5 ships it.
        FixKat1Suspension = false,
    },
    VVR = {
        -- Disables trailers spawn in traffic jams and basic car crashes. Still can be founded in car crash attached to vehicle and parkings.
        NoTrailers = false,
        -- Replaces burnt cars with KI5's ones in bad condition.
        NoBurnt = true,
        -- Set condition for vehicles that replaced burnt cars. Minimum=0 Maximum=100 Standard=10
        VehiCond = 10,
        -- Cars that shouldn't spawn in world. Divider - ;
        VehiclesBlacklist = "Base.ModernCar_Martin;",
    },
    RVVFX = {
        -- Temporary marks use the normal RVV lifetime. Persistent marks are saved with the world and remain until weather or RVV cleanup removes them. Safety limits still apply. Standard=Temporary
        -- 1 = Temporary
        -- 2 = Persistent
        TireMarkPersistence = 2,
    },
    MaskaradsSummerCar = {
        -- Shifts newly initialized vehicles toward better or worse coherent engine loadouts. Only affects vehicles initialized after the setting is applied. Standard=Normal
        -- 1 = Very poor
        -- 2 = Poor
        -- 3 = Normal
        -- 4 = Good
        -- 5 = Very good
        LoadoutQuality = 3,
        -- Controls how many components may be absent from newly initialized vehicles. Optional and service parts are more likely to be missing than critical internals. Standard=Common
        -- 1 = None
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Common
        -- 5 = Severe
        MissingParts = 4,
        -- Chance that each newly generated component belongs to a different Standard, Heavy-Duty, or Sport class. The transmission pair always stays internally consistent. Minimum=0 Maximum=100 Standard=10
        CrossClassChance = 10,
        -- Chance that a newly initialized vehicle receives a manual transmission and clutch instead of an automatic transmission and torque converter. Minimum=0 Maximum=100 Standard=50
        ManualTransmissionChance = 50,
        -- Legendary chance for newly created MSC components. Lower values make legendary parts more common; 350 means one chance in 350. Minimum=1 Maximum=5000 Standard=350
        LegendaryOneIn = 350,
        -- Multiplies condition loss from normal running wear and fluid-related engine damage. Zero disables those MSC wear sources. Minimum=0,00 Maximum=5,00 Standard=1,00
        ComponentWearMultiplier = 1.0,
        -- Multiplies condition- and pressure-related oil, coolant, and transmission-fluid leaks. Zero disables MSC leaks. Minimum=0,00 Maximum=5,00 Standard=1,00
        FluidLossMultiplier = 1.0,
        -- Default follows each player's account temperature preference. Celsius and Fahrenheit force that unit for every MSC vehicle temperature. Standard=Default (player preference)
        -- 1 = Default (player preference)
        -- 2 = Celsius
        -- 3 = Fahrenheit
        TemperatureDisplay = 1,
        -- Allows a shove near either end of a vehicle's side to turn it. Front and rear pushing remains available when disabled.
        AllowSidePushing = true,
        -- Controls how often Standard parts appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Minimum=0,00 Maximum=5,00 Standard=1,00
        StandardPartsSpawnRate = 1.0,
        -- Controls how often Heavy-Duty parts appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Minimum=0,00 Maximum=5,00 Standard=1,00
        HeavyDutyPartsSpawnRate = 1.0,
        -- Controls how often Sport parts appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Minimum=0,00 Maximum=5,00 Standard=1,00
        SportPartsSpawnRate = 1.0,
        -- Controls how often oil, coolant, and transmission-fluid bottles appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Minimum=0,00 Maximum=5,00 Standard=1,00
        FluidSuppliesSpawnRate = 1.0,
    },
    SPNCharCustom = {
        -- Admins or players holding an Appearance Changer ignore this Standard=Disabled
        -- 1 = Face and Details
        -- 2 = Face only
        -- 3 = Details only
        -- 4 = Disabled
        AllowCustomisationChange = 4,
        -- Customisation categories that are hidden to normal players. Comma separated, eg: joke,halloween,special
        AdminLockedCustomisation = "",
        -- Set to 0 to disable growth Minimum=0 Maximum=20 Standard=10
        BodyHairGrowth = 10,
        -- Set to 0 to disable growth Minimum=0 Maximum=20 Standard=6
        StubbleHeadGrowth = 6,
        -- Set to 0 to disable growth Minimum=0 Maximum=20 Standard=3
        StubbleBeardGrowth = 3,
        -- Body hair and stubble grows in-game Standard=Enabled for everyone
        -- 1 = Enabled for everyone
        -- 2 = Disabled for everyone
        -- 3 = Player Choice
        BodyHairGrowthEnabled = 1,
        -- Display visible muscles on character depending on strength level Standard=Enabled for everyone
        -- 1 = Enabled for everyone
        -- 2 = Disabled for everyone
        -- 3 = Player Choice
        MuscleVisuals = 1,
        -- Players with missing eye customisation will have a vision penalty - Set to 1.0 to disable Minimum=0,10 Maximum=1,00 Standard=0,50
        MissingEyeVisionModifier = 0.5,
        -- In vanilla washing yourself will also wash off makeup
        WashMakeup = true,
    },
    BathTowelsOverhaul = {
        -- Decreases the multiplier for how quickly the player's wetness dries naturally. <LINE> True = 0.002, False = 0.01 (vanilla)
        WetnessDecrease = true,
        -- Whether to give a random wet absorption when generating bath towels. If False, all bath towels will have a absobency of 30.
        RandomBathTowelQuality = true,
        -- The absorbency of bath towels is further randomized. <LINE> (Only work if Bath Towel Quality is True)
        MoreRandomAbsorbency = true,
        -- Whether to overwrite the display name according to the bath towel's absorbency. <LINE> (Only work if Bath Towel Quality is True)
        RandomBathTowelQualityName = true,
        -- Whether the towels likely to deteriorate with use. <LINE> (The rate and chance of deterioration is very low.)
        TowelConditionMayDeteriorate = true,
        -- Whether the towel absorbs blood and dirt on the body during Dry Self.
        WipesBloodAndDirt = true,
        -- If True, the towel can be used with DrySelf even if it grimed. If False, it will become unusable if it is too dirty. <LINE> <RED> Note: Using a grimes towel will make it even grimer and increase your unhappiness.
        AvailableEvenIfTooDirt = false,
        -- Whether hand towel spawn in the world. It spawns in the same place as Bath Towel.
        HandTowelsSpawn = true,
        -- This value is a divisor for the Bathtowel value. 1 is the same probability as a bath towel. 2 is half the probability. Minimum=1 Maximum=10 Standard=2
        HandTowelsSpawnProbabilty = 2,
        -- Whether dust cloth spawn in the world. It spawns in the same place as Sponge.
        DustClothSpawn = true,
        -- This value is a divisor for the Sponge value. 1 is the same probability as a bath towel. 2 is half the probability. Minimum=1 Maximum=10 Standard=1
        DustClothSpawnProbabilty = 1,
    },
    TakeABathAndShower = {
        -- Diese Checkbox Option hat an sich keine Funktion.
        GeneralSection = false,
        -- Es gibt ein Konzept für die Wassertemperatur beim Duschen und Baden. 
        --  Bei der Einstellung False profitieren Sie nicht mehr von der wohltuenden, wärmenden Wirkung von heißem Wasser oder dessen stresslindernden Effekten.
        WaterTemperatureConcept = true,
        -- Das ist die Wassermenge, die nach dem Ausfall der Wasserversorgung im Badewannenhahn zurückbleibt. <LINE> Wenn Sie diesen Wert höher ansetzen als die Menge des für das Bad verbrauchten Wassers, können Sie im ersten Haus, das Sie nach dem Ausfall der Wasserversorgung aufsuchen, ein Bad nehmen. Minimum=0 Maximum=1000 Standard=100
        RemainTubFaucetWater = 100,
        -- Dies ist die Wassermenge, die nach dem Ausfall der Wasserversorgung in der Duscharmatur verbleibt. <LINE> Wenn Sie diesen Wert höher ansetzen als die Menge des für das Duschen verbrauchten Wassers, können Sie in dem Haus duschen, das Sie nach dem Ausfall der Wasserversorgung als Erstes aufsuchen. Minimum=0 Maximum=1000 Standard=20
        RemainShowerFaucetWater = 20,
        -- Stellt die nach dem Ausfall der Wasserversorgung verbleibende Wassermenge zufällig fest. <LINE>Höhere Werte können die konfigurierte Restwassermenge stärker verringern. Standard=Keine
        -- 1 = Keine
        -- 2 = Bis zu 25% Reduktion
        -- 3 = Bis zu 50% Reduktion
        -- 4 = Bis zu 75% Reduktion
        -- 5 = Bis zu 100% Reduktion
        RemainingWaterRandomizationIntensity = 1,
        -- Die Wahrscheinlichkeit, dass body shampoo spawnt. Standard=Selten
        -- 1 = Keine
        -- 2 = Extrem selten
        -- 3 = Selten
        -- 4 = Normal
        -- 5 = Häufig
        -- 6 = Reichlich
        BathItemSpawnChance = 3,
        -- Die Chance von Badesalz spawning. Standard=Extrem selten
        -- 1 = Keine
        -- 2 = Extrem selten
        -- 3 = Selten
        -- 4 = Normal
        -- 5 = Häufig
        -- 6 = Reichlich
        BathSaltSpawnChance = 3,
        -- Diese Kontrollkästis-Option hat an sich keine Funktion.
        TubFluidContainerSection = false,
        -- Die Wassermenge, die in einer Badewanne gespeichert werden kann. 
        --  <PUSHRGB:1,0.5,0.5> Note: Dies ist unabhängig von der Wassermenge, die im Wasserhahn verbleibt, nachdem die Wasserversorgung eingestellt wurde. <POPRGB> Minimum=100 Maximum=1000 Standard=200
        TubWaterCapacity = 200,
        -- Wenn Sie eine Badewanne im Freien aufstellen, können Sie Regenwasser sammeln. Sie können dieses Wasser jedoch nicht für die Hausinstallation verwenden.
        TubRainCollect = true,
        -- Beim Baden wird das Wasser durch den Schmutz verunreinigt, der von Ihrem Körper abgewaschen wird.
        TubWaterGetDirty = true,
        -- Wenn Sie Strom haben, können Sie das Badewasser wieder aufwärmen.
        EnableReheat = true,
        -- Hier wird festgelegt, ob bei der Überprüfung von an Badewannen und Duschen angeschlossenen Flüssigkeitsbehältern alle Flüssigkeitstypen berücksichtigt werden sollen. Ist diese Option deaktiviert, werden nur Flüssigkeitsbehälter berücksichtigt, die Wasser enthalten.
        AvailableAllFluid = false,
        -- Diese Kontrollkästchen Option hat an sich keine Funktion.
        BathAndShowerSection = false,
        -- Die Wassermenge, die beim Waschen von Blut, Schmutz und Verunreinigungen vom Körper während eines Bades verbraucht wird. Dies ist ein relativer Wert, der sich nach der insgesamt entfernten Menge richtet. Wenn Sie den Wasserverbrauch deaktivieren möchten, setzen Sie den Wert auf 0. Minimum=0,00 Maximum=1,00 Standard=0,80
        WashInBathConsumeWater = 0.8,
        -- Die Wassermenge, die man zum Duschen benötigt. Minimum=0 Maximum=200 Standard=80
        ShowerConsumeWater = 80,
        -- Maximale Anzahl an Spielminuten, in denen die Vorteile von Badezusätzen genutzt werden können. Das Limit wird 12 Spielstunden nach dem letzten Vorteil zurückgesetzt. Auf 0 setzen, um das Limit aufzuheben. Minimum=0 Maximum=240 Standard=30
        BathingBenefitDailyMinutes = 30,
        -- Vermeiden Sie das zunehmende Unbehagen, die Langeweile und das Unbehagen, die beim Baden in Kleidung oder in Wasser von schlechter Beschaffenheit (falsche Temperatur oder Verschmutzung) entstehen.
        DisableNegativeEffectsOfBathing = false,
        -- Deaktiviere den erhöhten Stress, der dadurch entsteht, dass dich jemand (einschließlich Zombies) beim Baden sieht.
        DisableFeelingStressByGaze = false,
        -- Diese Kontrollkästchen-Option hat an sich keine Funktion.
        BodyGrimeSection = false,
        -- Aktivieren Sie die Funktionen für Körperschmutz. Wenn diese Option auf False gesetzt ist, werden alle darunterliegenden Einstellungen deaktiviert.
        EnableBodyGrime = true,
        -- Lass die Standardaktion Waschen den Körperschmutz entfernen.
        WashSelfRemovesGrime = true,
        -- Ermögliche es, Körperschmutz an Wasserstellen wie Waschbecken, Seen und Teichen abzuwaschen.
        EnableGrimeWash = true,
        -- Es wird ausreichend Seife benötigt, um die Grime Wash-Aktion auszuführen.
        GrimeWashRequiresSoap = false,
        -- Zeigt einen Status-Effekt an, dessen Schweregrad mit jeweils 25 angesammelten Einheiten Körperschmutz zunimmt. <LINE> <PUSHRGB:1,0.5,0.5> Es funktioniert nicht, wenn das Moodle Framework Mod nicht installiert ist!<POPRGB>
        EnableBodyGrimeMoodle = true,
        -- Die Grundmenge an Schmutz, die sich stündlich an deinem Körper ansammelt, ohne dass du etwas dafür tun musst. Minimum=0,00 Maximum=100,00 Standard=0,80
        BodyGrimeIncreasedBase = 0.8,
        -- Wenn sich mehr Blut an deinem Körper befindet als dieser Wert, sammelt es sich als Schmutz auf dem Körper an. Minimum=0 Maximum=100 Standard=30
        BloodToGrimeThreshold = 30,
        -- Wenn sich mehr Schmutz auf deinem Körper befindet als dieser Wert, lagert er sich als hartnäckiger Schmutz auf dem Körper ab. Minimum=0 Maximum=100 Standard=30
        DirtToGrimeThreshold = 30,
        -- Ein Multiplikator dafür, wie sich Blut und Schmutz, die über die Schwelle gelangen, als hartnäckiger Schmutz ansammeln. <LINE> Die Berechnung erfolgt anhand der Gesamtzahl der Blut- oder Schmutzflecken am gesamten Körper, nicht an einzelnen Körperteilen, und der Maximalwert beträgt 1, nicht 100. <LINE> Wenn du diesen Wert auf 3 festlegst, sammelst du jede Stunde 1,5 zusätzlichen Schmutz an, sofern du 50 Blut am Körper hast. Minimum=0,00 Maximum=100,00 Standard=1,00
        BloodAndDirtMultiplier = 1.0,
        -- Wenn sich zu viel Schmutz angesammelt hat, werden Sie sich unwohl fühlen.
        GrimeDiscomfort = true,
        -- Discomfort modifier when grime is 60 or more but below 75. <LINE> 0 disables discomfort for this stage. Minimum=0,00 Maximum=1,00 Standard=0,15
        GrimeDiscomfort1 = 0.15,
        -- Discomfort modifier when grime is 75 or more but below 90. <LINE> 0 disables discomfort for this stage. Minimum=0,00 Maximum=1,00 Standard=0,30
        GrimeDiscomfort2 = 0.3,
        -- Discomfort modifier when grime is 90 or more. <LINE> 0 disables discomfort for this stage. Minimum=0,00 Maximum=1,00 Standard=0,55
        GrimeDiscomfort3 = 0.55,
        -- Wenn sich zu viel Schmutz angesammelt hat, nehmen Sie einen leicht unangenehmen Geruch wahr.
        GrimeNoxiousSmell = true,
    },
    FcknSpldrV5 = {
        -- This is the loot multiplier for very rare spawns (default chance 0.001-0.010) for Frockin Splendor! Vol.5, such as loose items in residential and functional areas. Set the number to 0 to stop this category from spawning, set the number to 1000 to have them appear in almost all containers. Minimum=0,00 Maximum=1000,00 Standard=1,00
        LootBetaVRare = 1.0,
        -- This is the loot multiplier for rare spawns (default chance 0.010-0.900) for Frockin Splendor! Vol.5, such as lootboxes. Set the number to 0 to stop this category from spawning, set the number to 100 to have them appear in almost all containers. Minimum=0,00 Maximum=100,00 Standard=1,00
        LootBetaRare = 1.0,
        -- This is the loot multiplier for common spawns (default chance more than 1.000) for Frockin Splendor! Vol.5, such as items that are spawning in commercial areas. Set the number to 0 to stop this category from spawning, set the number to 10 to have them appear in almost all containers. Minimum=0,00 Maximum=10,00 Standard=1,00
        LootBetaCommon = 1.0,
    },
    FcknStmpr = {
        -- This is the loot multiplier for very rare spawns (default chance 0.001-0.010) for Frockin Stompers!, such as loose items in residential and functional areas. Set the number to 0 to stop this category from spawning, set the number to 1000 to have them appear in almost all containers. Minimum=0,00 Maximum=1000,00 Standard=1,00
        LootBetaVRare = 1.0,
        -- This is the loot multiplier for common spawns (default chance more than 1.000) for Frockin Stompers!, such as items that are spawning in commercial areas. Set the number to 0 to stop this category from spawning, set the number to 10 to have them appear in almost all containers. Minimum=0,00 Maximum=10,00 Standard=1,00
        LootBetaCommon = 1.0,
    },
    LowConditionGuns = {
        -- Minimum=1 Maximum=100 Standard=20
        NormalMinCondition = 20,
        -- Minimum=1 Maximum=100 Standard=70
        NormalMaxCondition = 70,
        -- Minimum=1 Maximum=100 Standard=70
        StoreMinCondition = 70,
        -- Minimum=1 Maximum=100 Standard=100
        StoreMaxCondition = 100,
        -- Minimum=1 Maximum=100 Standard=50
        PoliceMinCondition = 60,
        -- Minimum=1 Maximum=100 Standard=80
        PoliceMaxCondition = 90,
        -- Minimum=1 Maximum=100 Standard=80
        MilitaryMinCondition = 80,
        -- Minimum=1 Maximum=100 Standard=100
        MilitaryMaxCondition = 100,
        AffectMelee = false,
        -- Minimum=0,00 Maximum=100,00 Standard=0,10
        PerfectConditionChance = 0.1,
    },
    TacHold = {
        -- Required aiming level before Long gun animations activate. Minimum=0 Maximum=10 Standard=0
        AimingRequirement = 2,
        -- Required aiming level before pistol animations activate. Minimum=0 Maximum=10 Standard=0
        PistolAimingRequirement = 1,
    },
    VFE = {
        -- VFE weapons spawning attached to police zombies.
        PoliceWeapons = true,
        -- Weapons spawning attached to military zombies. (Not just VFE specific ones)
        MilitaryWeapons = true,
        -- Weapons spawning attached to survivor zombies. (Not just VFE specific ones)
        SurvivorWeapons = true,
        -- Weapons spawning attached to other zombies zombies, like bikers. (Not just VFE specific ones)
        OtherWeapons = true,
        -- VFE weapons spawning inside vehicle inventories.
        CarWeapons = true,
        -- VFE weapons spawning inside of normal houses.
        HouseWeapons = true,
        -- Multiplier to weapons spawning in houses (Requires previous option enabled) Minimum=0,10 Maximum=10,00 Standard=1,00
        HouseWeaponsMulti = 1.0,
        -- Allows spawning of weapons like the M60 Machinegun.
        HeavyWeapons = true,
        -- Global multiplier for how many VFE firearms spawn in containers. Minimum=0,10 Maximum=10,00 Standard=1,00
        GunLootMulti = 1.0,
        -- VFE firearms spawning in army storage, bunkers and military lockers.
        LootMilitary = true,
        -- VFE firearms spawning in police, SWAT and security storage.
        LootPolice = true,
        -- VFE firearms spawning in gun stores and pawn shops.
        LootStore = true,
        -- VFE firearms spawning in drug labs, dealer shacks and floor-plank stashes.
        LootCriminal = true,
        -- VFE firearms spawning in hunter, trapper and survival containers.
        LootHunting = true,
        -- VFE firearms spawning in survivor safehouse stashes that appear as the world ages.
        LootSafehouse = true,
        -- Vanilla-only firearms (JS14, L92, L94, MSR7T, Trapper Carbine, JS3T) plus the M1911 and both small revolvers stop spawning in the containers VFE fills. They still appear on zombies, in vehicles and in every other vanilla list.
        RemoveVanillaGuns = true,
        -- Range the x2 scope adds to the weapon. Minimum=-20 Maximum=50 Standard=5
        AT_x2ScopeRange = 5,
        -- Aiming time the x2 scope adds. Higher = slower to aim. Minimum=-50 Maximum=50 Standard=5
        AT_x2ScopeAim = 5,
        -- Range the x4 scope adds to the weapon. Minimum=-20 Maximum=50 Standard=10
        AT_x4ScopeRange = 10,
        -- Aiming time the x4 scope adds. Higher = slower to aim. Minimum=-50 Maximum=50 Standard=10
        AT_x4ScopeAim = 10,
        -- Range the x8 scope adds to the weapon. Minimum=-20 Maximum=50 Standard=15
        AT_x8ScopeRange = 15,
        -- Aiming time the x8 scope adds. Higher = slower to aim. Minimum=-50 Maximum=50 Standard=20
        AT_x8ScopeAim = 20,
        -- Aiming time the red dot adds. Negative = faster to aim. Minimum=-50 Maximum=50 Standard=-10
        AT_RedDotAim = -10,
        -- Aiming time the improved irons add. Negative = faster to aim. Minimum=-50 Maximum=50 Standard=-5
        AT_IronSightAim = -5,
        -- Aiming time the laser adds. Negative = faster to aim. Minimum=-50 Maximum=50 Standard=-5
        AT_LaserAim = -5,
        -- Hit chance the laser adds. Minimum=-50 Maximum=50 Standard=10
        AT_LaserHit = 10,
        -- Aiming time the bipod adds. Negative = faster to aim. Minimum=-50 Maximum=50 Standard=-5
        AT_BipodAim = -5,
        -- Hit chance the bipod adds. Minimum=-50 Maximum=50 Standard=30
        AT_BipodHit = 30,
        -- Range the bipod adds to the weapon. Minimum=-20 Maximum=50 Standard=5
        AT_BipodRange = 5,
        -- Aiming time the recoil pad adds. Negative = faster to aim. Minimum=-50 Maximum=50 Standard=-5
        AT_RecoilPadAim = -5,
        -- Recoil delay the pad adds. Negative = faster follow-up shots. Never lets a weapon reach 0. Minimum=-20 Maximum=20 Standard=-2
        AT_RecoilPadDelay = -2,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=20
        Ammo_762 = 20,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=20
        Ammo_223 = 20,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=50
        Ammo_22 = 50,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=20
        Ammo_545 = 20,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=30
        Ammo_76254 = 30,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=50
        Ammo_57 = 50,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=50
        Ammo_46 = 50,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=90
        Ammo_556bp = 90,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Minimum=1 Maximum=1000 Standard=30
        Ammo_m13 = 30,
    },
    RadArchery = {
        -- Percent chance a Carved Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=25
        CarvedArrowRecovery = 25,
        -- Percent chance a Fine Carved Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=40
        FineCarvedArrowRecovery = 40,
        -- Percent chance a Stone-Tipped Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=50
        StoneTippedArrowRecovery = 50,
        -- Percent chance a Bone-Tipped Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=50
        BoneTippedArrowRecovery = 50,
        -- Percent chance a Tipped Carved Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=55
        TippedCarvedArrowRecovery = 55,
        -- Percent chance a Carbon Hunting Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=90
        HuntingArrowRecovery = 90,
        -- Percent chance a Bodkin Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=75
        BodkinArrowRecovery = 75,
        -- Percent chance a Broadhead Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=65
        BroadheadArrowRecovery = 65,
        -- Percent chance a Bodkin (MFD) Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=90
        BodkinArrowMFDRecovery = 90,
        -- Percent chance a Broadhead (MFD) Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Minimum=0 Maximum=100 Standard=85
        BroadheadArrowMFDRecovery = 85,
        -- Scales how much arm muscle strain drawing and holding a bow causes: a one-off cost when the draw starts, plus a drain for every second the aim is held. Heavier bows tire the arms faster, a compound bow's let-off makes it far easier to hold, and a higher Archery level tires them slower. Set to 0 to remove bow strain entirely. Applied on top of the game's own Muscle Strain Factor setting. Minimum=0 Maximum=1000 Standard=100
        BowStrainFactor = 100,
        -- Scales the spawn chance of every RadArchery item together -- bows, arrows, the Leather Quiver and Archery skill books -- on top of each category's own slider below. Set to 0 to remove all RadArchery loot. Minimum=0 Maximum=1000 Standard=100
        LootGeneral = 180,
        -- Scales how often compound bows spawn in containers, vehicles and zombie outfits, on top of the Overall RadArchery Loot slider above. The craft-only carved bows are unaffected -- they never spawn as loot. Minimum=0 Maximum=1000 Standard=100
        LootBows = 100,
        -- Scales how often loose Carbon Hunting Arrows and their packs and crates spawn, on top of the Overall RadArchery Loot slider above. Minimum=0 Maximum=1000 Standard=100
        LootArrows = 100,
        -- Scales how often the Leather Quiver spawns, on top of the Overall RadArchery Loot slider above. The quiver is also craftable regardless of this setting. Minimum=0 Maximum=1000 Standard=100
        LootQuiver = 100,
        -- Scales how often the Archery and Fletching skill books spawn, on top of the Overall RadArchery Loot slider above. Minimum=0 Maximum=1000 Standard=100
        LootBooks = 100,
        -- Percent chance an arrow shot into an Archery Target survives and stays stuck in it, to be pulled back out. The same for every arrow type. Minimum=0 Maximum=100 Standard=90
        TargetArrowRecovery = 90,
        -- Archery level at which shooting an Archery Target stops awarding Archery XP. Zombie hits are unaffected. Set to 0 for no cap. Minimum=0 Maximum=10 Standard=5
        TargetXpCapLevel = 5,
    },
    Explosives = {
        -- Standardmäßig aus. Wenn aktiviert, gilt der eigene Wurfbogen und Ziel-Marker des Mods auch für vanilla Rohrbomben, Aerosolbomben, Rauchbomben, Brandfallen, Lärmfallen, Knallkörper und Molotow-Cocktails (inkl. Sensor-, Fernzünder- und Timer-Varianten, wo vorhanden), nicht nur für die eigenen Granaten dieses Mods.
        VanillaBallisticsEnabled = false,
        -- Multipliziert die Spawnchance aller Granaten und Minen in Loot-Containern. 0.5 = halb so häufig, 1.0 = Standard, 2.0 = doppelt so häufig. Minimum=0,01 Maximum=5,00 Standard=1,00
        LootMultiplier = 1.0,
        -- Wenn aktiviert, nehmen Zombies zusätzlichen Schaden während sie brennen, unabhängig von der Feuerquelle. Deaktivieren für Vanilla-Feuerverhalten.
        FireDamageEnabled = true,
        -- Multipliziert den zusätzlichen Feuerschaden an brennenden Zombies. 0.5 = ca. 30% schneller als Vanilla, 1.0 = ca. doppelt so schnell, 5.0 = ca. fünfmal schneller als Vanilla. Minimum=0,50 Maximum=5,00 Standard=1,00
        FireDamageMultiplier = 1.0,
        -- Standardmäßig aus. Wenn aktiviert, landen die eigenen Granaten dieses Mods (Mk2, M26, M67, M84 Flashbang, M14 TH3) scharf am Boden und explodieren erst nach ein paar Sekunden, statt sofort beim Aufprall zu detonieren. Betrifft nicht Minen/Claymores (die bereits als platzierte Fallen landen) oder vanilla Wurfwaffen.
        DelayedFuseEnabled = false,
        -- Wie viele Sekunden eine gelandete Granate scharf am Boden liegt, bevor sie explodiert, wenn 'Verzögerte Zündung bei Landung' aktiviert ist. Minimum=0,50 Maximum=10,00 Standard=4,00
        DelayedFuseSeconds = 4.0,
        -- Standardmäßig aus. Wenn aktiviert, erzeugt Shift + Nummernblock "+" (in den Mod-Optionen neu belegbar) eine einzelne Blendgranate direkt im Inventar für schnelle Flugbahn-Tests.
        DebugSpawnKeyEnabled = false,
    },
    ISIL = {
        -- Aktiviert konfigurierbare Schalldämpfung und optionale Haltbarkeit. Standardmäßig deaktiviert, damit die bisherige Spielbalance erhalten bleibt.
        ExtendedMode = false,
        -- Schalldämpfer verlieren bei jedem Schuss Haltbarkeit und werden vollständig verschlissen zerstört. Gilt nur im erweiterten Realismusmodus.
        EnableDurability = true,
        -- Passt den Schalldämpfer-Verschleiß an das Munitionskaliber an. Kleine Kaliber verbrauchen weniger Haltbarkeit, Gewehr- und Schrotmunition mehr. Unbekannte Munition verwendet den normalen 9-mm-Verschleiß.
        CaliberBasedWear = true,
        -- Prozentuale Reduzierung von Geräuschradius und Lautstärke im erweiterten Realismusmodus. Minimum=0 Maximum=100 Standard=60
        ProfessionalNoiseReduction = 80,
        -- Prozentuale Reduzierung von Geräuschradius und Lautstärke im erweiterten Realismusmodus. Minimum=0 Maximum=100 Standard=40
        MetalPipeNoiseReduction = 60,
        -- Prozentuale Reduzierung von Geräuschradius und Lautstärke im erweiterten Realismusmodus. Minimum=0 Maximum=100 Standard=30
        HandTorchNoiseReduction = 40,
        -- Prozentuale Reduzierung von Geräuschradius und Lautstärke im erweiterten Realismusmodus. Minimum=0 Maximum=100 Standard=20
        WaterBottleNoiseReduction = 30,
        -- Anzahl der 9-mm-äquivalenten Schüsse, bevor ein professioneller Schalldämpfer zerstört wird. Minimum=1 Maximum=10000 Standard=500
        ProfessionalDurability = 500,
        -- Anzahl der 9-mm-äquivalenten Schüsse, bevor ein Metallrohr-Schalldämpfer zerstört wird. Minimum=1 Maximum=10000 Standard=100
        MetalPipeDurability = 100,
        -- Anzahl der 9-mm-äquivalenten Schüsse, bevor ein Taschenlampen-Schalldämpfer zerstört wird. Minimum=1 Maximum=10000 Standard=20
        HandTorchDurability = 40,
        -- Anzahl der 9-mm-äquivalenten Schüsse, bevor ein Wasserflaschen-Schalldämpfer zerstört wird. Minimum=1 Maximum=10000 Standard=5
        WaterBottleDurability = 10,
    },
    ElectricWeaponMalfunction = {
        -- Passt den Fehlfunktionsfaktor elektrifizierter Waffen an.
        --  Höhere Werte erhöhen die Chance auf Fehlfunktionen. Minimum=0,10 Maximum=2,00 Standard=1,00
        MalfunctionFactor = 1.0,
        -- Passt den Batterieverbrauch elektrifizierter Waffen an.
        --  Je höher der Wert, desto schneller entlädt sich die Batterie. Minimum=0,10 Maximum=2,00 Standard=1,00
        PowerConsumptionFactor = 1.0,
    },
    Nihonto = {
        -- Wenn diese Option aktiviert ist, wird das Standard-Katana (Vanilla) an allen Fundorten durch Nihontō-Katanas ersetzt.
        replaceVanillaKatana = true,
        -- Dieser Wert bestimmt, wie stark die Spawnrate für Nihonto-Waffen und das vanilla Katana (falls ersetzt) verändert wird. 0.5=halbiert, 1=keine Änderung, 2=doppelt, etc. Beeinflusst nicht die zugehörigen Literatur-Spawns. Minimum=0,00 Maximum=100,00 Standard=10,00
        WeightMultiplier = 10.0,
        -- Wenn aktiviert, wird die Mechanik zum Schutz der Haltbarkeit auf alle Klingenwaffen angewendet, nicht nur auf Nihonto-Waffen. Die Mechanik bietet die Chance, bei einem Treffer die Schärfe anstatt der Haltbarkeit zu verringern. Dies simuliert, dass die Klinge stumpf wird, aber nicht sofort bricht.
        SharpnessMechanic = true,
        -- Je höher der Wert, desto länger hält die Waffe. Minimum=10,00 Maximum=100,00 Standard=36,00
        Katana_ConditionLowerChanceOneIn = 36.0,
        -- Legt die maximale Katana-Haltbarkeit fest. Minimum=10,00 Maximum=100,00 Standard=18,00
        Katana_ConditionMax = 18.0,
        -- Je höher der Wert, desto länger hält die Waffe. Minimum=10,00 Maximum=100,00 Standard=32,00
        Wakizashi_ConditionLowerChanceOneIn = 32.0,
        -- Minimum=5,00 Maximum=30,00 Standard=16,00
        Wakizashi_ConditionMax = 16.0,
        -- Je höher der Wert, desto länger hält die Waffe. Minimum=10,00 Maximum=50,00 Standard=36,00
        Nagamaki_ConditionLowerChanceOneIn = 36.0,
        -- Legt die maximale Nagamaki-Haltbarkeit fest. Minimum=10,00 Maximum=50,00 Standard=18,00
        Nagamaki_ConditionMax = 18.0,
        -- Je höher der Wert, desto länger hält die Waffe. Minimum=10,00 Maximum=100,00 Standard=40,00
        Odachi_ConditionLowerChanceOneIn = 40.0,
        -- Legt die maximale Haltbarkeit des Ōdachi fest. Minimum=10,00 Maximum=100,00 Standard=20,00
        Odachi_ConditionMax = 20.0,
        -- Je höher der Wert, desto länger hält die Waffe. Minimum=10,00 Maximum=50,00 Standard=28,00
        Tanto_ConditionLowerChanceOneIn = 28.0,
        -- Legt die maximale Tantō-Haltbarkeit fest. Minimum=10,00 Maximum=50,00 Standard=14,00
        Tanto_ConditionMax = 14.0,
        -- Chance, den Zustandsverlust bei 100% Schärfe zu verhindern. Skaliert linear mit der aktuellen Schärfe. Minimum=0,00 Maximum=100,00 Standard=75,00
        SharpnessProtectionMultiplier = 75.0,
        -- Bestimmt, wie schnell die Klinge beim Schützen stumpf wird. 0.5: Halb so schnell, 2.0: Doppelt so schnell. Minimum=0,50 Maximum=2,00 Standard=1,00
        SharpnessDullingMultiplier = 1.0,
        -- Chance for a properly oiled blade (Choji oil ritual) to fully prevent condition loss on a hit, at no cost to sharpness. Checked before the sharpness protection roll. Minimum=10,00 Maximum=100,00 Standard=50,00
        CareProtectionChance = 50.0,
        -- How many weapon hits the Choji oil protection lasts for before needing to be reapplied. Minimum=100,00 Maximum=1000,00 Standard=500,00
        ChojiOilProtectionHits = 500.0,
        -- Wenn aktiviert, können Katanas, Wakizashis, Handwerksbücher und Bauteile an zusätzlichen, alltäglicheren Orten in der Welt gefunden werden.
        MoreLoot = false,
    },
    B42PackMule = {
        -- Enables attaching lanterns to belt slots.
        Attachment1 = true,
        -- Enables attaching welding torches to back slot.
        Attachment2 = true,
        -- Enables slings to be worn in the satchel slot.
        Satchel1 = true,
        -- Enables cloth gun cases to be worn in the satchel slot.
        Satchel2 = false,
        -- Enables dedicated bracelet slot, can be worn with watches and forearm armor.
        Bracelet = true,
        -- Enabled dedicated watch slot, can be worn with bracelets and forearm armor.
        Watch = true,
        -- If enabled watches and bracelets will be forced to share a slot, but maintain their ability to be worn with forearm armor.
        Exclusion1 = true,
        -- Enables dedicated canteen slot, can be worn with satchels.
        Canteen = true,
        -- Enables dedicated ear protector slot, cannot be worn with full helmets or suit heads.
        Ear = true,
        -- Enables dedicated shoulder slot with the ability to equip alongside backpacks and SCBA gear.
        Shoulder = true,
        -- Enables dedicated slot for duffel and golf bags, can be worn with backpacks.
        Back1 = true,
        -- Enables dedicated cloth gun case slot, can be worn with backpacks and duffels (will overwrite 'Satchel: Sling' if both enabled).
        Back2 = true,
        -- (Singleplayer only) Enables dedicated pouch slot.
        Pouch1 = false,
        -- (Singleplayer only) Enables dedicated wallet slot.
        Wallet1 = false,
        -- If enabled wallets and pouches will be forced to share a slot.
        Exclusion2 = false,
        -- Increases wallet weight reduction from 0 to 30.
        WalletFix = true,
        -- (Does not work with 'Slot: Pouch') Enables keyring auto-equipping behavior to pouches.
        Pouch2 = false,
        -- (Does not work with 'Slot: Wallet') Enables keyring auto-equipping behavior to wallets.
        Wallet2 = false,
        -- Enables carry capacity on all hunting vests and converts them from a clothing item to a container item. If changed mid-game any already existing vests will disappear.
        Vest1 = false,
        -- Enables two new vest attachment slots and allows for firearm magazines/cd players to equip to them.
        Vest2 = true,
        -- (Does not work with 'Vest: Capacity') Enables patching holes on hunting vests.
        Vest3 = false,
        -- Disables the ability to gain holes on all hunting vests (will overwrite 'Vest: Repair' if both enabled).
        Vest4 = false,
        -- Enables webbing slots on all small backpacks.
        Webbing1 = true,
        -- Enables webbing slots on all hiking backpacks.
        Webbing2 = true,
        -- Enables webbing slots on all military and survivor backpacks.
        Webbing3 = true,
        -- Enables webbing slots on all small crafted backpacks.
        Webbing4 = true,
        -- Enables webbing slots on all framepacks.
        Webbing5 = true,
    },
    SBFPlus = {
        -- Writes passive flashlight attachment and light-state diagnostics to console.txt. Disabled by default. It does not send extra network packets, change items, or record player names. Enable only while reproducing a multiplayer light-visibility issue.
        DebugLogging = false,
    },
    KnoxNetworkTacticalGear = {
        -- Vests and helmets in military and police loot. Also controls Gorka and boots in military stores, army surplus and outdoor shops. None disables new finds in this group; already generated items remain. Minimum=0,00 Maximum=4,00 Standard=0,60
        ArmorLootRarity = 0.6,
        -- Gas masks in military, police and ordinary civilian loot, plus dead zombies. None disables new finds. Changes affect newly generated loot after loading the world; existing items remain. Minimum=0,00 Maximum=4,00 Standard=0,60
        MaskLootRarity = 0.6,
        -- Tactical belts in military, police and ordinary civilian loot, plus dead zombies. None disables new finds. Changes affect newly generated loot after loading the world; existing items remain. Minimum=0,00 Maximum=4,00 Standard=0,60
        BeltLootRarity = 0.6,
        -- Night vision rarity in military and police loot, pawnshops and gun stores, and on military and police zombie corpses. Excluded from ordinary civilian loot. None disables new finds. Changes affect newly generated loot after loading the world. Minimum=0,00 Maximum=4,00 Standard=0,60
        NVGLootRarity = 0.6,
        -- In-game hours of NVG operation per fully charged regular battery. Default: 12 hours. Charge is consumed only while the goggles are lowered and switched on. Minimum=1,00 Maximum=72,00 Standard=12,00
        NVGBatteryHours = 12.0,
    },
    Cerberus = {
        -- Does Nothing. Just name of category that separates categories
        Category1 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Minimum=0,00 Maximum=100,00 Standard=0,06
        UnifrormZombiesDefault = 0.06,
        -- Specifies the probability of encountering Zombies in Cerberus Light Armor at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Minimum=0,00 Maximum=100,00 Standard=0,04
        LightArmoredZombiesDefault = 0.04,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Minimum=0,00 Maximum=100,00 Standard=0,02
        MediumArmoredZombiesDefault = 0.02,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Minimum=0,00 Maximum=100,00 Standard=0,01
        HeavyArmoredZombiesDefault = 0.01,
        -- Does Nothing. Just separates categories
        EmptyLine2 = false,
        -- Does Nothing. Just name of category that separates categories
        Category2 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Police Stations Minimum=0,00 Maximum=100,00 Standard=0,08
        UnifrormZombiesPolice = 0.08,
        -- Minimum=0,00 Maximum=100,00 Standard=0,06
        LightArmoredZombiesPolice = 0.06,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Police Stations Minimum=0,00 Maximum=100,00 Standard=0,04
        MediumArmoredZombiesPolice = 0.04,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Police Stations Minimum=0,00 Maximum=100,00 Standard=0,02
        HeavyArmoredZombiesPolice = 0.02,
        -- Does Nothing. Just separates categories
        EmptyLine3 = false,
        -- Does Nothing. Just name of category that separates categories
        Category3 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Military Bases Minimum=0,00 Maximum=100,00 Standard=0,10
        UnifrormZombiesArmy = 0.1,
        -- Specifies the probability of encountering Zombies in Cerberus Light Armor at Military Bases Minimum=0,00 Maximum=100,00 Standard=0,80
        LightArmoredZombiesArmy = 0.8,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Military Bases Minimum=0,00 Maximum=100,00 Standard=0,60
        MediumArmoredZombiesArmy = 0.6,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Military Bases Minimum=0,00 Maximum=100,00 Standard=0,40
        HeavyArmoredZombiesArmy = 0.4,
        -- Does Nothing. Just separates categories
        EmptyLine4 = false,
        -- Does Nothing. Just name of category that separates categories
        Category4 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Secret Base Minimum=0,00 Maximum=100,00 Standard=2,00
        UnifrormZombiesSecretBase = 2.0,
        -- Specifies the probability of encountering Zombies in Cerberus Light Armor at Secret Base Minimum=0,00 Maximum=100,00 Standard=1,20
        LightArmoredZombiesSecretBase = 1.2,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Secret Base Minimum=0,00 Maximum=100,00 Standard=0,80
        MediumArmoredZombiesSecretBase = 0.8,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Secret Base Minimum=0,00 Maximum=100,00 Standard=0,60
        HeavyArmoredZombiesSecretBase = 0.6,
        -- Does Nothing. Just separates categories
        EmptyLine5 = false,
        -- Does Nothing. Just name of category that separates categories
        Category5 = false,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Bulletproof Vest in containers Minimum=0,00 Maximum=100,00 Standard=0,05
        BulletproofVest_Cerberus = 0.05,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_HighMobilityKit.png> <LINE> Defines spawn chances for the Cerberus High Mobility Kit in containers Minimum=0,00 Maximum=100,00 Standard=0,03
        BulletproofVest_Cerberus_HighMobilityKit = 0.03,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_AssaultLightKit.png> <LINE> Defines spawn chances for the Cerberus Light Assault Kit in containers Minimum=0,00 Maximum=100,00 Standard=0,03
        BulletproofVest_Cerberus_AssaultLightKit = 0.03,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_AssaultKit.png> <LINE> Defines spawn chances for the Cerberus Assault Kit in containers Minimum=0,00 Maximum=100,00 Standard=0,02
        BulletproofVest_Cerberus_AssaultKit = 0.015,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_FullProtectionKit.png> <LINE> Defines spawn chances for the Cerberus Full Protection Kit in containers Minimum=0,00 Maximum=100,00 Standard=0,01
        BulletproofVest_Cerberus_FullProtectionKit = 0.005,
        -- Does Nothing. Just separates categories
        EmptyLine6 = false,
        -- Does Nothing. Just name of category that separates categories
        Category6 = false,
        -- <IMAGE:media/textures/Item_Helmet_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Helmet in containers Minimum=0,00 Maximum=100,00 Standard=0,02
        Helmet = 0.02,
        -- <IMAGE:media/textures/Item_Helmet_Mandible_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Helmet Mandible in containers Minimum=0,00 Maximum=100,00 Standard=0,02
        Helmet_Mandible = 0.02,
        -- <IMAGE:media/textures/Item_MaskFull_BallisticMask_Cerberus.png><IMAGE:media/textures/Item_MaskFull_BallisticMask_Cerberus2.png><IMAGE:media/textures/Item_MaskFull_BallisticMask_Cerberus3.png> <LINE> Defines spawn chances for the Cerberus Ballistic Mask in containers Minimum=0,00 Maximum=100,00 Standard=0,15
        MaskFull_BallisticMask = 0.15,
        -- <IMAGE:media/textures/Item_ElbowPads_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Elbow Pads Kit in containers Minimum=0,00 Maximum=100,00 Standard=0,40
        ElbowPads = 0.4,
        -- <IMAGE:media/textures/Item_KneePads_Cerberus.png> <LINE> Defines spawn chances for the Knee Pads in containers Minimum=0,00 Maximum=100,00 Standard=0,40
        KneePads = 0.4,
        -- Does Nothing. Just separates categories
        EmptyLine7 = false,
        -- Does Nothing. Just name of category that separates categories
        Category7 = false,
        -- <IMAGE:media/textures/Item_HipBag_Cerberus.png> <LINE> Defines spawn chances for Cerberus Hip Bag in containers Minimum=0,00 Maximum=100,00 Standard=0,03
        HipBag = 0.03,
        -- <IMAGE:media/textures/Item_FannyPack_Cerberus.png> <LINE> Defines spawn chances for Cerberus Fanny Pack in containers Minimum=0,00 Maximum=100,00 Standard=0,03
        FannyPack = 0.03,
        -- <IMAGE:media/textures/Item_ChestRigs_Cerberus.png> <LINE> Defines spawn chances for Cerberus Chest Rig in containers Minimum=0,00 Maximum=100,00 Standard=0,03
        ChestRigs = 0.03,
        -- <IMAGE:media/textures/Item_Backpack_Cerberus.png> <LINE> Defines spawn chances for Cerberus Backpack in containers. Minimum=0,00 Maximum=100,00 Standard=0,03
        Backpack = 0.03,
        -- Does Nothing. Just separates categories
        EmptyLine8 = false,
        -- Does Nothing. Just name of category that separates categories
        Category8 = false,
        -- <IMAGE:media/textures/Item_Headsets_Cerberus2.png><IMAGE:media/textures/Item_Headsets_Cerberus.png><IMAGE:media/textures/Item_Mask_Balaclava_Cerberus.png><IMAGE:media/textures/Item_Mask_Balaclava_Cerberus2.png><IMAGE:media/textures/Item_Mask_BandanaMask_Cerberus.png><IMAGE:media/textures/Item_Mask_BandanaMask_Cerberus2.png><IMAGE:media/textures/Item_Mask_BandanaMask_Cerberus3.png><IMAGE:media/textures/Item_Glasses_Goggles_Cerberus.png><IMAGE:media/textures/Item_Glasses_Tactical_Cerberus.png><IMAGE:media/textures/Item_Hat_BaseballCap_Cerberus.png><IMAGE:media/textures/Item_Hat_BaseballCap_Cerberus2.png> <LINE> Defines spawn chances for headsets, balaclavas, bandanas, goggles and caps in containers Minimum=0,00 Maximum=100,00 Standard=0,30
        HeadApparel = 0.3,
        -- <IMAGE:media/textures/Item_Jacket_Lightweight_Cerberus.png><IMAGE:media/textures/Item_Jacket_Lightweight_Cerberus2.png> <LINE> Defines spawn chances for jackets in containers Minimum=0,00 Maximum=100,00 Standard=0,03
        Jacket = 0.03,
        -- <IMAGE:media/textures/Item_Gloves_Cerberus.png><IMAGE:media/textures/Item_GlovesFingerless_Cerberus.png> <LINE> Defines spawn chances for gloves in containers Minimum=0,00 Maximum=100,00 Standard=0,04
        Gloves = 0.04,
        -- <IMAGE:media/textures/Item_Shirt_Cerberus.png><IMAGE:media/textures/Item_Shirt_Cerberus2.png><IMAGE:media/textures/Item_Shirt_ShortSleeve_Cerberus.png><IMAGE:media/textures/Item_Shirt_ShortSleeve_Cerberus2.png><IMAGE:media/textures/Item_Shirt_TankTop_Cerberus.png><IMAGE:media/textures/Item_Shirt_TankTop_Cerberus2.png><IMAGE:media/textures/Item_Shirt_TankTopShort_Cerberus.png><IMAGE:media/textures/Item_Shirt_TankTopShort_Cerberus2.png><IMAGE:media/textures/Item_Shirt_Tshirt_Cerberus.png><IMAGE:media/textures/Item_Shirt_Tshirt_Cerberus2.png><IMAGE:media/textures/Item_Shirt_TshirtShort_Cerberus.png><IMAGE:media/textures/Item_Shirt_TshirtShort_Cerberus2.png> <LINE> Defines spawn chances for classic, short sleeve, tank top, short tank top, T-shirts, short T-shirts in containers Minimum=0,00 Maximum=100,00 Standard=0,04
        MilitaryTShirts = 0.04,
        -- <IMAGE:media/textures/Item_Pants_Classic_Cerberus.png><IMAGE:media/textures/Item_Pants_Skinny_Cerberus.png> <LINE> Defines spawn chances for cargo and skinny pants in containers Minimum=0,00 Maximum=100,00 Standard=0,04
        PantsShorts = 0.04,
        -- <IMAGE:media/textures/Item_Shoes_TacticalBoots_Cerberus.png><IMAGE:media/textures/Item_Shoes_TacticalBoots_Cerberus2.png> <LINE>  Defines spawn chances for Cerberus tactical boots in containers Minimum=0,00 Maximum=100,00 Standard=0,04
        BootsShoes = 0.04,
        -- <IMAGE:media/textures/Item_Shirt_Neckholder_Cerberus.png><IMAGE:media/textures/Item_Shirt_Neckholder_Cerberus2.png><IMAGE:media/textures/Item_Shirt_NeckholderShort_Cerberus.png><IMAGE:media/textures/Item_Shirt_NeckholderShort_Cerberus2.png><IMAGE:media/textures/Item_Tights_Cerberus.png><IMAGE:media/textures/Item_Tights_Cerberus2.png><IMAGE:media/textures/Item_Stockings_Cerberus.png><IMAGE:media/textures/Item_Stockings_Cerberus2.png><IMAGE:media/textures/Item_Stockings_Cerberus3.png><IMAGE:media/textures/Item_Pants_Shorts_Cerberus.png><IMAGE:media/textures/Item_Pants_Shorts_Cerberus2.png><LINE> Defines spawn chances for non-military apparel in store containers. Includes neckholder shirts, short neckholder shirts, tights, stockings and skinny shorts. Does not spawn at military bases Minimum=0,00 Maximum=100,00 Standard=0,30
        NonMilitary = 0.3,
    },
    KATTAJ1 = {
        -- Specifies the probability of finding NVGs in military storages Minimum=0,00 Maximum=100,00 Standard=0,10
        ArmyStorage = 0.1,
        -- Specifies the probability of finding NVGs in Police Storages Minimum=0,00 Maximum=100,00 Standard=0,05
        PoliceStorage = 0.05,
    },
    JordanalSpawns = {
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Minimum=0,00 Maximum=100,00 Standard=0,04
        Desert_Camo_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Minimum=0,00 Maximum=100,00 Standard=0,02
        Desert_Camo_UnitChance_General = 0.02,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Minimum=0,00 Maximum=100,00 Standard=0,04
        MARPAT_Camo_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Minimum=0,00 Maximum=100,00 Standard=0,04
        Black_Camo_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Minimum=0,00 Maximum=100,00 Standard=0,02
        Black_Camo_UnitChance_General = 0.02,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Minimum=0,00 Maximum=100,00 Standard=0,04
        SWAT_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Minimum=0,00 Maximum=100,00 Standard=0,02
        SWAT_UnitChance_General = 0.02,
    },
    BlackDivisionGear = {
        -- How often the BD1 set spawns in military lockers and storage: jacket, pants, sneakers, gloves, warbelt with holster, LV-119 light plate carrier and its pouches. Standard=Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD1 = 4,
        -- How often the BD2 set spawns: combat shirt, pants, boots, gloves, warbelt with holster, drop-leg pouch, wrist GPS, FCPC V5 plate carrier and its pouches, 2 Day Assault Pack. Standard=Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD2 = 4,
        -- How often the BD3 set spawns: hooded jacket, pants, boots, fingerless gloves, warbelt with holster, LV-119 plate carrier and its pouches, NICE Frame backpack. Standard=Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD3 = 4,
        -- How often the BD4 set spawns: hybrid jacket, pants with knee pads, boots, gloves, battle belt, drop-leg holster and pouches, tactical watch, Siege-R plate carrier and its pouches, Modular Pack 45 backpack. Standard=Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD4 = 4,
        -- How often the head gear spawns: helmets, headsets, glasses, balaclavas, the M53A1 gas mask and the night vision goggles. Standard=Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnHead = 4,
    },
    BritasArmorPackB42 = {
        -- Schaltet Nachtsicht, Batterieaktionen und Batterieverbrauch dieses Pakets ein oder aus. Kleidung und eingesetzte Batterien bleiben erhalten. Andere Frameworks erhalten dadurch keine Unterstützung für Brita-Nachtsichtgeräte. Nach Änderungen das Spiel neu starten.
        EnableNightVision = true,
        -- Ergänzt den üblichen Bonus von 15 Prozent für unterstützte Brita-Munitionsträger, die von der bisherigen Berechnung übergangen werden. Deaktivieren, wenn eine andere Mod Nachladeboni verwaltet. Sicherheitsprüfungen und bereits vom Spiel gewährte Boni bleiben aktiv.
        ReloadCarrierBonus = true,
    },
    NVFramework = {
        -- Diese integrierte Reparatur erfordert immer eine eingesetzte, geladene Batterie. In alten Spielständen gespeicherte deaktivierte Einstellungen werden automatisch migriert.
        BatterySystemEnabled = true,
        -- Bestimmt, wie schnell eingesetzte Nachtsichtbatterien entladen werden. 1,0 entspricht etwa 12 Spielstunden; 2,0 entlädt doppelt so schnell; 0,5 halb so schnell. Minimum=0,10 Maximum=100,00 Standard=1,00
        BatteryDrainMultiplier = 1.0,
        -- Skaliert nur die prozeduralen Spawn-Gewichte der vom Framework hinzugefügten Beispiel-Nachtsichtgeräte. 1,0 ist Standard, 2,0 verdoppelt das Gewicht und 0,0 deaktiviert diese Spawns. Minimum=0,00 Maximum=100,00 Standard=1,00
        ItemSpawnMultiplier = 1.0,
        -- Wenn aktiviert, verwendet der Einzelspieler den angefügten gerichteten Lichtkegel. Wenn deaktiviert, wird die Ersatzbeleuchtung auf Basis eines Laternenlichts verwendet.
        UseLightConeInSingleplayer = true,
    },
    LBO = {
        -- Minimum=15,00 Maximum=49,00 Standard=49,00
        BagCapacity = 49.0,
        -- Minimum=0,90 Maximum=0,99 Standard=0,99
        BagRunSpeedModifier = 0.99,
        -- Minimum=50,00 Maximum=99,00 Standard=99,00
        BagWeightReduction = 99.0,
        -- <RGB:0,1,0>Wie oft legendäre Rucksäcke in Häusern und Läden erscheinen. Jede Farbe erscheint an passenden Orten.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        BackpackCommon = 2,
        -- <RGB:0,1,0>Wie oft legendäre Rucksäcke in Polizeistationen, Militärgeländen, Feuerwachen, Antiquitätenläden und Überlebendenhäusern erscheinen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        BackpackRare = 3,
        -- <RGB:0,1,0>Wie oft Zombies einen legendären Rucksack tragen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        BackpackZombies = 1,
        -- <RGB:0,1,0>Wie oft die Zeitschrift mit den Rezepten erscheint (Bücherregale, Zeitschriftenständer, Überlebendenhäuser, Zombies...).
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        Magazine = 5,
        -- Starte mit einem Legendary Backpack (Grau) im Inventar.
        StartWithLBGrey = false,
    },
    LDO = {
        -- Minimum=15,00 Maximum=49,00 Standard=49,00
        BagCapacity = 45.0,
        -- Minimum=0,90 Maximum=0,99 Standard=0,99
        BagRunSpeedModifier = 0.99,
        -- Minimum=50,00 Maximum=99,00 Standard=99,00
        BagWeightReduction = 99.0,
        -- <RGB:0,1,0>Wie oft legendäre Reisetaschen in Häusern und Läden erscheinen. Jede Farbe erscheint an passenden Orten.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        DuffelbagCommon = 2,
        -- <RGB:0,1,0>Wie oft legendäre Reisetaschen in Polizeistationen, Militärgeländen, Feuerwachen, Antiquitätenläden und Überlebendenhäusern erscheinen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        DuffelbagRare = 3,
        -- <RGB:0,1,0>Wie oft Zombies eine legendäre Reisetasche tragen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        DuffelbagZombies = 1,
        -- <RGB:0,1,0>Wie oft die Zeitschrift mit den Rezepten erscheint (Bücherregale, Zeitschriftenständer, Überlebendenhäuser, Zombies...).
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        Magazine = 5,
        -- Starte mit einer Legendary Duffel Bag (Grau) im Inventar.
        StartWithLDGrey = false,
    },
    LFO = {
        -- Minimum=1,00 Maximum=49,00 Standard=10,00
        FannyCapacity = 15.0,
        -- Minimum=0,90 Maximum=0,99 Standard=0,99
        FannyRunSpeedModifier = 0.99,
        -- Minimum=50,00 Maximum=99,00 Standard=99,00
        FannyWeightReduction = 99.0,
        -- <RGB:0,1,0>Wie oft legendäre Bauchtaschen in Häusern und Läden erscheinen. Jede Farbe erscheint an passenden Orten.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        FannypackCommon = 5,
        -- <RGB:0,1,0>Wie oft legendäre Bauchtaschen in Polizeistationen, Militärgeländen, Feuerwachen, Antiquitätenläden und Überlebendenhäusern erscheinen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        FannypackRare = 5,
        -- <RGB:0,1,0>Wie oft Zombies eine legendäre Bauchtasche tragen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        FannypackZombies = 1,
        -- <RGB:0,1,0>Wie oft die Zeitschrift mit den Rezepten erscheint (Bücherregale, Zeitschriftenständer, Überlebendenhäuser, Zombies...).
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        Magazine = 5,
        -- Starte mit einer Legendary Fanny Pack (Grau) im Inventar.
        StartWithLFGrey = false,
    },
    LSO = {
        -- Minimum=10,00 Maximum=49,00 Standard=49,00
        BagCapacity = 40.0,
        -- Minimum=0,90 Maximum=0,99 Standard=0,99
        BagRunSpeedModifier = 0.99,
        -- Minimum=50,00 Maximum=99,00 Standard=99,00
        BagWeightReduction = 99.0,
        -- <RGB:0,1,0>Wie oft legendäre Taschen in Häusern und Läden erscheinen. Jede Farbe erscheint an passenden Orten.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        SatchelCommon = 2,
        -- <RGB:0,1,0>Wie oft legendäre Taschen in Polizeistationen, Militärgeländen, Feuerwachen, Antiquitätenläden und Überlebendenhäusern erscheinen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        SatchelRare = 3,
        -- <RGB:0,1,0>Wie oft Zombies eine legendäre Tasche tragen.
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        SatchelZombies = 1,
        -- <RGB:0,1,0>Wie oft die Zeitschrift mit den Rezepten erscheint (Bücherregale, Zeitschriftenständer, Überlebendenhäuser, Zombies...).
        -- 0 = nie, 1 = extrem selten, 5 = Standard, 10 = dreimal so häufig wie Standard. Minimum=0 Maximum=10 Standard=5
        Magazine = 5,
        -- Starte mit einer Legendary Satchel (Grau) im Inventar.
        StartWithLSGrey = false,
    },
    RepairableWindows = {
        -- Sets the formula used to determine the chance for a character to break a window when attempting to pick it up. Placing a window never breaks it. <LINE> Vanilla mimics the values used by vanilla moveable windows - level 2 has a 45% chance to break, level 10 has a 5% chance. <LINE> Generous further reduces the chance to break a window - level 2 has a 45% chance, level 7 has a 0% chance. Standard=Vanilla
        -- 1 = Vanilla
        -- 2 = Generous
        -- 3 = Windows never break
        BreakChance = 1,
    },
    BadlandsFence = {
        -- How many connected fence sections one energizer can feed. Sections past the cap stay dead. Minimum=5 Maximum=200 Standard=40
        LineCap = 40,
        -- Real seconds between shocks on a live line. Minimum=0,25 Maximum=5,00 Standard=1,00
        PulseSeconds = 1.0,
        -- Generator fuel the energizer burns per in-game hour on its own, in litres. A vanilla generator idles at 0.02; a fridge adds 0.08. Scaled by the Generator Fuel Consumption option. Minimum=0,00 Maximum=1,00 Standard=0,02
        BaseDraw = 0.02,
        -- Extra fuel per in-game hour for each live section. Minimum=0,00 Maximum=0,10 Standard=0,00
        SectionDraw = 0.002,
        -- Health a zombie loses to each pulse. Short of the lethal time this never takes a zombie below the health floor. Minimum=0,00 Maximum=1,00 Standard=0,08
        ZapDamage = 0.08,
        -- Chance a pulse knocks a standing zombie down. Otherwise it staggers back. Minimum=0 Maximum=100 Standard=20
        KnockdownChance = 20,
        -- Players who push against or climb over a live line get a jolt. Standing next to it is safe.
        PlayerShock = true,
        -- General health a player loses to one jolt (at most one per jolt cooldown). Minimum=0,00 Maximum=25,00 Standard=3,00
        PlayerShockDamage = 3.0,
        -- Real seconds between jolts while a player keeps touching a live line. Minimum=0,50 Maximum=10,00 Standard=2,00
        PlayerShockCooldown = 2.0,
        -- Anyone who stays on a live line too long dies: players who keep pushing against or climbing on the wire, zombies and animals that stay on a live square. Off: the fence only stuns and wears.
        Lethal = true,
        -- Real seconds of unbroken contact before a player dies. Letting go for a moment resets it. A warning shows halfway. Minimum=1,00 Maximum=60,00 Standard=5,00
        PlayerLethalSeconds = 5.0,
        -- Real seconds a zombie can stay on a live square before it dies. One pulse off the wire resets it. Minimum=1,00 Maximum=120,00 Standard=8,00
        ZombieLethalSeconds = 8.0,
        -- Short of the lethal time, pulses never take a zombie below this much health (1.0 is full). 0 lets pulse damage alone finish them. Minimum=0,00 Maximum=1,00 Standard=0,05
        ZombieHealthFloor = 0.05,
        -- Livestock and wildlife on a live square get zapped: a little health and a lot of stress each pulse. Mind your own pens.
        AnimalShock = true,
        -- Health an animal loses to each pulse (1.0 is full). Short of the lethal time this never takes one below 0.1. Minimum=0,00 Maximum=1,00 Standard=0,02
        AnimalShockDamage = 0.02,
        -- Stress added to an animal by each pulse, on the game's 0 to 100 scale. Minimum=0,00 Maximum=100,00 Standard=15,00
        AnimalStress = 15.0,
        -- Real seconds an animal can stay on a live square before it dies, if sustained contact kills. One pulse off the wire resets it. Minimum=1,00 Maximum=300,00 Standard=15,00
        AnimalLethalSeconds = 15.0,
    },
    BadlandsPower = {
        -- Percent of generators found on the map and in generator loot (crates, vehicles) that are Badlands Power machines instead of vanilla ones. 0 turns the mixing off; crafting still works. Minimum=0 Maximum=90 Standard=33
        WorldShare = 33,
    },
    BadlandsPowerControllers = {
        -- Electrical skill needed to build a generator controller. 0 means no requirement. Minimum=0 Maximum=10 Standard=5
        BuildSkill = 5,
        -- Electrical skill needed to change a controller's program. 0 means no requirement. Minimum=0 Maximum=10 Standard=3
        ConfigureSkill = 3,
    },
    PlayablePool = {
        -- Die Langeweile wird verringert, nachdem ein Spieler einen gültigen Poolschuss oder eine Minispielrunde ausgeführt hat. Minimum=0 Maximum=100 Standard=18
        BoredomReliefPerTurn = 18,
        -- Maximaler Abstand in Feldern, um einen Tisch zu benutzen oder sein Fenster offen zu halten. Weiteres Entfernen schließt das Fenster und reserviert den Platz. Die Rückkehr in Reichweite öffnet ein wegen der Entfernung geschlossenes Fenster wieder. Minimum=3 Maximum=30 Standard=8
        MaxPlayDistance = 8,
        -- Administratoren dürfen zum Testen eine Solo-Poolübung starten, auch wenn normale Soloübungen deaktiviert sind.
        AllowAdminSoloPractice = true,
        -- Erlaubt das Solotraining im Billardfenster.
        AllowSoloPractice = true,
        -- Erlaubt es, einem belegten Minispiel zuzusehen, ohne einen Platz einzunehmen. Gilt für alle Playable-Pool-Minispiele, nicht nur für Billard.
        AllowSpectators = true,
        -- Erlaubt es, an jedem Tisch, der sie anbietet, Computergegner hinzuzufügen. Ausgeschaltet wird nur allein oder gegen Menschen gespielt; das Solotraining beim Billard bleibt verfügbar. Ein Bot, der bereits sitzt, behält seinen Platz, bis ihn jemand entfernt.
        AllowBots = true,
        -- Entfernt die Ansage beim 8-Ball: eine versenkte Kugel der eigenen Gruppe behält den Tisch (nur gegnerische Kugeln geben ihn ab), ein gemischter Fall vergibt trotzdem eine Gruppe, und die eigene Gruppe plus die 8 in einem gültigen Stoß gewinnt. Weiße versenkt, falsche Gruppe zuerst getroffen und ungültiger Anstoß bleiben Fouls. Aus = Standardregeln.
        CasualCallRules = true,
        -- Balatroid aktivieren, das Poker-Roguelike in laufender Entwicklung. Alle anderen Spiele haben eigene Schalter. Im Einzelspieler gibt es außerdem eine lokale Beta-Option in den Minispiel-Einstellungen; im Mehrspieler gilt immer die Servereinstellung.
        EnableBetaMinigames = false,
        -- Das Spiel Darts 501 an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableDarts501 = true,
        -- Das Spiel Wordle an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableWordle = true,
        -- Das Spiel Blackjack an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableBlackjack = true,
        -- Das Spiel Texas Hold’em an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableHoldem = true,
        -- Das Spiel Solitär an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableSolitaire = true,
        -- Das Spiel Schach an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableChess = true,
        -- Das Spiel Dame an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableCheckers = true,
        -- Das Spiel Vier gewinnt an seiner Spielfläche anbieten. Wenn es deaktiviert ist, erklärt das Menü die blockierende Einstellung, und der Host verweigert Start, Beitritt und Zuschauen.
        EnableConnect4 = true,
        -- Ein verlassenes Spiel nach dieser Anzahl Minuten entfernen. Für einen vollständig vorübergehend verlassenen Tisch gilt eine kürzere Reservierungszeit. Ein Solospiel bleibt erhalten, solange sein Besitzer lebt und in der Nähe bleibt. Laufende Spiele werden nie auf die Festplatte gespeichert. Minimum=1 Maximum=120 Standard=20
        AbandonedSessionMinutes = 20,
        -- Zeitlimit pro Zug, wenn mindestens zwei Menschen am Tisch sitzen. Nach Ablauf wird bei Hold’em gepasst, bei Blackjack gehalten, bei Darts der Zug übersprungen, beim Pool dem Gegner Ball in Hand gegeben oder ein Brettspiel nach Zeit verloren. Die Uhr ist sichtbar. Solospiele und Spiele gegen Bots haben keine Zug-Uhr. Mit 0 deaktivieren. Minimum=0 Maximum=600 Standard=90
        TurnTimeoutSeconds = 90,
        -- Platz und Chips eines getrennten Spielers für diese Dauer behalten. Standard: 120 Sekunden. Wer innerhalb dieser Frist zurückkehrt, erhält seinen Platz wieder. Minimum=20 Maximum=600 Standard=120
        DisconnectGraceSeconds = 120,
        -- Die Ausrüstung freigeben, wenn alle menschlichen Spieler ihren Platz so lange vorübergehend verlassen haben. Standard: 2 Minuten. Ein Solospiel bleibt verfügbar, solange sein Besitzer lebt und in der Nähe bleibt. Minimum=1 Maximum=120 Standard=2
        ParkedSessionMinutes = 2,
        -- Hat ein sitzender Spieler zu wenige Chips für den Einstieg und an keinem Tisch Chips gebunden, wird sein Guthaben auf diesen Betrag oder den Mindesteinsatz des Tisches aufgefüllt, je nachdem, welcher höher ist. Standard: 50. Mit 0 deaktivieren. Minimum=0 Maximum=1000 Standard=50
        HouseStake = 50,
        -- Speichert pro Charakter gespielte, gewonnene und verlorene Partien, das gemeinsame Chip-Guthaben von Hold'em und Blackjack sowie freigeschaltete Balatroid-Einsätze. Das ist das Einzige, was Playable Pool in einen Spielstand schreibt; ausgeschaltet nutzt der Kartenraum nur Tischchips und speichert nichts. Laufende Partien werden so oder so nie gespeichert.
        EnableRecords = true,
        -- Optionaler Stressabbau nach einem gültigen Poolschuss oder einer Minispielrunde. Zum Deaktivieren auf 0 belassen. Minimum=0 Maximum=100 Standard=0
        StressReliefPerTurn = 0,
        -- Optionale Unzufriedenheitsreduzierung nach einem gültigen Poolschuss oder einer Minispielrunde. Zum Deaktivieren auf 0 belassen. Minimum=0 Maximum=100 Standard=0
        UnhappinessReliefPerTurn = 0,
    },
    PropaneExchangeCabinet = {
        -- Turn OFF to make the mod completely dormant: no spawning, no recovery, no cabinet visual updates - while the mod stays loaded so your save (especially multiplayer) remains loadable. Use this instead of uninstalling on game 42.20.4+, which cannot cleanly uninstall mods with craftable furniture. Existing cabinets remain as plain containers. A relog may be needed after changing this mid-save.
        Enabled = true,
        -- Chance that a propane exchange cabinet spawns at each eligible location (Fossoil/Gas2Go gas stations, Zippee's convenience stores). Rolled ONCE per station per save - a station that rolls empty stays empty on that save. 0 = never, 100 = always. Minimum=0 Maximum=100 Standard=50
        SpawnChance = 50,
        -- Upper limit on how many propane tanks a spawned cabinet is stocked with (actual count is random from 0 to this). Minimum=0 Maximum=6 Standard=6
        MaxTanks = 6,
        -- Relative weight for a tank being near-full (90%-100%). Weighted against the near-empty weight. Tanks are never in the 20%-90% range. Minimum=0 Maximum=100 Standard=55
        FillWeightFull = 55,
        -- Relative weight for a tank being near-empty (0%-20%). Minimum=0 Maximum=100 Standard=15
        FillWeightEmpty = 15,
        -- Chance that a stocked propane cabinet includes the recipe-teaching magazine (Welder Special Edition). 0 = never, 100 = always -- subject to the one-per-save limit below, if enabled. Minimum=0 Maximum=100 Standard=25
        MagazineChance = 25,
        -- If enabled, the magazine stops dropping after the first copy is found on this save (not per player -- see mod notes for the multiplayer caveat). If disabled, it can drop repeatedly at the chance above.
        MagazineOnePerSave = true,
        -- If selected only weathered cabinets will spawn, existing cabinets are not affected.
        RemoveNewCabinets = false,
    },
    ShelterHoldBeehive = {
        -- Erlaubt Zombienen bei der Nahrungssuche und beim Zerlegen wilder Honigwaben. Ist die Option deaktiviert, bleiben vorhandene Zombienen aus Speicherkompatibilitätsgründen erhalten, können nach dem Entfernen aber nicht erneut in einen Bienenstock eingesetzt werden.
        EnableZombees = true,
        -- Wenn aktiviert, zeigt Lockbeute > Köder hinzufügen nur Köder, die eine wilde Honigwabe anlocken können: Honig, Bienenwachs, Zucker, brauner Zucker, Zuckerwürfel und Zuckerpäckchen. Standardmäßig deaktiviert, um das Standardverhalten des Fallenmenüs beizubehalten.
        HideInvalidBaitHiveBaits = false,
        -- Minimale lokale Lufttemperatur am Feld des Bienenstocks, bei der Honigbienenköniginnen Honig produzieren. Standard: 12 °C. Minimum=-50,00 Maximum=50,00 Standard=12,00
        HoneybeeMinTemperature = 12.0,
        -- Maximale lokale Lufttemperatur am Feld des Bienenstocks, bei der Honigbienenköniginnen Honig produzieren. Standard: 32 °C. Minimum=-50,00 Maximum=60,00 Standard=32,00
        HoneybeeMaxTemperature = 32.0,
        -- Minimale lokale Lufttemperatur am Feld des Bienenstocks für Hummelköniginnen. Hummeln vertragen einen größeren Bereich als Honigbienen. Standard: 5 °C. Minimum=-50,00 Maximum=50,00 Standard=5,00
        BumblebeeMinTemperature = 5.0,
        -- Maximale lokale Lufttemperatur am Feld des Bienenstocks für Hummelköniginnen. Hummeln vertragen einen größeren Bereich als Honigbienen. Standard: 35 °C. Minimum=-50,00 Maximum=60,00 Standard=35,00
        BumblebeeMaxTemperature = 35.0,
        -- Multipliziert die Honigproduktion der Rahmen nach Königin-, Rahmen-, Saison- und Innen/Außen-Modifikatoren. Standard: 1.0x. Minimum=0,00 Maximum=5,00 Standard=1,00
        HoneyProductionSpeedMultiplier = 1.0,
        -- Radius in Feldern um einen Bienenstock, der vom täglichen Wachstumsbonus betroffen ist. Standard: 2 Felder, also 5x5 um den Bienenstock. Minimum=0 Maximum=10 Standard=2
        PlantGrowthBoostRadius = 2,
        -- Multipliziert die Biom-Abundanzwerte für Honigbienen-, Hummel- und Zombienenköniginnen sowie wilde Honigwaben bei der Nahrungssuche. Ändert nicht die Fangchance der Lockbeute. Standard: 1.0x. Minimum=0,00 Maximum=5,00 Standard=1,00
        BeeForagingAbundanceMultiplier = 1.0,
    },
    Tuna_MultiVHS = {
        -- Platziert von Hand ein QuadVision im Fernsehgeschäft der Mall von Louisville, auf der Verkaufsfläche neben den Ausstellungsgeräten. Immer nur ein einziges, und nur in einer Welt, die mit dieser Option erstellt wurde - einem bestehenden Spielstand wird es nie hinzugefügt.
        CuratedQuadVisionSpawns = true,
        -- Lässt das QuadVision zusätzlich als Behälterbeute auftauchen, neben dem DualVision. Standardmäßig aus: das zwei Felder große Spitzenmodell soll dort gefunden werden, wo es steht, und nicht aus einer Kiste gezogen werden. Das DualVision bleibt davon unberührt.
        QuadVisionContainerSpawns = false,
        -- Wie oft ein QuadVision in Behältern erscheint. Ohne Wirkung, solange QuadVision in Behältern ausgeschaltet ist. Standard=Außergewöhnlich selten
        -- 1 = Außergewöhnlich selten
        -- 2 = Sehr selten
        -- 3 = Selten
        QuadVisionContainerRarity = 1,
        -- Wie oft ein Breitbildfernseher, der bereits in einem Geschäft, Wohnzimmer oder Schlafzimmer steht, stattdessen ein Mirage AV DualVision ist. Dies wird bei der Welterstellung festgelegt und gilt danach unveränderlich für diese Welt - eine spätere Änderung wirkt sich auf eine laufende Welt nicht mehr aus. Auf einen Spielstand, der älter als diese Option ist, wird sie nie angewendet. Standard=Sehr selten
        -- 1 = Aus
        -- 2 = Außergewöhnlich selten
        -- 3 = Sehr selten
        -- 4 = Selten
        -- 5 = Ungewöhnlich
        DualVisionWorldSwaps = 3,
    },
    ForestWildlife = {
        -- Master switch for the hourly scan that places wild animals around you. Off leaves only the route options below.
        Enabled = true,
        -- Nothing appears closer than this to a player. Also the inner edge of the search ring. Minimum=20 Maximum=150 Standard=40
        ScanMinRadius = 40,
        -- Outer edge of the search ring. Automatically clamped to the loaded area (about 70 tiles in single player), because animals outside loaded chunks cannot be counted. Minimum=60 Maximum=250 Standard=70
        ScanMaxRadius = 70,
        -- Stop placing animals once this many wild animals are already alive within the scan radius. Minimum=1 Maximum=60 Standard=12
        MaxAnimals = 12,
        -- Total animals from groups this mod has placed across the whole save. The count corrects itself whenever you pass a group again. Minimum=50 Maximum=2000 Standard=300
        GlobalCap = 300,
        -- Tiles between any two groups placed by this mod. Minimum=20 Maximum=200 Standard=60
        MinGroupSpacing = 60,
        -- Skip spots a player can currently see. Single player only: the engine check needs a local player index and does nothing on a dedicated server.
        AvoidPlayerSight = true,
        -- Nothing is placed if any zombie is within this many tiles of the spot. A fresh animal starts calling at once and would drag them to itself. 0 disables the check. Minimum=0 Maximum=100 Standard=20
        ZombieFreeRadius = 20,
        -- Chance per day of a deer group being placed in suitable forest. Minimum=0,00 Maximum=100,00 Standard=5,00
        DeerChance = 5.0,
        -- Chance per day of a rabbit group being placed in suitable forest. Minimum=0,00 Maximum=100,00 Standard=9,00
        RabbitChance = 9.0,
        -- Chance per day of a raccoon group being placed in suitable forest. Minimum=0,00 Maximum=100,00 Standard=6,00
        RaccoonChance = 6.0,
        -- Chance per day of a mouse group being placed in suitable forest. Minimum=0,00 Maximum=100,00 Standard=10,00
        MouseChance = 10.0,
        -- Chance per day of a rat group being placed in suitable forest. Minimum=0,00 Maximum=100,00 Standard=7,00
        RatChance = 7.0,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. 0.0 means no males and the group will never breed. Vanilla herds run about 0.25. Minimum=0,00 Maximum=1,00 Standard=0,25
        DeerMaleRatio = 0.25,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. 0.0 means no males and the group will never breed. Minimum=0,00 Maximum=1,00 Standard=0,30
        RabbitMaleRatio = 0.3,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. Minimum=0,00 Maximum=1,00 Standard=0,40
        RaccoonMaleRatio = 0.4,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. Minimum=0,00 Maximum=1,00 Standard=0,50
        MouseMaleRatio = 0.5,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. Minimum=0,00 Maximum=1,00 Standard=0,50
        RatMaleRatio = 0.5,
        -- Around the clock ignores the time of day. By species behaviour applies the multiplier below during each species' active hours: rabbit and raccoon 19:00-05:00 (the game's own trapping data), deer at dawn and dusk, mouse and rat are active all day and get no bonus. Standard=By species behaviour
        -- 1 = Around the clock
        -- 2 = By species behaviour
        ActivityMode = 2,
        -- Chance multiplier during a species' active hours. Ignored when Activity Hours is set to around the clock. Minimum=1,00 Maximum=5,00 Standard=1,20
        NightMultiplier = 1.2,
        -- Chance multiplier in December, January and February. Minimum=0,00 Maximum=1,00 Standard=0,50
        WinterMultiplier = 0.5,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=1,00
        ZoneDeepForest = 1.0,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=1,00
        ZoneOrganicForest = 1.0,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,80
        ZoneBirchForest = 0.8,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,80
        ZoneBirchMixForest = 0.8,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,70
        ZonePRForest = 0.7,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,70
        ZonePHForest = 0.7,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,60
        ZoneForest = 0.6,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,50
        ZoneFarmForest = 0.5,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,50
        ZoneFarmMixForest = 0.5,
        -- Chance multiplier on open farmland, pasture and ranch land. 0 disables wildlife there entirely. Minimum=0,00 Maximum=2,00 Standard=0,30
        ZoneFarmland = 0.3,
        -- Multiplier on how many animals a placed group contains. Minimum=0,50 Maximum=3,00 Standard=0,75
        HerdSize = 0.75,
        -- Chance that a female placed by the mod brings a young one along.\ Vanilla herds run 20 for deer and 40 for rabbit. 0 places adults only. Minimum=0 Maximum=100 Standard=10
        BabyChance = 10,
        -- Livestock and poultry that wandered off the farms, placed loose in and around the woods. Useful on a long save where the game has already cleared the farms and there is nothing left to breed from. They keep their vanilla behaviour: none of them flee from you, and chickens and turkeys cannot graze off the ground, because making them act feral would mean editing shared animal definitions and changing every coop bird on the map. They are not flagged as wild, so you can catch them, lead them home and pen them.
        FarmAnimals = false,
        -- Chance per day of a loose chicken being placed.\ They do not flee and cannot feed off the ground - vanilla farm bird behaviour, kept as is. Minimum=0,00 Maximum=100,00 Standard=3,00
        FarmChickenChance = 3.0,
        -- Chance per day of a loose turkey being placed.\ Build 42 has no wild turkey, only the farm bird, so this is the way to meet one in the woods. Minimum=0,00 Maximum=100,00 Standard=2,00
        FarmTurkeyChance = 2.0,
        -- Chance per day of a loose pig being placed.\ Pigs graze off the ground, so they can genuinely live out there. Minimum=0,00 Maximum=100,00 Standard=1,00
        FarmPigChance = 1.0,
        -- Chance per day of a loose sheep being placed.\ Sheep graze off the ground. A ram fights back when stressed. Minimum=0,00 Maximum=100,00 Standard=1,00
        FarmSheepChance = 1.0,
        -- Chance per day of a loose cow being placed.\ Lowest by default, because one cow is an enormous amount of meat. A bull fights back when stressed. Minimum=0,00 Maximum=100,00 Standard=0,50
        FarmCowChance = 0.5,
        -- Chance per day of a loose horse being placed. Needs the Horse Mod; without it this setting does nothing.\ A horse can be tamed, saddled and ridden. A stressed stallion fights back and can knock you down. Minimum=0,00 Maximum=100,00 Standard=0,20
        FarmHorseChance = 0.2,
        -- How many animals a single farm spawn places.\ 1 keeps them solitary strays, which also means they never breed on their own. Minimum=1 Maximum=8 Standard=1
        FarmGroupSize = 1,
        -- Share of males among placed farm animals. 0.5 is an even split, lower means more females.\ Shared by all farm species. Minimum=0,00 Maximum=1,00 Standard=0,50
        FarmMaleRatio = 0.5,
        -- Chance that a placed farm female brings a young one along.\ 0 places adults only. A young animal needs its mother alive nearby. Minimum=0 Maximum=100 Standard=10
        FarmBabyChance = 10,
        -- Total farm animals from this mod across the whole save.\ Separate from the wildlife cap, because these are not flagged wild and the wildlife counter cannot see them. Minimum=0 Maximum=500 Standard=60
        FarmCap = 60,
        -- Chance multiplier on farmland, pasture, ranch land and the woods bordering them.\ This and the next multiplier replace the per-forest sliders above for farm animals. Minimum=0,00 Maximum=2,00 Standard=1,00
        FarmNearMultiplier = 1.0,
        -- Chance multiplier everywhere else in the forest, away from farmland.\ 0 keeps feral farm animals strictly around farms. Minimum=0,00 Maximum=2,00 Standard=0,25
        FarmWoodMultiplier = 0.25,
        -- Adds a Forest migration routes entry to the right-click menu in the world, where extra deer and rabbit routes can be previewed and then written into this save. Nothing is built until you pick Apply the plan to the save and confirm it. How to use: right-click the ground, Build a plan on the map, open the world map (M) and look at the yellow and red loops, change Extra Routes Multiplier and plan again if the density is wrong, then Apply the plan to the save, and reload the save straight afterwards without travelling anywhere. Applying cannot be undone - the routes become part of the save file, so back up the save folder first. Routes can only be placed where the game own map files describe the forest, so forest that stays empty after planning cannot take them at all - a limit of the game files, not of the mod. How many routes appear also depends on the game own Animal Paths Chance option.
        BuildMapPaths = false,
        -- Route density relative to vanilla: the game's roll count per cell times this, at the chance set by the vanilla option Animal Paths Chance.
        -- 1.0 is vanilla density, 1.2 adds about a fifth. Minimum=0,50 Maximum=5,00 Standard=1,20
        MapPathMultiplier = 1.2,
        -- Print every scan, spawn and rejection reason to the console and add the FWD Debug right-click menu. Also on automatically when the game runs with -debug.
        Debug = false,
        -- Just a separator. It does nothing.
        HydeCoSeparator = false,
        -- Needs HydeCo. Squirrels! Chance per day that a squirrel comes out of a den tree near you. Replaces that mod's own spawning: nothing comes out except by this roll. Its Most squirrels out at once setting still caps how many can be around you. 0 = none. Minimum=0,00 Maximum=100,00 Standard=10,00
        HydeCoSquirrelChance = 10.0,
        -- Needs HydeCo. Squirrels! When off, wild squirrel groups no longer spawn alongside rabbits, and only the den squirrels above remain. Applies when a save is loaded.
        HydeCoMigratingSquirrels = false,
        -- Needs HydeCo. Beavers! Chance per day that a beaver comes out of a lodge near you. Replaces that mod's own spawning: nothing comes out except by this roll. Its Most beavers out at once setting still caps how many can be around you. 0 = none. Minimum=0,00 Maximum=100,00 Standard=5,00
        HydeCoBeaverChance = 5.0,
        -- Needs HydeCo. Frogs! Chance per day that a frog appears by water near you. Replaces that mod's own spawning: nothing appears except by this roll. Its Most frogs out at once setting still caps how many can be around you. 0 = none. Minimum=0,00 Maximum=100,00 Standard=8,00
        HydeCoFrogChance = 8.0,
        -- Needs HydeCo. Robins! Chance per day that a robin appears near you. Replaces that mod's own spawning: nothing appears except by this roll. Its Most robins out at once setting still caps how many can be around you. 0 = none. Minimum=0,00 Maximum=100,00 Standard=10,00
        HydeCoRobinChance = 10.0,
    },
    ProjectCook = {
        -- Erlaubt Project Cook, gefrorene Lebensmittel in Basis-Kochen und Kochen nach Rezepten zu verwenden, auch wenn das Rezept des Grundspiels aufgetaute Zutaten verlangt. Standardmäßig deaktiviert. Betrifft nur Project Cook.
        AllowFrozenCooking = false,
    },
    TWF_BF = {
        -- Deaktiviert (Standard): Verwendet die Vanilla-Tabelle für die Fischgrößenverteilung. Aktiviert: Verwendet die Better-Fishing-Verteilung für Klein/Mittel/Groß. Die Vanilla-Skill- und Arten-Gewichtsgrenzen bleiben immer erhalten.
        -- Hinweis: Diese Auswahl wird beim Laden der Welt angewendet. Lade den Spielstand nach einer Änderung neu.
        UseTwF_SizeDistribution = false,
        -- Maximale Wurf-/Zieldistanz in Feldern.
        -- 16 (Standard) verwendet die originale Vanilla-Distanzprüfung. Höhere Werte aktivieren den Better-Fishing-Override. Minimum=16 Maximum=20 Standard=16
        TwF_AimDist = 16,
        -- Radius der Ufererkennung in Feldern.
        -- 7 (Standard) verwendet die originale Vanilla-Ufererkennung. Werte von 1-6 aktivieren die leichtere, richtungsbasierte Better-Fishing-Uferprüfung mit dem gewählten Radius. Minimum=1 Maximum=7 Standard=7
        TwF_ShoreRadius = 7,
        -- Steuert die Verschiebung zu kleineren Fischen in Ufernähe.
        -- 100% (Standard) behält die Vanilla-Stärke bei. Jeder andere Wert aktiviert eine benutzerdefinierte Stärke; 0% deaktiviert die Größenverschiebung in Ufernähe. Minimum=0 Maximum=100 Standard=100
        TwF_SizeBlend = 100,
        -- 100% (Standard) behält das vollständige Vanilla-Temperaturverhalten bei. Jeder andere Wert aktiviert einen flachen Better-Fishing-Modifikator für alle Temperaturen und ersetzt die Vanilla-Temperaturkurve. Minimum=10 Maximum=200 Standard=100
        TwF_TempCoeff = 100,
        -- Nebel-Koeffizient (Prozent).
        -- 100% = Basiswert.
        -- Standard: 80%. Minimum=50 Maximum=150 Standard=80
        TwF_FogCoeff = 80,
        -- Wind-Koeffizient (Prozent).
        -- 100% = Basiswert.
        -- Standard: 80%. Minimum=50 Maximum=150 Standard=80
        TwF_WindCoeff = 80,
        -- Regen-Koeffizient (Prozent).
        -- 100% = Basiswert.
        -- Standard: 120%. Minimum=50 Maximum=200 Standard=120
        TwF_RainCoeff = 120,
        -- Startstunde des Bonus-Zeitraums (morgens).
        -- Standard: 4. Minimum=3 Maximum=6 Standard=4
        TwF_MornStart = 4,
        -- Endstunde des Bonus-Zeitraums (morgens).
        -- Standard: 6. Minimum=6 Maximum=9 Standard=6
        TwF_MornEnd = 6,
        -- Startstunde des Bonus-Zeitraums (abends).
        -- Standard: 18. Minimum=15 Maximum=18 Standard=18
        TwF_EveStart = 18,
        -- Endstunde des Bonus-Zeitraums (abends).
        -- Standard: 20. Minimum=19 Maximum=21 Standard=20
        TwF_EveEnd = 20,
        -- Fangchancen-Multiplikator während der Bonus-Zeiträume (Prozent).
        -- 100% = kein Bonus.
        -- Standard: 120%. Minimum=50 Maximum=200 Standard=120
        TwF_TimeCoeff = 120,
    },
    VanillaFishingFix = {
        -- Recalculates fish nutrition from real caught weight and preserves the total nutrition when filleting.
        EnableNutritionBalance = true,
        -- Extra calories applied after the weight-based rebalance. 0% uses the balanced values; 100% doubles them and 400% makes them x5. Standard=0% (balanced)
        -- 1 = 0% (balanced)
        -- 2 = 10%
        -- 3 = 20%
        -- 4 = 30%
        -- 5 = 40%
        -- 6 = 50%
        -- 7 = 60%
        -- 8 = 70%
        -- 9 = 80%
        -- 10 = 90%
        -- 11 = 100%
        -- 12 = 150%
        -- 13 = 200%
        -- 14 = 250%
        -- 15 = 300%
        -- 16 = 350%
        -- 17 = 400%
        CalorieBonusPreset = 1,
        -- Enables escapes, exceptional catches and the event system used by line breaks, rod breaks and double catches.
        EnableCatchEvents = true,
        -- Scales the probability of catch events, treasure and rare fish. Standard=Normal (x1)
        -- 1 = Low (x0.5)
        -- 2 = Normal (x1)
        -- 3 = High (x2)
        EventFrequency = 2,
        -- Allows high tension and heavy fish to break the fishing line. Line type and condition affect risk.
        EnableLineBreaks = true,
        -- Allows a very rare rod failure. Heavy fish and damaged rods are more dangerous.
        EnableRodBreaks = true,
        -- Adds boots, branches, cans, cordage, hooks and other vanilla junk to fishing catches.
        EnableExpandedTrash = true,
        -- Allows very rare catches such as watches, rings, old coins, tools and premium line.
        EnableTreasure = true,
        -- Makes carp, trout, catfish, pike and compatible mod fish fight with different speed, force and escape risks.
        EnableFishAI = true,
        -- Makes dawn and dusk best, morning good, midday poor and night less productive.
        EnableTimeEffects = true,
        -- Light rain helps, while storms, strong wind, heavy rain and fog reduce fishing success.
        EnableWeatherEffects = true,
        -- Long uninterrupted fishing sessions drain endurance and progressively slow reeling. Resting starts a fresh session.
        EnableFatigue = true,
        -- Hooks alter attraction, line quality alters break risk, and professional rods wear more slowly.
        EnableEquipmentEffects = true,
        -- Insects favour small fish, fresh fish bait attracts predators, meat favours catfish, and stale or rotten bait shifts catches toward scavengers and trash.
        EnableBaitQuality = true,
        -- Shows a blue-and-yellow 1-to-16-tile meter while aiming. Yellow marks the aimed distance and the blue cursor selects the cast.
        EnableCastMiniGame = true,
        -- Allows fishing from the ground and from recognized chairs or furniture. Furniture must face the water.
        EnableSeatedFishing = true,
        -- Caught fish receive an invisible Normal, Good, Excellent or Legendary quality that affects weight, nutrition, mood and value metadata.
        EnableFishQuality = true,
        -- Some thirty-tile water areas are richer. Catches still deplete vanilla abundance and double catches deplete it twice.
        EnableFishSchools = true,
        -- Allows albino, mutated, gigantic, scarred and diseased catches.
        EnableRareFish = true,
        -- Small fish barely wear rods; large and exceptional fish may remove substantially more condition.
        EnableRealisticWear = true,
        -- Tracks fish, total weight, species, records, escapes, breaks, junk, treasure and special catches per character.
        EnableStatistics = true,
        -- Awards +1 XP on a bite, +2 when control starts, +5 on capture and +10 extra for an exceptional catch.
        EnableEnhancedXP = true,
        -- Automatically balances all species registered in the Build 42 Fishing.fishes table and enables dedicated support for Yumi's Fishing Expansion.
        EnableModCompatibility = true,
    },
    B42Horticulture = {
        -- Adds 'Make Glass Pipe' recipe to 'Magazine: Murano Glass Manual'.
        LearnedRecipe = true,
    },
    BurdJournals = {
        -- Master toggle for the entire survival journals system.
        EnableJournals = true,
        -- Allow players to use personal journals for recording/recovering skills. Disable to block player-journal interactions entirely.
        EnablePlayerJournals = true,
        -- Allow crafting/restore conversion recipes for personal journals. Disable to prevent journal crafting while still allowing reading/claiming from existing player journals.
        EnablePlayerJournalCrafting = true,
        -- Allow BSJ to add crafting recipes for vanilla Notebook and Journal items. Disable to hide these recipes while keeping existing vanilla items usable.
        EnableVanillaJournalCrafting = true,
        -- Deprecated and no longer active. Existing filled journal restoration is disabled because it can create unsafe duplicate UUID and world-state edge cases. Use Spawn with Blank Player Journal instead.
        RespawnWithExistingPlayerJournal = false,
        -- Give each new character a blank player journal, including replacement characters created after death.
        SpawnWithBlankPlayerJournal = false,
        -- How journal XP recovery is handled. Full Recovery returns 100% of stored XP, while Diminishing Returns reduces repeated reads. Standard=Full Recovery (100%)
        -- 1 = Full Recovery (100%)
        -- 2 = Diminishing Returns
        XPRecoveryMode = 1,
        -- Chooses whether wear advances for each skill claim, each reading session, or independently for each recorded skill. Standard=Per Skill (Per Journal)
        -- 1 = Per Skill Claim (Journal-wide)
        -- 2 = Per Reading Session (Journal-wide)
        -- 3 = Per Skill (Per Journal)
        DiminishingTrackingMode = 3,
        -- Player journals only. Per Journal keeps each physical volume independent. Per Author Survivor links journals written by the same stable survivor. Per Author Account links every player journal written by that Steam/account identity. Loot journals are never linked. Standard=Per Journal
        -- 1 = Per Journal
        -- 2 = Per Author Survivor
        -- 3 = Per Author Account
        DiminishingScope = 1,
        -- XP percentage on first read (50-100%). Only applies with Diminishing Returns. Minimum=50 Maximum=100 Standard=100
        DiminishingFirstRead = 100,
        -- XP reduction for each subsequent read (0-50%). Minimum=0 Maximum=50 Standard=10
        DiminishingDecayRate = 10,
        -- Floor percentage that recovery cannot go below (0-50%). Minimum=0 Maximum=50 Standard=10
        DiminishingMinimum = 10,
        -- Only applies when Journal XP Mode is Diminishing Returns. Gradually restores one percentage point of journal XP readiness after the configured connected in-game time. Only living, connected play counts. Offline server time and paused solo time do not count. Time is not banked while fully ready.
        EnablePassiveDiminishingRecovery = false,
        -- Only applies with Diminishing Returns and passive recovery enabled. Connected in-game hours required to restore one percentage point of journal XP readiness. Sleep and normal time acceleration count. Minimum=0,10 Maximum=168,00 Standard=24,00
        DiminishingRecoveryHoursPerPercent = 24.0,
        -- Only applies when Journal XP Mode is Diminishing Returns. Adds Maintain Journal for player-journal entries with reduced readiness. Requires a reusable needle, one thread use, and one ripped sheet, denim strip, or leather strip. Maintenance restores the linked diminishing-returns history, not only the selected physical copy.
        EnableManualDiminishingRecovery = false,
        -- Only applies with Diminishing Returns and journal maintenance enabled. Percentage points of journal XP readiness restored by one completed Maintain Journal action. Minimum=1 Maximum=100 Standard=10
        DiminishingMaintenancePercent = 10,
        -- Require a pen or pencil to log skills in a clean journal.
        RequirePenToWrite = true,
        -- Pen durability consumed when logging skills (1-10). Minimum=1 Maximum=10 Standard=1
        PenUsesPerLog = 1,
        -- Require an eraser to wipe clean journal contents.
        RequireEraserToErase = true,
        -- When enabled, erasing/restoring and re-writing a journal keeps diminishing-returns read progress instead of resetting it.
        PersistDROnErase = false,
        -- When enabled, journals only record XP earned through gameplay - not profession starting bonuses or trait skill boosts. This prevents exploits where players farm profession skills by creating multiple characters. Recommended ON for multiplayer servers.
        EnableBaselineRestriction = true,
        -- When Only Record Earned Progress is enabled, this controls how player journals are recorded. Strict Earned Only excludes starting data. Legacy Full Current Data records everything. Vested Starting XP lets each eligible skill XP earned after spawning unlock one matching point of that skill's starting XP. Starting traits and recipes stay excluded. Ignored when Only Record Earned Progress is disabled. Standard=Strict Earned Only (Recommended)
        -- 1 = Strict Earned Only (Recommended)
        -- 2 = Legacy Full Current Data
        -- 3 = Vested Starting XP (1:1 Earned Match)
        BaselineRecordingMode = 2,
        -- Allows player journals to include TV/VHS skill XP. Claimed journal entries mark their recorded media lines as watched to prevent double-dipping.
        AllowVhsSkillRecording = true,
        -- Controls how the learning time for each skill is calculated. Flat uses one base time per skill. Level Progress charges for the levels and partial levels actually recovered. Total XP charges from the skill's own XP curve, similar to LG Skill Journal. Standard=Flat Per Skill (Legacy)
        -- 1 = Flat Per Skill (Legacy)
        -- 2 = Recovered Level Progress
        -- 3 = Recoverable Total XP (LG-style)
        SkillLearningTimeScaling = 1,
        -- Base time in seconds to learn each skill from a journal. Simulates reading/studying. Minimum=0,50 Maximum=30,00 Standard=4,00
        LearningTimePerSkill = 4.0,
        -- When enabled, Fitness/Strength can be recorded and claimed from player journals. When disabled, passive skill entries are hidden but preserved.
        EnablePassiveSkillsPlayer = true,
        -- Allow players to record traits in their personal journals. When disabled, the traits tab will be hidden in player journals and existing traits will be preserved but inaccessible.
        EnableTraitRecordingPlayer = true,
        -- Base time in seconds to absorb each trait from a journal. Minimum=1,00 Maximum=60,00 Standard=5,00
        LearningTimePerTrait = 5.0,
        -- Allow players to record magazine-learned recipes in their personal journals. When disabled, the recipes tab will be hidden and existing recipes will be preserved but inaccessible.
        EnableRecipeRecordingPlayer = true,
        -- Base time in seconds to learn each recipe from a journal. Minimum=0,50 Maximum=30,00 Standard=5,00
        LearningTimePerRecipe = 5.0,
        -- Master toggle for recording player stats (kills, survival time, etc.) in personal journals.
        EnableStatRecording = true,
        -- Allow players to record their zombie kill count in journals.
        RecordZombieKills = true,
        -- Allow players to record their survival time in journals.
        RecordHoursSurvived = true,
        -- Allow players to build customizable note pages in personal journals. Existing notes remain readable when this is disabled.
        EnablePlayerJournalNotes = true,
        -- Maximum number of writable note pages in a personal journal. Higher limits allow longer roleplay notes but increase saved journal payload size. Minimum=1 Maximum=100 Standard=30
        PlayerJournalNotesMaxPages = 30,
        -- Maximum characters allowed on each personal journal note page. Longer pages increase saved journal payload size. Minimum=250 Maximum=8000 Standard=2000
        PlayerJournalNotesMaxCharsPerPage = 2000,
        -- Require a carried pen, pencil, marker, or other vanilla writing tool to add or change note blocks. The tool determines the available ink colors.
        RequireWritingToolForPlayerJournalNotes = true,
        -- Require a carried eraser or vanilla eraser-tagged item to remove note blocks, list items, or pages.
        RequireEraserForPlayerJournalNoteDeletion = true,
        -- Global multiplier for all learning times. 0.5 = twice as fast, 2.0 = twice as slow. Minimum=0,10 Maximum=5,00 Standard=1,00
        LearningTimeMultiplier = 1.0,
        -- Maximum number of skills that can be recorded in a single journal. Set to 0 for unlimited. Vanilla game has ~30 skills. Minimum=0 Maximum=500 Standard=0
        MaxSkillsPerJournal = 0,
        -- Maximum number of traits that can be recorded in a single journal. Set to 0 for unlimited. Vanilla game has ~50 grantable traits. Minimum=0 Maximum=500 Standard=0
        MaxTraitsPerJournal = 0,
        -- Maximum number of recipes that can be recorded in a single journal. Set to 0 for unlimited. Heavily modded games can have 400+ magazine recipes. Minimum=0 Maximum=10000 Standard=0
        MaxRecipesPerJournal = 0,
        -- Multiplier for XP gained from journals (0.25 = 25%, 1.0 = 100%, 2.0 = 200%). Applies to both worn and bloody journals. Minimum=0,10 Maximum=10,00 Standard=1,00
        JournalXPMultiplier = 1.0,
        -- When enabled, Fitness/Strength can appear and be claimed on worn/bloody journals. When disabled, passive skill entries are hidden but preserved.
        EnablePassiveSkillsLoot = true,
        -- When enabled, discovered worn, bloody, and cursed loot journals dissolve after the selected number of in-game days.
        EnableLootJournalExpiration = true,
        -- In-game days after a survivor first discovers a loot journal before its notes fade and it dissolves. Minimum=1 Maximum=365 Standard=30
        LootJournalExpirationDays = 30,
        -- Allow worn journals to spawn in world containers (shelves, desks, cabinets). These offer light XP rewards.
        EnableWornJournalSpawns = true,
        -- Chance for worn journals to appear in world containers (0.1-100%). Minimum=0,10 Maximum=100,00 Standard=1,00
        WornJournalSpawnChance = 1.0,
        -- Minimum skills in world-found worn journals. Minimum=1 Maximum=5 Standard=1
        WornJournalMinSkills = 1,
        -- Maximum skills in world-found worn journals. Minimum=1 Maximum=5 Standard=2
        WornJournalMaxSkills = 2,
        -- Minimum XP per skill in worn journals. Minimum=10 Maximum=200 Standard=25
        WornJournalMinXP = 25,
        -- Maximum XP per skill in worn journals. Minimum=25 Maximum=500 Standard=75
        WornJournalMaxXP = 75,
        -- When enabled, recipes can be claimed from worn journals. When disabled, recipes tab will be hidden on worn journals but existing recipe data is preserved for when re-enabled.
        EnableWornJournalRecipes = true,
        -- Chance for worn journals to spawn with recipes (0-100%). Set to 0% to prevent recipes from spawning on new journals. Worn journals have a lower chance than bloody. Minimum=0 Maximum=100 Standard=15
        WornJournalRecipeChance = 15,
        -- Maximum number of magazine recipes that can spawn on a single worn journal (1-5). Minimum=1 Maximum=5 Standard=1
        WornJournalMaxRecipes = 1,
        -- Chance for a newly generated worn journal to contain a point-of-interest map segment. Minimum=0 Maximum=100 Standard=8
        WornJournalMapSegmentChance = 8,
        -- Maximum point-of-interest map segments generated in a worn journal. Minimum=1 Maximum=5 Standard=1
        WornJournalMaxMapSegments = 1,
        -- When enabled, traits can be claimed from worn journals. When disabled, traits tab will be hidden on worn journals but existing trait data is preserved for when re-enabled.
        EnableWornJournalTraits = true,
        -- Chance for worn journals to spawn with traits (0-100%). Set to 0% (default) for classic behavior where only bloody journals have traits. Minimum=0 Maximum=100 Standard=0
        WornJournalTraitChance = 0,
        -- Minimum number of traits that can spawn on a worn journal when traits roll succeeds (1-5). Minimum=1 Maximum=5 Standard=1
        WornJournalMinTraits = 1,
        -- Maximum number of traits that can spawn on a worn journal (1-5). Minimum=1 Maximum=5 Standard=1
        WornJournalMaxTraits = 1,
        -- When enabled, worn journals may spawn with a claimable forget slot.
        EnableWornJournalForgetSlot = true,
        -- Chance for worn journals to include a special forget slot when worn forget slots are enabled. Minimum=0 Maximum=100 Standard=1
        WornJournalForgetChance = 1,
        -- Allow newly spawned loot journals to sometimes include read-only generated lore notes. Existing discovered journals are not retroactively given notes.
        EnableLootJournalNotes = true,
        -- Chance for newly spawned worn journals to include a generated read-only note page. Minimum=0 Maximum=100 Standard=35
        WornJournalNoteChance = 35,
        -- Allow zombies to drop bloody journals. These offer better rewards and rare traits.
        EnableBloodyJournalSpawns = true,
        -- Chance for a zombie to drop a bloody journal (0.1-100%). Minimum=0,10 Maximum=100,00 Standard=0,30
        BloodyJournalSpawnChance = 0.3,
        -- Minimum skills in zombie-dropped bloody journals. Minimum=1 Maximum=5 Standard=2
        BloodyJournalMinSkills = 2,
        -- Maximum skills in zombie-dropped bloody journals. Minimum=2 Maximum=10 Standard=4
        BloodyJournalMaxSkills = 4,
        -- Minimum XP per skill in bloody journals. Minimum=25 Maximum=500 Standard=50
        BloodyJournalMinXP = 50,
        -- Maximum XP per skill in bloody journals. Minimum=50 Maximum=1000 Standard=150
        BloodyJournalMaxXP = 150,
        -- When enabled, traits can be claimed from bloody journals. When disabled, traits tab will be hidden on bloody journals but existing trait data is preserved for when re-enabled.
        EnableBloodyJournalTraits = true,
        -- Chance for bloody journals to spawn with traits (0-100%). Set to 0% to prevent traits from spawning on new journals. Minimum=0 Maximum=100 Standard=15
        BloodyJournalTraitChance = 15,
        -- Maximum number of traits that can spawn on a single bloody journal (0-5). Minimum=0 Maximum=5 Standard=2
        BloodyJournalMaxTraits = 2,
        -- When enabled, bloody journals may spawn with a claimable forget slot.
        EnableBloodyJournalForgetSlot = true,
        -- Chance for bloody journals to include a special forget slot when bloody forget slots are enabled. Minimum=0 Maximum=100 Standard=3
        BloodyJournalForgetChance = 3,
        -- When enabled, recipes can be claimed from bloody journals. When disabled, recipes tab will be hidden on bloody journals but existing recipe data is preserved for when re-enabled.
        EnableBloodyJournalRecipes = true,
        -- Chance for bloody journals to spawn with recipes (0-100%). Set to 0% to prevent recipes from spawning on new journals. Bloody journals have a higher chance than worn. Minimum=0 Maximum=100 Standard=60
        BloodyJournalRecipeChance = 60,
        -- Maximum number of magazine recipes that can spawn on a single bloody journal (1-5). Minimum=1 Maximum=5 Standard=3
        BloodyJournalMaxRecipes = 3,
        -- Chance for a newly generated bloody journal to contain a point-of-interest map segment. Minimum=0 Maximum=100 Standard=18
        BloodyJournalMapSegmentChance = 18,
        -- Maximum point-of-interest map segments generated in a bloody journal. Minimum=1 Maximum=5 Standard=2
        BloodyJournalMaxMapSegments = 2,
        -- Chance for newly spawned bloody journals to include a generated read-only note page. Minimum=0 Maximum=100 Standard=50
        BloodyJournalNoteChance = 50,
        -- Master toggle for fun loot journals. When disabled, cursed and Yuletide journal spawns and seasonal fun-journal hooks are turned off.
        EnableLootJournalsFun = true,
        -- Allow zombies to rarely drop dormant cursed journals. The first opener is cursed, then the journal becomes a richer bloody reward.
        EnableCursedJournalSpawns = true,
        -- When enabled, cursed zombie drops appear as ordinary bloody journals until first open. The curse springs immediately on that first open instead of showing a sealed warning prompt.
        DisguiseCursedJournalsAsBloody = false,
        -- Chance for a zombie to drop a cursed journal (0-100%). If this rolls, normal bloody drop is skipped for that zombie. Minimum=0,00 Maximum=100,00 Standard=0,08
        CursedJournalSpawnChance = 0.08,
        -- Minimum skills generated on a cursed reward journal. Minimum=1 Maximum=10 Standard=2
        CursedJournalMinSkills = 2,
        -- Maximum skills generated on a cursed reward journal. Minimum=1 Maximum=10 Standard=5
        CursedJournalMaxSkills = 5,
        -- Minimum XP per skill on a cursed reward journal. Minimum=1 Maximum=5000 Standard=75
        CursedJournalMinXP = 75,
        -- Maximum XP per skill on a cursed reward journal. Minimum=1 Maximum=5000 Standard=300
        CursedJournalMaxXP = 300,
        -- When enabled, cursed reward journals can generate and allow trait claims.
        EnableCursedJournalTraits = true,
        -- Chance for cursed reward journals to include traits (0-100%). Minimum=0 Maximum=100 Standard=40
        CursedJournalTraitChance = 40,
        -- Minimum traits generated on cursed reward journals when trait roll succeeds. Minimum=1 Maximum=5 Standard=1
        CursedJournalMinTraits = 1,
        -- Maximum traits generated on cursed reward journals. Minimum=1 Maximum=5 Standard=3
        CursedJournalMaxTraits = 3,
        -- When enabled, cursed reward journals can generate and allow recipe claims.
        EnableCursedJournalRecipes = true,
        -- Chance for cursed reward journals to include recipes (0-100%). Minimum=0 Maximum=100 Standard=60
        CursedJournalRecipeChance = 60,
        -- Maximum recipes generated on cursed reward journals. Minimum=1 Maximum=5 Standard=3
        CursedJournalMaxRecipes = 3,
        -- Chance for a revealed cursed journal to contain a point-of-interest map segment. Minimum=0 Maximum=100 Standard=30
        CursedJournalMapSegmentChance = 30,
        -- Maximum point-of-interest map segments generated in a cursed journal. Minimum=1 Maximum=5 Standard=2
        CursedJournalMaxMapSegments = 2,
        -- When enabled, cursed reward journals may generate a claimable forget slot.
        EnableCursedJournalForgetSlot = true,
        -- Chance for cursed reward journals to include a forget slot when cursed forget slots are enabled. Minimum=0 Maximum=100 Standard=25
        CursedJournalForgetChance = 25,
        -- Relative weight for the softer cursed penalty that adds a negative trait. Higher values make it more likely when a cursed journal opens. Minimum=0 Maximum=200 Standard=90
        CursedJournalNegativeTraitCurseWeight = 90,
        -- Relative weight for the severe cursed penalty that removes a positive trait. Lower values make this punishment rarer. Minimum=0 Maximum=200 Standard=12
        CursedJournalLosePositiveTraitCurseWeight = 12,
        -- Relative weight for the severe cursed penalty that removes a skill level. Lower values make this punishment rarer. Minimum=0 Maximum=200 Standard=10
        CursedJournalLoseSkillCurseWeight = 10,
        -- After a recent severe curse, this is the percent of normal chance retained by severe penalties like losing positive traits or skill levels. Set to 0 to nearly hard-lock repeats, or 100 to disable this cooldown. Minimum=0 Maximum=100 Standard=4
        CursedJournalSevereRepeatChancePercent = 4,
        -- How long recent severe cursed penalties continue suppressing more severe repeats for the same player. Set to 0 to disable the repeat window. Minimum=0 Maximum=336 Standard=72
        CursedJournalSevereCooldownHours = 72,
        -- When a cursed journal inflicts a persistent or severe penalty, guarantee a forget slot and (for severe curses) richer skill rewards to keep opening worthwhile.
        CursedJournalSeverityCompensation = true,
        -- Extra percent of skill XP granted by a cursed reward journal when the applied curse was severe. Only applies when Cursed Severity Compensation is enabled. Minimum=0 Maximum=200 Standard=50
        CursedJournalSevereRewardBonusPercent = 50,
        -- When enabled, cursed journals older than the expiration age open safely without applying a curse.
        EnableCursedJournalExpiration = true,
        -- In-game days before a cursed journal's curse goes dormant. Expired cursed journals still open into bloody reward journals, but no curse fires. Minimum=1 Maximum=365 Standard=30
        CursedJournalExpirationDays = 30,
        -- Allows perceptive survivors to notice disguised cursed journals and read escalating Hint, Aware, and Exact curse warnings from Cat's Eyes, Foraging, Herbalist, and fieldcraft backgrounds.
        EnableCursedJournalInsight = true,
        -- Foraging level for Hint insight, letting survivors notice hidden-cursed journals. Cat's Eyes and fieldcraft traits can also reveal suspicious journals. Minimum=0 Maximum=10 Standard=4
        CursedJournalInsightRevealForagingLevel = 4,
        -- Foraging level that, with Cat's Eyes, Herbalist, or Park Ranger fieldcraft, gives Aware insight and reveals the curse's broad omen category. Minimum=0 Maximum=10 Standard=6
        CursedJournalInsightOmenForagingLevel = 6,
        -- Foraging level used for exact curse insight when exact effect insight is enabled. Minimum=0 Maximum=10 Standard=8
        CursedJournalInsightExactForagingLevel = 8,
        -- When enabled, survivors meeting the Exact insight threshold can identify the specific curse effect in item hover tooltips and Breaking the Seal confirmation prompts.
        CursedJournalInsightExactEffect = false,
        -- Chance for newly spawned cursed reward journals to include a generated read-only occult note page. Minimum=0 Maximum=100 Standard=75
        CursedJournalNoteChance = 75,
        -- Allow seasonal Yuletide journals to replace some worn and bloody journals when the Yuletide season is active.
        EnableYuletideJournalSpawns = true,
        -- Controls when Yuletide journal replacements are active. Choose the in-game calendar, the host/server real-world month, either December source, or year-round activation. Standard=Only December (In-Game)
        -- 1 = Only December (In-Game)
        -- 2 = Either December (In-Game or IRL Host Month)
        -- 3 = Only December (IRL Host Month)
        -- 4 = Any Time
        YuletideSeasonMode = 1,
        -- Controls when newly spawned cursed journals use Krampus as their author identity. This is separate from Yuletide journal spawn timing. Standard=During Yuletide Season (Default)
        -- 1 = During Yuletide Season (Default)
        -- 2 = Only December (In-Game)
        -- 3 = Only December (IRL Host Month)
        -- 4 = Never
        EnableYuletideKrampusCursedAuthors = 1,
        -- Chance for an eligible worn journal world spawn to become a wrapped Yuletide journal during the active season. Minimum=0,00 Maximum=100,00 Standard=8,00
        YuletideWornReplacementChance = 8.0,
        -- Chance for an eligible bloody zombie drop to become a wrapped Yuletide journal during the active season after cursed roll precedence is checked. Minimum=0,00 Maximum=100,00 Standard=4,00
        YuletideBloodyReplacementChance = 4.0,
        -- Minimum skills generated on unwrapped Yuletide journals. Minimum=1 Maximum=10 Standard=2
        YuletideJournalMinSkills = 2,
        -- Maximum skills generated on unwrapped Yuletide journals. Minimum=1 Maximum=10 Standard=5
        YuletideJournalMaxSkills = 5,
        -- Minimum XP per skill generated on Yuletide journals. Minimum=1 Maximum=5000 Standard=75
        YuletideJournalMinXP = 75,
        -- Maximum XP per skill generated on Yuletide journals. Minimum=1 Maximum=5000 Standard=300
        YuletideJournalMaxXP = 300,
        -- When enabled, Yuletide journals can include claimable traits.
        EnableYuletideJournalTraits = true,
        -- Chance for a Yuletide journal to include traits. Minimum=0 Maximum=100 Standard=40
        YuletideJournalTraitChance = 40,
        -- Minimum traits generated on Yuletide journals when trait roll succeeds. Minimum=1 Maximum=5 Standard=1
        YuletideJournalMinTraits = 1,
        -- Maximum traits generated on Yuletide journals. Minimum=1 Maximum=5 Standard=3
        YuletideJournalMaxTraits = 3,
        -- When enabled, Yuletide journals can include claimable recipes.
        EnableYuletideJournalRecipes = true,
        -- Chance for a Yuletide journal to include recipes. Minimum=0 Maximum=100 Standard=60
        YuletideJournalRecipeChance = 60,
        -- Maximum recipes generated on Yuletide journals. Minimum=1 Maximum=5 Standard=3
        YuletideJournalMaxRecipes = 3,
        -- Chance for a Yuletide journal to contain a point-of-interest map segment. Minimum=0 Maximum=100 Standard=25
        YuletideJournalMapSegmentChance = 25,
        -- Maximum point-of-interest map segments generated in a Yuletide journal. Minimum=1 Maximum=5 Standard=2
        YuletideJournalMaxMapSegments = 2,
        -- Chance for newly spawned Yuletide journals to include a generated read-only holiday note page. Minimum=0 Maximum=100 Standard=75
        YuletideJournalNoteChance = 75,
        -- Allow Yuletide journals to roll the forget-slot reward.
        EnableYuletideJournalForgetSlot = true,
        -- Chance for Yuletide journals to include a forget slot when Yuletide forget slots are enabled. Minimum=0 Maximum=100 Standard=25
        YuletideJournalForgetChance = 25,
        -- Relative weight for practical bundled gift rolls. Minimum=0 Maximum=100 Standard=70
        YuletideGiftPracticalWeight = 70,
        -- Relative weight for rare bundled gift rolls. Minimum=0 Maximum=100 Standard=25
        YuletideGiftRareWeight = 25,
        -- Relative weight for jackpot bundled gift rolls. Minimum=0 Maximum=100 Standard=5
        YuletideGiftJackpotWeight = 5,
        -- Minimum immediate physical gift items granted when a Yuletide journal is unwrapped. Minimum=1 Maximum=10 Standard=1
        YuletideGiftMinItems = 1,
        -- Maximum immediate physical gift items granted when a Yuletide journal is unwrapped. Minimum=1 Maximum=10 Standard=2
        YuletideGiftMaxItems = 2,
        -- When enabled, worn, bloody, cursed, and Yuletide journals allow only a limited number of successful rewards. Already-known or blocked claims do not consume the limit. With per-player loot claims, the limit applies separately to each survivor and the journal does not dissolve.
        EnableLimitedClaimLootJournals = false,
        -- When enabled, each survivor gets a separate claim history for worn, bloody, cursed, and Yuletide journals. If limited claims are also enabled, the limit applies separately to each survivor and locks only that survivor's remaining rewards. The journal never dissolves from claims while this setting is active. Default: Off
        EnablePerPlayerLootJournalClaims = false,
        -- Maximum successful rewards one survivor can claim from one eligible loot journal. The journal normally dissolves at the limit. With per-player loot claims, only that survivor's remaining rewards lock and the journal stays. Only applies when limited-claim loot journals are enabled. Default: 1 Minimum=1 Maximum=25 Standard=1
        LootJournalMaxClaimsBeforeDissolve = 1,
        -- When enabled, skill book XP multipliers (from reading skill books) will apply to XP absorbed from Worn and Bloody journals ONLY. Player Journals are not affected. The multiplier is capped by the setting below.
        SkillBookMultiplierForJournals = true,
        -- Maximum XP multiplier from skill books when absorbing skills from Worn and Bloody journals. Default 2x prevents overpowered early-game progression. Set to 16 to allow full skill book multipliers. Does not affect Player Journals. Minimum=1,00 Maximum=16,00 Standard=2,00
        SkillBookMultiplierCap = 2.0,
        -- When enabled, opening journals and reading/writing journal actions require enough light, following vanilla reading darkness rules.
        RequireLightForJournalUse = true,
        -- Higher reading skill levels reduce learning time when absorbing from journals.
        ReadingSkillAffectsSpeed = true,
        -- Speed bonus per reading skill level (0.1 = 10% faster per level, max 100% at level 10). Minimum=0,00 Maximum=0,50 Standard=0,10
        ReadingSpeedBonus = 0.1,
        -- Time in seconds to erase a journal's contents. Minimum=1,00 Maximum=60,00 Standard=10,00
        EraseTime = 10.0,
        -- Time in seconds to convert a worn journal to a clean journal. Minimum=5,00 Maximum=120,00 Standard=15,00
        ConvertTime = 15.0,
        -- Allows animated journal backgrounds and future animated journal effects in the UI. Disable this to keep journal visuals static.
        EnableAnimatedJournalVisuals = true,
        -- How many entries a journal tab can show on one page before pagination appears. Lower values reduce UI load but split long lists into more pages. Minimum=10 Maximum=200 Standard=50
        JournalUIPaginationThreshold = 50,
        -- If enabled, other players can open and view personal journals they didn't create. If disabled, only the journal's author can open it.
        AllowOthersToOpenJournals = true,
        -- If enabled, other players can claim skills/traits from personal journals they didn't create. Requires 'Allow Others to Open' to be enabled. If disabled, only the author can claim from their own journals.
        AllowOthersToClaimFromJournals = true,
        -- If enabled, journal owners can let other players record progress and edit Notes. This does not allow renaming, erasing recorded progress, or changing access.
        AllowOthersToWriteInJournals = false,
        -- Let journal owners make an individual journal more private than the server-wide sharing rules. Individual journals can never grant access the server has disabled.
        AllowPerJournalSharingControls = true,
        -- Let journal owners approve specific readers, writers, and claimers. Player lists cannot grant a permission disabled by the server.
        AllowJournalAccessWhitelists = true,
        -- If enabled, negative traits (like Clumsy, Slow Learner, etc.) can appear in journals and be recorded. Useful for modded traits or challenge runs. Default: OFF (only positive traits).
        AllowNegativeTraits = false,
        -- If enabled, journals will not record or grant traits automatically managed by Fitness, Strength, or body weight changes: Unfit, Out of Shape, Fit, Athletic, Puny, Weak, Feeble, Stout, Strong, Overweight, Obese, Underweight, Very Underweight, and Emaciated. Default: ON.
        ExcludePassiveSkillRelatedTraits = true,
        -- Controls whether 'Restored' journals (player journals created from worn/bloody blanks) dissolve after all contents are claimed. Restored journals always display their origin status. Default: OFF (restored journals persist forever like clean journals).
        AllowPlayerJournalDissolution = false,
        -- When claiming a trait that conflicts with one you already have, the conflicting trait is automatically removed.
        AllowMutualExclusionCancellation = true,
        -- When enabled, BSJ stores SteamID-anchored baseline snapshots for admin recovery and rollback safety.
        EnableBaselineSnapshots = true,
        -- Maximum baseline snapshots kept per SteamID before old entries are pruned. Active snapshots are preserved. Minimum=1 Maximum=500 Standard=5
        BaselineSnapshotsPerSteamLimit = 5,
        -- Automatically captures snapshots when baseline data is registered, recovered, or debug-edited.
        BaselineSnapshotsAutoCapture = true,
        -- When enabled, baseline snapshot lineage is finalized with death metadata during death cleanup.
        BaselineSnapshotsCaptureOnDeath = true,
        -- Legacy safety mode. When enabled, applying a snapshot sets debugModified=true (requires manual unlock). Default is OFF for canon restore flow.
        BaselineSnapshotsProtectOnRestore = false,
        -- How many skills/traits/recipes to record in a single action when using 'Record All' or 'Record Tab'. Higher values complete faster but can cause heavy multiplayer/server desync on busy servers. Set to 1 for classic one-at-a-time behavior. Default: 15 Minimum=1 Maximum=50 Standard=15
        RecordBatchSize = 15,
        -- How many skills/traits/recipes to absorb in a single action when using 'Absorb All'. Higher values complete faster but can cause heavy multiplayer/server desync on busy servers. Set to 1 for classic one-at-a-time behavior. Default: 15 Minimum=1 Maximum=50 Standard=15
        AbsorbBatchSize = 15,
        -- Multiplier for batch action duration. Lower = faster batches. Example: 15 recipes at 0.8s each = 12s normally. With 0.25 multiplier = 3s. Only affects 'Record All' and 'Absorb All', not individual clicks. Default: 0.25 (4x faster) Minimum=0,10 Maximum=1,00 Standard=0,25
        BatchTimeMultiplier = 0.25,
        -- Compatibility toggle for Traits Purchase System (Mod ID: TraitsPurchaseSystem). When disabled (default), its trait-currency skills (Traits/Traits1/Traits2/Traits3) are hidden from journal recording and claiming, while existing data remains preserved.
        AllowTraitPurchaseSkillRecording = false,
        -- Compatibility toggle for Adaptive Traits (Mod ID: AdaptiveTraits). When disabled (default), AdaptiveTraits-managed traits are hidden from player journal recording and claiming while existing journal data is preserved.
        AllowAdaptiveTraitsManagedTraitRecording = false,
        -- Compatibility toggle for Evolving Traits World (Mod ID: EvolvingTraitsWorld). When disabled (default), ETW-managed traits are hidden from player journal recording and claiming while existing journal data is preserved.
        AllowEvolvingTraitsWorldManagedTraitRecording = false,
        -- Compatibility toggle for Evolving Traits World (Mod ID: EvolvingTraitsWorld). When disabled (default), ETW-managed traits are excluded from newly generated worn, bloody, cursed, and yuletide journals while existing journal data is preserved.
        AllowEvolvingTraitsWorldManagedTraitLootGeneration = false,
        -- Allow clean blank and filled player journals to be painted with vanilla paint buckets and washed clean with water or a completed washing-machine cycle.
        EnableJournalCoverPainting = true,
        -- Compatibility toggle for Lifestyle: Hobbies (Mod ID: LifestyleHobbies). When disabled (default), music like/dislike traits are excluded from recording, claiming, and loot journals to prevent stacked or conflicting preferences. Enabling this also consolidates restored preferences to one like and one dislike.
        AllowLifestyleMusicPreferenceTraitRecording = false,
        -- Compatibility toggle for Lifestyle: Hobbies. When disabled (default), traits that Lifestyle awards or removes from skill progression are excluded from recording, claiming, and loot journals. Restore the Lifestyle skill XP and let Lifestyle recalculate these traits. Enable only if you want journals to control the traits directly.
        AllowLifestyleManagedTraitRecording = false,
        -- Master switch for BSJ debug commands and menus. The game's -debug launch flag does not enable them. Multiplayer access is controlled separately below.
        AllowDebugCommands = false,
        -- Controls which multiplayer roles may use BSJ debug commands when enabled. Single-player remains available to the local player. Standard=Admins Only
        -- 1 = Admins Only
        -- 2 = Admins and Staff
        -- 3 = All Players
        DebugCommandAccessLevel = 1,
        -- Allow player journals to record traits managed by Dynamic Traits and Expanded Moodles. Claims use the mod server hooks. Dynamic progression counters are not restored. Build 42.15+ only.
        AllowDynamicTraitsManagedTraitRecording = false,
        -- Allow player journals to record traits managed by the legacy More Traits Dynamic submod. Progression counters are not restored. Prepared starting-item rewards remain excluded.
        AllowMoreTraitsDynamicManagedTraitRecording = false,
    },
    GydeTraitMags = {
        -- Erlaubt es, die positive Version einer Eigenschaft zu erhalten, wenn der Charakter mit der negativen Version gestartet ist (z. B. Sonntagsfahrer → Geschwindigkeitsdämon).
        -- 
        -- Wenn diese Option zusammen mit „Verbrauchbare Magazine“ aktiviert ist, werden 2 Magazine benötigt, um von einer negativen zu einer positiven Eigenschaft zu wechseln.
        NegativeToPositive = false,
        -- Durch das Lesen eines Eigenschaftsmagazins wird die zugehörige Eigenschaft entfernt, falls der Spieler sie besitzt.
        ReadRemove = false,
        -- Wenn diese Option aktiviert ist, werden Zeitschriften nur einmal verwendet. Wenn Sie ein Magazin lesen, wird der Gegenstand verbraucht und aus Ihrem Inventar entfernt.
        ReadDelete = false,
        -- Anzahl der Tage, bevor Eigenschaftsmagazine gelesen werden können, Höchstwert ist 1 Jahr. Minimum=0 Maximum=8766 Standard=0
        DaysBeforeRead = 0,
        -- Ändern Sie die Häufigkeit des Spawns von Magazinen. Weitere Informationen finden Sie auf der Workshop-Seite. Standard=Standard
        -- 1 = Sehr niedrig
        -- 2 = Niedrig
        -- 3 = Standard
        -- 4 = Hoch
        -- 5 = Sehr Hoch
        SpawnRate = 3,
        -- Deaktivieren, um zu verhindern, dass das Speed Demon-Magazin im Spiel spawnen kann.
        -- 
        -- Eigenschaftbeschreibung:
        -- 200% Schaltgeschwindigkeit, 115% Höchstgeschwindigkeit für alle Fahrzeuge.
        SpawnSpeedDemon = true,
        -- Deaktivieren, um zu verhindern, dass das Ernährungsberater-Magazin im Spiel spawnen kann.
        -- 
        -- Eigenschaftsbeschreibung:
        -- Ermöglicht es dem Spieler, die Nährwerte aller Lebensmittel zu sehen, auch solcher, die nicht verpackt sind.
        SpawnNutritionist = true,
        -- Deaktivieren, um zu verhindern, dass das organisierte Magazin im Spiel spawnen kann.
        -- 
        -- Eigenschaftsbeschreibung:
        -- 130% Kapazität für alle Container, einschließlich Kisten, Schränke und Autos.
        SpawnOrganized = true,
        -- Deaktivieren, um zu verhindern, dass das Outdoorsman-Magazin im Spiel spawnen kann.
        -- 
        -- Traitbeschreibung:
        -- 10% Chance, sich zu erkälten. 1% oder 1,25% Chance, beim Gehen oder Laufen durch Bäume einen Kratzer/eine Schürfwunde zu bekommen. Schnelleres Anzünden von Lagerfeuern mit Kerbholz.
        SpawnOutdoorsman = true,
        -- Deaktivieren, um zu verhindern, dass das Fast-Reader-Magazin im Spiel spawnen kann.
        -- 
        -- Eigenschaftsbeschreibung:
        -- 130% Lesegeschwindigkeit.
        SpawnFastReader = true,
        -- Deaktivieren, um zu verhindern, dass das Magazin „Schneller Lerner“ im Spiel spawnen kann.
        -- 
        -- Traitbeschreibung:
        -- 130% XP für alle Fertigkeiten außer Stärke und Fitness.
        SpawnFastLearner = true,
        -- Deaktivieren, um zu verhindern, dass das Handy-Magazin im Spiel spawnen kann.
        -- 
        -- Traitbeschreibung:
        -- +100HP für alle Konstruktionen.
        -- Erhöht die Baugeschwindigkeit (~11%).
        SpawnHandy = true,
        -- Deaktivieren, um zu verhindern, dass das Axtmann-Magazin im Spiel spawnen kann.
        -- 
        -- Eigenschaftsbeschreibung:
        -- Schwingt Äxte 25% schneller (Kampf und Baumhacken).
        SpawnAxeMan = true,
        -- Deaktivieren, um zu verhindern, dass Einbrechermagazine im Spiel spawnen.
        -- 
        -- Eigenschaftsbeschreibung:
        -- Kann Fahrzeuge kurzschließen und hat eine geringere Chance, das Schloss eines gewaltsam geöffneten Fensters aufzubrechen.
        SpawnBurglar = true,
        -- Deaktivieren, um zu verhindern, dass ein anmutiges Magazin im Spiel spawnen kann.
        -- 
        -- Eigenschaftsbeschreibung:
        -- 60% Geräuschradius für Schritte.
        -- 90% Chance zu stolpern, wenn man beim Laufen/Sprinten einen niedrigen Zaun überspringt oder sich an Zombies vorbeischleicht.
        SpawnGraceful = true,
        -- Deaktivieren, um zu verhindern, dass das Gewandt-Magazin im Spiel spawnen kann.
        -- 
        -- Trait-Beschreibung:
        -- 50% Inventarübertragungszeit.
        SpawnDextrous = true,
        -- Deaktivieren, um zu verhindern, dass unauffällige Magazine im Spiel spawnen.
        -- 
        -- Eigenschaftsbeschreibung:
        -- 50% Chance, von Zombies entdeckt zu werden.
        SpawnInconspicuous = true,
        -- Deaktivieren, um zu verhindern, dass Gutes Hörvermögen Magazine im Spiel spawnen.
        -- 
        -- Traitbeschreibung:
        -- 200% Wahrnehmungsradius. Zombies, die sich von hinten nähern, werden viel früher sichtbar.
        SpawnKeenHearing = true,
    },
    NeuroRadio = {
        -- Turns Aftermath Radio broadcasts on or off.
        Enabled = true,
        -- Radio frequency as MHz x 1000. Default 101800 means 101.8 MHz. Minimum=200 Maximum=1000000 Standard=101800
        Frequency = 101800,
        -- In-game minutes after world start before the first possible broadcast. Minimum=0 Maximum=1440 Standard=5
        StartDelayMinutes = 5,
        -- Minimum in-game minutes between Louisville Relay broadcasts. Minimum=1 Maximum=10080 Standard=20
        MinIntervalMinutes = 20,
        -- Maximum in-game minutes between Louisville Relay broadcasts. Minimum=1 Maximum=10080 Standard=60
        MaxIntervalMinutes = 60,
        -- How many text-pack entries can be sent in one broadcast. Serial arcs still play as coherent episodes. Minimum=1 Maximum=5 Standard=1
        MaxLinesPerBroadcast = 1,
        -- In-game minutes before the same listener can receive another XP or mood effect. Does not change how often broadcasts air. Minimum=0 Maximum=1440 Standard=10
        ListenCooldownMinutes = 10,
        -- Scales only positive unhappiness effects from broadcasts. 50 means half depression. Relief messages, panic, boredom, and XP are not reduced. Minimum=0 Maximum=100 Standard=50
        UnhappinessMultiplierPercent = 50,
        -- How many recent broadcasts the station tries not to repeat. 0 disables this protection. Minimum=0 Maximum=50 Standard=3
        AvoidRepeatWindow = 3,
        -- Tile range where a tuned radio placed in the world can trigger XP and mood effects. Set 0 to ignore placed radios for effects. Minimum=0 Maximum=50 Standard=12
        WorldRadioRadius = 12,
        -- Off by default. When off, a radio inside the backpack does not give XP or mood effects; use hands, vehicle radio, or a placed radio.
        InventoryRadioEffects = false,
        -- 0 Auto, 1 English, 2 Russian, 3 Simplified Chinese. Force a language on servers when auto-detection picks the wrong pack. Minimum=0 Maximum=3 Standard=0
        LanguageMode = 0,
        -- Chooses where broadcast text is loaded from: 0 built-in only, 1 built-in plus custom overlays, 2 custom only with built-in fallback. Does not change language. Minimum=0 Maximum=2 Standard=1
        TextMode = 1,
        -- Allows ordered multi-part voices such as Dispatch, Bookman, Mapmaker, Hollow Choir, and Field Logs.
        ArcEnabled = true,
        -- Percent chance per broadcast to play the next available serial arc episode. 0 disables arc picks but keeps standalone broadcasts. Minimum=0 Maximum=100 Standard=30
        ArcChancePercent = 30,
        -- Writes extra Aftermath Radio details to the game logs. Use mainly for testing.
        Debug = false,
        -- Colors lines by tone or speaker: horror, warnings, Bookman, Dispatch, Pastor, and system fragments.
        LineColors = true,
    },
    ComputerMod = {
        -- Minimum=0 Maximum=100 Standard=14
        DiscSpawnChance = 14,
        -- Minimum=0 Maximum=300 Standard=100
        GameDiscWeightPercent = 100,
        -- Minimum=0 Maximum=300 Standard=100
        SystemDiscWeightPercent = 100,
        -- Minimum=0 Maximum=300 Standard=100
        BlankDiscWeightPercent = 100,
        -- Minimum=0 Maximum=300 Standard=100
        HackDiscWeightPercent = 100,
        -- Minimum=0 Maximum=100 Standard=60
        PreinstalledGameChance = 60,
        -- Minimum=0 Maximum=100 Standard=34
        PasswordChance = 34,
        -- Minimum=0 Maximum=100 Standard=12
        FramePasswordNoteChance = 12,
        -- Minimum=0 Maximum=100 Standard=18
        NearbyPasswordNoteChance = 18,
        -- Minimum=0 Maximum=10 Standard=1
        HackRequiredElectricalLevel = 1,
        -- Minimum=0 Maximum=100 Standard=28
        EmptyFolderChance = 28,
        -- Minimum=0 Maximum=100 Standard=12
        FolderMagazineChance = 12,
        -- Minimum=0 Maximum=100 Standard=18
        FolderNewspaperChance = 18,
        -- Minimum=0 Maximum=100 Standard=9
        FolderVideoChance = 9,
        -- Minimum=0 Maximum=100 Standard=10
        PaintFileChance = 10,
        -- Minimum=0 Maximum=100 Standard=6
        ComponentSpawnChance = 6,
        -- Minimum=0 Maximum=100 Standard=18
        FoundComputerBadPartChance = 18,
        -- Minimum=0 Maximum=100 Standard=1
        FoundComputerBrokenPartChance = 1,
        -- Minimum=0 Maximum=300 Standard=100
        ComponentWearRate = 100,
        EnableGameInstallVirus = true,
        -- Minimum=0 Maximum=100 Standard=8
        GameInstallVirusChance = 8,
        EnableBoardApp = true,
        EnableChatApp = true,
        EnableCommerceApp = true,
        NetworkOutageOnPowerLoss = true,
        NetworkTerminalNeedsPower = true,
        -- Minimum=1 Maximum=168 Standard=24
        MarketShopRefreshHours = 24,
        -- Minimum=1 Maximum=168 Standard=24
        MarketJobRefreshHours = 24,
        -- Minimum=0 Maximum=100 Standard=42
        MailAccountChance = 42,
        -- Minimum=0 Maximum=100 Standard=55
        MailLoggedInChance = 55,
        -- Minimum=0 Maximum=100 Standard=28
        SecretSiteHintChance = 28,
    },
    ComputerModLaptop = {
        -- Minimum=0 Maximum=100 Standard=1
        LaptopSpawnChance = 1,
        -- Minimum=0 Maximum=100 Standard=3
        SpareBatterySpawnChance = 3,
        -- Minimum=25 Maximum=300 Standard=100
        BatteryDrainRate = 100,
        -- Minimum=25 Maximum=300 Standard=100
        BatteryChargeRate = 100,
    },
    ComputerModNewMusic = {
        -- Minimum=0 Maximum=100 Standard=1
        CassetteDeckSpawnChance = 1,
    },
    ALife = {
        Preset_ExplicitValues = false,
        -- How dangerous NPCs are. Easy: half damage, 80 health, raids from day 60. Only default-valued options change; density is separate. Reload for full effect.
        -- Default Easy (1). Standard=Easy
        -- 1 = Easy
        -- 2 = Medium
        -- 3 = Hard
        -- 4 = Hardcore
        Preset_Difficulty = 1,
        -- The War Challenge: Biggest limits. Lots of NPCs alive at once. Needs a decent PC. Changes limits only, not chances or timing. High stays the normal choice.
        -- Default High (4). Standard=High
        -- 1 = Very few
        -- 2 = Few
        -- 3 = Medium
        -- 4 = High
        -- 5 = Maximum (unsupported, may lag)
        -- 6 = The War Challenge
        Preset_World = 4,
        -- Lets your profession affect how NPCs treat you, including Creator rules. Off: profession has no attitude effect; faction and folder relations still apply.
        -- Default off.
        ProfessionAffectsAttitude = true,
        -- Adds extra activity for the first 3 game days and a National Guard checkpoint north of West Point. After 72 hours, road police, army and the checkpoint disappear.
        -- Default on.
        Realistic_Outbreak = true,
        -- Off prevents hostile factions, automatic raids and new outposts. Friendly, neutral and cautious survivors can still appear.
        -- Default on.
        World_HostileEnabled = true,
        -- Scales the chance of natural faction encounters. At 50, these checks have half their normal chance of bringing a group.
        -- Default 200. Minimum=25 Maximum=400 Standard=200
        Population_RatePercent = 300,
        -- Scales the number of NPCs in naturally appearing groups. At 100, groups keep their original sizes. Faction size limits still apply.
        -- Default 125. Minimum=50 Maximum=200 Standard=125
        Population_PartyPercent = 125,
        -- Sets how close saved NPCs must be to a player before they appear as physical characters. Larger distances keep more nearby NPCs active.
        -- Default 90. Minimum=40 Maximum=250 Standard=90
        World_SimRadius = 90,
        -- Stops new travelling crews at this living-NPC count, including peaceful survivors. It is not the county population; existing crews stay.
        -- Default 32. Minimum=4 Maximum=160 Standard=32
        Population_HostileCeiling = 48,
        -- Time to raise, aim and start firing, and to look for a new combat target. Default 75% shortens these delays by one quarter. 100% restores the previous timing. Lower is faster. Weapon fire rate, reload time and warnings keep their own timings. Minimum=25 Maximum=200 Standard=75
        Combat_ReactionDelayPercent = 75,
        -- Higher choices make NPC gunfire more accurate against players. Medium keeps their own aiming skill; zombie accuracy is separate.
        -- Default Medium (3). Standard=Medium
        -- 1 = Very Easy
        -- 2 = Easy
        -- 3 = Medium
        -- 4 = Hard
        -- 5 = Very Hard
        -- 6 = Hardcore
        Combat_AimDifficulty = 3,
        -- Sets the chance of a group on each natural encounter check. Both the game-hour faction checks and game-minute encounter checks use it.
        -- Default 15. Minimum=0 Maximum=100 Standard=15
        Encounters_RollPercent = 30,
        -- Sets the time between natural faction encounter checks. A check can fail; this is not a guaranteed time between meetings.
        -- Default 3. Minimum=1 Maximum=24 Standard=3
        Encounters_GapHours = 3,
        -- Extra no-spawn distance around claimed multiplayer safehouses. At 8, new NPCs cannot spawn within eight extra tiles of the claim.
        -- Default 8. Minimum=0 Maximum=50 Standard=8
        World_SafehouseClearance = 8,
        -- Allows hostile NPC factions to fight each other.
        -- Default on.
        World_FactionWarfare = true,
        -- Allows wounded hostile NPCs to retreat from a fight.
        -- Default on.
        Behavior_Retreat = true,
        -- NPCs infected by zombie bites or attacks can rise in their own clothes. The game's Transmission, Mortality and Reanimate settings still apply.
        -- Default on.
        Behavior_NPCsReanimate = true,
        -- Infected NPC corpses wait before rising, giving you time to right-click and put them down. Off: they rise immediately. The wait advances only while the body is loaded.
        -- Default on.
        Turning_Enabled = true,
        -- Sets the shortest wait before an infected NPC corpse rises. For example, 30 means at least half a minute while the body is loaded.
        -- Default 20. Minimum=0 Maximum=600 Standard=20
        Turning_DelaySecondsMin = 20,
        -- Sets the longest wait before an infected NPC corpse rises. For example, 120 allows up to two minutes while the body is loaded.
        -- Default 90. Minimum=0 Maximum=600 Standard=90
        Turning_DelaySecondsMax = 90,
        -- Allows hostile looters to take nearby supplies.
        -- Default on.
        Behavior_Scavenge = true,
        -- Hostile NPCs may walk toward gunfire, shouts and other signs of activity they notice.
        -- Default on.
        Behavior_Investigate = true,
        -- Members that fall behind close back up on their group instead of drifting.
        Behavior_Regroup = true,
        -- Groups travel together in formation rather than as separate walkers.
        Behavior_MarchTogether = true,
        -- Outside combat, the last group member closes doors the group opened. Player-opened doors and occupied doorways stay untouched; no locks are changed.
        -- Default on.
        Behavior_CloseDoors = true,
        -- Allows eligible NPC guns and melee weapons to remain on their bodies for looting. The weapon drop chance still applies.
        -- Default on.
        Drops_WeaponsEnabled = true,
        -- Per NPC profile uses each NPC's own chance times the NPC loot percent. Another choice sets one chance for all weapons and ignores that percent; needs NPC weapon drops.
        -- Default Per NPC profile (1). Standard=Per NPC profile
        -- 1 = Per NPC profile
        -- 2 = Off (0%)
        -- 3 = Very low (0-10%)
        -- 4 = Low (10-20%)
        -- 5 = Moderate (20-30%)
        -- 6 = High (30-50%)
        -- 7 = Very high (50-70%)
        -- 8 = Almost always (70-99%)
        -- 9 = Always (100%)
        Drops_WeaponChance = 3,
        -- Sets dropped weapon condition, not NPC combat strength. Per NPC profile keeps its rating and early-game wear curve; Broken needs repairs before use.
        -- Default Per NPC profile (1). Standard=Per NPC profile
        -- 1 = Per NPC profile
        -- 2 = Broken (0/10)
        -- 3 = Scrap, a shot or two (1/10)
        -- 4 = Very poor, a few shots (2/10)
        -- 5 = Poor (3/10)
        -- 6 = Worn (4/10)
        -- 7 = Used, half gone (5/10)
        -- 8 = Serviceable (6/10)
        -- 9 = Good (7/10)
        -- 10 = Very good (8/10)
        -- 11 = Near new (9/10)
        -- 12 = Issue fresh (10/10)
        Drops_WeaponCondition = 1,
        -- Only military and special-response crews can drop rare armor, dirty and at 10-40 percent condition. 0 stops these drops. Sledgehammers and crafting components never drop.
        -- Default 5. Minimum=0 Maximum=100 Standard=5
        Loot_RareDropPercent = 5,
        -- On: Creator profiles keep their chosen rare gear. Off: custom sledgehammers, crafting heads and heavy armor are replaced with common gear at spawn.
        -- Default off.
        Loot_AllowRareFromProfiles = false,
        -- Restores the earlier factions, attitudes and spawn weights instead of the merged roster. Takes effect when the game or server starts.
        -- Default off.
        Factions_LegacyRoster = false,
        -- Changes factions, gear and aim as the world ages. Emergency services disappear by day 120; survivor and raider groups take over. Off uses fixed faction schedules.
        -- Default on.
        Funnel_Enabled = true,
        -- Moves faction progression ahead or back. At +30, a new world uses day-30 factions and gear; -10 delays progression by 10 days.
        -- Default 0. Minimum=-3650 Maximum=3650 Standard=0
        Funnel_DayOffset = 0,
        -- Limits lone survivors and survivor pairs to this many NPCs, even if group-size settings would make their party larger.
        -- Default 2. Minimum=1 Maximum=2 Standard=2
        Funnel_LoneSurvivorMax = 2,
        -- How much NPC aim improves as the stages pass, in % of the built-in ramp (up to +3 aim rating in the last stage). 0% turns the ramp off, 100% is the default. Minimum=0 Maximum=200 Standard=100
        Funnel_SkillRampPercent = 100,
        -- Scales the ammo an NPC starts with; 100 keeps its profile amount. Each gun retains at least one full load. Infinite-ammo profiles are unchanged.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Ammo_SpawnPercent = 100,
        -- Caps starting and collected spare ammo in gun loads of at least 6 rounds. Smaller kits stay smaller; 2 permits two spare loads. 0 removes the cap; infinite-ammo profiles are unchanged.
        -- Default 2. Minimum=0 Maximum=20 Standard=2
        Ammo_ReserveLoads = 2,
        -- Chooses which NPC profiles may use infinite ammo. Creator profiles only limits it to profiles you made or edited; stock NPCs can run dry.
        -- Default Creator profiles only (1). Standard=Creator profiles only
        -- 1 = Creator profiles only
        -- 2 = Every profile that asks
        -- 3 = Never
        Ammo_Bottomless = 1,
        -- On: dropped magazines use only ammo the NPC had left, up to its profile limit. Off: each issued magazine gets a drop roll and can be full even after its rounds were fired.
        -- Default on.
        Ammo_HonestDrops = true,
        -- Allows NPC firearms other than revolvers to jam: the gun clicks instead of firing, then the NPC racks it clear.
        -- Default on.
        Combat_EnableJamming = true,
        -- Base chance per trigger pull for a non-revolver NPC firearm to jam. Zero disables jams even if the feature is enabled. Minimum=0,00 Maximum=25,00 Standard=1,00
        Combat_JamChance = 1.0,
        -- How hard NPCs work a door, a window or a barricade when they break in. 100 is the tested default: a window takes three swings, a plank four, a plain door about half a minute, and only one man swings while the rest cover him. Lower it and they take longer; raise it and they come through faster. Minimum=25,00 Maximum=200,00 Standard=100,00
        Breach_Strength = 100.0,
        -- A two-handed swing by an NPC carries into a second zombie standing in the arc, at three quarters of the blow. Zombies only, never people. Off by default.
        Combat_MultiHit = false,
        -- A round an NPC puts into a zombie goes on into the zombie standing right behind it (up to three squares). Zombies only, never people; better against a horde. Off by default.
        Combat_BulletPenetration = false,
        -- Marks 10, 20 or 35 percent of suitable buildings once per world, up to the building limit. Residents appear when approached and are saved. Realistic outbreak does not turn it off.
        -- Default Uncommon (3). Standard=Uncommon
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Uncommon
        -- 4 = Common
        Population_PopulateOnStart = 3,
        -- Limits buildings selected for starting residents across the whole map. Selection happens once per world; stations, firehouses and clinics take priority.
        -- Default 75. Minimum=1 Maximum=200 Standard=75
        Population_PopulateMax = 75,
        -- Adds small local groups, such as a family or rescue crew, when a new character starts in town. Reloading or rejoining does not add more.
        -- Default on.
        TownWelcome_Enabled = true,
        -- How many welcome groups each new character gets, and how many can be alive in one town at once, even when several players start there.
        -- Default 8. Minimum=1 Maximum=8 Standard=8
        TownWelcome_GroupsPerTown = 8,
        -- On allows a character's town welcome group only during their first game day. Off extends the window to their first game week.
        -- Default on.
        TownWelcome_FirstDayOnly = true,
        -- Sets the finite survivor pool when the world starts. Natural groups and reinforcements draw from it; deaths reduce it. Slow arrivals replace losses. Admin spawns do not count.
        -- Default 360. Minimum=20 Maximum=5000 Standard=360
        Census_Size = 360,
        -- Sets how many newcomers can replace dead survivors each game week early in the outbreak. If nobody has died, nobody arrives.
        -- Default 7.0. Minimum=0,00 Maximum=100,00 Standard=7,00
        Census_ArrivalsEarly = 7.0,
        -- Sets the replacement arrival rate after the early period. Arrivals gradually fall from the early rate to this one; they only replace losses.
        -- Default 1.0. Minimum=0,00 Maximum=100,00 Standard=1,00
        Census_ArrivalsLate = 1.0,
        -- Sets how long the weekly arrival rate takes to fall from the early value to the later value.
        -- Default 28. Minimum=1 Maximum=365 Standard=28
        Census_ArrivalsFadeDays = 28,
        -- Keeps a camp, outpost or inhabited building empty after all its residents die. Once this period ends, rare newcomers may settle there if resettlement is enabled.
        -- Default 30. Minimum=1 Maximum=365 Standard=30
        Census_ClearedDays = 30,
        -- Allows newcomers to settle cleared sites after their vacancy period, at most one site per four arrivals. Off keeps cleared sites empty for the rest of the game.
        -- Default on.
        Census_Resettle = true,
        -- NPCs walk to where a target was last seen and sweep the area before giving up.
        Search_Enabled = true,
        -- Shouting draws every NPC within earshot toward you.
        Search_ShoutResponse = true,
        -- An NPC that spots something tells its group where, once. Not a live feed.
        Search_GroupCallout = true,
        -- When not fighting, NPCs search areas with signs that survivors are nearby, such as barricades or a running generator.
        -- Default on.
        Clues_Enabled = true,
        -- Running or hotwired vehicles attract NPC searches in the surrounding area.
        -- Default on.
        Clues_Vehicles = true,
        -- Planks on doors and windows make NPCs treat a building as occupied and worth investigating.
        -- Default on.
        Clues_Barricades = true,
        -- Player-built walls, gates and fences make NPCs treat a place as occupied and worth investigating.
        -- Default on.
        Clues_PlayerBuilt = true,
        -- A running generator gives NPCs a strong sign that someone lives nearby, attracting investigation.
        -- Default on.
        Clues_Power = true,
        -- Scales how readily NPCs investigate survivor traces. Higher values let weaker evidence draw a search; lower values require stronger evidence.
        -- Default 1.0. Minimum=0,25 Maximum=5,00 Standard=1,00
        Clues_WeightMultiplier = 1.0,
        -- Enables recorded speech where available. Off keeps conversations as text; pain and death sounds are separate.
        -- Default off.
        Voice_Enabled = false,
        -- Nearby NPCs answer typed questions, requests, threats and yes-or-no replies. They also speak when you hit them or help them fight.
        -- Default on.
        Talk_Enabled = true,
        -- The Toggle chat key opens a small chat line for talking to NPCs in single player. Start a message with ! to shout.
        -- Default on.
        Talk_SinglePlayerChat = true,
        -- Friendly and neutral NPCs notice you nearby, stop and look when you speak. Passing friends greet you; outlaw groups call out strangers.
        -- Default on.
        Talk_Presence = true,
        -- Fresh survivors avoid unprovoked fights, but hostile relations, grudges and self-defence still allow attacks. Veterans and predators ignore this caution.
        -- Default on.
        Talk_RiskAssessment = true,
        -- Non-enemy groups within eight tiles may stop and talk, then part or walk together briefly. Off disables meetings; fights, fleeing and player orders always interrupt.
        -- Default Normal (3). Standard=Normal
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Often
        Talk_GroupMeetings = 3,
        -- Calm groups pause to talk, and passing NPCs greet each other or you. Danger interrupts them. Off disables both group chatter and these greetings.
        -- Default on.
        Chatter_Enabled = true,
        -- How often calm groups start talking. At 200, conversations happen twice as often; at 50, half as often.
        -- Default 100. Minimum=10 Maximum=400 Standard=100
        Chatter_Frequency = 100,
        -- Chance that an NPC greets you or another NPC while passing. Friendly people greet more, wary people less, enemies never. At 0, passing greetings stop.
        -- Default 70. Minimum=0 Maximum=100 Standard=70
        Chatter_PassingGreetPercent = 70,
        -- Maximum group conversations happening at once. Lower values keep speech easier to follow in crowded places.
        -- Default 3. Minimum=1 Maximum=8 Standard=3
        Chatter_MaxConcurrent = 3,
        -- Outlaws may rob a lone player instead of shooting: hands up, weapon down, three or four valuables taken, then they leave. Refusal can lead to shooting.
        -- Default on.
        Robbery_Enabled = true,
        -- Scales how often outlaws choose robbery rather than a fight. 0 means never; 200 means twice the normal rate, not a guaranteed robbery.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Robbery_Chance = 100,
        -- Lets you order NPCs to raise their hands, drop weapons, leave or follow. Obedience depends on fear, faction, weapons and group size.
        -- Default on.
        Orders_Enabled = true,
        -- Scales the chance an NPC obeys a spoken order. At 0, nobody obeys; at 200, obedience is twice as likely. Civilians are easier to command than armed factions.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Orders_Chance = 100,
        -- Chance the target and their group attack after refusing hands-up, drop-weapon or hold-up orders. At 100, they always attack; at 0, they only refuse.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Orders_FailFight = 100,
        -- A surrendering NPC lowers their hands and reacts when a zombie comes within this distance.
        -- Default 4. Minimum=1 Maximum=8 Standard=4
        Orders_ZombieTiles = 4,
        -- Longest time an NPC keeps their hands up before lowering them and carrying on.
        -- Default 90. Minimum=10 Maximum=600 Standard=90
        Orders_SurrenderSeconds = 90,
        -- How much weapons, loaded ammo, armour, numbers, distance and clear sight affect obedience. At 0, these advantages do not matter; at 300, they dominate the decision.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Orders_Advantage = 100,
        -- When one member surrenders, each groupmate chooses whether to obey, fight or flee after a warning. Off: the whole group always follows the surrendering member.
        -- Default on.
        Orders_GroupSurrender = true,
        -- Robbed NPCs flee, then remember you as dangerous and keep their distance for this long. At 0, this caution is not remembered.
        -- Default 15. Minimum=0 Maximum=240 Standard=15
        Orders_CarefulMinutes = 15,
        -- Opening a calm NPC's talk menu makes them stop, face you and greet you before choices appear. Fighting or frightened NPCs are not interrupted.
        -- Default on.
        Talk_GreetOnOpen = true,
        -- NPCs remember repeated questions, lose patience and react to your tone. Off: no question memory or opinion changes from words; deeds still count.
        -- Default on.
        Talk_AntiSpam = true,
        -- Prioritises useful replies, marks asked questions and hides unsuitable choices, such as personal questions for strangers. Requires conversation memory and patience.
        -- Default on.
        Talk_MenuFocus = true,
        -- Within this time, a repeated question gets an already-answered reply and no opinion gain. Personal-life answers stay remembered for a full game day.
        -- Default 30. Minimum=1 Maximum=600 Standard=30
        Talk_RepeatCooldownMinutes = 30,
        -- Base number of questions an NPC will answer. NPCs who like you allow more; those who dislike you allow fewer. After warning that patience is spent, they end the talk.
        -- Default 10. Minimum=2 Maximum=30 Standard=10
        Talk_QuestionsPerTalk = 10,
        -- After ending an overlong or irritating conversation, the NPC refuses to answer and closes the talk window until this time passes.
        -- Default 60. Minimum=5 Maximum=1440 Standard=60
        Talk_RefuseMinutes = 60,
        -- Talks needed before family and past-life questions open up, unless the NPC already likes you. Asking too early lowers their opinion.
        -- Default 2. Minimum=1 Maximum=10 Standard=2
        Talk_PersonalAfterTalks = 2,
        -- Scales how much polite, nosy, rude or kind words change an NPC's opinion. At 0, words do not change opinion; repetition, patience and refusals still work.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Talk_OpinionFromTalk = 100,
        -- Limits opinion gained from words in one talk; losses stop at one and a half times this amount. Twenty quiet game minutes begin a new conversation.
        -- Default 6. Minimum=1 Maximum=40 Standard=6
        Talk_OpinionCapPerConversation = 6,
        -- Limits opinion gained from words with each NPC per game day. Losses stop at one and a half times this amount.
        -- Default 12. Minimum=1 Maximum=100 Standard=12
        Talk_OpinionCapPerDay = 12,
        -- Conversation cannot raise an NPC's opinion above this score. Beyond it, gifts, healing or fighting beside them must earn further trust.
        -- Default 40. Minimum=0 Maximum=100 Standard=40
        Talk_OpinionWordCeiling = 40,
        -- After fights, NPCs near players loot bodies when no danger is within 15 tiles, taking supplies and useful gear. Player bodies and former player companions' bodies are left alone.
        -- Default on.
        BodyLoot_Enabled = true,
        -- Caps how many bodies one group searches each real minute. For example, 2 prevents it searching more than two corpses in a minute.
        -- Default 3. Minimum=1 Maximum=20 Standard=3
        BodyLoot_PerMinute = 3,
        -- Adds a survivor-run station with scanner traffic, military chatter, calls, stories, jokes and rumors about events in your world.
        -- Default on.
        Radio_KnoxCounty = true,
        -- Tracks kills, help and mistreatment, with change notices and character-window scores. Off stops both tracking and display.
        -- Default on.
        Reputation_Tracking = true,
        -- Each NPC remembers a separate opinion of each player, shaped by temperament, reputation and deeds toward their group. Shown in conversations. Off disables individual opinions.
        -- Default on.
        Reputation_NpcOpinion = true,
        -- Scales how deeds change an NPC's opinion. At normal strength, a gift gives about 8 points, a hit loses 20 and killing a groupmate loses 45; others may hear about it.
        -- Default 100. Minimum=25 Maximum=300 Standard=100
        Reputation_NpcOpinionScale = 100,
        -- Scales opinion's effect on prices, replies, invitations, company, deals, greetings, betrayal and orders. At 0, opinion is displayed but has no gameplay effect.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Reputation_NpcOpinionEffects = 100,
        -- How far each NPC's opinion moves back toward its starting value each day. At 0, the NPC never forgets.
        -- Default 3. Minimum=0 Maximum=20 Standard=3
        Reputation_NpcOpinionDecay = 3,
        -- Radio stories may name players after lasting reputation changes, fighting sprees or surviving raids. Requires personal reputation; never reveals the player's location.
        -- Default on.
        Reputation_RadioNames = true,
        -- Allows radio stories about a player's bad reputation. Off: only neutral or positive mentions are broadcast.
        -- Default on.
        Reputation_RadioBadNews = true,
        -- Food gifts and fair trades improve standing with the visitor's faction. Off: these choices do not change faction standing; existing grudges remain.
        -- Default Off (1). Standard=Off
        -- 1 = Off
        -- 2 = On
        Reputation_Mode = 1,
        -- How quickly earned faction standing returns toward zero. At 200, it fades twice as fast; at 0, earned standing stays unchanged.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Reputation_DecayPercent = 100,
        -- Shows the number beside your reputation level in the character window, notes and radio panel, such as Cutthroat (-62). Off shows only the level name.
        -- Default on.
        Reputation_ShowScore = true,
        -- New characters reset personal reputation, faction standing and NPC memories, not faction or Creator relations. Off keeps the old values. Reconnecting never resets the same character.
        -- Default on.
        Reputation_ResetOnNewCharacter = true,
        -- The T-menu reputation answer also lists other players' reputation levels on the server. Off shows only your own.
        -- Default off.
        Reputation_ShowOthers = false,
        -- Killing an NPC already in a fight counts as a hostile kill and is not held against you. Off judges each kill by the NPC's attitude toward you.
        -- Default on.
        Reputation_NpcFightIsHostile = true,
        -- Points of personal reputation that drift toward neutral each day. At 0, your earned reputation stays unchanged.
        -- Default 5. Minimum=0 Maximum=50 Standard=5
        Reputation_DriftPerDay = 5,
        -- Scales personal reputation changes from kills and from deeds (visitors, hosting, gifts, treating, trading). At 0 none count; at 200 they count twice as much.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Reputation_KillScale = 100,
        -- Limits reputation gained from kills each day at full rate; extra hostile kills count at the reduced share below. Deeds get their own limit of 150 percent of this.
        -- Default 60. Minimum=0 Maximum=1000 Standard=60
        Reputation_GainCapPerDay = 60,
        -- Share of normal gain earned for hostile or criminal kills after the daily limit, with at least 1 point per kill. At 0, no further gain is possible that day.
        -- Default 25. Minimum=0 Maximum=100 Standard=25
        Reputation_OverCapPercent = 25,
        -- Extra points beyond a level boundary needed before your reputation label changes. Higher values reduce frequent label changes.
        -- Default 15. Minimum=0 Maximum=100 Standard=15
        Reputation_Hysteresis = 15,
        -- Personal reputation gained for killing an NPC who was hostile toward you.
        -- Default 10. Minimum=0 Maximum=200 Standard=10
        Reputation_KillHostile = 10,
        -- Personal reputation gained for killing an NPC from a criminal faction.
        -- Default 15. Minimum=0 Maximum=200 Standard=15
        Reputation_KillCrime = 15,
        -- Personal reputation lost for killing a neutral or cautious NPC who meant you no harm.
        -- Default 40. Minimum=0 Maximum=500 Standard=40
        Reputation_KillNeutral = 40,
        -- Personal reputation lost for killing an NPC who regarded you as a friend.
        -- Default 80. Minimum=0 Maximum=500 Standard=80
        Reputation_KillFriendly = 80,
        -- Personal reputation lost for killing an NPC who had surrendered.
        -- Default 100. Minimum=0 Maximum=500 Standard=100
        Reputation_KillSurrendered = 100,
        -- Choose an unused frequency; 100000 means 100 MHz. Other channels are never replaced. Restart the server after changes, then open a radio to add the matching preset.
        -- Default 99600. Minimum=88000 Maximum=108000 Standard=99600
        Radio_KnoxFrequency = 99600,
        -- The admin console, spawn panel, encounter list, outpost builder and raid setup in the right-click menu. Players also need Diagnostics ticked in Options. Turn this off for a clean right-click menu; the Creator (Insert key) and world status (Home key) stay on their keys and the pause menu. Admins on a server are unaffected.
        -- Default on.
        Debug_ShowAdminTools = true,
        -- After an admin has run CLEANUP A-LIFE to the end, the mod stays inert in that world so it can be removed safely. Turn this on only if you want the mod to spawn people and outposts again in a cleaned world.
        -- Default off.
        Cleanup_RespawnAfter = false,
        -- Adds a right-click peephole view on closed doors. Each player can also turn it off in their own mod options.
        -- Default on.
        Peek_Enabled = true,
        -- Every few seconds, an NPC within two tiles of the door may hear you peeking and speak. They cannot see you through the peephole. At 0, peeking is never heard.
        -- Default 5. Minimum=0 Maximum=100 Standard=5
        Peek_NoticeChancePercent = 5,
        -- Hides faction, rank, mood and standing in the talk window. Shows only a name you have learned and held items. Off restores the full heading.
        -- Default on.
        Talk_MysteryMode = true,
        -- Moving vehicles hurt NPCs they hit, with damage based on speed. Off: collisions do no NPC damage. Intact car windows still protect you from NPC attacks either way.
        -- Default on.
        Combat_VehicleDamage = true,
        -- On: NPCs do not start fights in non-PvP zones, but still retaliate against an attacker. Off: NPCs may attack there. Safehouses protect you either way.
        -- Default off.
        Combat_NonPvpZoneShield = false,
        -- Scales how often NPC gunfire hits a ZOMBIE. 100 is unchanged; raise it if crews look helpless against a horde. Does not affect their aim against you. Minimum=10 Maximum=200 Standard=100
        Combat_AimZombiePercent = 100,
        -- Global multiplier on how often NPC gunfire hits players, applied on top of the NPC aim setting and each character's own accuracy. 100 is unchanged. NPCs also aim worse in the first seconds of a fight, at long range and against a moving target. Minimum=10 Maximum=200 Standard=70
        Combat_AimPlayerPercent = 70,
        -- Scales NPC melee and gun damage to players. At 50, each hit deals half the original damage; 100 is the original amount.
        -- Default 72. Minimum=0 Maximum=100 Standard=72
        Combat_DamagePercent = 72,
        -- Optional extra overall-health loss added on top of a hit, on top of the damage option above. 0 means no extra damage, so the 60% option is exactly 60% of the original hit. Default 0. Minimum=0 Maximum=200 Standard=0
        Combat_ExtraWoundPercent = 0,
        -- Scales each survivor's original health. At 80, they have four-fifths of their usual health; profession differences still apply.
        -- Default 98. Minimum=25 Maximum=300 Standard=98
        NpcHealth_Percent = 98,
        -- How hard bullets, melee hits, shoves and zombie bites land on NPCs, on top of the NPC maximum health setting. At 100 guns, shoves and bites cost what they used to, 130 is 30% more. Melee hits are priced so that the defaults keep the old number of swings. This is the damage NPCs receive, not what they deal to players (see NPC damage output). Default 130. Minimum=25 Maximum=400 Standard=130
        NpcHealth_DamageTakenPercent = 130,
        -- How fast a resting NPC recovers health. 100 is the original 1.5% of maximum health per game hour, 50 is half of that. Only an NPC that has been out of the fight for two minutes and has no open wound recovers. 0 turns recovery off. Default 50. Minimum=0 Maximum=400 Standard=50
        NpcHealth_RegenPercent = 50,
        -- Switches the NPC health rebalance off: original maximum health, original hits needed to put an NPC down, original bleeding and regeneration. Default off.
        NpcHealth_Legacy = false,
        -- NPCs carrying a weapon walk into buildings slowly with the weapon raised, pause at doorways and corners and look over the room before moving on.
        Combat_RoomSweep = true,
        -- Shows a visible streak along NPC gunshots. Turning this off does not change muzzle flashes, gunfire sounds or casings.
        -- Default on.
        Combat_VisibleTracers = true,
        -- Shows weapon-sized flashes and nearby ground light when NPCs fire. Suppressed weapons do not flash. Gunfire sounds and casings are unchanged.
        -- Default on.
        Combat_MuzzleFlash = true,
        -- Sets how far other players can see an NPC shot's flash and streak and hear its gunshot and casing in multiplayer.
        -- Default 90. Minimum=20 Maximum=150 Standard=90
        Combat_ShotFxRange = 90,
        -- Armed NPCs get out of the line of fire to reload, break contact when hurt, and fight from behind walls and corners.
        Modules_Cover = true,
        -- A shooter that is losing breaks contact, runs about a block back, holes up out of sight -- inside a building when there is one -- then comes back in from another side. Ranged only; melee always closes.
        Modules_Withdraw = true,
        -- Civilians, families and workers flee zombies, flinch at loud events and spread fear early in the outbreak. Soldiers, police and criminals stay steadier. Requires Civilian fear of zombies.
        -- Default on.
        Panic_FirstDays = true,
        -- 100% is the standard curve: full fright on days 0 and 1, then easing off. Lower values make survivors calmer, higher values keep them frightened longer. 0 turns the panic off. Minimum=0 Maximum=200 Standard=100
        Panic_Strength = 100,
        -- Stretches or shortens the early-outbreak panic curve. Fright is strongest at the start and nearly gone by this many days after the outbreak.
        -- Default 12. Minimum=2 Maximum=60 Standard=12
        Panic_LengthDays = 12,
        -- A frightened survivor makes the people around them more frightened for 30 to 60 seconds: their own group first, strangers within about 12 tiles less. Soldiers and police nearby calm them down. Off keeps every survivor's fright separate.
        Panic_Contagion = true,
        -- Civilians, families and workers avoid distant zombies and flee crowds for at least 30 seconds, fighting if cornered. Soldiers, police, criminals and hardened members stay steadier.
        -- Default on.
        Modules_Fear = true,
        -- Civilians start out at full fear and steady over this many days, down to the lingering fear below. 0 starts them at the lingering fear. Minimum=0 Maximum=30 Standard=7
        Fear_Days = 7,
        -- How many zombies it takes before civilians break and run. Standard=Normal
        -- 1 = Hard to scare
        -- 2 = Normal
        -- 3 = Easily scared
        Fear_Level = 2,
        -- How much of their fear civilians keep once they have steadied. At 50 it takes a crowd about 1.6 times the size to make them run. 0 means they stop running from zombies altogether after the days above. Minimum=0 Maximum=100 Standard=50
        Fear_Lingering = 50,
        -- Poorly armed NPCs back away from a player or hostile aiming or raising a firearm. The Creator determines which factions and members have this fear.
        -- Default on.
        GunFear_Enabled = true,
        -- Chance that an NPC panics when a gun is aimed at it. Rolled once per NPC and player, so the same NPC always reacts the same way to the same player. A gun that is raised but not pointed at it counts half. Default 60. Minimum=0 Maximum=100 Standard=60
        GunFear_Percent = 60,
        -- How far, in tiles, a frightened NPC runs from the gun on each leg. It heads for cover that breaks line of sight and keeps going until the gun has been out of sight for a few seconds. Default 35. Minimum=8 Maximum=80 Standard=35
        GunFear_RunDistance = 35,
        -- How fast a frightened NPC runs away. A flight may use all of its stamina and slows down only when it is empty. Standard=Sprint
        -- 1 = Run
        -- 2 = Sprint
        GunFear_RunSpeed = 2,
        -- How long an NPC freezes and stares at the gun before it starts to run. 0 runs at once. Default 400. Minimum=0 Maximum=3000 Standard=400
        GunFear_ReactDelayMs = 400,
        -- After a fight, a wounded NPC stops, bandages, and loses the limp and the bleeding.
        Modules_Healing = true,
        -- In melee, NPCs step back while swinging when zombies press or outnumber them, and step in when a lone zombie is within reach or backing off. Decided each swing from the zombies' positions and facing.
        Combat_MeleeFootwork = true,
        -- How many zombies facing an NPC within the step-back radius it takes before the NPC steps back between swings. 0 turns stepping back off. Minimum=0 Maximum=8 Standard=2
        Combat_MeleeKiteCrowd = 2,
        -- How far around an NPC zombies are counted for melee footwork. Minimum=1 Maximum=5 Standard=2
        Combat_MeleeKiteTiles = 2,
        -- How far an NPC steps back between swings. It never steps out of weapon reach. 16 is 1.6 tiles. Minimum=3 Maximum=30 Standard=16
        Combat_MeleeStepBackTenths = 16,
        -- How far an NPC steps toward a lone zombie that is in reach or backing off. 11 is 1.1 tiles. Minimum=3 Maximum=25 Standard=11
        Combat_MeleeStepInTenths = 11,
        -- A zombie an NPC has just struck with a melee weapon cannot start or finish a bite and stops chasing for this long, so a fighter who keeps swinging is not bitten by the zombie in front of him. 0 turns the stun off. Minimum=0 Maximum=3000 Standard=1100
        Combat_ZombieStunMs = 1100,
        -- Master switch. On: the Sawmill Hands crew can spawn and the five melee modules work. Off: the faction is hidden from spawning, the Creator and the debug spawner, and every melee module is inert.
        Melee_FactionEnabled = true,
        -- Sidestep between swings, back off when zombies press in, step back in afterwards. Tuned for pairs and groups.
        Melee_Footwork = true,
        -- In a melee group one member engages and the others circle round to the far side of the target.
        Melee_Flank = true,
        -- A fighter holding an axe cuts through doors and windows faster and does it when checking a noise. The normal courtesy rules still apply.
        Melee_Breach = true,
        -- Walks up on a player, shouts the warning from range, then closes in. The normal warn-before-strike rules still decide when the first blow may land.
        Melee_Intimidate = true,
        -- Breaks contact early when a few zombies close in, using the existing withdraw behaviour with a lower crowd threshold.
        Melee_Caution = true,
        -- How many zombies near a crew member make it retreat. Normal fighters need five. Minimum=2 Maximum=8 Standard=3
        Melee_CautionCrowd = 3,
        -- How quickly zombies notice and engage NPCs compared with the old pace. 500 is five times faster, 100 is the old pace. Higher values cost a little more processing near NPCs. Minimum=100 Maximum=1000 Standard=500
        Zombies_ReactSpeed = 500,
        -- Zombies use the game's bite and scratch attack animations when attacking NPCs.
        -- Default on.
        Zombies_AttackAnims = true,
        -- How many of the attacks on a standing NPC are scratches instead of bites. Minimum=0 Maximum=100 Standard=35
        Zombies_ScratchPercent = 35,
        -- Enough zombies grabbing one NPC at once drag it down and kill it, with the game's being-eaten voice.
        -- Default on.
        Zombies_DragDown = true,
        -- Sets how many zombies must grab an NPC at the same time to drag it down. For example, 4 requires four simultaneous attackers.
        -- Default 4. Minimum=2 Maximum=8 Standard=4
        Zombies_DragDownCount = 4,
        -- How long the NPC is held down before it dies. 30 is 3 seconds. Minimum=5 Maximum=60 Standard=30
        Zombies_DragDownTenths = 30,
        -- The base armour system for NPCs, with the same rules a player gets. It is not a Creator module. Every hit on an NPC (zombie bites and scratches, melee, bullets; from NPCs and from players) rolls against the matching protection of what is worn on the struck body part: bite, scratch or bullet defense. 100 always blocks, 0 never does, layers add up to 100. A blocked hit does no damage and cannot wound or infect, and the clothing tears. Body parts with no protection take the normal damage. Off ignores worn clothing. Default on.
        Combat_NpcArmorVsZombies = true,
        -- NPCs that would bleed out can lie injured, be rescued, bandaged or questioned. Off keeps ordinary injury behavior; in multiplayer, only the client controlling the NPC runs its movement.
        -- Default on.
        Injury_Enabled = true,
        -- A teammate or friendly ally from the same bloc who can see a downed NPC walks over and bandages it. The rescued NPC stands up limping.
        -- Default on.
        Injury_Rescue = true,
        -- Rescuers drag downed NPCs away before bandaging when zombies or hostiles are within 12 tiles. Off: rescue cannot start with danger that close.
        -- Default on.
        Injury_RescueDrag = true,
        -- Allows rescues while players are near or watching. Off: rescuers wait until all players are beyond the nearby-player distance set under expert combat.
        -- Default on.
        Injury_RescueInView = true,
        -- Teammates and friendly members of the same faction this close to the injured NPC may come to help. Helpers outside his squad also need a clear line of sight. Hostile NPCs never rescue him. Minimum=5 Maximum=40 Standard=15
        Injury_RescueRange = 15,
        -- Downed NPCs crawl away from zombies and hostiles toward their group, and occasionally shuffle instead of lying still.
        -- Default on.
        Injury_Crawl = true,
        -- When an NPC would start bleeding out, this is the chance it goes injured instead. 0 means only the debug menu makes injured NPCs. Minimum=0 Maximum=100 Standard=50
        Injury_AutoPercent = 50,
        -- Health an NPC has when it goes down injured. Minimum=2 Maximum=40 Standard=12
        Injury_DownHpPercent = 12,
        -- Each question put to an injured NPC can kill it. The player sees that it bled out. Minimum=0 Maximum=100 Standard=25
        Injury_InterrogationDeathPercent = 25,
        -- Taken once per injured NPC when you question a friendly, neutral or careful one. Hostile NPCs cost nothing. Minimum=0 Maximum=20 Standard=3
        Injury_RepPenalty = 3,
        -- Small reward for giving a bandage or medical item. Minimum=0 Maximum=20 Standard=4
        Injury_RepGain = 4,
        -- Sets the time from getting up with low health to full health and a normal walk. For example, 12 means half a game day of recovery.
        -- Default 8. Minimum=1 Maximum=72 Standard=8
        Injury_RecoverHours = 8,
        -- Sets how long a downed NPC waits without help before getting up on its own, still limping. For example, 6 means a quarter of a game day.
        -- Default 4. Minimum=1 Maximum=48 Standard=4
        Injury_DownHours = 4,
        -- Only used when Rescues happen in front of players is off: then a teammate rescues an injured NPC only when no player is within this range or in sight. Minimum=10 Maximum=60 Standard=25
        Injury_PlayerRangeTiles = 25,
        -- Lets downed NPCs run on a server with connected players. The client that controls the NPC keeps its own bleed-out timers and wound list; the server only hands it a downed state. Off keeps the ordinary bleed-out in multiplayer. Single player is not affected.
        -- Default on.
        Injury_MultiplayerEnabled = true,
        -- After you bandage an injured NPC it turns neutral and walks this far from you. Minimum=30 Maximum=120 Standard=45
        Injury_LeaveTiles = 45,
        -- Sets the volume of zombie bites, being-eaten voices and NPC pain cries. Sounds fade with distance and are heard only within 25 tiles. At 0, they are muted.
        -- Default 40. Minimum=0 Maximum=100 Standard=40
        Audio_BiteLoudness = 40,
        -- Hits cause bruises, fractures, cuts, bullet wounds or bites. Leg wounds slow NPCs, arm wounds spoil aim, and open wounds bleed until bandaged; below 10 percent health, bleed-out is rapid.
        -- Default on.
        Combat_Wounds = true,
        -- How fast an NPC's open wounds bleed: scratches and cuts clot on their own, deep wounds and bullet wounds bleed until bandaged. 0 turns the bleeding off. Minimum=0 Maximum=300 Standard=100
        Combat_InjuryBleed = 100,
        -- Chance that an NPC's hit with a heavy blunt weapon (bat, sledgehammer) breaks the player's arm or leg it lands on. Blunt weapons never cut: a laceration becomes a scratch. Minimum=0 Maximum=50 Standard=4
        Combat_BluntFracture = 4,
        -- Allows sprint windows for melee closing, cover moves, and retreats. Off keeps those moves at a run or walk.
        Modules_Sprint = true,
        -- A shooter that loses sight of its target dumps the magazine into the last known position, full auto, spraying left and right. Pistols magdump too.
        Modules_Gunner = true,
        -- Allows groups such as patrols, scavengers and hostile crews to appear near players in suitable map areas.
        -- Default on.
        Encounters_Enabled = true,
        -- Sets the time between random encounter checks, including while sleeping or fast-forwarding. The encounter chance still decides whether a group appears.
        -- Default 45. Minimum=10 Maximum=720 Standard=45
        Encounters_IntervalMinutes = 45,
        -- Scales Roadside Pickers, small looting crews that may warn or rob you. They are common in the first two weeks and gone by week four. At 0, they do not appear.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Encounters_EarlyLooters = 100,
        -- Free groups choose goals such as supplies or shelter, discuss them and follow through until done, blocked, hurt or threatened. Off: groups return to travelling and idling.
        -- Default on.
        Plans_Enabled = true,
        -- Sets how far a group looks for a building to visit for its plan. Nearby buildings are preferred; 80 limits the search to 80 tiles.
        -- Default 100. Minimum=40 Maximum=200 Standard=100
        Plans_Radius = 100,
        -- Sets how long a group keeps a plan before giving up and choosing again. Shelter plans last until morning.
        -- Default 6. Minimum=1 Maximum=48 Standard=6
        Plans_LifespanHours = 6,
        -- Groups discuss plans before leaving and speak when they arrive or give up. Off: they still follow plans, but silently.
        -- Default on.
        Plans_Talk = true,
        -- Crews can move on after an encounter, such as fixing a car then scavenging from it. Distant groups plan around supplies. Off: crews keep their earlier behavior.
        -- Default on.
        Activities_Enabled = true,
        -- Sets the share of finished encounters whose crews take up another activity. The rest keep their post and later leave as before; higher values put more crews on roads.
        -- Default 70. Minimum=0 Maximum=100 Standard=70
        Activities_SwitchChance = 70,
        -- Allows armed NPC crews to hunt. Offline only allows hunting away from players and leaves nearby wildlife to you.
        -- Default Offline and nearby wildlife (3). Standard=Offline and nearby wildlife
        -- 1 = Off
        -- 2 = Offline only
        -- 3 = Offline and nearby wildlife
        Activities_Hunting = 3,
        -- A crew stuck at a broken or crashed car this long may leave it and go scavenging, but only when no player is nearby.
        -- Default 10. Minimum=1 Maximum=72 Standard=10
        Activities_SwitchHours = 10,
        -- A crew cannot abandon its car while any player is closer than this distance. For example, 80 keeps it at the car while you are within 80 tiles.
        -- Default 60. Minimum=20 Maximum=150 Standard=60
        Activities_SwitchClearTiles = 60,
        -- Crews of two or more may settle in an empty building away from players, store their loot and return after trips.
        -- Default on.
        Activities_Bases = true,
        -- Caps settled NPC bases across the world. If the limit is exceeded, the oldest base is abandoned. At 0, crews cannot found new bases.
        -- Default 6. Minimum=0 Maximum=24 Standard=6
        Activities_MaxBases = 6,
        -- Scales encounters with fishers, hunters, foragers, woodcutters, camp builders, scavengers and water carriers. 100 keeps the usual rate; 0 disables these encounters.
        -- Default 100. Minimum=0 Maximum=500 Standard=100
        Activities_PartyWeight = 100,
        -- Chance that each eligible crew founds a base, checked once per game day.
        -- Default 25. Minimum=0 Maximum=100 Standard=25
        Activities_BaseChance = 25,
        -- Time a crew with a base spends away before planning a return home.
        -- Default 8. Minimum=2 Maximum=48 Standard=8
        Activities_BaseReturnHours = 8,
        -- Minimum distance from any player when an NPC crew founds a base.
        -- Default 45. Minimum=20 Maximum=120 Standard=45
        Activities_BaseClearTiles = 45,
        -- Scales food gained from NPC hunts. 100 keeps the usual amount; 0 gives no food and 200 gives twice the usual amount.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Activities_HuntYieldPercent = 100,
        -- Allows NPC crews to fish near water without reducing the fish available to players.
        -- Default on.
        Activities_Fishing = true,
        -- Sessions last 60-140 percent of this time. Fishers stop if noticed by a player, hostile or zombie, or after gunfire or a hit.
        -- Default 65. Minimum=10 Maximum=240 Standard=65
        Activities_FishingMinutes = 65,
        -- Scales fish caught by NPC crews. 100 keeps the usual catch; 0 gives no fish and 200 gives twice the usual catch.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Activities_FishYieldPercent = 100,
        -- Foraging crews bring seasonal berries, herbs, nuts and mushrooms to their camp stash. This does not reduce what players can forage.
        -- Default on.
        Activities_Foraging = true,
        -- Scales food foraged per crew per game day. 100 gives six items, 200 gives twelve and 0 gives none.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        Activities_ForageYieldPercent = 100,
        -- Scales how quickly groups become hungry and thirsty. Higher values cause more supply runs and more chances to encounter you.
        -- Default 100. Minimum=25 Maximum=400 Standard=100
        Activities_NeedsDrainPercent = 100,
        -- Caps encounter crews kept travelling while you are away; they share the distant-group limit. Extra crews may continue while you are near, then leave the world as before.
        -- Default 6. Minimum=0 Maximum=24 Standard=6
        Activities_AdoptCap = 6,
        -- On: repaired cars have working engines, batteries, bonnets and some fuel, and remain with their trunk loot. Off: the car stays a wreck but remains the crew's stash.
        -- Default on.
        Activities_FixedCarDrivable = true,
        -- Sets how full a repaired car's fuel tank is. For example, 25 gives it a quarter tank.
        -- Default 15. Minimum=0 Maximum=100 Standard=15
        Activities_FixedCarFuelPercent = 15,
        -- Removes inactive NPCs after nobody has approached them for this long. Persistent crews, such as anchored NPCs and garrisons, never expire. At 0, cleanup is disabled.
        -- Default 8. Minimum=0 Maximum=168 Standard=8
        Population_DormantTtlHours = 8,
        -- The conduct layer: squad leaders that deploy and rally their group, snipers that keep distance, medics that dress their wounded, ambushers that wait in the dark, stealth killers. Off disables every conduct at once.
        Modules_Behaviors = true,
        -- Armed NPCs keep the gun on their target, or on where it was last seen, while they walk, back off or sidestep.
        Modules_Strafe = true,
        -- Flashlights: NPCs see 12 tiles in darkness, or 20 when their light reaches you. Night vision: they can see at night, but you must supply goggles yourself.
        -- Default Flashlights (1). Standard=Flashlights
        -- 1 = Flashlights
        -- 2 = Night vision
        Night_Sight = 1,
        -- How many groups keep travelling and working at night. No risks makes everyone shelter; Risk takers keeps most groups active.
        -- Default Moderate chance (3). Standard=Moderate chance
        -- 1 = No risks
        -- 2 = Low chance
        -- 3 = Moderate chance
        -- 4 = High chance
        -- 5 = Risk takers
        Night_Activity = 3,
        -- Saved travelling groups return up to this rate-scaled limit after restart; at 0 or in Local only, the saved-crew cap applies. Lowering stops new groups; extras keep moving until reload.
        -- Default 45. Minimum=0 Maximum=500 Standard=45
        Offline_SquadCap = 45,
        -- Limits outpost garrisons and persistent crews kept after restart. Distant travelling groups and starting building residents have separate limits. Lowering it affects the next save.
        -- Default 60. Minimum=0 Maximum=500 Standard=60
        Population_PersistentSquadCap = 60,
        -- Visitors, travellers and traders you met stay in the world when you quit. Raiders and other hostile groups do not. Counts toward the saved crew limit.
        -- Default on.
        Population_KeepEncounterNpcs = true,
        -- Caps simultaneous patrol, scavenging and hunting teams from each outpost. At 0, none are sent. Teams last for the session; the outpost stays saved.
        -- Default 3. Minimum=0 Maximum=4 Standard=3
        Outposts_TaskSquadCap = 3,
        -- Sets how often distant travelling groups move and make decisions. Longer intervals mean fewer updates.
        -- Default 20. Minimum=10 Maximum=60 Standard=20
        Offline_TickSeconds = 20,
        -- How far an offline squad walks in one in-game hour. Default 150, a walking pace at the default day length; towns are 1700-3400 tiles apart. Minimum=20 Maximum=400 Standard=150
        Offline_TravelTilesPerHour = 150,
        -- Groups that lose members to you and escape can return for revenge two to three game days later, bringing backup.
        -- Default on.
        Offline_RevengeEnabled = true,
        -- Sets the daylight game hours between distant travelling groups (up to 1500 tiles away) heading for you and arriving out of sight. Hostile ones wait until day 3. At 0, off.
        -- Default 6. Minimum=0,00 Maximum=48,00 Standard=6,00
        Offline_ApproachGapHours = 6.0,
        -- Game hours between hunts sent by each hostile outpost. From day 7, after dark, one crew per player. Uses faction sightings refreshed every 24 game hours. At 0, off.
        -- Default 72. Minimum=0 Maximum=168 Standard=72
        Assassins_GapHours = 72,
        -- Lets fortified stations, occupied houses and forest camps appear over time, with garrisons that remain at their site.
        -- Default on.
        Outposts_Enabled = true,
        -- Limits how many outposts may exist at once across the map. At 0, outposts are disabled.
        -- Default 9. Minimum=0 Maximum=24 Standard=9
        Outposts_MaxSites = 9,
        -- Limits how many fortified-building outposts each town may hold. Outdoor camps have a separate limit.
        -- Default 2. Minimum=1 Maximum=4 Standard=2
        Outposts_PerCity = 2,
        -- Time between chances to found an outpost. Sleep and fast-forward count. If the game clock stops, checks use this many real minutes instead.
        -- Default 20. Minimum=5 Maximum=120 Standard=20
        Outposts_IntervalMinutes = 20,
        -- Chance that an outpost check founds a new site, if a suitable location is available.
        -- Default 35. Minimum=0 Maximum=100 Standard=35
        Outposts_Chance = 35,
        -- Normal outposts start within this distance, at least 40 tiles from players. Fixed checkpoints may start up to 200 tiles away; all need loaded ground.
        -- Default 120. Minimum=60 Maximum=200 Standard=120
        Outposts_BuildRadius = 120,
        -- Share of destroyed or burned walls, doors, windows and fences that causes an outpost to be removed. At 0, this damage-based removal is disabled.
        -- Default 40. Minimum=0 Maximum=100 Standard=40
        Outposts_StructureLossPercent = 40,
        -- Pauses multiplayer wall and structure work until players stop crossing map sections. At least 5 seconds protects loading clients; new joins keep a separate 30-second pause.
        -- Default 5. Minimum=5 Maximum=30 Standard=5
        Outposts_StreamHoldSeconds = 5,
        -- A built outpost receives its garrison when a player comes within this distance.
        -- Default 90. Minimum=40 Maximum=150 Standard=90
        Outposts_SpawnRadius = 90,
        -- Sets the relative frequency of natural 1-3-person parties compared with larger groups. Higher means more small parties; faction-specific rules take priority.
        -- Default 2. Minimum=0,00 Maximum=20,00 Standard=2,00
        Party_LoneWeight = 2.0,
        -- Sets the relative frequency of natural groups of 4 or more compared with small parties. Equal weights give both sizes equal selection weight.
        -- Default 2. Minimum=0,00 Maximum=20,00 Standard=2,00
        Party_GroupWeight = 2.0,
        -- Sets the minimum time between new distant travelling groups. Existing groups stay; the world group limit and local quiet periods still apply.
        -- Default 3. Minimum=0,25 Maximum=48,00 Standard=3,00
        Offline_FoundGapHours = 3.0,
        -- Enables automatic raids: a radio warning, scouts arriving unseen, then a buildup before the attack. The earliest raid day still applies. Admins can force raids.
        -- Default on.
        Raid_Enabled = true,
        -- Automatic raids cannot begin before the world reaches this age. For example, 60 prevents them during the first 60 game days.
        -- Default 21. Minimum=0 Maximum=365 Standard=21
        Raid_MinDay = 21,
        -- Sets the minimum time between automatic full-scale raids. For example, 14 requires at least two game weeks between raids.
        -- Default 14. Minimum=0,25 Maximum=60,00 Standard=14,00
        Raid_CooldownDays = 14.0,
        -- Chance for scouts to begin a raid buildup on each check. Set 0 to stop automatic raids; cooldown and earliest-day limits still apply.
        -- Default 0.025. Minimum=0,00 Maximum=100,00 Standard=0,03
        Raid_Chance = 0.03,
        -- How often the raid director checks automatic eligibility. Minimum=1 Maximum=120 Standard=10
        Raid_CheckMinutes = 10,
        -- Sets the number of attacking waves in a raid. The total attacker limit still applies, so extra waves do not bypass that limit.
        -- Default 4. Minimum=1 Maximum=10 Standard=4
        Raid_Waves = 4,
        -- Sets the requested attackers in each wave. The total raid limit and other spawn limits can reduce the actual number.
        -- Default 8. Minimum=1 Maximum=12 Standard=8
        Raid_GroupSize = 8,
        -- Caps attackers across all automatic raid waves, spread evenly among the waves. Earlier scouts do not count. Admin-forced raids ignore this limit.
        -- Default 12. Minimum=1 Maximum=48 Standard=12
        Raid_MaxAttackers = 12,
        -- Sets the warning-to-scout delay; the raid follows its buildup. 0 sends scouts immediately. Scouts and raiders walk in from 40-50 tiles away, unseen and away from player bases.
        -- Default 3. Minimum=0,00 Maximum=24,00 Standard=3,00
        Raid_WarningHours = 3.0,
        -- Paces reinforcement waves after the initial warning. Minimum=1 Maximum=120 Standard=5
        Raid_WaveDelayMinutes = 5,
        -- Allows all A-Life helicopters: raid and backup arrivals, night searchlights and flyovers. Off: none of these helicopters fly.
        -- Default on.
        Raid_Helicopter = true,
        -- Controls opening sirens, jets and raid aircraft sounds. Helicopter raid arrivals also need the helicopter option switched on.
        -- Default on.
        Raid_SirenAircraftSounds = true,
        -- Wait this long after scouts successfully arrive before a raid can start. Minimum=0,00 Maximum=72,00 Standard=6,00
        Raid_ScoutBuildupHours = 6.0,
        -- An expired scout report cannot authorize a raid; new scouts must be sent. Minimum=1,00 Maximum=168,00 Standard=48,00
        Raid_ScoutLifetimeHours = 48.0,
        -- Sets how many enemy scouts arrive before an automatic full-scale raid. They are separate from the raid's total attacker limit.
        -- Default 4. Minimum=1 Maximum=8 Standard=4
        Raid_ScoutSize = 4,
        -- Groups in contact may request backup, with limited calls, a cooldown and a chance of no answer.
        -- Default on.
        Support_Enabled = true,
        -- Sets the chance that an allowed backup call succeeds. For example, 50 gives each permitted call a one-in-two chance of an answer.
        -- Default 35. Minimum=0 Maximum=100 Standard=35
        Support_Chance = 35,
        -- Sets the minimum wait between successful backup calls by the same group. For example, 6 means it must wait a quarter of a game day.
        -- Default 1.5. Minimum=0,00 Maximum=24,00 Standard=1,50
        Support_CooldownHours = 1.5,
        -- Sets backup size only when the calling NPC or its faction has no size of its own. It does not replace sizes chosen in their profiles.
        -- Default 4. Minimum=1 Maximum=8 Standard=4
        Support_GroupSize = 4,
        -- Limits how many reinforcement requests one group may make, preventing repeated backup calls without end.
        -- Default 2. Minimum=0 Maximum=10 Standard=2
        Support_MaxCalls = 2,
        -- Sets the chance of a searchlight call from an NPC authorized to request helicopter support. Ground-only callers cannot request it.
        -- Default 20. Minimum=0 Maximum=100 Standard=20
        Support_SpotlightChance = 20,
        -- Sets how long a requested searchlight flight lasts before the helicopter leaves.
        -- Default 180. Minimum=5 Maximum=180 Standard=180
        Support_SpotlightSeconds = 180,
        -- Sets how long the support helicopter's flyover effects last. This does not set how long ground reinforcements stay.
        -- Default 35. Minimum=5 Maximum=180 Standard=35
        Support_HelicopterSeconds = 35,
        -- Allows moving searchlights at night or in low light. They can reveal people outdoors; cover and buildings hide them. Off disables only the searchlight.
        -- Default on.
        Helicopter_Spotlight = true,
        -- Sets the radius of the lit area. A larger beam covers more ground and makes it easier to be caught in the light.
        -- Default 11. Minimum=4 Maximum=20 Standard=11
        Helicopter_SpotlightSize = 11,
        -- Sets how strongly the helicopter searchlight illuminates the ground.
        -- Default 100. Minimum=20 Maximum=100 Standard=100
        Helicopter_SpotlightBrightness = 100,
        -- Sets the minimum time between searchlight flights anywhere in the world. Shorter intervals allow more flights; the call chance still applies.
        -- Default 20. Minimum=2 Maximum=240 Standard=20
        Helicopter_SpotlightGapMinutes = 20,
        -- Residents slowly carry zombie corpses out of loaded buildings to reduce corpse sickness. Never removes player or NPC corpses, or corpses in claimed player safehouses.
        -- Default on.
        Residents_ClearCorpses = true,
        -- Sets how far scavengers look for a nearby building. Higher values widen the search but increase the work needed to find one.
        -- Default 27. Minimum=10 Maximum=60 Standard=27
        Scavenge_BuildingRadius = 27,
        -- Scavengers return to their camp or base depot after collecting this many items. For example, 4 sends them home with four collected items.
        -- Default 8. Minimum=1 Maximum=24 Standard=8
        Scavenge_CarryLimit = 8,
        -- Scavengers bring supplies home after searching this many buildings. For example, 3 allows three building searches before returning.
        -- Default 2. Minimum=1 Maximum=8 Standard=2
        Scavenge_ReturnAfterBuildings = 2,
        -- Adds winter layers, removes heavy layers in summer and adds rainwear in wet weather. Uniforms and profiles with their own seasonal outfits are preserved.
        -- Default on.
        Loadouts_SeasonalDress = true,
        -- Each new person gets their own hair, hair colour, beard and clothing colours, so crews stop looking cloned. Off keeps the authored look. People already in a save keep theirs.
        -- Default on.
        Appearance_Variation = true,
        -- Share of new people who keep their authored face, so named characters stay recognisable. 0 varies everyone, 100 varies nobody. Needs Varied NPC looks on.
        -- Default 35. Minimum=0 Maximum=100 Standard=35
        Appearance_KeepAuthoredPercent = 35,
        -- People whose profile lists several weapons for one slot pick one of them per person. Off always uses the first listed weapon. Profiles with a single weapon are unaffected. Default on.
        Appearance_LoadoutVariation = true,
        -- Weather and clothing affect NPC warmth. Prolonged chill can cause coughing, worse aim, slower walking and faster fatigue. Indoors or near a fire, NPCs warm up.
        -- Default on.
        Cold_Enabled = true,
        -- How hard the cold hits NPCs and how big the penalties of a cold are. 0 = NPCs never get chilled. 100 = default and gentle. 300 = harsh winters. Default 100. Minimum=0 Maximum=300 Standard=100
        Cold_Severity = 100,
        -- Per game hour spent badly chilled, the base chance that an NPC comes down with a cold (it grows with how chilled and wet the NPC is). 0 = chills never turn into a cold. Default 6. Minimum=0,00 Maximum=100,00 Standard=6,00
        Cold_ChancePercent = 6.0,
        -- A sneeze or cough from a sick NPC is a small sound (a few tiles) that nearby zombies can hear. Turn off to keep them silent.
        Cold_SneezeNoise = true,
        -- Chilled NPCs without orders or danger seek a fire or heated building and wear warmer clothes from their packs. Groups follow their leader to a fire.
        -- Default on.
        Cold_SeekWarmth = true,
        -- In cold weather, NPCs sitting beside a lit campfire periodically hold their hands toward it. In warm weather or without a fire, they just sit.
        -- Default on.
        Idle_CampWarmHands = true,
        -- Shore fishers cast, wait and pull their rods every 20-60 seconds. Off: they continue fishing without the rod animation.
        -- Default on.
        Idle_FishingAnim = true,
        -- Camp sitters beside a free outdoor bench sit on it instead of the ground. Off: they always sit on the ground.
        -- Default on.
        Idle_BenchSeat = true,
        -- New arrivals from built-in factions mix uniforms with civilian clothes from this day; makeshift armour appears later. At 0, uniforms stay intact. Creator profiles are unchanged.
        -- Default 10. Minimum=0 Maximum=365 Standard=10
        Loadouts_UniformDecayDay = 10,
        -- Sets how quickly built-in civilian groups gain guns over time. At 200, guns spread twice as fast; at 50, half as fast. Police, army and elite units are unaffected.
        -- Default 100. Minimum=25 Maximum=400 Standard=100
        Loadouts_ArmingPace = 100,
        -- Scales gun ownership among built-in non-military NPCs. At 0, affected NPCs use melee tools only. Police, army, elite units and Creator profiles are unchanged.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Loadouts_ArmingShare = 100,
        -- Full keeps groups travelling beyond players' view. Local only stops new distant groups; existing ones retire on reload. Outposts can still develop in either mode.
        -- Default Full A-Life (offline squads roam the map) (1). Standard=Full A-Life (offline squads roam the map)
        -- 1 = Full A-Life (offline squads roam the map)
        -- 2 = Local only (groups near players; outposts stay)
        World_Mode = 1,
        -- Scales the chance of a random group near players without changing check intervals. Low halves the chance; Abundant triples it.
        -- Default Normal (2). Standard=Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_Encounters = 2,
        -- Scales natural group arrivals and the distant travelling group limit together. Low halves both; Abundant triples them, within their limits.
        -- Default Normal (2). Standard=Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_Groups = 2,
        -- Scales how often friendly, neutral and wary factions are picked compared with hostile ones. Low halves their selection weight; Abundant triples it.
        -- Default Normal (2). Standard=Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_Survivors = 2,
        -- Changes distant gunfire, helicopters and other background events. Low halves event limits and doubles the wait between them.
        -- Default Normal (2). Standard=Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_MetaEvents = 2,
        -- Limits outdoor sites such as forest camps, field bases and aid stations, separate from fortified town buildings. At 0, outdoor sites are disabled.
        -- Default 4. Minimum=0 Maximum=12 Standard=4
        Outposts_OutsideCity = 4,
        -- Allows cautious survivor communities to hold outposts alongside hostile crews. They warn strangers away but never send hunting parties. Off leaves only hostile holders.
        -- Default on.
        Outposts_SurvivorHolds = true,
        -- Patrols and scouts pause off the road every few hours and after fights to sit, smoke, drink or talk, then resume their route.
        -- Default on.
        PatrolRest_Enabled = true,
        -- Sets the minimum length of a patrol rest. For example, 30 means each rest lasts at least half a game hour.
        -- Default 20. Minimum=5 Maximum=180 Standard=20
        PatrolRest_MinMinutes = 20,
        -- Sets the maximum length of a patrol rest. For example, 60 limits each rest to one game hour.
        -- Default 45. Minimum=10 Maximum=240 Standard=45
        PatrolRest_MaxMinutes = 45,
        -- Sets the usual time between a group's planned rests, with some variation. Rest after a fight is separate from this schedule.
        -- Default 3.0. Minimum=0,50 Maximum=48,00 Standard=3,00
        PatrolRest_EveryHours = 3.0,
        -- Controls notes, gifts, visitors and attacks at claimed safehouses or buildings you live in. Off disables these base events.
        -- Default Normal (3). Standard=Normal
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Often
        Safehouse_Events = 3,
        -- Some visitors may lie about why they came. They give a warning sign before you open the door.
        -- Default on.
        Safehouse_Betrayal = true,
        -- Allows groups who hate you to attack your base after warnings. Off prevents these base-event attacks.
        -- Default on.
        Safehouse_Attacks = true,
        -- Only when invited: visitors enter after you let them in at the door. Never: all visitors remain outside.
        -- Default Only when invited (1). Standard=Only when invited
        -- 1 = Only when invited
        -- 2 = Never
        Safehouse_Entry = 1,
        -- Time after a place becomes your base before its first base event can happen.
        -- Default 3. Minimum=0 Maximum=14 Standard=3
        Safehouse_QuietDays = 3,
        -- Allows base events on dedicated servers while at least one resident is online. Off disables them there. Single player and co-op do not need this switch.
        -- Default on.
        Safehouse_Dedicated = true,
        -- Radio messages, door marks, knocks, distant gunfire and dog barks can happen in the world. Off leaves text notices only.
        -- Default on.
        Events_ScriptedEffects = true,
        -- Tunes and switches on a nearby radio for base-event messages, then turns it off. No radio: text only. Requires physical and audible base-event effects.
        -- Default on.
        Events_RadioActivate = true,
        -- Survivors may ask about your travels or how you cope: up to two questions per talk, then a ten-real-minute cooldown. Not during combat, injury or surrender.
        -- Default on.
        Talk_NpcQuestions = true,
        -- Shows requests for an NPC to follow you or walk alongside you. These conversation choices are still being reworked.
        -- Default off.
        Talk_FollowOptions = false,
        -- Visitor and ambient NPC lines show over their heads only within this many tiles, and only if you can see them or stand by the door. 0 shows them at any distance.
        -- Default 14. Minimum=0 Maximum=60 Standard=14
        Text_VisitorRangeTiles = 14,
        -- NPC speech appears as a bubble with the speaker's name and a pointer. A speaker off screen gets an edge arrow and the distance. Off: the game's plain floating text.
        -- Default on.
        Text_Bubbles = true,
        -- Shows a clickable Talk or Answer button while a visitor waits at your door or someone has just asked you something. Right-click still works.
        -- Default on.
        Talk_StartButton = true,
        -- How solid the talk window and the speech bubble boxes are. Text stays fully opaque. Lower is more see-through, 100 is the classic look.
        -- Default 100. Minimum=40 Maximum=100 Standard=100
        Talk_UIOpacity = 100,
        -- Copies NPC speech into the chat box in multiplayer, or a small log panel in single player. Only on your own screen, rate limited, names follow the stranger rule.
        -- Default Off (1). Standard=Off
        -- 1 = Off
        -- 2 = Spoken to you
        -- 3 = Everything you hear
        Text_NpcChatLog = 1,
        -- Travellers may visit your door with goods to trade. Their trading conversation is still being reworked.
        -- Default off.
        Safehouse_TraderVisits = false,
        -- Places washable wall marks by the door: up to four, fading after ten game days. Off gives text only. Requires physical and audible base-event effects.
        -- Default on.
        Events_WallMarks = true,
        -- A hostile NPC never lands its first blow or shot on a player who has not attacked it unless the player had a fair chance to notice: a shouted warning, a door or window heard opening, or the NPC in plain view for the first-contact grace. Fighting back is never delayed.
        Fair_TellBeforeStrike = true,
        -- How long a hostile NPC must have been in your view before it may attack without shouting first. Minimum=0,00 Maximum=10,00 Standard=2,50
        Fair_FirstContactGrace = 2.5,
        -- Time between a hostile NPC's warning shout and its first blow or shot. Minimum=0,50 Maximum=6,00 Standard=1,50
        Fair_WarningLead = 1.5,
        -- Time between the sound of a hostile NPC opening a door or climbing through a window and its first attack on a player nearby. Minimum=0,00 Maximum=6,00 Standard=1,50
        Fair_EntryLead = 1.5,
        -- How long an NPC needs to open a closed window before it climbs through. The window can be heard opening. Minimum=0,30 Maximum=4,00 Standard=1,20
        Fair_WindowOpenTime = 1.2,
        -- How long NPCs remember who started a fight with a player. Fighting back inside this time is self-defence, and the NPC that started it does not speak like a victim. Minimum=10 Maximum=240 Standard=60
        Fair_FightMemory = 60,
        -- Enables warnings for crews set to warn; others attack on sight unless a chance below allows a warning. Off: hostile crews attack on sight. Careful factions keep their own rules.
        -- Default on.
        Warning_Enabled = true,
        -- Sets the share of normally kill-on-sight crews that warn anyway. Each group rolls once and keeps its result. 0 means none; 100 means all. Raids use their separate chance.
        -- Default 15. Minimum=0 Maximum=100 Standard=15
        Warning_ChancePercent = 15,
        -- Sets the share of raids, assassins, highway ambushers and admin-spawned attackers that warn first. 0 makes all of these crews attack on sight.
        -- Default 10. Minimum=0 Maximum=100 Standard=10
        Warning_RaidChancePercent = 10,
        -- Limits unanswered warnings, standoffs and hold-ups. A crew waits four fifths of this per warning or demand before the next step. Replies restart the clock, up to four times this limit.
        -- Default 8. Minimum=2 Maximum=60 Standard=8
        Warning_HoldSeconds = 8,
        -- Crews that warn may question you, demand a toll or call you outside before fighting. Silence, leaving, a raised gun or betrayal can start a fight. Off: only their attack warning remains.
        -- Default on.
        Encounter_Standoffs = true,
        -- How long a hostile crew holds its fire after it discovers a player: time to answer, drop the weapon, raise the hands or act first. Aiming at the crew or attacking it ends the beat at once. Minimum=1,00 Maximum=10,00 Standard=3,00
        Encounter_SurpriseSeconds = 3.0,
        -- How long a confronting crew waits for an answer before it asks again ('Will you answer me?'). After the third silence the crew acts: leave, warn or attack, by faction. Minimum=4 Maximum=30 Standard=10
        Encounter_AnswerSeconds = 10,
        -- Scales how often crews call hidden players outside instead of searching; police do this more than raiders. Player bases are always called out first. 0 disables ordinary callouts.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Encounter_CalloutPercent = 100,
        -- How long a crew outside a building waits for the player to answer or come out, with repeated calls and a warning shot, before it searches the building or leaves. The time left is shown to the player. Minimum=15 Maximum=180 Standard=45
        Encounter_CalloutSeconds = 45,
        -- Scales outlaw flanking during talks. A flanker circles while the leader stalls; calling it out or raising a gun makes them back off. 0 disables this betrayal.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Encounter_BetrayalPercent = 100,
        -- How long a crew searches a building where it believes a player is hiding: one man at the door, the rest room by room. Then it gives up and moves on. Minimum=20 Maximum=600 Standard=90
        Encounter_SearchSeconds = 90,
        -- How long an NPC keeps chasing a player it can no longer see or hear. After that it only knows where he was last seen and searches from there. Minimum=2,00 Maximum=30,00 Standard=6,00
        Encounter_LostSightSeconds = 6.0,
        -- A hunting, raiding or revenge crew gets ONE tip about where its target is when it sets out, off by up to this many tiles. It never follows the player's live position; it searches and gives up. Minimum=0 Maximum=60 Standard=12
        Encounter_FixBlurTiles = 12,
        -- Stand-offs and hold-ups lean on gestures and distance instead of text over heads: one spoken line per phase (notice, demand, turn, parting), the rest goes to the talk panel, hand signals and nods carry the in-between. Every line is picked so it does not repeat. Off: every line is shouted over the head as before.
        -- Default on.
        Encounter_ScriptedCues = true,
        -- In a hold-up one crew member, never the speaker if someone else is free, walks up to arm's length and pats you down with an animation and one of three pat-down sounds. The search lasts exactly as long as the sound. If you step away or fight, it stops and the crew reacts. Off: the old instant search.
        -- Default on.
        Robbery_FriskScripted = true,
        -- Limits revenge groups sent after a player for one grudge. Each is drawn from the original crew's survivors plus at most two reinforcements.
        -- Default 2. Minimum=1 Maximum=10 Standard=2
        Revenge_MaxWaves = 2,
        -- Your shoves briefly stagger NPCs, and melee hits interrupt their next swing. A staggered NPC cannot finish its attack.
        -- Default on.
        Outplay_Stagger = true,
        -- Unvisited scavenged buildings may have fewer valuables and signs of looting. Never changes buildings players entered, player bases, safehouses or outposts.
        -- Default on.
        PickedOver_Enabled = true,
        -- Scales the chance that a building is already scavenged. 100 keeps the usual chance, 300 triples it and 0 disables it.
        -- Default 100. Minimum=0 Maximum=300 Standard=100
        PickedOver_Strength = 100,
        -- Sets the base chance before building type and rate scaling. Nearby scavenging adds up to 60 percentage points before those adjustments.
        -- Default 5. Minimum=0 Maximum=100 Standard=5
        PickedOver_Baseline = 5,
        -- Already scavenged buildings may show open doors, broken windows and blood. These signs are placed only while every player is at least 40 tiles away.
        -- Default on.
        PickedOver_Visuals = true,
        -- Already scavenged buildings may contain one or two dead zombies.
        -- Default on.
        PickedOver_ZombieCorpses = true,
        -- A building may rarely contain a dead member of the group that scavenged the area, wearing that group's clothes and carrying its gear.
        -- Default on.
        PickedOver_FactionCorpses = true,
        -- NPCs killed in battles away from players leave dressed bodies at the battle site. Bodies are placed while players are 40-110 tiles away and forgotten after 14 game days.
        -- Default on.
        WarDead_Enabled = true,
        -- Outposts start with one or two ground-floor planks, adding more every four game days while players stay over 40 tiles away. Upstairs gets sheets; metal bars stay unchanged.
        -- Default on.
        Boarding_Staged = true,
        -- Crews weigh guns, ammo, distance and nearby zombies before attacking a player, and avoid poor odds. Crews sent to attack and NPCs you have hurt still fight.
        -- Default on.
        Discretion_Enabled = true,
        -- Uses each faction's view of your profession when choosing nearby encounters. Off: every profession uses that faction's general attitude.
        -- Default on.
        Reputation_ProfessionEncounters = true,
        -- During the first week, NPCs from a similar background may recognise your former profession, such as police recognising police. Requires personal reputation.
        -- Default on.
        Reputation_ProfessionRecognition = true,
        -- Time an invited visitor waits for the door to open before giving up.
        -- Default 10. Minimum=2 Maximum=60 Standard=10
        Safehouse_InviteMinutes = 10,
        -- Visitors face the door and wait for roughly two thirds to four thirds of this duration. Opening the door, talking or attacking ends it immediately. At 0, no initial wait.
        -- Default 30. Minimum=0 Maximum=120 Standard=30
        Safehouse_VisitorHoldSeconds = 30,
        -- Hear visitors knock at doors or windows from about 50 tiles away. Break-ins sound when the first inside door opens. Off: text notices only.
        -- Default on.
        Safehouse_KnockSounds = true,
        -- Chance that an overnight guest refuses to leave in the morning until you talk them out.
        -- Default 15. Minimum=0 Maximum=100 Standard=15
        Safehouse_SquatPercent = 15,
        -- Chance that a wounded visitor is secretly bitten. Bitten visitors refuse to be searched.
        -- Default 15. Minimum=0 Maximum=100 Standard=15
        Safehouse_BittenPercent = 15,
        -- Minimum time between a hostile group's threat letter, door mark, sabotage and eventual attack.
        -- Default 48. Minimum=12 Maximum=240 Standard=48
        Safehouse_LadderGapHours = 48,
        -- In SP/co-op, recognised bases block NPC spawning, shelter, loot and uninvited non-hostiles. Off: any slept-in or built-at place blocks spawns, as on dedicated servers.
        -- Default on.
        Safehouse_BaseFlag = true,
        -- Points needed to recognise a base, with at least two kinds of evidence. A night adds 20, a day there 10, a running generator 20 and a claim 30.
        -- Default 100. Minimum=20 Maximum=400 Standard=100
        Safehouse_BaseScore = 100,
        -- Chance of an event at an eligible house. Rare halves this chance; Often increases it by half.
        -- Default 12. Minimum=1 Maximum=100 Standard=12
        Safehouse_ChancePercent = 12,
        -- Time between event checks at the same house.
        -- Default 2. Minimum=1,00 Maximum=24,00 Standard=2,00
        Safehouse_CheckHours = 2.0,
        -- Minimum gap between events at one house. Rare doubles the gap; Often halves it, but never below one game day.
        -- Default 2. Minimum=0,50 Maximum=14,00 Standard=2,00
        Safehouse_GapDays = 2.0,
        -- Minimum gap between two visits to the same house.
        -- Default 1. Minimum=1 Maximum=30 Standard=1
        Safehouse_VisitGapDays = 1,
        -- Minimum gap between attacks on the same house.
        -- Default 1. Minimum=1 Maximum=60 Standard=1
        Safehouse_AttackGapDays = 1,
        -- World age before the first attack on a house is allowed.
        -- Default 14. Minimum=0 Maximum=365 Standard=14
        Safehouse_AttackMinDay = 14,
        -- Above this many zombies within 40 tiles of the front door, only armed groups visit.
        -- Default 10. Minimum=0 Maximum=200 Standard=10
        Safehouse_DensityMid = 10,
        -- Above this many zombies within 40 tiles of the front door, nobody visits and notes arrive half as often.
        -- Default 30. Minimum=0 Maximum=400 Standard=30
        Safehouse_DensityHigh = 30,
        -- Above this many zombies within 40 tiles of the front door, nothing is left at the house.
        -- Default 60. Minimum=0 Maximum=800 Standard=60
        Safehouse_DensityExtreme = 60,
        -- Notes and gifts can be left when every resident is at least this far from the delivery point and is not looking toward it.
        -- Default 40. Minimum=10 Maximum=60 Standard=40
        Safehouse_AwayTiles = 40,
        -- Notes and gifts can also be left when every resident is at least this far away, is not looking toward the delivery point and cannot see it.
        -- Default 20. Minimum=5 Maximum=60 Standard=20
        Safehouse_HiddenTiles = 20,
        -- How long a note waits for a safe delivery opportunity before it expires without being delivered.
        -- Default 3. Minimum=1 Maximum=14 Standard=3
        Safehouse_DropDeadlineDays = 3,
        -- Notes go into a mailbox within this distance of the front door. Without one, they are left on the porch.
        -- Default 10. Minimum=2 Maximum=20 Standard=10
        Safehouse_MailboxTiles = 10,
        -- A crew fights when its score reaches this value. Lower means bolder crews, higher means more cautious ones. Default 50. Minimum=0 Maximum=100 Standard=50
        Discretion_FightPercent = 50,
        -- A gun with fewer rounds than this (loaded plus reserve) counts as a melee weapon when a crew weighs a fight. Default 6. Minimum=0 Maximum=30 Standard=6
        Discretion_LowAmmoRounds = 6,
        -- A crew that keeps holding back because of the odds alone commits to the fight after this many seconds if you stay near. Crews short on ammunition or surrounded by zombies never commit this way. Default 45. Minimum=10 Maximum=600 Standard=45
        Discretion_PatienceSeconds = 45,
        -- Careful factions can calm down after provocation once their waiting time passes. Naturally hostile factions and grudges from real attacks do not fade this way.
        -- Default on.
        CalmDown_Enabled = true,
        -- Game hours until a provoked careful faction forgives. Default 2. Minimum=0 Maximum=24 Standard=2
        CalmDown_Hours = 2,
        -- With multiple players, outpost theft blames those inside the outpost rather than everyone. A manhunt keeps its named target instead of switching to the nearest player.
        -- Default on.
        Blame_Fair = true,
        -- NPCs break into a building only when raiding or looting, use an unlocked door first, try a window before smashing a door, and tell before entering a player's base. On by default.
        Breach_Policy = true,
        -- NPCs leave distant zombies alone unless they approach, threaten a friend or are near the NPC's post, helping the group stay on task.
        -- Default on.
        ZombieFocus_Enabled = true,
        -- Zombies inside this distance are always fought. Default 8. Minimum=2 Maximum=30 Standard=8
        ZombieFocus_Radius = 8,
        -- Travelling NPCs avoid zombie groups by skipping buildings, detouring, waiting or backing off. They still fight zombies that are close or coming at them.
        -- Default on.
        Caution_Enabled = true,
        -- How far ahead on their route NPCs watch for zombies. Default 12. Minimum=4 Maximum=30 Standard=12
        Caution_AvoidTiles = 12,
        -- Groups walk in a loose formation instead of one clump, never share a square when calm, and when they stop for a rest they move into a nearby house or shelter and idle there with different jobs: one sits in a corner, one keeps watch, two talk face to face, one comments, one stays quiet, others eat or smoke. Danger breaks it up at once. Off restores the old behaviour. On by default.
        GroupLife_Enabled = true,
        -- How wide a travelling group spreads out. 100 is the normal formation, 50 keeps them closer, 150 spreads them wider, 0 turns the formation off. Default 100. Minimum=0 Maximum=150 Standard=100
        GroupLife_Spread = 100,
        -- Typical length of a group rest, in game minutes. Each rest lasts between half and double of this value. Default 20, so 10 to 40. Minimum=5 Maximum=90 Standard=20
        GroupLife_ShelterIdleMinutes = 20,
        -- While a group rests, every member gets a role (lookout, sitter, talker, commenter, quiet, eater, smoker) with its own spot and pose. Off: they only spread out and stand. On by default.
        GroupLife_Roles = true,
        -- NPCs sometimes sneak (slow, crouched) while moving around town or scavenging. They stop sneaking when they see a player or a hostile NPC. Sneaking NPCs are harder for zombies to notice; the effect follows the zombie sight and hearing settings of the world. On by default.
        Stealth_Enabled = true,
        -- Share of the time a calm NPC or group moves sneaking. Higher near zombies. 0 never, 100 always. Default 30. Minimum=0 Maximum=100 Standard=30
        Stealth_Frequency = 30,
        -- How far zombies notice a sneaking NPC, as a share of the normal distance. Poor zombie sight or hearing makes sneaking stronger, eagle sight and pinpoint hearing weaker. Default 50. Minimum=10 Maximum=100 Standard=50
        Stealth_NoticePercent = 50,
        -- Groups scavenging away from players keep this share of each house's loot value. They stash it at a base or carry it if homeless. 0 disables this loot gain.
        -- Default 25. Minimum=0 Maximum=100 Standard=25
        Offline_LootPercent = 25,
        -- Lets you ask a friendly NPC group to take you in. The group keeps its own plans, offers jobs and warnings, and can leave you behind if you stay away.
        -- Default on.
        Party_Enabled = true,
        -- A group at this size refuses new members. NPCs and players both count toward the limit.
        -- Default 6. Minimum=2 Maximum=12 Standard=6
        Party_MaxSize = 6,
        -- Sets the leader's minimum opinion of you before you can join. Soldiers and raiders require more; gentler groups, such as families, require less.
        -- Default 20. Minimum=-50 Maximum=80 Standard=20
        Party_MinOpinion = 20,
        -- Sets the minimum time between jobs offered by your group leader at calm stops. At 0, automatic offers stop; you can still ask for a job.
        -- Default 45. Minimum=0 Maximum=240 Standard=45
        Party_TaskFrequency = 45,
        -- Sets how long you can stay far from your NPC group before it leaves you behind and your membership ends.
        -- Default 10. Minimum=2 Maximum=60 Standard=10
        Party_AwayMinutes = 10,
        -- Allows settled groups near you to tell stories about their old lives. You can also ask for a story.
        -- Default on.
        Party_Stories = true,
        -- How often an NPC that could shoot a zombie does so. Gunfire draws more zombies, so lowering this makes NPCs walk around zombies, use melee on a lone one, and keep their guns for NPCs and players. They still shoot when cornered, hurt, defending a hurt player, on a horde that blocks the way, or on duty as military or police. 0 means never unless cornered. 100 is the old behaviour. While the world is under 14 days old the default 50 acts as 70, so early NPCs shoot more. Default 50. Minimum=0 Maximum=100 Standard=50
        Combat_GunsVsZombiesPercent = 50,
        -- An NPC holds fire when more than this many zombies are within 25 tiles, unless it is cornered, hurt or defending a hurt player. 0 turns the check off. Default 8. Minimum=0 Maximum=40 Standard=8
        Combat_GunNoiseZombies = 8,
        -- A group of at least this many zombies within 12 tiles that blocks an NPC's route may be shot at, if it is not too loud (see the noise limit). Default 5. Minimum=2 Maximum=30 Standard=5
        Combat_GunHordeSize = 5,
        -- Scales how far zombies and others hear NPC gunfire. At 50, a shot carries half as far. Players and NPCs hear the same reduced range. Lower it on busy servers where NPC shooting pulls hordes across the map. Default 100. Minimum=10 Maximum=100 Standard=100
        Combat_NpcShotNoisePercent = 100,
        -- Sets how many travelling groups each town receives when the world starts. The distant travelling group limit may allow extra groups in larger worlds.
        -- Default 3. Minimum=1 Maximum=4 Standard=3
        Population_SeedPerTown = 3,
        -- Prevents starting travelling groups from being placed this close to a player. Groups may still arrive later. At 0, this starting clearance is disabled.
        -- Default 150. Minimum=0 Maximum=400 Standard=150
        Population_SeedClearTiles = 150,
        -- Blocks new travelling groups when this many already live within 240 tiles. From day 4, the limit drops by one but never below one.
        -- Default 4. Minimum=1 Maximum=8 Standard=4
        Population_NeighbourGroups = 4,
        -- Beyond this distance (60-400 tiles), groups stop travelling, planning and using supplies. Members and loot stay; groups wake on approach without catching up missed time.
        -- Default 150. Minimum=60 Maximum=400 Standard=150
        Population_HibernateTiles = 150,
        -- Blocks new travelling groups in an area of about 120 tiles after NPC deaths. Heavy losses extend the delay. At 0, this delay is disabled.
        -- Default 3. Minimum=0 Maximum=60 Standard=3
        Population_RespawnCooldownDays = 3,
        -- After the death cooldown, limits a recovering area to one new group per interval. At 0, this additional recovery limit is disabled.
        -- Default 2. Minimum=0 Maximum=30 Standard=2
        Population_RegrowthDays = 2,
        -- Keeps spawning, waking and removal away from nearby or watching players. Also reduces rural encounters and prevents checkpoints near players or on dead-end roads.
        -- Default on.
        Spawn_FairnessEnabled = true,
        -- Minimum distance from players for random groups to appear, then walk in. Sight and loaded-map limits also apply; too large a distance can prevent spawns.
        -- Default 45. Minimum=20 Maximum=150 Standard=45
        Spawn_PlayerKeepOutTiles = 45,
        -- Lets welcome and starting-town groups appear nearby during a new character's first minutes. Other groups still obey the normal player clearance.
        -- Default 10. Minimum=0 Maximum=240 Standard=10
        Spawn_StartGraceMinutes = 10,
        -- Restores NPCs after map reloads, removes leftover zombie copies out of sight and clears zombies around returning groups. Blocked groups return farther away. Off removes this protection.
        -- Default on.
        Lifecycle_ReloadGuard = true,
        -- NPCs can become inactive or be removed only when they are at least this far from every player and out of sight.
        -- Default 60. Minimum=0 Maximum=200 Standard=60
        Spawn_DespawnMinTiles = 60,
        -- Sets open-countryside encounters relative to towns. At 50, the rate is half the town rate. Only suitable visitors, such as travellers and hunters, appear.
        -- Default 50. Minimum=0 Maximum=100 Standard=50
        Spawn_RuralDensityPercent = 50,
        -- Sets forest and wilderness encounters relative to towns. At 30, the rate is 30 percent of the town rate.
        -- Default 30. Minimum=0 Maximum=100 Standard=30
        Spawn_WildernessDensityPercent = 30,
        -- Sets farm and ranch encounters relative to towns. At 60, the rate is 60 percent of the town rate.
        -- Default 60. Minimum=0 Maximum=100 Standard=60
        Spawn_FarmDensityPercent = 60,
        -- Blockades and checkpoints are never built within this distance of a player, a player base or a place a player drove through in the last five minutes, and never on dead-end roads. Default 150. Minimum=0 Maximum=400 Standard=150
        Spawn_CheckpointMinTiles = 150,
        -- Adds floor splatter, bleeding drips and death pools, respecting the game's blood settings. Off: only the game's ordinary splatter and body stains remain.
        -- Default on.
        Blood_Enabled = true,
        -- Scales floor splatter, body stains, drips and pools from non-melee deaths. At 100, only the earlier body-stain behavior remains.
        -- Default 200. Minimum=100 Maximum=500 Standard=200
        Blood_Percent = 200,
        -- Size of the blood pool when an NPC is killed with a blade, bat or other melee weapon, and the blood on the attacker. Only used while the NPC blood amount is above 100%. Default 300%. Minimum=100 Maximum=800 Standard=300
        Blood_MeleeKillPercent = 300,
        -- Allows NPCs to react to world sounds and notice nearby players who run or shoot.
        -- Default on.
        Hearing_Enabled = true,
        -- Scales how far NPCs hear sounds. At 50, hearing distance is halved. Indoor player sounds and NPC gunshots use half the resulting range.
        -- Default 100. Minimum=25 Maximum=200 Standard=100
        Hearing_RadiusPercent = 100,
        -- Sets how much hearing distance remains when a wall blocks the sound's path. At 50, a blocked sound can be heard from half as far away.
        -- Default 50. Minimum=0 Maximum=100 Standard=50
        Hearing_WallPercent = 50,
        -- Reduces hearing distance for each floor between the NPC and sound. At 50, one floor leaves half the range; two floors leave one quarter.
        -- Default 50. Minimum=0 Maximum=100 Standard=50
        Hearing_FloorPercent = 50,
        -- Lets NPCs notice a running or recently shooting player behind them on the same floor. At 0, this rear detection is disabled.
        -- Default 8. Minimum=0 Maximum=12 Standard=8
        Hearing_PeripheralTiles = 8,
        -- Sets how long extra awareness from sounds and warnings lasts before the NPC returns to its normal awareness.
        -- Default 20. Minimum=1 Maximum=60 Standard=20
        Hearing_AlertSeconds = 20,
        -- Sets the minimum awareness after an NPC hears a sound. Confirmed contacts and final warnings still give full awareness.
        -- Default 70. Minimum=0 Maximum=100 Standard=70
        Hearing_AlertPercent = 70,
        -- Walking NPCs take short detours around nearby zombie crowds and fresh combat or loud noises. They wait or abandon an unsafe destination when no safe detour is found. Running and combat movement keep their existing rules.
        Caution_DangerRouting = true,
        -- Checks proposed movement legs for burning tiles, lit campfires and water. NPCs reject legs with known hazards. Applies to all movement paces.
        Caution_HazardCheck = true,
        -- Limits extra sight checks for danger detours across all NPCs. Groups wait when the limit is reached. At 0, these extra checks stop; normal perception is unaffected.
        -- Default 32. Minimum=0 Maximum=120 Standard=32
        Caution_DangerRaysPerSecond = 32,
        -- Shooters can advance to nearby cover and briefly step out to fire. Eligible squad gunners provide bounded covering fire. Turning this off cancels active maneuvers.
        Combat_FireManeuver = true,
        -- Maximum length of a forward cover leg. Default 4; range 2-6. Weapon distance and movement safety still apply. Minimum=2 Maximum=6 Standard=4
        Combat_ForwardCoverTiles = 4,
        -- Time at the firing point before returning to cover. Default 1200; range 600-2000. At most two shots; weapon cycles finish normally. Minimum=600 Maximum=2000 Standard=1200
        Combat_PeekWindowMs = 1200,
        -- Maximum covering fire time for one squad maneuver. Default 4000; range 2000-6000. Requires an eligible gunner and a clear friendly-safe line. Minimum=2000 Maximum=6000 Standard=4000
        Combat_PinWindowMs = 4000,
        -- Prefer nearby retreat destinations that hide the NPC from the threat. Existing retreat triggers, stamina and fallback destinations remain in use.
        Combat_RetreatLOS = true,
        -- Expose living Jeem residents as residents through the A-Life compatibility API when the Jeem extension is active. Needs an available actor registry. Does not replace the Companion Dogs patch. Applied at world startup; restart after changing this.
        Compat_JeemResidents = true,
        -- Enable the A-Life compatibility adapter when Point Blank is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_PointBlank = true,
        -- Enable the A-Life compatibility adapter when Wandering Zombies is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_WanderingZombies = true,
        -- Enable the A-Life compatibility adapter when Cye's Push Doors is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_CyesPushDoors = true,
        -- Enable the A-Life compatibility adapter when More Traits Definitive is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_MoreTraits = true,
        -- Enable the A-Life compatibility adapter when Project Exile is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_ProjectExile = true,
        -- Enable the A-Life compatibility adapter when Pixel Strike Indicator is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_PixelStrike = true,
        -- Enable the A-Life compatibility adapter when GaelGunStore-Firearms is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_GaelGunStore = true,
        -- Enable the A-Life compatibility adapter when Project RV Interior is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_RVInterior = true,
        -- Enable the A-Life compatibility adapter when Advanced Trajectory is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_AdvancedTrajectory = true,
        -- Enable the A-Life compatibility adapter when Auto All is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_AutoAll = true,
        -- Let Cry of Fear monsters bite A-Life people when their own attack animation never starts, at the same pace as ordinary zombies. Applied once at world startup; restart after changing this. Does nothing without the monsters mod.
        Compat_CryOfFear = true,
        -- Mark A-Life people as already searched when they appear, so the vanilla zombie pocket loot is not rolled on their bodies. Off keeps the vanilla loot. Use it with mods that add loot to zombies.
        -- Default off.
        Compat_NoPocketLoot = false,
        -- Maximum work units per round. Higher values finish sooner but may increase server stalls. Multiplayer streaming pauses still apply.
        -- Default 100. Minimum=1 Maximum=2000 Standard=100
        Outposts_BuildBudget = 100,
        -- Limits new walled compounds. At 0, none are proposed. Existing sites, small camps, checkpoints and admin-built sites stay.
        -- Default 1. Minimum=0 Maximum=40 Standard=1
        Outposts_MaxCompounds = 1,
        -- Minimum distance between new walled compounds. Recently expired sites count until cleared. Small camps and fixed checkpoints are unchanged.
        -- Default 500. Minimum=0 Maximum=5000 Standard=500
        Outposts_CompoundSpacing = 500,
        -- Keeps campfires, lamps and generators in outposts, compounds, checkpoints and camps burning and switched on, refuelled while a player is near. Off leaves them as built.
        -- Default on.
        Outposts_LightsOn = true,
        -- Chance for each carried item to stay on an NPC's body. 100 drops all items; lower values drop fewer. Fixed NPC weapon drop chances take priority. Use wear below for poorer gear.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Loot_NpcDropPercent = 100,
        -- Wear added to gear and ammo on death. 0 adds no wear; 100 is full. Fixed NPC weapon conditions take priority. Guns can still drop broken: set Dropped weapon condition for working guns.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Loot_NpcWearPercent = 100,
        -- Multiplies the NPC loot percent for guns and melee weapons. Ignored while NPC weapon drop chance is a fixed choice. For example, 50 halves weapon drops.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Loot_NpcWeaponPercent = 100,
        -- Multiplies the NPC loot percent for worn armor and clothing, including rare armor. For example, 50 halves armor drops.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Loot_NpcArmorPercent = 100,
        -- Multiplies the NPC loot percent for dropped magazines and loose ammo. For example, 50 halves ammo drops.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Loot_NpcAmmoPercent = 100,
        -- Multiplies the NPC loot percent for food, medicine, tools and pocket items; identity cards always stay. For example, 50 halves supply drops.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Loot_NpcSuppliesPercent = 100,
        -- Door visits bring named individuals and small groups with their own history, needs and conversation. Off: visits work exactly as before.
        -- Default on.
        Visitors_Persons = true,
        -- How often a guest inside your home starts talking by themselves, for example asking about the TV. Rare waits longer, Often waits less. Off: guests only answer when you talk.
        -- Default Normal (3). Standard=Normal
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Often
        Visitors_ProactiveEvents = 3,
        -- Real seconds that must pass after a guest speaks up before the same player is prompted again. Higher is calmer.
        -- Default 240. Minimum=60 Maximum=1800 Standard=240
        Visitors_EventMinGapSeconds = 240,
        -- A guest never stays inside longer than this. Most guests leave sooner. Raise it to let people ask to stay for a few nights; more time inside means more risk and more help.
        -- Default 1. Minimum=1 Maximum=48 Standard=1
        Visitors_StayHours = 1,
        -- Pairs and trios of related people can knock together instead of one stranger at a time. Off: one visitor per visit.
        -- Default on.
        Visitors_Parties = true,
        -- Once you have really helped someone, this chance decides whether a later visit is that person coming back. 0 means never.
        -- Default 15. Minimum=0 Maximum=50 Standard=15
        Visitors_ReturningChance = 15,
        -- Guests inside your home walk around, sit on furniture, read and look out of windows instead of standing where they were let in. Off: they stand still.
        -- Default on.
        Visitors_Life = true,
        -- Adult guests can ask for clean clothes and change in a closed room, down to the default body and never beyond. Off: no clothes changes.
        -- Default on.
        Visitors_ChangeClothes = true,
        -- Strict: a guest only changes in a room with the door shut, and not while you stand near the door. Normal: the door may be open.
        -- Default Strict (1). Standard=Strict
        -- 1 = Strict
        -- 2 = Normal
        Visitors_Privacy = 1,
        -- Adult guests can show gentle, optional, non-explicit warmth after real trust and always accept a no. Off: no flirting at all.
        -- Default On (2). Standard=On
        -- 1 = Off
        -- 2 = On
        Visitors_Flirt = 2,
        -- Guests can carry and read books and newspapers and discuss them with you. Off: no book conversations.
        -- Default on.
        Visitors_Books = true,
        -- Words spoken by guests also appear in the chat window, not only as speech bubbles. Needs the chat mirror of the talk interface.
        -- Default on.
        Visitors_ChatMirror = true,
        -- Adds extra visitor lines to the QA dump and the flight recorder to help find problems. Leave off for normal play.
        -- Default off.
        Visitors_Debug = false,
        -- Established outposts can send three existing squads together. Their people leave the site; this does not create extra survivors.
        -- Default on.
        Outposts_TrioEnabled = true,
        -- Game days between coordinated departures from each outpost. Set 0 to stop these departures.
        -- Default 5. Minimum=0,00 Maximum=120,00 Standard=5,00
        Outposts_TrioGapDays = 5.0,
        -- Maximum outposts with a coordinated group away at once. Set 0 to stop departures. The War Challenge raises this limit to 3.
        -- Default 2. Minimum=0 Maximum=8 Standard=2
        Outposts_TrioMaxActive = 2,
        -- An outpost must exist this many game days before sending three squads. At 0, a new site can qualify if it has enough people.
        -- Default 7. Minimum=0,00 Maximum=120,00 Standard=7,00
        Outposts_TrioMinAgeDays = 7.0,
        -- Automatic keeps these groups off on Light difficulty and on otherwise. Choose Off or On to override that rule in any world preset.
        -- Default Automatic: off on Light, on otherwise (1). Standard=Automatic: off on Light, on otherwise
        -- 1 = Automatic: off on Light, on otherwise
        -- 2 = Off
        -- 3 = On
        Outposts_MegaEnabled = 1,
        -- Game days between large-group departures from each outpost. They use existing people and weaken the site while away. Set 0 to stop departures.
        -- Default 12. Minimum=0,00 Maximum=120,00 Standard=12,00
        Outposts_MegaGapDays = 12.0,
        -- People combined from an outpost and its existing squads. A site without enough people cannot send the group. Rendering remains spread across frames.
        -- Default 16. Minimum=12 Maximum=40 Standard=16
        Outposts_MegaSize = 16,
        -- Maximum large marching groups away at once, with one per faction. Set 0 to stop departures. The War Challenge raises the world limit to 2.
        -- Default 1. Minimum=0 Maximum=8 Standard=1
        Outposts_MegaMaxActive = 1,
        -- An outpost must exist this many game days before sending a large group. At 0, a new site can qualify if it has enough people.
        -- Default 10. Minimum=0,00 Maximum=120,00 Standard=10,00
        Outposts_MegaMinAgeDays = 10.0,
        -- Adds rare, tougher hostile factions after their earliest day. Their weapons and clothing use existing game items. Off keeps these new factions out.
        -- Default on.
        Late_FactionsEnabled = true,
        -- Earliest world day for the new raider and hazmat factions. Special forces have a separate earliest day. At 0, no minimum day applies.
        -- Default 14. Minimum=0 Maximum=3650 Standard=14
        Late_FactionStartDay = 14,
        -- Scales later weapon, ammunition and armour progression for new groups after day 13. The early worn-weapon curve stays unchanged. Set 0 to disable this progression.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Late_WeaponScalePercent = 100,
        -- Earliest world day for rare four-to-six-person special forces groups. At 0, no minimum day applies; late hostile factions must still be enabled.
        -- Default 21. Minimum=0 Maximum=3650 Standard=21
        Late_SpecialForcesStartDay = 21,
        -- Chance to react to a distant hit, close bullet crack or witnessed killing. People need a real cue, not knowledge of a hidden shooter. Set 0 to disable.
        -- Default 100. Minimum=0 Maximum=100 Standard=100
        Combat_SniperAwareness = 100,
        -- Shots from at least this many tiles can trigger distant-fire reactions. Scoped rifles can qualify closer; normal sight and ownership checks still apply.
        -- Default 40. Minimum=10 Maximum=200 Standard=40
        Combat_SniperAwarenessTiles = 40,
        -- Volume of human footsteps for nearby A-Life survivors on this computer. Set 0 to turn them off. Does not change noise heard by zombies.
        -- Default 100. Minimum=0 Maximum=200 Standard=100
        Audio_NpcFootsteps = 100,
        -- Military checkpoint crews are hostile by default and warn once before firing. Off restores their careful stance. Earned relations and combat safety still apply.
        -- Default on.
        Outposts_BridgeHostile = true,
    },
    ALifeDriving = {
        -- NPC driving, passenger crews and automatic multiplayer control handover. Driving debug controls require admin access.
        Enabled = true,
        -- By car spawns create functioning vehicles with seated NPC crews. They drive to a reachable nearby road and dismount. Requires loaded terrain.
        VehicleArrivals = true,
    },
    ALifeJimmy = {
        -- No NPC spawns in player bases (right-click > [A-Life Jimmy] Bases), and non-hostile NPCs won't break, pick or scavenge anything inside.
        Base_Protect = true,
        -- NPCs open doors they can open, but only smash windows, break doors, pull down barricades or pick locks when they're looting or raiding, and only when there's no door they could open instead. When forcing their way in they go for a window before a door (much quicker), and looters may use windows when a building's doors are all locked. Everyone else goes another way or somewhere else.
        Breach_Policy = true,
        -- NPCs don't choose spots inside your grounds to wander to, and anyone who lingers there without belonging (6 seconds) walks back out. Not your residents, people following a player's orders, captives, raiders or anyone fighting a player, or someone you're standing next to (talking or trading).
        Base_KeepOut = true,
        -- NPCs fighting a player, and raiders, may still break doors and barricades in base areas, and walk past door and window markers anywhere. Off: bases and markers hold them too.
        Base_HostileCanBreach = true,
        -- Your residents shut a door or window of their base behind them once they've gone through and nobody is in the way, and one they opened in passing (one you opened or left open stays as it is). An outside door that was locked locks again. Off: doors and windows they open stay open.
        Base_ShutDoors = true,
        -- Right-click a door or window > [A-Life Jimmy] to mark it No trespassing (NPCs who don't belong keep out; your residents, people on your orders and captives may pass) or Private (everyone keeps out, your residents too). Raiders and anyone fighting a player pass both while Attackers can breach bases is on. NPCs can always get out, and shut a marked door they opened behind them (never one you opened or left open).
        Doors_Marks = true,
        -- How many bases each player (or vanilla faction) may mark. Admins aren't limited. Minimum=0 Maximum=20 Standard=2
        Base_MaxBases = 2,
        -- Rectangles (main, quarters, yard) one base may have. Admins aren't limited. Minimum=1 Maximum=30 Standard=6
        Base_MaxAreas = 6,
        -- Tiles a resident crew stands guard on. Admins aren't limited. Minimum=0 Maximum=40 Standard=8
        Base_MaxPosts = 8,
        -- Right-click near an allied crew to invite them to one of your bases. They stand guard at your guard posts, live in the quarters and defend the base. A-Life never builds there.
        Residents_Enabled = true,
        -- People living at your base become members of an A-Life faction for your group (civilian, never spawns on its own), keeping their looks; restyle them in A-Life's Faction & NPC Creator. They go back to their old faction if they leave. Single player: A-Life keeps this faction in a file shared by all your SP worlds.
        Residents_JoinFaction = true,
        -- In A-Life's conversation, people living at your base talk to you as their own people, not as strangers: they greet you by name, call the base home, don't ask to join or offer you a walk, and A-Life's stranger, robbery and recruiting choices are hidden for them. On A-Life 1.4 their window gets a Home tab (how they're holding up, what they're on, base news, how long they've been here, what they think of you), and their small talk at the base is about the base. Off: A-Life's own lines, as before.
        Residents_Talk = true,
        -- When one of your residents gets a new kind of task (a guard post, a body to move, a weapon to fetch, a job) they say a short line, like "Heading to the Gate." At most one line each every 45 seconds, only with a player nearby. Standard=Text and voice
        -- 1 = Off
        -- 2 = Text only
        -- 3 = Text and voice
        Residents_Announce = 3,
        -- Guards take turns on the posts, by the schedule or by tiredness: each base picks with Shifts by on its Schedule tab (the setting below is the default). By tiredness, on posts you haven't pinned anyone to, a rested resident relieves a tired guard (needs tiredness to be on). A tired guard sits down at the post (and gets up to fight). Off: posts are filled in order and nobody takes turns - no schedule and no Trip shifts (the setting below does nothing).
        Residents_Shifts = true,
        -- The default for a base that has not chosen: each base picks its own on the Schedule tab (Shifts by), and that choice wins over this option. The schedule (the default for a new world): three 8-hour shifts (day 06-14, evening 14-22, night 22-06) and a schedule per resident - a guard post, work, training, a trip, free time, sleep - dealt by the base itself (Auto-schedule, on by default) or set by hand. 20 minutes before a shift starts the relief walks up beside the post, and only then does the guard go off duty. Tiredness (automatic): a rested resident relieves a tired guard, as before; pins and jobs work as they do today. Switching between the two keeps what you set up: pins and picks become schedules, and a schedule is parked while shifts go by tiredness and comes back when they go by the schedule again. A world from before the schedule goes on it too when you load it: pins become Guard cells, workers the Worker role, and Auto-schedule deals in the rest; a base that prefers tiredness presses Shifts by on its Schedule tab. There is no 12-hour watch any more: a guard who stands two shifts in a row covers 16 hours. Standard=The schedule
        -- 1 = Tiredness (automatic)
        -- 2 = The schedule
        Residents_ShiftMode = 2,
        -- Residents off a post live their day with animations of their own, with either kind of guards' shifts. They sleep in their room in their sleep window (in their own bed with Residents sleep in beds on): with Shifts by: The schedule, their Sleep shift (15-45 minutes in, to its end, or to the call before a Guard, Work or Train shift); otherwise (tiredness) about 22:30 to 06:30. Worn out, they take a two-hour nap. They eat and drink in their room at meal times - about one, six and twelve hours after their sleep shift ends, so around 07:00, 12:00 and 18:00 for someone who sleeps at night (and for everyone with tiredness shifts) - or when hungry or thirsty, unless the base is out of food. Otherwise they relax on the floor in their room, read, exercise or have a smoke (outside by day), which keeps them from wandering in and out of the house. Danger wakes them at once, and when a real threat gathers at the base (one of the crew fighting people, hostile people close by, zombies in numbers) everyone off duty gets up until it has passed, with a note for you. Workers and trainees keep their work. Off: as before.
        Residents_DayPlan = false,
        -- Each resident gets a bed of their own in their quarters (a double bed sleeps two; everyone has a bed to themselves before anyone shares), kept until the beds or their quarters change. In their sleep window they walk to it, get in and lie down to sleep, and get up out of it at the end, at an alarm, when danger comes or when you talk to them. With no bed free, or none they can get to, they sit down and doze. Their task says Asleep only while they really are, else Going to bed, Dozing, Getting up or Resting. With the day plan off this still runs for the schedule's Sleep shifts. Off: they sit beside a bed as before.
        Residents_Beds = true,
        -- When a real threat comes to a base, everyone living there gets up and the crew off the guard posts go to it. It goes off when one of the crew is fighting people, shot or killed at the base, a raider is within 40 tiles, two other hostile people are within 25, hostile people drive up, a loud noise near the grounds comes with hostile people about (A-Life 1.4), or zombies gather in numbers by a building or a sleeper. Sleepers stand up, training and work pause (the task says Alarm), and those off a post head for the fight, with a longer reach while it lasts; the guards hold their posts, and with more than three going one stays in each quarters. It lasts 15 minutes after the last sign of the threat, with a note in the base's News. A loud noise alone sends whoever is awake to look, without waking anyone. Off: they react only to what each of them sees.
        Residents_BaseAlarm = true,
        -- Your people inside their own base behave like people at home. Nobody sneaks about (A-Life's Stealth specialty and its quiet walking). Nobody leaves the base to look for a zombie that went out of sight past the fence, or walks out to a noise past it (someone who shot at them is still hunted). Nobody goes to check a noise made by their own crew or by you, or treats the base's own barricades, generators and cars as clues to search. Guards stay on their posts unless a crewmate close by calls for help. The early-outbreak panic doesn't grip them. A real threat changes all of it: someone they see and fight, the base alarm, a mission, an escort. Off: A-Life decides as it does everywhere else.
        Residents_HomeCalm = true,
        -- With a working two-way radio (a walkie-talkie in your inventory, or a ham radio you stand next to: on, with power), right-click it > Call your people: a status check of your bases (who's at home, on a post, asleep, out, hurt or bitten, and the alarm), Come to me (1, 2 or 4 of the people off the guard posts, or one by name, follow you as an escort for a day), Hold the base (everyone at home up and alert for an hour), Sound the alarm, Stand down and Head home. The base must be within the reach of both your radio and the base's own radio. People you call travel unseen and come into view about 40 tiles from you, after about one game hour per 400 tiles. Off: no radio menu.
        Radio_Enabled = true,
        -- How far each base's own radio reaches, in tiles. A call goes through when the base is within both this and your radio's own range (750 tiles for a toy walkie-talkie, 2000 for an ordinary one, up to 20000 for military and high-end radios). A radioman living at the base doubles it. Minimum=100 Maximum=20000 Standard=4000
        Radio_BaseRange = 4000,
        -- Off duty, residents spread out over the quarters' rooms instead of crowding the middle, keep away from bodies, and at night rest beside the beds.
        Residents_RestSpots = true,
        -- When a resident dies the others mourn for three game days: one of them says something, they fight worse if the base is raided, and they turn on whoever did it (a player who isn't one of the base's people, or an NPC crew you can then send people to hunt).
        Residents_Grief = true,
        -- A-Life 1.4 only. A resident whose opinion of the base's people stays at A-Life's worst (Hates you) for 6 game hours leaves, as if sent away: no grudge, back to their old faction. Only hours with one of the base's people online count. They wait until they're home, off shift and awake. An admin's Clear opinions or a kind act before then puts it right.
        Residents_LeaveWhenHated = true,
        -- An off-duty resident carries zombie corpses out of the base to its body dump, one at a time. Set a dump from the Bases menu; with none, bodies are left where they are.
        Residents_ClearBodies = true,
        -- Residents can be given a mission or a clean-up duty that repeats at the same hour (faction window > People > Every day...). It runs by the game clock, whether or not the player who set it is online. At a base whose shifts go by the schedule it also runs the Trip shifts (Scavenge, Patrol, Patrol an area) and the Scavenger role. Off: nothing runs; saved routines and Trip shifts are kept, a Trip shift counts as Free and a Scavenger stands watch like an All-rounder.
        Residents_Routines = true,
        -- A routine never sends out so many that fewer than this many residents stay at the base, and Auto-schedule keeps a Scavenger home for the same; a Trip shift you put in someone's schedule yourself goes regardless. Pinned guards and workers are never picked automatically, and at a base on the schedule a routine takes only people on a Free shift. Minimum=0 Maximum=12 Standard=2
        Residents_RoutineKeepHome = 2,
        -- A crew only moves in if the base's quarters have a bed for each of them: single beds and sleeping bags hold 1, double beds 2, bunk beds twice that. Residents per base still caps it.
        Residents_NeedBeds = true,
        -- Residents eat 1 supply a day each and scrounge half that themselves; mark a container as a Food store (My people > Bases > Stores...) and they eat from it when their supplies run low. Out of food for 7 days, they leave. Off: they never go hungry, and only take enough from the Food store for training and trades (medicine in a Medical store still heals).
        Residents_NeedFood = false,
        -- Off: the crew never touches containers in the quarters, so your things are safe there; they only take what they need from containers you mark as stores (My people > Bases > Stores..., or right-click a container > Bases > Store). On (the old way): every 10 minutes while nobody is near, food, drink, smokes and medicine in the quarters' containers become supplies, and ammo and weapons go to their armory. Containers marked as stores are always left out of it.
        Residents_QuartersIntake = false,
        -- A-Life gives about half of all groups a flashlight beam at night (19:00 to 07:00), and a base's residents share one group. Not indoors (the default): residents put the light away while they sleep, sit, or are inside one of the base's buildings (a main building or quarters), and take it out again outside: on a post in the yard, on patrol, escorting you, on a trip. Traders visiting a base do the same inside its buildings. Always: A-Life's way, the light on wherever they are. Never: residents and visiting traders never carry one. Their night sight stays the same either way. Standard=Not indoors at the base
        -- 1 = Not indoors at the base
        -- 2 = Always (A-Life's way)
        -- 3 = Never
        Residents_Flashlights = 1,
        -- How many NPCs may live at one base (default 12, up to 30), whatever the beds say; beds in the quarters are the other limit. A crew only moves in if all of them fit. Minimum=0 Maximum=30 Standard=12
        Base_MaxResidents = 12,
        -- Longest side of one base area, for players. Admins may mark up to 400. Minimum=10 Maximum=400 Standard=80
        Base_MaxSide = 80,
        -- Hostile groups may attack a base with residents while no player is within 110 tiles (from day 7, at most every 3 days a base). Guard posts help; a crew out of food fights worse. Nobody takes the base over.
        Bases_Raids = true,
        -- Per hostile group within 80 tiles, checked every game hour while you're away. Minimum=0 Maximum=100 Standard=5
        Bases_RaidChance = 5,
        -- Under the name of someone living at your base: what they're meant to be doing (on guard, working, carrying a body, patrolling...), how far they are from where they should be, and whether they're stuck. Their spot is highlighted. Only for your own bases.
        NpcTags_Tasks = true,
        -- Under an NPC's name: keeping their distance from you, attacking you, protecting you, fighting zombies, checking out a noise, searching, scavenging, running away... So someone marked hostile who isn't attacking shows why.
        NpcTags_Intent = true,
        -- Outpost theft only angers the garrison at the players who were inside; avengers only hunt someone who actually killed that outpost's people; manhunters never switch to a bystander.
        Blame_Fair = true,
        -- Deeds move points with each faction; your standing moves one step at a time from the faction's default (hostile, careful, neutral, friendly, allied). Attacking or killing costs points instead of turning a faction hostile forever (the people you fought still turn on you). Helping them and gifts raise it.
        Standing_Enabled = true,
        -- Scales every standing gain (gifts, help). Factions also differ: families trust readily, raiders and hostile factions slowly. Minimum=0 Maximum=500 Standard=100
        Standing_GainRate = 100,
        -- Scales every standing loss (attacks, killings). Law and military take violence hardest, raiders and gangs least. Minimum=0 Maximum=500 Standard=100
        Standing_LossRate = 100,
        -- Puts a Reset standing button on everyone's Standing tab in the faction window: it wipes their standing points with every faction and crew. Admins can always reset. NPCs' own grudges stay.
        Standing_PlayersMayReset = false,
        -- With A-Life's per-person opinion on, a faction's standing with you is built from what its people think of you, what the faction remembers (your old points, and what people who are gone thought of you) and rumours. Hits, kills and help in a fight count through the people (they fade as A-Life's opinions do); gifts, trades and the rest add to what the faction remembers. Off: your standing points alone decide, as before.
        Standing_OneReputation = true,
        -- Food and medicine become supplies (growth; medicine heals defenders), guns, ammo and melee weapons go to the outpost's armory (defenders use them in sieges). Players who were inside recently gain standing with that faction (capped per day). Taken in once you're 40+ tiles away.
        Donations_Enabled = true,
        -- When you start talking, NPCs may bring up real things you did to their faction or crew (gifts, help, attacks, killings) with where and when it happened. Only deeds their faction has heard about.
        Memories_Enabled = true,
        -- Say 'take this' (or 'here you go', 'this is for you') to someone who isn't hostile while holding an item: they take it and your standing with their faction rises. Outpost members pass supplies and weapons on to their outpost.
        HandGifts_Enabled = true,
        -- Right-click one of your residents or someone following you > Equip (or 'Gear up for this.' in conversation): hand them weapons, clothes (residents) and gear from your inventory for a trip, and take any of it back whenever you like. No prices, no standing. Ammo that fits their gun goes into their spare rounds and isn't given back.
        Equip_Enabled = true,
        -- When someone you equipped stops following or waiting for you (for a quarter of an hour), what you lent them goes back into your inventory if you're within 30 tiles, or else a resident's goes into their base's stores and anyone else's waits until you're near. Off: they keep it until you take it back.
        Equip_AutoReturn = true,
        -- Now and then a few traders from a peaceable faction that you get on with walk to one of your bases, wait a few tiles outside the grounds and trade through the Trade window (right-click them, or say: want to trade). They sell food, medicine, tools, general goods or guns and ammo, and pay for what they want. Needs Trade (hand gifts) on.
        Traders_Enabled = true,
        -- Percent, each game hour from 7:00 to 17:00, that a base with one of its people online nearby gets traders. 3 is about one or two visits a week for a base someone plays at most days. 0: no visits (the debug menu still sends them). Minimum=0 Maximum=100 Standard=3
        Traders_Chance = 3,
        -- Game hours after traders leave a base before the next visit there can happen. Minimum=6 Maximum=336 Standard=48
        Traders_CooldownHours = 48,
        -- The world day from which traders visit. Minimum=0 Maximum=60 Standard=3
        Traders_MinDay = 3,
        -- Game hours traders wait once they've reached your base (a little longer if you're in the middle of trading). They leave sooner if they sell out or the base is raided. Minimum=1 Maximum=24 Standard=6
        Traders_StayHours = 6,
        -- A trader plus guards. More people means more who can fight off zombies while they wait, and more NPCs on the map. Minimum=1 Maximum=4 Standard=2
        Traders_PartySize = 2,
        -- Now and then a gunsmith comes, selling guns, ammo and gun parts. Off: never.
        Traders_Guns = true,
        -- Attack, hold up or kill a trader and the rest run; no traders visit that base for this many days. Traders killed by zombies bring no penalty. Minimum=0 Maximum=60 Standard=14
        Traders_BanDays = 14,
        -- A visiting trader can be asked to live at your base (Would you stay with us?). They need friendly standing with their faction, to like you (or a trade first), a free bed and some supplies. They keep a stall, restock from their faction, buy what you put in a Trade goods store and trade through the Trade window. Off: nobody can be asked, and a trader who stayed is an ordinary resident.
        Traders_CanStay = true,
        -- On A-Life 1.4 with its NPC opinions on: how much the trader must think of you (16 is Likes you, 41 Trusts you). Without opinions they want one trade with you first. Minimum=-100 Maximum=100 Standard=16
        Traders_StayOpinion = 16,
        -- Taken from the base's supplies when a trader agrees to stay. 0: free. Minimum=0 Maximum=100 Standard=10
        Traders_StayCost = 10,
        -- Every this many game hours a trader living at your base gets fresh goods from their faction (about half of what a visit brings, up to twice a visit's most of each). Minimum=6 Maximum=168 Standard=24
        Traders_RestockHours = 24,
        -- With Sell what we can spare, a resident trader sells only what the base's Food and Medical stores hold beyond this many items of each. Minimum=0 Maximum=200 Standard=20
        Traders_SurplusKeep = 20,
        -- With friendly standing, say 'follow me', 'wait here' or 'go away' to someone (or answer yes to 'Maybe we can work together?'): their crew follows you for 3 game hours or holds its spot for 6. At most 4 followers.
        Friendlies_Enabled = true,
        -- Your own people and anyone following or waiting for you never complain or get scared when your gun points their way. Allies don't either while a fight is on around them. Anyone hostile to you or fighting you still reacts as usual.
        AimCalm_Enabled = true,
        -- NPCs normally only fight other NPCs their faction is at war with. With this on, anyone hostile to you is hostile to your residents too (anywhere, and while you are away: a grudge against the base owner, a raid, a faction hostile to all players). Allied NPCs step in within 25 tiles of you, friendly ones only when it is right on you (6 tiles). It fights back.
        Defenders_Enabled = true,
        -- A crew you've helped (or wronged) enough treats you by its own standing, not just its faction's: a crew that owes you stays friendly even if its faction turns hostile, and the other way round. A grudge or a raid still wins.
        CrewStanding_Enabled = true,
        -- How many times one of your own people or an ally lets it go when you hit them (within 10 minutes): no anger, no grudge, no lost standing, they don't fight back. The next hit turns that one person against you, never their faction or crew. Killing still counts as killing. 0: off (A-Life's own rule only). Minimum=0 Maximum=10 Standard=2
        FriendlyFire_Forgiven = 2,
        -- Once a faction hears what you did, the story reaches other factions over the next day or so - weaker, and sometimes exaggerated, played down, lost or pinned on someone else. The victim's friends think less of you, their enemies a little better; raiders barely care about violence, the law cares most. Rumors fade over a few days and on their own never make a faction hostile (careful at worst). Harm to people who were hostile to you angers nobody. Off by default.
        Rumours_Enabled = false,
        -- Emotes count as saying the matching thing to the nearest person you face: wave = hello, follow me / come here = follow, stop / freeze = wait, move out = go away, thank you, thumbs up, insult, yes / no answer their questions.
        Emotes_Enabled = true,
        -- Aim a gun at an NPC and tap the shout key (Q). They may surrender: hands up, and you can make them drop their weapon or empty their pockets, or let them go. If they refuse, they hold a grudge.
        Intimidation_Enabled = true,
        -- A-Life has hold-ups of its own (orders in the talk window). A-Life's: Q while aiming gives its orders (hands up, then hand over weapons, then empty pockets), with ours on top: the disarmed stay disarmed, standing, grudges, Mercy. Ours: our own hold-ups (Q) beside A-Life's, one owner per NPC. Talk window only: Q is the game's own shout. Standard=A-Life's, Q gives its orders
        -- 1 = A-Life's, Q gives its orders
        -- 2 = Ours
        -- 3 = Talk window only
        Intimidation_Mode14 = 1,
        -- A-Life weighs a hold-up its own way. On: someone hurt, frightened or in pain gives in more easily, and crew-mates you killed lately make them more or less likely to (by who they are), up to 30 points either way. Only with Hold people up at gunpoint on.
        Intimidation_Odds14 = true,
        -- Told to drop their weapon or empty their pockets, someone who surrendered may refuse: run for it, or (still armed) fight. More likely when they're angry with you, hostile, or have the numbers; less when they're wounded or peaceable.
        Intimidation_Defiance = true,
        -- How long someone who surrendered stays put with nobody aiming at them before they may make a break for it (checked every 3 seconds after that). Walk more than 30 tiles away and they slip off anyway. Only with 'Captives may refuse orders' on. Minimum=3 Maximum=300 Standard=15
        Intimidation_CoverSeconds = 15,
        -- Someone you let go after a hold-up remembers how you treated them. Treated well, they may put in a good word or their crew may offer to join you; robbed or hurt, they may warn everyone or their squad may come after you. Killing someone who surrendered costs extra standing and brings revenge.
        Mercy_Enabled = true,
        -- A-Life only saves squads and a few outposts. Promoted keeps crews you've interacted with; All keeps every living NPC. Standard=Promoted crews
        -- 1 = A-Life default
        -- 2 = Promoted crews
        -- 3 = All living NPCs
        Persist_Mode = 2,
        -- Minimum=0 Maximum=500 Standard=150
        Persist_Cap = 150,
        -- Once an outpost has been manned it no longer expires of old age; it falls only when its garrison is wiped out. One that is never built or manned still expires as in A-Life. Scripted events are unaffected.
        Outposts_Permanent = true,
        -- When a player talks to (or fights) an encounter crew, it becomes a real squad: it lives on off-screen, travels and scavenges, and is saved with the world. Uses a roaming-squad slot.
        Promote_Enabled = true,
        -- A crew you fight carries on as a real squad - whether you hit them first or they opened fire on you. Survivors remember it through faction reputation.
        Promote_OnFight = true,
        -- A crew that robs you and walks away carries on as a real squad you may meet again.
        Promote_OnRobbery = true,
        -- A-Life fills its roaming-squad cap quickly in a new world. Crews you interact with can still be promoted past it, up to this many at once. Minimum=0 Maximum=50 Standard=10
        Promote_MaxExtra = 10,
        -- Off-screen squads head to an outpost of their own faction and join its garrison; they appear there the next time you're nearby. Calls for help are answered by the outpost's own faction. Fewer groups roam as a result.
        Homes_Enabled = true,
        -- Per squad, per game hour, when an outpost of its faction has room nearby. Doubled when the garrison is under half strength. Minimum=0 Maximum=100 Standard=4
        Homes_JoinChance = 4,
        -- Squads only consider outposts within this distance. Calls for help reach any distance. Minimum=100 Maximum=5000 Standard=900
        Homes_JoinRadius = 900,
        -- A small squad (3 or fewer) with no outpost of its own nearby may move in with a friendly peaceable faction, like a lone nurse joining a family. They keep their own faction.
        Homes_Mixed = true,
        -- This share of squads never settle down or join an outpost. Minimum=0 Maximum=100 Standard=30
        Homes_NomadShare = 30,
        -- For squads of 1-3 whose faction has no outpost nearby. The home (a holdout, forest camp or held house, whatever the faction uses) is placed when a player is 60-150 tiles from their town, never within 40 tiles of a player, never in a base area or a building a player has been in. Minimum=0 Maximum=100 Standard=2
        Homes_FoundChance = 2,
        -- Real garrison members leave to scavenge or patrol and come back (or don't). Replaces A-Life's outpost squads, which appear from nowhere and never return. Members only leave while no player is within 120 tiles, and the garrison never drops below its minimum.
        Expeditions_Enabled = true,
        -- Outposts spend supplies from expeditions (and a little foraging) to add a supply crate and campfire, then a fence with a gate at the main door, then take over a neighbouring building. Only placed while no player is within 40 tiles. The main entrance is never blocked.
        Growth_Enabled = false,
        -- When an outpost's garrison is wiped out, its barricades, fences, crates (and their loot) stay standing instead of vanishing. New groups prefer to settle in ruins of a type their faction uses.
        Ruins_Keep = true,
        -- When A-Life's groups fight each other away from players, the fallen are left where it happened, dressed as who they were. Bodies appear the next time a player comes within about 110 tiles (never within 40, never in a base area).
        WarDead_Enabled = true,
        -- Away from players, a group may attack an outpost of a faction it's hostile to (A-Life's own faction stances; peaceable factions never do). Fences and buildings help defenders. Outposts that lose everyone fall and leave ruins, and the attackers may move in.
        Sieges_Enabled = true,
        -- Per eligible group and outpost within 80 tiles. Each outpost can be attacked at most every 2 days. Minimum=0 Maximum=100 Standard=15
        Sieges_Chance = 15,
        -- Across the whole map. 0 turns sieges off. Minimum=0 Maximum=50 Standard=3
        Sieges_PerDay = 3,
        -- An outpost whose faction counts a player as Friendly defends this much better in off-screen sieges. Minimum=0 Maximum=200 Standard=15
        Sieges_FriendlyBonus = 15,
        -- The same, for a faction that counts a player as Allied. Minimum=0 Maximum=200 Standard=30
        Sieges_AlliedBonus = 30,
        -- Each gun given to an outpost goes to one of its guards, with some of its ammo; they carry it the next time they spawn and drop it if killed.
        ArmedGuards_Enabled = true,
        -- Give NPCs longer before a path counts as stuck, and before they give up. Turn off for a baseline session.
        Tuning_Enabled = true,
        -- How long without progress before a move counts as stalled. A-Life default 800. Minimum=500 Maximum=10000 Standard=800
        Tuning_StallMs = 800,
        -- Time allowed for the pathfinder to start moving. A-Life default 1600. Minimum=1000 Maximum=20000 Standard=1600
        Tuning_StartupGraceMs = 1600,
        -- A-Life default 3. Minimum=1 Maximum=20 Standard=3
        Tuning_MaxStalls = 3,
        -- Checks (every 0.5s) before a player's game lets go of an NPC it no longer owns. Higher means fewer resets when players move near each other. A-Life default 3. Minimum=1 Maximum=40 Standard=8
        Tuning_OwnershipLossReads = 8,
        -- When deciding whether a roaming squad may appear, ignore encounter crews and camps.
        Crowding_SquadsOnly = true,
        -- In multiplayer, when a different player's game takes over an NPC, it resumes chasing or searching where the last owner left off instead of forgetting.
        Handoff_Enabled = true,
        -- Fixes for bugs inside A-Life itself. NPCs are put away before the area around them unloads, so they don't come back as zombies (single player and servers). In multiplayer, NPCs left frozen are rebuilt. NPCs inside a building can unlock its key-locked doors, as a player there could, and knock broken glass out of a window before climbing through. On servers, zombies no longer drop masks and hats they aren't wearing (clothing left on reused zombie bodies). Also removes an error that filled the log. Off brings these bugs back.
        AlifeFixes_Enabled = true,
        -- A zombie the game creates inside a base's main building or quarters, or on an upper floor anywhere in a base, as the area loads or the zombie population fills it, is removed in the moment it is made, before anyone sees it. Zombies that walk in, and people or NPCs who turn inside, are never touched: only the game's own new zombies are. Zombies spawned there by an admin or another mod are removed too. Needs Fix A-Life bugs on. Off by default.
        AlifeFixes_NoZombiesInBase = false,
        -- Instead of chasing every zombie in sight, NPCs fight zombies that are close, coming for them, their allies or a player they're friendly with, or at their outpost or post. They stay calmer and will stop to talk.
        ZombieFocus_Enabled = true,
        -- Zombies closer than this are always fought. A-Life's own range is 16-21+ tiles. Minimum=2 Maximum=30 Standard=8
        ZombieFocus_Radius = 8,
        -- Unless attacked or holding a grudge, NPCs won't start fights when outgunned, low on ammo against an armed target, or surrounded by zombies (gunfire would draw them). Against zombies they switch to melee when the dead are thick around or ammo is low.
        Discretion_Enabled = true,
        -- A-Life infects and turns bitten NPCs by its own Mortality and Transmission settings. This adds a Bitten tag and the infection moodles, sets how often one zombie bites, and, where A-Life's own wounds are off, has an infected NPC die when their time comes.
        ZombieBites_Enabled = true,
        -- How long each zombie waits before biting the same NPC again. A-Life's own is 4.5; it lets up to 8 zombies bite one NPC at once. Minimum=0,50 Maximum=10,00 Standard=3,50
        ZombieBites_BiteGap = 3.5,
        -- Hits leave wounds on body parts: scratches, lacerations, deep wounds, bites, bullet wounds, bruises and fractures, depending on what hit them. Wounds bleed until bandaged or clotted, heal over days, and show on the hover tag.
        Injuries_Enabled = true,
        -- A broken or badly hurt leg makes them limp, and hurt arms make them aim worse, until healed or treated.
        Injuries_Effects = true,
        -- How fast open wounds drain health. 0: wounds never bleed. At 100 an untreated bullet wound kills in about six minutes. Minimum=0 Maximum=300 Standard=100
        Injuries_BleedRate = 100,
        -- At 100 a scratch heals in about two days, a bullet wound in about ten, a fracture (with a splint) in about forty. Minimum=10 Maximum=1000 Standard=100
        Injuries_HealSpeed = 100,
        -- Right-click a hurt NPC who isn't hostile to you (or has surrendered to you) to bandage, stitch or splint their wounds with your own supplies. Gives First Aid experience, and a little standing with their faction and crew.
        Injuries_Treatment = true,
        -- A bleeding NPC who isn't fighting bandages the wound with their own kit, even on guard or under orders; a resident fighting zombies stops to do it once none is close. With nothing left they call out when someone can come or hear them, and the nearest crewmate or fellow resident with a bandage (a medic first) comes over and does it. One dressing per wound.
        Injuries_SelfCare = true,
        -- Tops up each NPC's first aid when they appear. A-Life gives most 1-2 (medics 4). 0 leaves A-Life's own. Minimum=0 Maximum=10 Standard=3
        Injuries_Bandages = 3,
        -- Open wounds that aren't disinfected can get infected (not the zombie infection): they heal at a quarter of the speed and hurt more until disinfected. Alcohol bandages disinfect as they go on.
        Injuries_WoundInfection = true,
        -- A-Life spares NPCs from fall damage. With this on, a fall of a floor bruises or breaks a leg, two floors most likely break one, and three or more mean bad breaks and real harm.
        Injuries_Falls = true,
        -- NPCs on fire build up burns: painful, slow to heal and prone to infection. Treat them by disinfecting and bandaging.
        Injuries_Burns = true,
        -- With nothing bleeding, an NPC's health slowly comes back (about a day to full), held back by wounds that haven't healed yet. A-Life has no recovery of its own.
        Injuries_Regen = true,
        -- A resident with the Medic specialty walks over to wounded residents of their base, downed ones first, then the worst bleeding, and treats them with supplies from the base's Medical store (bandage, disinfect, stitch, splint, take a bullet out). Players of the base can call them too: right-click Call the medic, or Medic! in a conversation. During the base alarm they only treat people under a roof.
        Injuries_MedicRounds = true,
        -- NPCs near you and your residents have needs, shown in Medical Check and on the hover tag when pressing. Residents eat and drink at a base with food and sleep at night (in their Sleep shift where shifts go by the schedule); NPCs away from you look after themselves. Food and drink you hand them help; so does a drink for their nerves. Wounds, losing crewmates and being held up stress them.
        Needs_Enabled = true,
        -- Tired NPCs can't sprint; very hungry, thirsty, exhausted or panicked ones aim worse; starving or dehydrated residents slowly lose health (anyone else gets by on their own supplies), and wounds heal at half speed. Stressed or panicked NPCs give up more easily when held up.
        Needs_Effects = true,
        -- At 100 an NPC with no food gets hungry in about a day; a resident at a base with no food starves in under two. Thirst is a little faster. Minimum=10 Maximum=500 Standard=100
        Needs_Rate = 100,
        -- Now and then an NPC near you says something about their most pressing moodle: hunger, thirst, tiredness, stress, pain, drink, sickness, grief or the infection taking hold. Never in a fight.
        Needs_Lines = true,
        -- An NPC near you says something when they change course: backing off from a fight that isn't worth it (and why: the odds, the noise, their ammo), deciding it's on after all when you come too close, or stepping in to protect you or their base. At most once every 45 seconds each.
        Intent_Lines = true,
        -- Off: NPCs never get hungry (no moodle, no effects).
        Needs_Hunger = true,
        -- Off: NPCs never get thirsty (no moodle, no effects).
        Needs_Thirst = true,
        -- Off: NPCs never get tired (no moodle, no sprinting limits).
        Needs_Fatigue = true,
        -- Coffee, tea, Vitamins, coffee beans or a cola handed to an NPC makes them less tired, and residents on watch take one from a base Food or Medical store when tired. Each dose works less while the last is still in them, part of the tiredness comes back as it wears off, and too much makes them jittery. Needs tiredness on.
        Needs_Caffeine = true,
        -- Off: no stress from wounds, losses or hold-ups (no moodle, no effect on aim or surrendering).
        Needs_Stress = true,
        -- Off: alcohol you hand over still calms them but never gets them drunk.
        Needs_Drunk = true,
        -- Off: living near bodies doesn't sicken NPCs (no smell or sickness moodles, no effects).
        Needs_CorpseSickness = true,
        -- Residents mourning a crewmate are Depressed, then Unhappy, then Sad over three days, and stay a little stressed. Off: no moodle or stress (they still mourn).
        Needs_Grief = true,
        -- Shows A-Life's own fear and panic as moodles. Display only: A-Life acts on them either way.
        Needs_Fear = true,
        -- Bitten NPCs go Unwell, Feverish, Delirious and Zombified as they near turning, getting weaker. Off: no moodle or weakness (they still turn).
        ZombieBites_Stages = true,
        -- Lets an admin run Debug > Self-test > Scenario test in single player: it builds a base, spawns a crew, zombies and a hostile group, and changes the world for good. Only tick this on a world made for testing.
        Scenario_Allow = false,
        -- Off hides the [A-Life Jimmy] entry of the right-click menu for everyone, admins and -debug games included, and its Debug (admin) tools go with it until it is back on. Each player can also hide it just for themselves in Options > Mods. Trade, Medical Check and the other entries outside it stay. With it hidden: the faction window opens from the people button in the sidebar (its Bases section has the tools for land, buildings, guard posts, stores and the body dump, and the Show bases on the ground tick box), NPC safety from its sidebar button or the faction window, and you invite someone to your nearest base by talking to them (Come live at our base). Only in this menu: the Status panel, door and window marks, letting someone who surrendered go (Q still makes them drop their weapon and empty their pockets), sending a whole base crew away at once (People > Actions sends one at a time) and inviting someone to a base other than your nearest.
        ContextMenu_Show = true,
        -- Shows Debug (admin) in the [A-Life Jimmy] right-click menu in single player: admin tools for testing (self-test, spawning, sieges, traders). Off, it shows only in a -debug game, on a test world (the scenario test option, or a save with the word test in its name), and to admins in multiplayer.
        Debug_Menu = false,
        -- Write A-Life counters (ownership handoffs, movement stalls, squads, saves) to the server log as [ALIFE-JIMMY] diag lines.
        Diagnostics_Enabled = false,
        -- Minimum=1 Maximum=60 Standard=5
        Diagnostics_IntervalMinutes = 5,
        -- With your safety on, hitting, shooting or shoving one of your own people (see Who safety protects) does nothing (no damage, no anger). Multiplayer uses the game's own safety button (server option SafetySystem); single player gets a safety button in the left sidebar.
        NpcSafety_Enabled = true,
        -- With your safety on, which NPCs your hits can't hurt. People hostile to you can always be hurt. Standard=Your residents and allies
        -- 1 = Your residents
        -- 2 = Your residents and allies
        -- 3 = Anyone not hostile to you
        NpcSafety_Who = 2,
        -- Multiplayer. On: a faction's leader can set their people (residents and parties) to treat every player outside the faction as hostile (My people > Reputation). The server's PvP setting, safehouses and non-PvP zones still apply, and faction members are never targets. Off: the switch is greyed out.
        HostileFactions_Allow = false,
        -- To the game an NPC is a zombie, so any NPC near you means "Not safe to sleep here", fast-forward dropping to normal speed, search mode switching off, panic when one walks into view, and the jump-scare sound when one steps out right beside you. With this on, NPCs who aren't hostile to you no longer do any of that. Zombies in view, hostile NPCs within 20 tiles and anyone attacking or robbing you still stop you resting; a zombie or a hostile NPC coming into view still panics you, and one stepping out beside you still plays the sound. Followers also stand back while you sit, rest or sleep. Fast-forward is single player only; on a server the panic part runs on the server. Off: the game's own rules.
        RestNearNpcs_Enabled = true,
        -- A-Life 1.4 draws a random name for every NPC unless their NPC Creation preset's NPC name is Set name. On, a preset you made yourself that has no name setting (every preset made before 1.4, and Random name, which A-Life saves the same way) names its people with its Display name, as before 1.4, in our tags and windows and, for your residents, in A-Life's too. Off, or a preset set to Random male name or Random female name: A-Life's random names.
        Names_CreatorDisplayName = true,
        -- Hover the mouse over an NPC to see their name above their head, coloured by how they feel about you.
        NpcTags_Names = true,
        -- Adds a [TAG] (the faction's initials) before the name, so you can tell who belongs to which faction.
        NpcTags_Factions = true,
        -- A skull in front of the label of anyone hostile to you, even if they seem friendly.
        NpcTags_Hostile = true,
    },
    ElectrifyRadios = {
        -- Mindest-Elektro-Skill (0-10), der zum Umbauen von Radios auf oder von Netzstrom benötigt wird. Bei 0 ist keine Anforderung aktiv. Minimum=0 Maximum=10 Standard=3
        RequiredElectricalLevel = 2,
    },
    ImmersiveBlackouts = {
        -- Enabling this option will reset the mod's saved data.
        -- Only enable this if you have changed the day when the shutdowns will occur.
        -- It will automatically disable afterwards.
        ModReset = false,
        -- Enables automatic emergency radio broadcasts from the Knox Emergency Regional Infrastructure Service.
        -- The radio will provide information about upcoming outages, current infrastructure status, and other emergency events.
        Radio = true,
        -- Sets the frequency of the emergency radio broadcasts in MHz.
        RadioFrequency = "89.2",
        -- Sets the day range for a random permanent shutoff.
        -- Format: minimum day - maximum day
        -- 0-30 = random day
        -- 30-30 = fixed day.
        -- Overrides the vanilla 'Water Shutoff' day setting.
        -- If the value becomes blank, the entered format was invalid and was rejected.
        WaterShutoffDayRange = "0-30",
        -- Number of days before the scheduled permanent shutoff to start random outages.
        -- Vanilla shutoff: 30, Random Outage Offset: 5 = random outages start on day 25.
        -- Vanilla shutoff: Disabled, Random Outage Offset: 2147483647 = random outages start on day 0. Minimum=1 Maximum=2147483647 Standard=7
        WaterOffset = 7,
        -- Determines how often the chance of a shutoff or restoration is checked.
        -- The value is specified in in-game minutes. Minimum=1 Maximum=1440 Standard=10
        WaterCheckInterval = 10,
        -- Cooldown time (in in-game hours) before another state change can occur.
        -- Format: after restoration|after shutoff
        -- 2-2 = 2 hour cooldown after both restoration and shutoff
        -- 1-3|12-24 = random cooldown of 1-3 hours after a restoration and 12-24 hours after a shutoff
        -- 0-0|2-2 = no cooldown after a restoration and a fixed 2 hour cooldown after a shutoff.
        WaterCooldown = "0-0|0-0",
        -- Chance (in percent) that the supply will be shut off.
        -- Checked according to the configured check interval. Minimum=0,00 Maximum=100,00 Standard=1,00
        WaterPercentOFF = 1.0,
        -- Chance (in percent) that the supply will be restored.
        -- Checked according to the configured check interval. Minimum=0,00 Maximum=100,00 Standard=5,00
        WaterPercentON = 5.0,
        -- Weather conditions affect the chance of outages.
        -- Bad weather increases the chance of outages and decreases the chance of restoration.
        -- Determines the maximum percentage of weather influence on the chance. Minimum=0,00 Maximum=100,00 Standard=0,00
        WeatherInfluenceWater = 0.0,
        -- Dynamically adjusts the chance of shutoffs and restorations based on how close the scheduled shutoff day is.
        -- Uses the maximum chance set in the Shutoff Chance and Restore Chance settings.
        -- The restore chance always remains at a minimum of 5%.
        -- It is recommended to use a cooldown when this option is enabled.
        DynamicWaterChance = false,
        -- Sets the day range for a random permanent shutoff.
        -- Format: minimum day - maximum day
        -- 0-30 = random day
        -- 30-30 = fixed day.
        -- Overrides the vanilla 'Electricity Shutoff' day setting.
        -- If the value becomes blank, the entered format was invalid and was rejected.
        ElectricityShutoffDayRange = "14-30",
        -- Number of days before the scheduled permanent shutoff to start random outages.
        -- Vanilla shutoff: 30, Random Outage Offset: 5 = random outages start on day 25.
        -- Vanilla shutoff: Disabled, Random Outage Offset: 2147483647 = random outages start on day 0. Minimum=1 Maximum=2147483647 Standard=7
        ElectricityOffset = 7,
        -- Determines how often the chance of a shutoff or restoration is checked.
        -- The value is specified in in-game minutes. Minimum=1 Maximum=1440 Standard=10
        ElectricityCheckInterval = 10,
        -- Cooldown time (in in-game hours) before another state change can occur.
        -- Format: after restoration|after shutoff
        -- 2-2 = 2 hour cooldown after both restoration and shutoff
        -- 1-3|12-24 = random cooldown of 1-3 hours after a restoration and 12-24 hours after a shutoff
        -- 0-0|2-2 = no cooldown after a restoration and a fixed 2 hour cooldown after a shutoff.
        ElectricityCooldown = "0-0|0-0",
        -- Chance (in percent) that the supply will be shut off.
        -- Checked according to the configured check interval. Minimum=0,00 Maximum=100,00 Standard=1,00
        ElectricityPercentOFF = 1.0,
        -- Chance (in percent) that the supply will be restored.
        -- Checked according to the configured check interval. Minimum=0,00 Maximum=100,00 Standard=5,00
        ElectricityPercentON = 5.0,
        -- Weather conditions affect the chance of outages.
        -- Bad weather increases the chance of outages and decreases the chance of restoration.
        -- Determines the maximum percentage of weather influence on the chance. Minimum=0,00 Maximum=100,00 Standard=0,00
        WeatherInfluenceElectricity = 0.0,
        -- Dynamically adjusts the chance of shutoffs and restorations based on how close the scheduled shutoff day is.
        -- Uses the maximum chance set in the Shutoff Chance and Restore Chance settings.
        -- The restore chance always remains at a minimum of 5%.
        -- It is recommended to use a cooldown when this option is enabled.
        DynamicElectricityChance = false,
    },
    ImmersiveWaterShutoff = {
        -- Determines how water will be handled once the main supply is shut off.
        -- 
        -- Off — water will not be removed or reduced.
        -- Randomized Reduction — water will be reduced by a random amount within the range defined by 'Minimum Reduction' and 'Maximum Reduction'.
        -- Full Shutoff — completely removes all water sources, except when the 'Keep Water in Toilets' or/and 'Keep Water in Baths' option is enabled.
        --  Standard=Full Shutoff
        -- 1 = OFF
        -- 2 = Randomized Reduction
        -- 3 = Full Shutoff
        WaterRemovalMode = 3,
        -- If enabled, toilets will retain a randomized amount of water in their tanks.
        -- Toilet water will be reduced based on the Minimum Reduction and Maximum Reduction values.
        -- This option has no effect if 'Randomized Reduction' is active.
        -- 
        ToiletsKeepWater = true,
        -- If enabled, baths may retain water prior to the shutoff to emulate people filling their tubs as emergency water.
        -- Bath water is randomized from 0 to 100, and the chance a bath has been filled is determined by the 'Filled Bath Chance' option.
        -- This option has no effect if 'Randomized Reduction' is active.
        -- 
        BathsKeepWater = false,
        -- If enabled, baths can be filled in advance to prepare for the main water supply being shut off.
        -- This allows players to have emergency water stored in their tubs.
        -- 
        FillableBaths = false,
        -- The percentage chance that a bath has been filled prior to the water shutoff to emulate people filling their tubs for emergency use.
        -- This option only has effect if 'Keep Water in Baths' is enabled. Minimum=0 Maximum=100 Standard=10
        BathPercent = 10,
        -- The minimum percentage of water to be removed when 'Randomized Reduction' or 'Keep Water in Toilets' is enabled. Minimum=0 Maximum=100 Standard=90
        MinPercent = 90,
        -- The maximum percentage of water to be removed when 'Randomized Reduction' or 'Keep Water in Toilets' is enabled. Minimum=0 Maximum=100 Standard=100
        MaxPercent = 100,
        -- Determines when water becomes tainted after the main supply is shut off:
        -- 
        -- -1 = disabled
        -- 0 = immediately
        -- 1+ = water becomes tainted after the specified number of in-game days.
        --  Minimum=-1 Maximum=2147483647 Standard=-1
        TaintedWater = -1,
        -- Determines the strength of poisoning when consuming tainted water.
        -- 
        -- 1 = vanilla value.
        -- 2 = twice as strong.
        -- 3+ = extremely dangerous values.
        -- 
        -- The Iron Gut trait reduces the poison received, but does not make the character completely immune to tainted water.
        -- The Weak Stomach trait increases the poison received from tainted water.
        -- At x2, drinking around 2 liters of tainted water at maximum thirst can result in fatal food poisoning. Minimum=1,00 Maximum=10,00 Standard=1,00
        TaintedWaterPoisonMultiplier = 1.0,
        -- If enabled, water quality in connected plumbing will depend on the water source.
        -- If the connected barrel contains tainted water or another tainted liquid, sinks, baths, and other plumbing objects will also provide tainted liquid.
        PlumbingSourceQuality = false,
        -- If enabled, the settings below will be used.
        -- By default, they contain the game's default values.
        UseCustomRainCollectors = false,
        -- Determines the maximum amount of water that can be stored in a square rain collector. Minimum=0,00 Maximum=10000,00 Standard=400,00
        RainCollectorCapacity = 400.0,
        -- Determines how efficiently the square rain collector collects rainwater. Minimum=0,00 Maximum=100,00 Standard=0,40
        RainCollectorRainFactor = 0.4,
        -- Determines the maximum amount of water that can be stored in a round rain collector. Minimum=0,00 Maximum=10000,00 Standard=600,00
        RainCollectorRoundCapacity = 600.0,
        -- Determines how efficiently the round rain collector collects rainwater. Minimum=0,00 Maximum=100,00 Standard=0,25
        RainCollectorRoundRainFactor = 0.25,
        -- Determines the maximum amount of water that can be stored in a square tarp rain collector. Minimum=0,00 Maximum=10000,00 Standard=400,00
        RainCollectorTarpCapacity = 400.0,
        -- Determines how efficiently the square tarp rain collector collects rainwater. Minimum=0,00 Maximum=100,00 Standard=0,40
        RainCollectorTarpRainFactor = 0.4,
        -- Determines the maximum amount of water that can be stored in a round tarp rain collector. Minimum=0,00 Maximum=10000,00 Standard=600,00
        RainCollectorRoundTarpCapacity = 600.0,
        -- Determines how efficiently the round tarp rain collector collects rainwater. Minimum=0,00 Maximum=100,00 Standard=0,25
        RainCollectorRoundTarpRainFactor = 0.25,
        -- Determines the maximum amount of water that can be stored in an amphora. Minimum=0,00 Maximum=10000,00 Standard=300,00
        AmphoraCapacity = 300.0,
        -- Determines how efficiently the amphora collects rainwater. Minimum=0,00 Maximum=100,00 Standard=0,40
        AmphoraRainFactor = 0.4,
    },
    LGExtendedElectricity = {
        -- Ein Generator versorgt das ganze Gebäude, das er erreicht, nicht nur die Felder ringsum. Jede Etage, das Dach und den Keller. Schalte das aus und starte neu, bevor du den Mod entfernst.
        Enabled = true,
        -- An: Du schließt einen Generator an und er versorgt das Gebäude sofort. Aus: Du machst erst einen Rechtsklick und wählst Gebäude verkabeln. So oder so kannst du es bei jedem Generator anders entscheiden.
        ExtendByDefault = false,
        -- An: Die zusätzlichen Räume kosten Sprit, ein großes Gebäude verbrennt also mehr. Aus: Sie sind kostenlos. Um den Verbrauch selbst zu ändern, nimm die Spieloption Generator-Kraftstoffverbrauch.
        ChargeFuel = true,
        -- An: Zwei Generatoren an einem Gebäude teilen sich die Spritrechnung, statt sie beide voll zu zahlen. Aus: Jeder zahlt sie voll.
        ShareLoad = true,
        TakeoverMark = "v1:f20:F1:fv3:FV1",
        -- Häng zu viel an einen Generator und sein Sicherungsautomat löst aus und nimmt jeden Generator an denselben Gebäuden mit. Starte sie alle wieder, dann Rechtsklick auf einen und zurückschalten. Damit er nicht mehr auslöst, stell einen Generator dazu oder schalte etwas ab. Braucht Generator-Kraftstoffverbrauch über null.
        Breaker = true,
        -- Wie viel ein Generator auf einmal tragen kann. Ein besserer trägt mehr: bei 225 reichen sie von 5400 bis 8100 Watt. Runter für ein härteres Spiel, hoch für ein leichteres. Minimum=10 Maximum=10000 Standard=225
        BreakerWattsPerPoint = 225,
        -- Lässt dich Benzin mit einer Rohrzange zu einem Generator leiten. Ein Fass daneben versorgt ihn direkt. Mit LG Extended Plumbing kann ein Generator auch aus den Benzinfässern der ganzen Basis ziehen. Aus: Es lässt sich nichts anschließen.
        FuelLine = true,
        -- Lässt dich eine Tankstellenzapfsäule an einen daneben geparkten Generator anschließen, sodass er aus den Tanks darunter läuft. Aus: nur Fässer.
        FuelFromPumps = true,
        -- Wie weit der Strom über die Wände hinaus reicht, damit eine Verandalampe oder eine Gefriertruhe draußen läuft. 0 heißt nur innen. Manche Felder reichen etwas weiter, nimm es also als Mindestwert. Minimum=0 Maximum=8 Standard=1
        ExteriorReach = 1,
        -- An: Generatoren und Relais nutzen die zwei Reichweiten darunter, und die Spieloption Generator tile range wird auf 1 gesetzt. Aus: Es gilt die Reichweite des Spiels. Braucht einen Neustart.
        TakeOverGeneratorRange = true,
        -- Wie viele Felder ein laufender Generator um sich herum versorgt und wie weit ein Gebäude weg sein darf, damit du es verkabeln kannst. Gilt, wenn der Mod die Generator-Reichweite festlegt. Minimum=1 Maximum=100 Standard=20
        GeneratorRange = 20,
        -- Wie viele Felder ein Relais um sich herum versorgt und wie viele Stromkabel es kostet. Gilt, wenn der Mod die Generator-Reichweite festlegt. Minimum=1 Maximum=100 Standard=2
        WireRelayRange = 2,
        -- An: Generatoren und Relais nutzen die zwei Etagen-Einstellungen darunter, und die Spieloption Generator vertical range wird auf 1 gesetzt. Geht nur, wenn Mod legt Generator-Reichweite fest an ist. Aus: Es gilt die vertikale Reichweite des Spiels. Braucht einen Neustart.
        TakeOverGeneratorVerticalRange = true,
        -- Wie viele Etagen über und unter sich ein laufender Generator versorgt. Ein verkabeltes Gebäude bekommt immer alle Etagen. Gilt, wenn der Mod die vertikale Generator-Reichweite festlegt. Minimum=1 Maximum=15 Standard=1
        GeneratorVerticalRange = 1,
        -- Wie viele Etagen über und unter sich ein Relais versorgt. Gilt, wenn der Mod die vertikale Generator-Reichweite festlegt. Minimum=1 Maximum=15 Standard=1
        WireRelayVerticalRange = 1,
        -- Was dich eine Straßenlaterne am Generator kostet, sobald du sie angeklemmt hast. Das Spiel berechnet für Straßenlaternen nichts, dieser Wert ist also vom Mod. Setze 0, damit sie gratis sind. Minimum=0 Maximum=1000 Standard=100
        StreetLightWatts = 100,
        -- Schreibt jede Stromänderung in die Logdatei. Nur nützlich, um einem Problem nachzugehen.
        Debug = false,
    },
    LGExtendedPlumbing = {
        -- Ein an ein Gebäude angeschlossener Regensammler versorgt jede Zapfstelle darin, nicht nur die direkt darunter. Schalte das aus für normale Leitungen.
        Enabled = true,
        -- Wie weit eine Zapfstelle nach Fässern sucht, wenn sie nicht in einem echten Gebäude steht, etwa in einer selbst gebauten Basis. In einem echten Gebäude wird das ganze Gebäude genommen und das hier tut nichts. 12 deckt eine gut geschnittene Basis ab. Minimum=1 Maximum=64 Standard=12
        Reach = 12,
        -- Dinge, die angeschlossen werden können, um von der Versorgung GEFÜLLT zu werden, statt sie zu speisen. Standardmäßig Wasserspender. Du musst trotzdem einen Rechtsklick machen und mit einer Rohrzange anschließen. Nimm den Skriptnamen des Objekts, mit Semikolon getrennt. Feld leeren, um das abzuschalten.
        FedFixtures = "WaterDispenser",
        -- Behebt zwei Fehler des Grundspiels auf Servern: eine Waschmaschine, die sich nicht anschließen lässt, und eine, die auf deinem Bildschirm weiterläuft, nachdem ihr das Wasser ausgegangen ist. Im Einzelspieler nicht nötig.
        WasherPatch = true,
        -- Behebt einen Fehler des Grundspiels, der deine Fässer leert, ohne etwas zu füllen. Betroffen sind nur Getränke wie Cola, Saft und Vodka. Wasser, Bier und Whiskey waren nie betroffen.
        FluidPatch = true,
        -- Schreibt jede Änderung an den Leitungen in die Logdatei. Nur nützlich, um einem Problem nachzugehen.
        Debug = false,
    },
    PIP = {
        -- Wenn aktiviert, bewässern Rohre automatisch nahegelegene Pflanzen aus angeschlossenen Regenfässern.
        EnableAutoWatering = true,
        -- Spielinterne Minuten zwischen den einzelnen Bewässerungszyklen. Minimum=1 Maximum=1440 Standard=10
        WateringInterval = 10,
        -- 0 = nur das Feld des Rohres selbst. Höhere Werte bewässern Pflanzen in einem quadratischen Bereich um jedes Rohr. Minimum=0 Maximum=10 Standard=0
        WateringRadius = 0,
        -- Wenn aktiviert, füllen Rohre die Pflanzen bis zu ihrem optimalen Wasserstand auf. Wenn deaktiviert, fügen sie pro Zyklus eine feste kleine Menge hinzu.
        SmartPipes = true,
        -- Maximaler Wasserstand, der einer Pflanze pro Zyklus im Modus für intelligente Rohre hinzugefügt wird. Minimum=3 Maximum=100 Standard=20
        SmartPipesFillMax = 20,
        -- Wenn aktiviert, teilen und gleichen Fässer im selben Netzwerk ihr Wasser aus (ein volles und ein leeres Fass gleichen sich an).
        SharedWaterPool = true,
        -- Wenn aktiv: Dünger oder Kompost in ein verbundenes Regenfass füllen, und das Rohrnetz düngt nahe Pflanzen automatisch (eine sichere Dosis pro Pflanze, nie Überdüngung). Standardmäßig an.
        EnableFertigation = true,
        -- Simuliertes Landwirtschafts-Level beim Auto-Düngen. Höher = bessere Chance auf Ertragsbonus. Beeinflusst die Sicherheit nicht. Minimum=0 Maximum=10 Standard=5
        FertigationSkill = 5,
        -- Wie viele Pflanzen ein eingefüllter Sack düngen kann. Unabhängig vom Wasserstand des Fasses. Minimum=1 Maximum=100 Standard=10
        ChargesPerBag = 10,
        -- Gibt interne Protokolle in der Konsole aus. Nur zur Fehlerbehebung.
        DebugLogs = false,
    },
    PSR = {
        -- Wie oft wird die Batteriebank aufgeladen? Standard=Alle zehn Minuten
        -- 1 = Alle zehn Minuten
        -- 2 = Jede Stunde
        ChargeFreq = 1,
        -- Wirkungsgrad von Solarmodulen
        -- 12 % sind für 1993 realistisch
        -- 25 % sind moderne Solaranlagen
        -- Standard ist unrealistisch Minimum=1 Maximum=100 Standard=25
        solarPanelEfficiency = 25,
        -- How fast batteries wear while the bank is running, in percent of 1 condition point per day.
        -- 100 = 1 point per day (default) - 50 = half as fast on average - 200 = twice as fast - 0 = no wear.
        -- A DIY Battery always wears 64 times slower. Minimum=0 Maximum=1000 Standard=100
        batteryDegradeChance = 100,
        -- Multiplikator für den Stromverbrauch der Geräte, in Prozent.
        -- 100 = normaler Verbrauch (Standard)
        -- 50 = halber Verbrauch
        -- Verringere diesen Wert, wenn deine Basis zu viele Solarpanels benötigt. Minimum=1 Maximum=1000 Standard=100
        consumptionMultiplier = 100,
        -- Multipliziert die Kapazität der im Rezept verwendeten Batterie. Bei 800 % ergibt eine verkabelte CarBattery1 (50 Ah) eine DIY-Batterie mit 400 Ah, eine improvisierte Batterie (100 Ah) ergibt 800 Ah. Minimum=1 Maximum=10000 Standard=100
        DIYBatteryMultiplier = 100,
        -- Seltenheit des Spawnens einer Batteriebank auf der Karte. Standard=Selten
        -- 1 = Keiner
        -- 2 = Sehr selten
        -- 3 = Selten
        -- 4 = Ungewöhnlich
        BatteryBankSpawn = 3,
        -- Das Erscheinen von Solarmodulen in zufälligen Behältern und vorab platzierten Kisten erhöht den Multiplikator Minimum=0,00 Maximum=100,00 Standard=1,00
        LRMSolarPanels = 1.0,
        -- Batterien erscheinen in zufälligen Behältern und vorab platzierten Kisten mit Multiplikator Minimum=0,00 Maximum=100,00 Standard=1,00
        LRMBatteries = 1.0,
        -- Multiplikator für das Erscheinen des Magazins, des Wechselrichters und des Solar Failsafe in zufälligen Behältern und vorplatzierten Kisten Minimum=0,00 Maximum=100,00 Standard=1,00
        LRMMisc = 1.0,
        -- Basisanzahl der Spielminuten, die zum Anschließen eines Panels benötigt werden Minimum=1 Maximum=1440 Standard=30
        ConnectPanelMin = 30,
        -- Maximale Entfernung, um einen Notgenerator mit einer Batteriebank zu verbinden.
        -- 0 = nach Elektrik-Fähigkeit (Standard, ~10 Felder max.)
        -- 1-50 = feste Reichweite in Feldern, unabhängig vom Skill. Minimum=0 Maximum=50 Standard=0
        BackupConnectRange = 0,
        -- Maximale waagerechte Entfernung zwischen einem Solarmodul und dem Batteriespeicher, mit dem es sich verbindet.
        -- 20 ist der Standardwert und das ursprüngliche Verhalten. Erhöhe ihn für große Basen und Bunker.
        -- Die vertikale Reichweite wird getrennt eingestellt, siehe Vertikale Reichweite der Solarmodule.
        -- Höhere Werte lassen den Mod einen größeren Bereich absuchen, was in sehr großen Gebäuden Leistung kostet. Minimum=20 Maximum=40 Standard=20
        PanelConnectRange = 20,
        -- Wie viele Etagen nach oben oder unten ein Solarmodul reichen kann, um seinen Batteriespeicher zu finden.
        -- 3 ist der Standardwert und das ursprüngliche Verhalten. Erhöhe ihn, wenn dein Speicher tief in einem Keller oder Bunker oder hoch oben in einem Turm steht.
        -- Jede zusätzliche Etage erweitert die Suche nach oben und unten, was in sehr großen Gebäuden Leistung kostet. Minimum=3 Maximum=8 Standard=3
        PanelConnectFloors = 3,
        -- Wie viele Etagen nach oben oder unten ein Batteriespeicher reichen kann, um seinen Notstromgenerator zu finden.
        -- 1 ist der Standardwert und das ursprüngliche Verhalten. Erhöhe ihn, wenn dein Generator auf einem Dach oder mehrere Etagen vom Speicher entfernt steht.
        -- Das erweitert auch das Distanzbudget, sodass ein Generator auf dem Dach nicht mehr für seine Höhe bestraft wird. Minimum=1 Maximum=8 Standard=1
        BackupConnectFloors = 1,
        -- Seltenheit der bereits platzierten Solarkisten auf der Karte, in Schuppen, Garagen, Lagerräumen, Elektroniklagern und Farmlagern.
        -- Kisten sind der beste Fund im Mod — ein ganzer Satz Teile auf einmal — daher bleiben sie seltener als Batteriespeicher.
        -- Auf Keine stellen, um sie ganz zu entfernen. Standard=Selten
        -- 1 = Keine
        -- 2 = Sehr selten
        -- 3 = Selten
        -- 4 = Ungewöhnlich
        SolarCrateSpawn = 3,
        -- When ON, crafting solar panels needs a harder, more realistic recipe (tempered glass + aluminium frame, more components, higher Electricity skill).
        -- OFF = the standard recipe (default).
        -- This sets what the magazine teaches, so choose it before creating a save.
        HardenedPanelRecipe = false,
        -- Erlaubt es, ein Gebäude der Karte — nicht eines, das du gebaut hast — mit einem Batteriespeicher zu verbinden, über Diesen Bereich mit dem Batteriespeicher verbinden.
        -- Standardmäßig überall aus, auch im Einzelspieler und beim Koop-Host - schalte es ein, um es zu nutzen.
        -- Der Grund: Auf einem Server könnte sonst jeder das Haus eines Nachbarn verbinden und dessen Geräte vom Solarcomputer aus abschalten.
        AllowVanillaConnect = false,
    },
    LGRealisticPowerUsage = {
        -- Aus: nichts verbraucht mehr Strom als vorher, nur weniger. An: ein paar Dinge, die wirklich viel ziehen, kosten jetzt viel. Ein Trockner geht auf 3000 Watt und ein Ofen auf 1500.
        Increases = true,
    },
    UsefulBarrels = {
        -- Enables additional information for debugging purposes.
        DebugMode = false,
        -- maximale Tonnenräumlichkeit 
        --  betreff nur neue Tonnen, die alten bleiben unverändert Minimum=1 Maximum=9999 Standard=400
        BarrelCapacity = 400,
        -- Falls nötig, braucht man für die Öffnung der Tonne eine Rohrzange
        RequirePipeWrench = true,
        -- Wenn aktiviert, wird ein Gummischlauch benötigt, um Treibstoff aus dem Fass abzulassen.
        RequireHoseForTake = true,
        -- Wenn aktiviert, wird ein Trichter benötigt, um Treibstoff in das Fass zu füllen.
        RequireFunnelForFill = true,
        -- Der Trichter beschleunigt das Befüllen der Tonne mit Benzin um den Faktor X (1.25 = +25%, 2.0 = +100% etc.).
        -- Wert 1 schaltet aus die Beschleunigung.
        --  Unabhängig von 'Trichter braucht's'. Minimum=1,00 Maximum=2,00 Standard=1,25
        FunnelSpeedUpFillModifier = 1.25,
        -- Acid, Alkohol, Blut, Gasolin, Färbemittel...
        AllowIndustrial = true,
        -- Gasolin
        AllowFuel = true,
        -- Acid, Bleichmittel, Reinigungsflüssigkeit...
        AllowHazardous = true,
        -- Selterswasser, Wasser, verunreinigtes Wasser
        AllowWater = true,
        -- Alkohol, Bier, Wein...
        AllowAlcoholic = false,
        -- Blut, Bier, Kaffee, Milch, Honig, Soda...
        AllowBeverage = false,
        -- Alkohol
        AllowMedical = false,
        -- Färbemittel, gefärbtes Haare, Wein
        AllowColors = false,
        -- Färbemittel
        AllowDyes = false,
        -- Haarfarbe
        AllowHairDyes = false,
        -- Keine Flüssigkeiten wie bei B42.4
        AllowPaint = false,
        -- Starkes Gift
        AllowPoisons = false,
        EnableGeneratorRefuel = true,
        GeneratorRefuelRequiresHose = true,
        EnableCarRefuel = true,
        CarRefuelRequiresHose = true,
        EnableFillBarrelFromVehicles = true,
        FillBarrelFromVehiclesRequiresHose = true,
        InitialFluid = true,
        -- Durch Leerzeichen getrennte Liste spawnbarer Fass-Flüssigkeiten.
        InitialFluidPool = "Acid Water TaintedWater Petrol Petrol Bleach PotentPoison",
        -- Maximale Menge für Ausgangsflüssigkeit.
        -- Darf das Fassvolumen nicht überschreiten Minimum=0 Maximum=9999 Standard=54
        InitialFluidMaxAmount = 54,
        -- Spawn-Chance für Ausgangsflüssigkeit. Minimum=0,00 Maximum=100,00 Standard=25,00
        InitialFluidSpawnChance = 25.0,
        RequireWeldingMask = true,
        RequireBlowTorch = true,
    },
    HereGoesTheSun = {
        EnableGodRays = true,
        EnableStormMood = true,
        -- Standard=Recommended
        -- 1 = Soft
        -- 2 = Recommended
        -- 3 = Night of the Living Dead
        StormMoodPreset = 2,
    },
    ImmersiveSnow = {
        -- Who leaves footprints in ground snow: everyone (players and the zombies near a player), players only, or nobody (no footprints and no snow carried off on the soles). Each player can also show fewer for themselves in Options > Mods. Standard=Everyone (players and zombies)
        -- 1 = Everyone (players and zombies)
        -- 2 = Players only
        -- 3 = Nobody (off)
        FootprintsFrom = 1,
        -- Vehicles leave tire tracks in ground snow. Off: no tire tracks and no snow carried off on the tires. Each player can also turn them off for themselves in Options > Mods.
        TireTracks = true,
        -- For weak integrated graphics with little video memory. Turns off snow on zombies, on items in hand and on vehicle doors, hoods and wheels, and the icing on vehicles; fewer footprints and tire tracks (at most 600 / 1200), zombie footprints only within 15 tiles, fewer snow particles blown off cars, half the footprint textures. The same switch is in Options > Mods for each player.
        LowEndMode = false,
        -- In-game hours a player's footprint lasts when no snow is falling. Minimum=0,50 Maximum=168,00 Standard=6,00
        FootprintHours = 6.0,
        -- In-game hours a zombie's footprint lasts when no snow is falling. Lower it so hordes do not trample the snow for long. Minimum=0,50 Maximum=168,00 Standard=6,00
        ZombieFootprintHours = 6.0,
        -- How much faster footprints disappear during heavy snowfall. Minimum=0,00 Maximum=50,00 Standard=8,00
        SnowfallCoverRate = 8.0,
        -- Above this limit the oldest footprints fade out. Players and zombies share it (each keeps at least half); lower it if the game slows down in snow. Minimum=10 Maximum=10000 Standard=2000
        MaxFootprints = 2000,
        -- Only zombies within this many tiles of the player leave footprints. Minimum=5 Maximum=60 Standard=25
        ZombieRadius = 25,
        -- B42 animals (deer, rabbits, chickens, cows, pigs, sheep...) and the horses, dogs and cats of the Horse Mod and Companion Dogs leave hoof and paw prints in ground snow, also out of sight, so game can be tracked. Each player can also turn them off for themselves in Options > Mods.
        AnimalTracks = true,
        -- In-game hours an animal's print lasts when no snow is falling. Minimum=0,50 Maximum=168,00 Standard=12,00
        AnimalTrackHours = 12.0,
        -- Above this limit the oldest animal prints fade out (a limit of their own, apart from the footprints). Lower it if the game slows down by a farm in snow. Minimum=10 Maximum=10000 Standard=1000
        MaxAnimalTracks = 1000,
        -- Only animals within this many tiles of the player leave prints (the nearest 48 at most). Minimum=5 Maximum=60 Standard=25
        AnimalTrackRadius = 25,
        -- A player or zombie without shoes leaves the print of a bare foot (heel, ball and toes) instead of a boot sole, in the snow and with the snow carried onto clear ground.
        BarefootPrints = true,
        -- A player or zombie who steps on a corpse leaves red prints for the next steps, each fainter, in the snow and on clear ground (asphalt, floors). Blood on the floor alone does not count. Off with the game's blood decals set to none.
        BloodyFootprints = true,
        -- How many steps after the blood still leave red prints. Minimum=1 Maximum=40 Standard=8
        BloodyFootprintSteps = 8,
        -- Drops of blood behind a bleeding player or a wounded zombie, covered by snowfall like the footprints. In multiplayer only for players on this computer and zombies: the game does not tell other clients that a player bleeds. Off with the game's blood decals set to none.
        BloodOnSnow = true,
        -- In-game hours a tire track lasts when no snow is falling. Minimum=0,50 Maximum=168,00 Standard=12,00
        TireTrackHours = 12.0,
        -- A segment is 0.4 tile of one wheel's track. Hard limit: above it the oldest segments vanish within seconds; lower it if the game slows down in snow. Minimum=20 Maximum=20000 Standard=4000
        MaxTireTracks = 4000,
        -- Above this many segments the oldest fade out over about 20 seconds, so a spot driven over again and again keeps only its latest laps. Has no effect at or above the max segments. Minimum=20 Maximum=20000 Standard=1500
        TireTrackSoftLimit = 1500,
        -- A wheel that runs over a corpse leaves a red track that pales out: a red rut in snow, red tread marks on clear ground. Only the wheels that went over it; blood on the ground alone does not count. Follows the vanilla blood settings (none with Blood Level none or blood decals off). Each player can also turn it off for themselves in Options > Mods.
        BloodyTireTracks = true,
        -- Tiles a wheel keeps leaving a red track after the blood, paler and paler. Minimum=0,40 Maximum=40,00 Standard=2,00
        BloodyTireTrackTiles = 2.0,
        -- Snow builds up on vehicles parked outdoors, melts in warmth and from a running engine, and blows off when driving. Works with modded vehicles.
        VehicleSnow = true,
        -- In-game hours of heavy snowfall until a parked vehicle is fully covered. Minimum=0,25 Maximum=24,00 Standard=2,00
        VehicleSnowHours = 2.0,
        -- Glazed ice around the snow on the body, the wheels and the glass edges. Off: plain snow only. Frost on the glass is a separate option.
        VehicleSnowIce = true,
        -- Snow settles on the clothes and on what you hold while you are outdoors in snowfall, and melts in warmth: indoors, by a fire, in the rain above freezing. Melting snow wets the clothes. Off: no snow on characters at all, so none melts into the clothes (falling snow and walking through snow still wet them).
        CharSnow = true,
        -- In-game hours of heavy snowfall outdoors a full layer of snow on the clothes would take (players stop at the most snow below). Light snowfall builds up slower. Minimum=0,10 Maximum=24,00 Standard=3,00
        CharSnowHours = 3.0,
        -- How much snow snowfall leaves on a player's clothes, moving about shakes off as much as falls; the lighter the snowfall, the less. 1: a full layer only in the heaviest snowfall. 1.5: a full layer in heavy snowfall, three quarters in light. Never more than a full layer. Zombies always get a full layer. Minimum=0,10 Maximum=2,00 Standard=1,50
        CharSnowMax = 1.5,
        -- Game hours a full layer of snow on a character takes to melt at 20 C (indoors, by a fire, in a heated car). At 10 C it takes twice as long; below 0 C it does not melt. Minimum=0,10 Maximum=24,00 Standard=1,25
        CharSnowMeltHours = 1.25,
        -- Under a roof or in a vehicle just above 0 C a full layer of snow on a character melts in this many game hours, however cold the room; warmer rooms melt it faster still (the option above). Minimum=0,10 Maximum=24,00 Standard=0,50
        CharSnowIndoorMeltHours = 0.5,
        -- Game hours body heat takes to melt a full layer of snow in the cold while it does not snow. Zombies have no body heat. Minimum=1,00 Maximum=500,00 Standard=50,00
        CharSnowBodyMeltHours = 50.0,
        -- Game hours of heavy rain above 0 C that wash a full layer of snow off a character or zombie (on top of melting in the warmth). Minimum=0,10 Maximum=48,00 Standard=3,00
        CharSnowRainMeltHours = 3.0,
        -- Snow on what characters hold and carry on the body: weapons, tools, backpacks on the back. Off: snow on the clothes only. Turn it off if a weapon mod shows the wrong weapon models in the snow.
        CharItemSnow = true,
        -- Darker snow on vehicles, characters and items, and darker snow particles, to match darker ground snow. On by itself with Snow Lands - Darker Snow. Takes effect after loading the save again.
        DarkSnow = false,
        -- Zombies get snow on their clothes too. They have no body heat: the snow melts in warmth above freezing or in the rain, and goes within an hour once the ground outdoors is bare.
        ZombieSnow = true,
        -- Game hours of heavy snowfall until a zombie outdoors is fully covered. Melting works as for players, without body heat; outdoors on bare ground the snow goes within an hour. Minimum=0,10 Maximum=24,00 Standard=0,50
        ZombieSnowHours = 0.5,
        -- A zombie or player that dies with snow on keeps it on the corpse, and it melts there as on zombies: in warmth above freezing, in the rain, and within an hour once the ground outdoors is bare. No new snow settles on corpses. Off: the snow comes off when a character dies. In multiplayer only on the corpses of deaths this client saw.
        CorpseKeepSnow = false,
        -- While it is 0 C or colder outdoors, no flies buzz over corpses and their stench makes nobody sick: the mod holds the game's "Decaying Corpse Health Impact" at None and sets it back above +1 C. If you set that option yourself while it is held, the mod leaves it as you set it and turns this option off. Before taking the mod out of a save, run ISnow.cleanSave() in the console (see the mod page), or that option may stay at None.
        ColdCorpses = true,
        -- Snow falling on a player and the snow melting on the clothes make them wet, like rain does in vanilla; walking through snow wets the shoes. Water-resistant clothes and boots protect. Wet clothes keep less warm.
        SnowWetness = true,
        -- Multiplier of how fast snow wets the clothes. 1 = wet snow at 0 C soaks an outer layer in about 3 game hours; the colder, the drier the snow. Minimum=0,00 Maximum=5,00 Standard=1,00
        SnowWetnessRate = 1.0,
        -- Stepping or driving from snow onto a clear square leaves a few fading snowy prints.
        CarriedSnow = true,
        -- How many steps on clear ground after the snow still leave snowy prints. Minimum=1 Maximum=10 Standard=3
        CarriedSnowSteps = 3,
        -- How far a wheel leaves snowy tread marks on clear ground after the snow. Minimum=0,40 Maximum=20,00 Standard=3,20
        CarriedSnowTireTiles = 3.2,
        -- Game hours snowy prints and tire marks on clear ground last at 0 C and below. Minimum=0,10 Maximum=48,00 Standard=2,00
        CarriedSnowHours = 2.0,
        -- Game hours snowy prints and tire marks take to melt at 20 C (a heated house); at 10 C twice as long. Uses the temperature of their square. Minimum=0,02 Maximum=24,00 Standard=0,25
        CarriedSnowMeltHours = 0.25,
        -- Living players breathe out vapour in the cold: faster and thicker after running, none through a gas mask or respirator, half through cloth over the face. Uses the air temperature at the character (indoors, heaters and the vehicle heater count). Zombies do not breathe.
        Breath = true,
        -- Air temperature at and below which the vapour shows, faint at first. Minimum=-20,00 Maximum=15,00 Standard=7,00
        BreathMaxTemp = 7.0,
        -- Air temperature at and below which the vapour is at full strength. Minimum=-40,00 Maximum=0,00 Standard=-20,00
        BreathFullTemp = -20.0,
        -- How thick the vapour is, 0.1 (barely visible) to 1. Minimum=0,10 Maximum=1,00 Standard=0,85
        BreathOpacity = 0.85,
        -- While the engine is warm, the snow on the hood melts faster than on the roof: the hotter the engine, the faster (vanilla engine temperature: it warms up over the first hour or so of running and stays warm for a while after it stops). Only on vehicles whose hood is a separate model (KI5, Vanilla Vehicles Animated...); on the vanilla cars the hood is part of the body. In multiplayer the server decides; each player can hide it for themselves in Options > Mods.
        VehicleHoodMelt = true,
        -- Game hours a hot engine takes to melt a full layer of snow off the hood. A cold engine melts nothing; half warm, twice as long. In multiplayer always as on the server. Minimum=0,10 Maximum=24,00 Standard=1,00
        VehicleHoodMeltHours = 1.0,
        -- Running and sprinting through snow throws a little powder back off the feet; a player or zombie that goes down in the snow (knocked down, tripped, killed) raises a puff. Only with footprints on.
        SnowKick = true,
        -- Powder puffs a running step into snow throws (a fraction is the chance of one): 0 none, 0.4 about every other step, 3 a lot. Minimum=0,00 Maximum=3,00 Standard=0,40
        SnowKickRun = 0.4,
        -- Powder puffs a sprinting step into snow throws, with a chance of a clump. Minimum=0,00 Maximum=5,00 Standard=1,30
        SnowKickSprint = 1.3,
        -- A player or zombie that goes down in the snow (knocked down, tripped, killed) raises a puff along the body.
        SnowKickFalls = true,
        -- How much snow a fall raises: 1 is 7 puffs and 3 clumps, 2 twice as many. Minimum=0,10 Maximum=3,00 Standard=1,00
        SnowKickFallAmount = 1.0,
        -- Vehicle wheels in snow throw powder and now and then a clump behind them: more the faster the vehicle goes, more again when it slides sideways. Works with tire tracks off too.
        SnowKickWheels = true,
        -- How much snow the wheels throw: 1 is about 40 puffs a second off a car at 40 km/h and over, 2 twice as many. Minimum=0,10 Maximum=3,00 Standard=0,80
        SnowKickWheelAmount = 0.8,
        -- Frost creeps in from the edges of the screen with the Hypothermia moodle: further in at each level, in full at level 4. Goes away as the character warms up. In multiplayer each player can hide it for themselves in Options > Mods.
        FrostScreen = true,
        -- How thick the frost at the edges of the screen is at its fullest, 0.1 (barely visible) to 1. In multiplayer always as on the server. Minimum=0,10 Maximum=1,00 Standard=0,80
        FrostScreenOpacity = 0.8,
        -- Level of the Hypothermia moodle (1-4) at which the first frost shows at the edges of the screen. It reaches further in at each level above, in full at level 4. In multiplayer always as on the server. Minimum=1 Maximum=4 Standard=1
        FrostScreenFromLevel = 1,
        -- Real seconds the frost takes to creep in to the next stage when the Hypothermia moodle rises. In multiplayer always as on the server. Minimum=1,00 Maximum=120,00 Standard=12,00
        FrostScreenComeSeconds = 12.0,
        -- Real seconds the frost takes to thaw back when the Hypothermia moodle drops or goes. In multiplayer always as on the server. Minimum=1,00 Maximum=300,00 Standard=30,00
        FrostScreenGoSeconds = 30.0,
        -- The frost at the edges of the screen trembles while the character shivers with cold, harder at each Hypothermia level. Turn off if screen motion bothers you.
        FrostScreenShiver = true,
        -- Level of the Hypothermia moodle (1-4) at which the frost starts to tremble. Minimum=1 Maximum=4 Standard=2
        FrostScreenShiverLevel = 2,
        -- A vehicle parked outdoors in the frost gets frost on its windows, on the glass itself. Scrape it off (right-click the vehicle; faster with a scraper, spatula or trowel) or run the engine with the heater on. In multiplayer each player can hide it for themselves in Options > Mods.
        VehicleFrost = true,
        -- Game hours a vehicle parked outdoors at -8 C or colder takes to frost over fully. Slower in a milder frost, none above 0 C. In multiplayer always as on the server. Minimum=0,25 Maximum=24,00 Standard=3,00
        VehicleFrostHours = 3.0,
        -- Game minutes the heater (with the engine running) takes to clear fully frosted windows. The engine alone takes four times as long. In multiplayer always as on the server. Minimum=1,00 Maximum=120,00 Standard=10,00
        VehicleFrostHeaterMinutes = 10.0,
        -- Game hours full frost takes to thaw on its own at +5 C; at +10 C half as long. Below 0 C it does not thaw on its own. In multiplayer always as on the server. Minimum=0,25 Maximum=24,00 Standard=2,50
        VehicleFrostMeltHours = 2.5,
        -- In a strong wind in the frost, low snow dust sweeps along the ground snow with the wind, in gusts. In multiplayer each player can hide it for themselves in Options > Mods.
        DriftingSnow = true,
        -- Wind speed from which snow drifts along the ground; it grows to full 30 km/h above it. Minimum=5,00 Maximum=100,00 Standard=25,00
        DriftingSnowWind = 25.0,
        -- How much snow dust drifts: 1 is about 30 wisps a second on the screen at full wind, 2 twice as many. Minimum=0,10 Maximum=3,00 Standard=1,00
        DriftingSnowAmount = 1.0,
        -- A campfire, a fire on the ground or a burning building melts the snow around it into a dark wet patch, with a little steam, while it burns. The patch freezes over and is snowed over after the fire goes out. In multiplayer each player can hide it for themselves in Options > Mods.
        FireThaw = true,
        -- Game hours a fully thawed patch takes to go after the fire is out, if no snow falls (falling snow covers it faster). Minimum=0,25 Maximum=24,00 Standard=2,00
        FireThawHours = 2.0,
        -- Snow walked over again and again (players and zombies) becomes a trodden path that lasts much longer than footprints: you can see where a horde keeps walking. Counted from the footprints, so only with footprints on. In multiplayer each player can hide them for themselves in Options > Mods.
        TrampledPaths = true,
        -- Footprints on one square that make a path there (older ones count less, half after 3 game hours); the path gets darker with more. About 2 footprints a square each time someone walks through. Minimum=3 Maximum=100 Standard=12
        TrampledPathSteps = 12,
        -- Game hours a path lasts after the last walker, if no snow falls (falling snow covers it faster). Minimum=1,00 Maximum=336,00 Standard=48,00
        TrampledPathHours = 48.0,
        -- Only with the Immersive Snow - Viewpoint add-on: depth of the snow on the ground in Viewpoint's 3D view at the highest snow level, less while it is building up or melting. The snow also drifts deeper against buildings, steps run together into a trench and shovelled squares stand as cuttings; from 10 cm it slows you down (3D snow slows you down). Minimum=5 Maximum=100 Standard=35
        SnowDepth = 35,
        -- Only with the Immersive Snow - Viewpoint add-on (its 3D snow on the ground): from 10 cm of snow (Snow depth) wading through it tires you, from 30 cm you cannot sprint, and a vehicle you drive goes slower (at 45 cm about half its top speed). Not on squares cleared with a shovel; on trampled paths it is easier. In MP the server decides.
        SnowSlowdown = true,
        -- Game hours of rain that wash a full cover of snow off the ground, in stages: the snow thins out, the prints and the depth go with it; heavy rain is twice as fast. 0: all at once at the next hour, as in vanilla. In MP the server decides. Minimum=0,00 Maximum=48,00 Standard=3,00
        RainWashHours = 3.0,
        -- Only in the 3D view of Viewpoint with the Immersive Snow - Viewpoint add-on: the snow on vehicles stands out as a layer where it settles on top (the roof, the bonnet: up to about 12 cm at the last stage at 100%); clothes, the vehicles' sides, ice and frost on the glass stay flat. 0: flat, as before. Minimum=0 Maximum=200 Standard=100
        SnowThickness3D = 100,
        -- Only in the 3D view of Viewpoint with the Immersive Snow - Viewpoint add-on: the snow on the ground has a depth (prints, ruts and furrows pressed into it). Off: the ground snow is flat, as Viewpoint lays it.
        Snow3DGround = true,
        -- Only in the 3D view of Viewpoint with the Immersive Snow - Viewpoint add-on: the snow on vehicles lies on top as a layer with a thickness (roof, bonnet, boot). Off: the snow on vehicles is flat, as in the isometric view.
        Snow3DVehicles = true,
    },
    PFR = {
        -- Standardzieltemperatur beim Platzieren einer neuen Kühleinheit. Bereich -30 bis 0 Celsius. Pro Einheit über das Bedienfeld änderbar. Zum Einfrieren ist ein Ziel unter 0 nötig: auf 0 gestellt bleibt der Raum kalt, aber nichts gefriert jemals. Minimum=-30 Maximum=0 Standard=-10
        TargetTemp = -10,
        -- Multiplikator für die Kühlrate. 1.0 = Standard, 0.25 = langsam, 4.0 = sehr schnell. Minimum=0,25 Maximum=4,00 Standard=1,00
        CoolingSpeed = 1.0,
        -- Temperaturen im Bedienfeld in Celsius oder Fahrenheit anzeigen. Standard=Celsius
        -- 1 = Celsius
        -- 2 = Fahrenheit
        TempUnit = 1,
        -- Multiplikator für den Einfluss offener Türen, zerbrochener Fenster und Lücken auf die Isolierung des Kühlraums. 0.0 = deaktiviert (Öffnungen haben keine Wirkung, wie in v1.1), 1.0 = Standard (Verhalten von v1.2), 3.0 = dreifache Wirkung. Minimum=0,00 Maximum=3,00 Standard=1,00
        InsulationStrength = 1.0,
        -- Wenn aktiviert, spürt deine Spielfigur die Kälte, solange sie sich in einem PFR-Kühlraum mit aktiver Kühleinheit aufhält. Löst je nach Raumtemperatur die spieleigenen Zustände aus (Unterkühlung, Erkältung). Wird automatisch deaktiviert, wenn die Mod Realistic Temperature aktiv ist, um Konflikte zu vermeiden.
        ColdFeelingEnabled = true,
    },
    PWS = {
        -- How many days ahead the computer shows exact highs and lows.
        -- 3 days is what a real station can honestly predict. 7 is the most this mod will give you.
        -- Set to 0 to remove precise forecasting entirely. Minimum=0 Maximum=7 Standard=3
        PreciseForecastDays = 3,
        -- How many days ahead the computer shows a rough trend - warm or cold front only, no numbers - past the precise range.
        -- Beyond about a week, real forecasting is guesswork, so 7 is the limit here. Minimum=0 Maximum=7 Standard=7
        TrendForecastDays = 7,
        -- How many past days the computer shows, up to 10.
        -- Days when the station had no power leave gaps in the record. Minimum=1 Maximum=10 Standard=10
        HistoryDays = 10,
        -- How often the meteorology magazine spawns in containers.
        -- The magazine is the only way to learn the recipes, so setting this to 0 disables the mod's crafting. Minimum=0 Maximum=1000 Standard=100
        MagazineLootMultiplier = 100,
        -- How far the desktop computer can sit from the weather station and still read it.
        -- 1 means right next to it, which is the default and the way the mod is balanced.
        -- The station has to stand outside, so raise this if you would rather keep the computer indoors. Minimum=1 Maximum=10 Standard=1
        ComputerRange = 1,
        -- How many floors up or down the computer can sit from the weather station and still read it.
        -- 0 means the same floor only, which is the default and changes nothing.
        -- Raise it if you want the station on the roof while the computer stays indoors. Minimum=0 Maximum=2 Standard=0
        ComputerVerticalRange = 0,
    },
    UnseasonalWeather = {
        -- If false, this mod's unseasonal weather events are disabled.
        Enabled = true,
        -- Approximate chance per day for an unseasonal weather event to occur. Minimum=0 Maximum=100 Standard=25
        DailyEventChance = 25,
        -- Shortest possible duration of a single unseasonal weather event. Minimum=1 Maximum=48 Standard=3
        MinDuration = 3,
        -- Longest possible duration of a single unseasonal weather event. Minimum=1 Maximum=72 Standard=8
        MaxDuration = 8,
        -- Scales the strength of unseasonal weather events. 1.0 = default. Minimum=0,20 Maximum=3,00 Standard=1,00
        IntensityMultiplier = 1.0,
        -- If enabled, each winter day rolls against Daily event chance to decide whether hardcore winter temperatures apply that day. Default: off.
        HardcoreWinterTemps = false,
        -- If enabled, each summer day rolls against Daily event chance to decide whether hardcore summer temperatures apply that day. Default: off.
        HardcoreSummerTemps = false,
        -- If true, unseasonal weather events keep their temperature, wind, fog and cloud changes but do not generate rain or snow.
        DryEvents = false,
        -- Rain now increases wetness progressively. Prolonged high wetness amplifies cold damage indirectly; rain does not cause direct illness.
        EnhancedRainExposure = true,
        -- If enabled, a lit campfire, fireplace, antique oven or barbecue warms players anywhere in the same enclosed room as strongly as standing beside it. Heat does not spread to other rooms. Default: off.
        RoomWideIndoorHeat = false,
        PauseWhileDriving = true,
        -- If true, lightning strikes emit a strong world sound that attracts zombies like a global meta event. Default: off.
        LightningAttractsZombiesGlobal = false,
        -- If true, Unseasonal Weather uses its custom minute-precision clock UI. If false, it is disabled and the normal clock is used.
        ClockUIEnabled = true,
    },
    UW_RadioForecasting = {
        -- If false, all SPEC radio forecasts are disabled.
        Enabled = true,
        -- If true, schedules broadcasts between 20:00 and 23:00; otherwise between 08:00 and 11:00.
        UseNightWindow = false,
        -- If true, active walkies show subtle WX scanner readings (default: on).
        WalkieHints = true,
        -- If true, print broadcast text to console for verification.
        DebugLogging = false,
    },
    PainkillersRemoveMuscleStrain = {
        -- Amount of stiffness/muscle strain removed from enabled body parts when taking painkillers (1-120). Minimum=1 Maximum=100 Standard=20
        strainRemoval = 20,
        -- Remove muscle strain from Right Hand when taking painkillers
        Hand_R = true,
        -- Remove muscle strain from Right Forearm when taking painkillers
        ForeArm_R = true,
        -- Remove muscle strain from Right Upper Arm when taking painkillers
        UpperArm_R = true,
        -- Remove muscle strain from Left Hand when taking painkillers
        Hand_L = true,
        -- Remove muscle strain from Left Forearm when taking painkillers
        ForeArm_L = true,
        -- Remove muscle strain from Left Upper Arm when taking painkillers
        UpperArm_L = true,
        -- Remove muscle strain from Head when taking painkillers
        Head = false,
        -- Remove muscle strain from Neck when taking painkillers
        Neck = false,
        -- Remove muscle strain from Upper Torso when taking painkillers
        Torso_Upper = false,
        -- Remove muscle strain from Lower Torso when taking painkillers
        Torso_Lower = false,
        -- Remove muscle strain from Groin when taking painkillers
        Groin = false,
        -- Remove muscle strain from Left Upper Leg when taking painkillers
        UpperLeg_L = false,
        -- Remove muscle strain from Left Lower Leg when taking painkillers
        LowerLeg_L = false,
        -- Remove muscle strain from Left Foot when taking painkillers
        Foot_L = false,
        -- Remove muscle strain from Right Upper Leg when taking painkillers
        UpperLeg_R = false,
        -- Remove muscle strain from Right Lower Leg when taking painkillers
        LowerLeg_R = false,
        -- Remove muscle strain from Right Foot when taking painkillers
        Foot_R = false,
    },
    PIW = {
        -- Wenn deaktiviert, sind die folgenden Funktionen nicht aktiv: 'Wundinfektionswahrscheinlichkeit', 'Wundinfektionsstärke', 'Verschmutzte Verbandstragzeit' und 'Wundinfektionsschadensmodifikator'.
        enableinfection = true,
        -- Ändert die Chance auf eine Wundinfektion, Standardchance ist 10/1000, wird jede Spielminute nach der sicheren Tragezeit aktualisiert. Minimum=1 Maximum=1000 Standard=11
        chanceofinfection = 11,
        -- Ändert, wie stark die Wundinfektion sein soll. Minimum=0,01 Maximum=8,00 Standard=0,75
        infectionstrength = 0.75,
        -- Ändert, wie lange man den schmutzigen Verband tragen kann, bevor man die Chance hat, eine Wundinfektion zu bekommen (gemessen in Spielminuten, bei Standardeinstellungen 24 Spielminuten = 1 echte Minute). Minimum=1 Maximum=10000 Standard=240
        safetime = 240,
        -- Ändert den Modifikator des Wundinfektionsschadens. Minimum=0,00 Maximum=1000,00 Standard=0,00
        infectiondamage = 0.0,
        -- Ändert, ob das Tragen von schmutzigen Verbänden auf Wunden Schaden verursacht.
        unsafedirtybandages = true,
        -- Ändert den Modifikator des Schadens von schmutzigen Verbänden. (Macht nichts, wenn 'Schmutzige Verbände richten Schaden an' deaktiviert ist). Minimum=0,00 Maximum=1000,00 Standard=2,25
        dirtybandagesdamage = 2.25,
        -- Ändert sich, wenn du reduzierte Heilung hast, wenn du eine infizierte Wunde hast (Achtung: Erhöht indirekt den Schaden).
        reducedhealingwhilewounded = true,
        -- Ändert den Prozentsatz (z.B. 0.3 = 30%) der Standardheilung, während ihr eine infizierte Wunde habt (bewirkt nichts, wenn 'Infizierte Wunde reduziert Heilung' deaktiviert ist). Minimum=0,00 Maximum=1,00 Standard=0,50
        reducedhealingwhilewoundedammount = 0.5,
        -- Ermöglicht es, durch eine Wundinfektion krank zu werden.
        sicknessenabled = true,
        -- Ändert die Stärke und Geschwindigkeit des Krankwerdens. Standard=Niedrig
        -- 1 = Sehr niedrig
        -- 2 = Niedrig
        -- 3 = Mittel
        -- 4 = Hoch
        -- 5 = Sehr hoch
        sicknessdificulty = 2,
        -- Ändert, wie lange man eine Wundinfektion haben kann, bevor man anfängt, krank zu werden (gemessen mit Spielminuten, bei Standardeinstellungen 24 Spielminuten = 1 echte Minute). Minimum=1 Maximum=10000 Standard=270
        sicknesssafetime = 270,
    },
    NaturesCall = {
        -- Multiplier applied to bladder filling over time. Minimum=0,10 Maximum=5,00 Standard=1,00
        BladderRateMult = 1.0,
        -- Multiplier applied to bowel filling over time. Minimum=0,10 Maximum=5,00 Standard=1,00
        BowelRateMult = 1.0,
        -- Multiplier applied to chance-based accidents from fill pressure, overflow, and incontinence. Minimum=0,10 Maximum=5,00 Standard=1,00
        AccidentChanceMult = 1.0,
        -- Multiplier applied to how much is released and how harsh the consequences are for non-forced accidents. Minimum=0,10 Maximum=5,00 Standard=1,00
        AccidentSeverityMult = 1.0,
        -- Multiplier applied to wipe supply consumption when cleaning after relief and accidents. Minimum=0,10 Maximum=5,00 Standard=1,00
        WipeNeedMult = 1.0,
        -- Multiplier applied to relief and wiping action duration. Minimum=0,10 Maximum=5,00 Standard=1,00
        WipeDurationMult = 1.0,
        -- When checked, gut health stays at a constant neutral and your diet no longer causes cramps, diarrhea, constipation, heartburn or any other good/bad gut effects. Eating and drinking still track and fill your bladder and bowels, and you can still get sick from rotten or tainted food and normal vanilla food effects. Can be changed mid-game (single-player and multiplayer).
        DisableGutSystem = false,
        -- Multiplier applied to how quickly gut health improves or worsens from diet. Minimum=0,10 Maximum=5,00 Standard=1,00
        GutTrendMult = 1.0,
        -- Multiplier applied to the duration of stomach effects (cramps, heartburn, diarrhea, constipation, laxative, sugar/water/caffeine highs, binge fatigue) when they are triggered or extended. Lower values let effects wear off faster. Minimum=0,10 Maximum=5,00 Standard=1,00
        EffectDurationMult = 1.0,
        -- Multiplier applied to discomfort and unhappiness from wearing soiled clothing. Set to 0 to disable these penalties. Minimum=0,00 Maximum=5,00 Standard=1,00
        SmellPenaltyMult = 1.0,
        -- Multiplier applied to zombie attraction radius from player soilage, dropped soiled items, exposed waste, and foul toilets. Set to 0 to disable smell-based attraction. Minimum=0,00 Maximum=5,00 Standard=1,00
        ZombieSmellRangeMult = 1.0,
        -- Multiplier applied to unhappiness from using unflushed toilets and to nearby foul-toilet smell severity. Set to 0 to disable these penalties. Minimum=0,00 Maximum=5,00 Standard=1,00
        ToiletPenaltyMult = 1.0,
        -- Multiplier applied to trait modifiers such as fill rates, control, soilage penalties, and accident scaling. Minimum=0,00 Maximum=5,00 Standard=1,00
        TraitIntensityMult = 1.0,
        -- Minimum accumulated scale (servings) before a food category's per-hour effects (bowel rate, control, mood, sleepiness) start applying. Higher values mean you must eat more of a category in a short window before its effects engage. Default 1.0 means roughly 2-3 servings. Minimum=0,50 Maximum=3,00 Standard=1,00
        CategoryActivationThreshold = 1.0,
        -- How fast a food category's effect fades per game hour once you stop eating it. Higher means effects wear off quicker. Default 0.50: a heavy meal's effect lasts about 1-3 hours and a single snack fades in well under an hour. Minimum=0,05 Maximum=1,00 Standard=0,50
        CategoryScaleDecayPerHour = 0.5,
        -- Multiplier applied to the per-hour magnitude of active food category effects and binge penalties. Higher values make the effects hit harder while active. Default 1.5. Minimum=0,50 Maximum=3,00 Standard=1,50
        CategoryIntensityScale = 1.5,
    },
    WoundsOverhaul = {
        -- Eine unbehandelte Wundinfektion erreicht die Blutbahn und tötet.
        -- Antibiotika wirken als Behandlung über mehrere Tage, nicht als einzelne Tablette.
        -- Ausgeschaltet verhält sich die Wundinfektion wie im Original.
        SepsisEnabled = true,
        -- Wie schnell eine Infektion greift und steigt. 1.0 ist die Balance, um die herum der Mod gebaut wurde: unbehandelt kommen die ersten Anzeichen nach etwa zwölf Stunden, und nach rund drei Tagen tötet sie.
        -- Niedriger ist milder. Der Körper heilt dadurch nie schneller, die Krankheit wird nur langsamer. Minimum=0,10 Maximum=5,00 Standard=1,00
        SepsisSpeed = 1.0,
        -- Wie viel Abdeckung nötig ist, um eine Infektion zu besiegen. 1.0 sind 48 Stunden - drei Antibiotika hintereinander, die Balance, um die herum der Mod gebaut wurde.
        -- Niedriger auf einer Welt mit wenig Medizin: 0.66 macht eine Kur aus zwei Tabletten, 0.33 aus einer. Höher macht die Heilung zum eigenen Projekt.
        -- Auf das Tempo der Krankheit selbst wirkt das nicht - dafür gibt es die eigene Einstellung. Minimum=0,25 Maximum=3,00 Standard=1,00
        AntibioticCourse = 1.0,
        -- Ein gebrochener Knochen unter einer offenen Wunde wird ohne Schiene schlimmer und füttert die Infektion.
        -- Nur Arme und Beine.
        -- Braucht zusätzlich die Option Bone Fracture, sonst kann überhaupt nichts brechen.
        FractureEnabled = true,
        -- Rippen, Schädel, Becken - die Brüche, an die keine Schiene kommt. An: Sitzen heilt sie messbar schneller, Laufen tut weh, wirft den Knochen zurück und zehrt an den Kräften; Schmerzmittel dämpfen das. Aus: Sie heilen auf dem festen Timer des Grundspiels, egal was du tust.
        AxialFractureEnabled = true,
        -- Mehr Medikamente, als der Körper abbauen kann, machen dich weit länger krank als die Überdosis selbst dauert - und hinterlassen Spuren an Leber und Nieren.
        -- Alkohol zusätzlich zu einer laufenden Behandlung ist für die Leber deutlich härter als Alkohol allein.
        -- Wasser hilft: wer getrunken hat, baut eine Überdosis etwa doppelt so schnell ab, und gesunde Nieren sind der Grund dafür.
        -- Ausgeschaltet verhalten sich Medikamente wie zuvor - eine Überdosis macht dich weiterhin krank, solange sie anhält, aber es sammelt sich nichts an.
        PoisoningEnabled = true,
        -- Starkes Bluten lässt den Überlebenden noch Tage nach dem Verbinden geschwächt zurück.
        BloodLossEnabled = true,
        -- Ein schwererer Überlebender hat mehr Blut zu verlieren: etwa 4,2 Liter bei 70 kg und weniger, 5 bei 80, 5,8 bei 90 und mehr. Dieselbe Wunde leert einen leichten Körper schneller, und derselbe Blutbeutel bringt einem schweren weniger. Aus: alle haben 5 Liter, wie bisher.
        BloodVolumeByWeight = false,
        -- Vervielfacht, wie schnell verlorenes Blut zurückkommt. 1.0 ist die Rate des Mods - etwa ein Tag, um ein Drittel des Blutes neu zu bilden, wenn man satt ist. 2.0 doppelt so schnell, 0.5 halb.
        -- Essen und die Heilungs-Eigenschaften wirken zusätzlich. Minimum=0,10 Maximum=10,00 Standard=1,00
        BloodRegenRate = 1.0,
        -- Vervielfacht, wie schnell ein blutender Körper Blut verliert. 1.0 ist die Rate des Mods - eine unbehandelte tiefe Wunde führt in etwa dreieinhalb Stunden zum Gesundheitsverlust. 2.0 doppelt so schnell, 0.5 halb.
        -- Die Schwellen bleiben: Ohnmacht, Gesundheitsverlust und das Ende kommen beim selben Anteil verlorenen Blutes. Minimum=0,10 Maximum=10,00 Standard=1,00
        BloodLossRate = 1.0,
        -- Schaltet den Blut-Teil des Mods frei: Blut abnehmen, Transfusion, Blutgruppen, Bestimmung und Kreuzprobe - und legt den Nachschub dafür in die Beute von Kliniken und Krankenhäusern: Blutbeutel (Einweg, das einzige Gefäß, in das Blut geht), ein Transfusionsbesteck und ein Blutgruppen-Testkit.
        -- Voreingestellt AUS. Solange es aus ist, wird nichts davon angeboten und kein Gegenstand spawnt jemals - der Mod bleibt reines Lua und lässt sich jederzeit entfernen.
        -- Einschalten lässt Mod-Gegenstände in deinen Spielstand.
        MedicalItemsEnabled = false,
        -- Vervielfacht, wie oft Blutbeutel, Transfusionsbestecke und Testkits in der Beute von Kliniken und Sanitätslagern auftauchen. 1.0 ist die Rate des Mods, 0.5 halb so oft, 2.0 doppelt - 0 nimmt sie ganz aus der Beute.
        -- Wirkt nur, solange der Schalter darüber an ist. Minimum=0,00 Maximum=5,00 Standard=1,00
        MedicalItemsRate = 1.0,
        -- Wie viele Spielstunden entnommenes Blut warm brauchbar bleibt. Echte Blutbanken erlauben 4; voreingestellt sind 8, damit der Heimweg möglich ist.
        -- Ein laufender Kühlschrank hält die Uhr an, eine Kühlbox verlangsamt sie um das Sechsfache, Winterluft bei 6 C oder kälter hält Blut, das nicht am Körper getragen wird.
        -- Ein Gefrierschrank macht Vollblut unbrauchbar. Minimum=1,00 Maximum=72,00 Standard=8,00
        BloodWarmHours = 8.0,
        -- An: mit Nadel und leerem Beutel kannst du nicht nur dir selbst, sondern auch einem Spieler neben dir Blut abnehmen - den Blutverlust trägt der Spender. Auf einem Server gilt das auch für jemanden, der bewusstlos ist und nicht ablehnen kann, also nur einschalten, wenn du deinen Spielern vertraust.
        -- Im Mehrspielermodus noch nicht getestet.
        -- Aus: jeder nimmt nur sich selbst Blut ab.
        DrawFromOthers = false,
        -- An: zwei Dinge vor dem Verband. Mit der Hand auf die Wunde drücken - solange du drückst, ein Viertel des Blutverlusts, die Hände sind beschäftigt. Arm oder Bein mit Gürtel, Seil oder Stoffstreifen hoch abbinden - darunter hört die Blutung auf, aber nach zwei Stunden wird die Gliedmaße taub und nach vier stirbt das Gewebe ab.
        -- Aus: keins von beiden.
        BleedingFirstAidEnabled = true,
        -- An: eine Verbrennung hat Grad 1 bis 4. Grad 1 heilt in einem Tag und entzündet sich nicht, Grad 2 bildet Blasen und braucht einen Verband, Grad 3 und 4 haben totes Gewebe, das kaum heilt und Infektionen nährt, bis es ausgeschnitten wird. Wer länger brennt, verbrennt tiefer; eine frische ungekühlte Verbrennung kann binnen einer halben Stunde tiefer werden - mit Wasser kühlen. Tiefe Verbrennungen machen durstig.
        -- Aus: die eine Verbrennung des Originals.
        BurnDegreesEnabled = true,
        -- An: eine Kugel bleibt entweder in einem Gelenk stecken - sie muss vor allem anderen heraus - oder tief im Gewebe, wo sie bleibt: die Wunde wird tamponiert und mit Antibiotika behandelt, bis sich das Gewebe darüber schließt. Schusswunden werden tamponiert, nicht genäht.
        -- Im Mehrspielermodus noch nicht getestet.
        -- Aus: Kugeln funktionieren genau wie im Original.
        GunshotWoundsEnabled = false,
        -- An: beim Nähen öffnet sich eine Nahaufnahme der Wunde, und jeden Stich setzt du selbst - die Nadel geht auf einer Seite hinein und auf der anderen hinaus, und wie gut das gerät, liegt an dir. Erste Hilfe entscheidet, wie ruhig deine Hand ist; eine chirurgische Nadel verzeiht mehr als eine Nähnadel. Eine schlechte Naht kann beim Laufen wieder aufreißen.
        -- Aus: das Nähen läuft genau wie im Original, entschieden von einem Würfelwurf im Hintergrund.
        SutureGameEnabled = true,
        -- An: das Ausschneiden einer gerissenen Wunde öffnet eine Nahaufnahme, und den abgestorbenen Rand schneidest du selbst weg - mit Skalpell oder Schere. Wie sauber der Schnitt ist, entscheidet, wie gut die Naht danach hält und wie sehr es schmerzt.
        -- Aus: das Ausschneiden ist eine gewöhnliche Aktion mit Zeitbalken, wie vor dem Minispiel.
        TrimGameEnabled = true,
        -- An: das Entfernen einer steckenden Kugel öffnet eine Nahaufnahme, und die Pinzette führst du selbst. Eine zitternde Hand tut weh und kann abrutschen.
        -- Aus: die Kugel wird wie im Original entfernt.
        ExtractGameEnabled = true,
        -- An: Salbe auftragen öffnet eine Nahaufnahme, in der du sie Klecks für Klecks selbst verreibst. Bedecke die ganze Verbrennung und geh sanft über Blasen.
        -- Aus: eine einfache Aktion, die den Großteil der Verbrennung bedeckt.
        OintmentGameEnabled = true,
        -- An: Das Abtragen des toten Gewebes einer Verbrennung dritten oder vierten Grades öffnet eine Nahaufnahme, in der du die Klinge selbst um jedes Stück führst. Neben dem Rand schneidest du lebende Haut.
        -- Aus: eine einfache Aktion trägt alles auf einmal ab.
        DebrideGameEnabled = true,
        -- An: Eine Verbrennung dritten oder vierten Grades rund um Arm oder Bein kann sich zuziehen und das Glied darunter absterben lassen, wenn der Schorf nicht eingeschnitten wird; eine abgetragene tiefe Verbrennung kann mit Haut vom Oberschenkel geschlossen werden; eine verheilte tiefe Verbrennung hinterlässt tagelang eine straffe, schmerzende Narbe. Mit The Only Cure wird ein abgestorbenes Glied amputiert.
        -- Aus: Bei tiefen Verbrennungen bleibt nur das Abtragen des toten Gewebes.
        DeepBurnsEnabled = true,
        -- An: Das Einschneiden des Schorfs zeigt die Verbrennung, und du führst die Klinge selbst.
        -- Aus: eine einfache Aktion erledigt es.
        EscharGameEnabled = true,
        -- An: Eine Hauttransplantation sind drei eigene Handgriffe - einen Streifen in einem gleichmäßigen Zug vom Oberschenkel abtragen, ihn auf die Verbrennung legen und an jeder Markierung festklammern (oder mit Nadel und Faden annähen).
        -- Aus: eine einfache Aktion erledigt es.
        GraftGameEnabled = true,
        -- An: Rechtsklick auf eine frische Leiche (höchstens drei Tage alt), um daran zu üben - Nähen, Wundränder ausschneiden und eine Kugel entfernen, falls beim Schuss eine stecken blieb. Dieselben Minispiele, derselbe Verbrauch, drei Viertel der Erste-Hilfe-EP. Drei Übungen Nähen und Ausschneiden pro Leiche.
        -- Jede Art braucht ihr Minispiel.
        CorpsePracticeEnabled = true,
        -- Der Körper zeigt immer, wo es weh tut und wie schlimm. Hier wird entschieden, wie viel vom Benennen zuerst eine Untersuchung übernehmen muss - und wie schnell und genau die ausfällt, entscheidet Erste Hilfe.
        -- Alles: nichts wird benannt, bevor du hinsiehst, Behandlung eingeschlossen.
        -- Nur was man nicht spürt: eine Verletzung, die du kommen sahst, wird sofort benannt, und das Hinsehen bleibt für Infektion, Schmutz und den Stand der Dinge.
        -- Nichts: alles wird sofort benannt, so wie im Original. Standard=Alles
        -- 1 = Alles
        -- 2 = Nur was man nicht spürt
        -- 3 = Nichts
        RequireExamination = 1,
        -- Wie schnell eine Untersuchung durchgeführt wird. Höher ist schneller.
        -- Erste Hilfe verkürzt sie zusätzlich. Minimum=0,10 Maximum=5,00 Standard=1,00
        ExamineSpeed = 1.0,
        -- Auf der strengsten Einstellung lässt sich ein Körperteil erst behandeln, wenn es untersucht wurde - du kannst nicht verbinden, was du dir nicht angesehen hast.
        -- Schalte das aus, damit die Benennung weiterhin eine Untersuchung braucht, die Erste Hilfe aber sofort möglich ist: in der Eile verbinden und später an einem sicheren Ort herausfinden, was es überhaupt war.
        -- Auf die anderen beiden Einstellungen hat das keine Wirkung, dort wurde ohnehin nichts zurückgehalten.
        TreatmentNeedsExam = true,
        -- An: ein Glied mit wenig darauf ist ein Blick, eines mit viel darauf eine richtige Untersuchung - ein Kratzer braucht etwa die halbe Grundzeit, drei Befunde die ganze.
        -- Aus (Standard): jede Untersuchung dauert die feste Zeit aus Fertigkeit und Tempo-Regler, egal wie viel oder wenig zu finden ist.
        ExamineScalesWithFindings = false,
        -- Unterhalb dieser Stufe in Erster Hilfe hält eine Untersuchung den Charakter an Ort und Stelle fest. 0 erlaubt Gehen von Anfang an, 10 nie.
        -- Beine, Füße und Leiste verlangen immer Stillstand - das ist Anatomie, nicht Können. Minimum=0 Maximum=10 Standard=4
        WalkingExamSkill = 4,
        -- Ein verbundenes Körperteil zeigt nur den Verband, einen Knochenbruch und ob es wehtut. Art der Wunde, Nähte und Infektion bleiben verborgen, bis der Verband abgenommen wird.
        -- Was vorher untersucht wurde, bleibt bekannt: Nach dem Abnehmen ist es ohne neue Untersuchung zu sehen.
        -- Aus: Wunden sind wie bisher durch den Verband hindurch zu lesen.
        CoveredWoundsHidden = true,
        -- Eine durchtrennte Halsschlagader leert einen Überlebenden in deutlich unter einer Minute, und eine ungeübte Figur schaut zwölf Sekunden hin, bevor sie eingreifen darf.
        -- An: der Hals kann sofort behandelt werden, wie im Grundspiel.
        -- Aus: er wartet auf eine Untersuchung wie jedes andere Körperteil.
        NeckSkipsExamination = true,
        -- Nur mit installiertem Mini Health Panel oder Mini Health Plus von Bedeutung. Deren schwebendes Fenster behandelt ohne Untersuchung - an der zentralen Regel dieses Mods vorbei.
        -- An: an einem nicht untersuchten Glied wird ihr Menü zurückgehalten, wie das Panel dieses Mods selbst.
        -- Aus: ihr Fenster bleibt die schnelle Spur - auf manchen Servern zählt bei einer Halswunde jede Sekunde, und ein Fenster zu viel vor dem Verband kann den Tod bedeuten.
        GateMiniHealthPanel = true,
        -- BETA - Aktivierung auf eigene Gefahr. Im Mehrspielermodus noch nicht getestet. Neuladen hilft nicht - wer bewusstlos war, liegt danach wieder. Feststecken kann niemand: nach sechs Stunden kommt die Figur in jedem Fall zu sich, und das Ausschalten der Option stellt sie sofort auf.
        -- 
        -- An: Nach dem Verlust von etwa einem Drittel des Blutes geht die Figur zu Boden und der Bildschirm wird dunkel - sie kann sich nicht bewegen und nichts tun und liegt hilflos da, wo sie gefallen ist. Ist die Blutung gestillt, kann ein anderer Überlebender sie wieder zu sich bringen: das bringt eine Stunde auf den Beinen, aber kein Blut zurück - das schafft nur eine Transfusion oder Zeit.
        -- Blutet sie weiter, kann das Herz stehen bleiben: dann helfen nur Herzdruckmassage (verschafft Zeit) und ein Defibrillator (startet es), sonst stirbt sie binnen einer halben Stunde.
        -- Von allein wacht sie auf, sobald die Blutung lange genug gestillt ist. Blutet sie noch, kommt sie für ein paar Minuten zu sich – Zeit für einen Verband; sonst wird sie wieder ohnmächtig.
        -- Aus: Der Blutverlust verhält sich genau wie bisher.
        UnconsciousEnabled = true,
        -- Vervielfacht die Erfahrung für das, was der Mod SELBST tut: eine Gliedmaße untersuchen, Wundränder ausschneiden, Blut abnehmen, kreuzproben, eine Transfusion legen. 1.0 ist die Rate des Mods, 0 zahlt dafür nichts.
        -- Nähen und Verbinden sind Belohnungen des Spiels und bleiben unangetastet - die bewegt man mit dem XP-Multiplikator der Welt. Minimum=0,00 Maximum=5,00 Standard=1,00
        XpRate = 1.0,
        -- Zeichnet die Nahaufnahmen der Wunden - das Untersuchungsfenster und das Näh-Minispiel - in einem pixeligen Stil, der zum Look des Spiels passt, statt in den gezeichneten Originalen.
        -- Die Wunden, die Zielmarken und alles, was sie tun, bleiben genau gleich; nur die Darstellung ändert sich.
        -- Voreingestellt aus.
        PixelArt = false,
        -- Schreibt in Zomboid/Lua/Wounds_debug.log, auf einem Server in Wounds_debug_server.log: die Werte jeder Erkrankung einmal pro Spielminute und was sie angefordert hat.
        -- Um herauszufinden, wohin die Gesundheit verschwindet, wenn im Panel nichts zu sehen ist. Schaltet KEINE Cheats frei.
        -- Standardmäßig aus: die Datei wächst und wird nie geleert.
        DebugLog = false,
    },
    DynamicGearRattling = {
        -- When enabled, zombies will hear the sounds of your gear. Off by default.
        ZombiesCanHearNoise = false,
        -- Multiplier for how loud zombies hear sounds (DOESN'T AFFECT PLAYERS). 1 by default, which is what the mod is balanced on. Minimum=0,10 Maximum=5,00 Standard=1,00
        ZombiesCanHearNoiseMultiplier = 1.0,
    },
    WorkingKnowledge = {
        -- How often Working Knowledge documents appear in loot containers. Does not affect already-generated containers; only new ones loaded after this setting is applied. Standard=Normal
        -- 1 = Very Rare
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Common
        -- 5 = Abundant
        SpawnRate = 3,
        -- Base XP awarded when a character reads a document for the first time. Scaled by the game's passive skill rate. Set to 0 to disable XP entirely. Default: 50. Minimum=0 Maximum=500 Standard=50
        XPGrant = 50,
        -- When enabled, a document is destroyed once it has been read, so it cannot be passed to another survivor. Intended for multiplayer servers that do not want a single copy training the whole group. Default: off.
        ConsumeOnRead = false,
    },
    ZombieVirusVaccineBETA = {
        -- <BHC>NICHT ändern. NUR FÜR ENTWICKLER. <RGB:1,1,1><LINE> Gibt eine riesige Menge an Debug-Informationen in der Konsole aus.
        DebugMode = false,
        -- Aktiviert oder deaktiviert vollständig das Erscheinen von Gegenständen aus Zombie Virus Vaccine in der Welt.
        EnableWorldLoot = true,
        -- Legt fest, wie viele chemische Gegenstände aus der Mod in der Welt erscheinen. Standard=Standard
        -- 1 = Deaktiviert
        -- 2 = Niedrig
        -- 3 = Standard
        -- 4 = Hoch
        LootChemicals = 3,
        -- Erweitert die Beutetabelle um zusätzliche chemische Produkte.
        ExpandChemicalsLoot = false,
        -- Aktiviert oder deaktiviert das Erscheinen von Gegenständen in Fahrzeugen.
        EnableVehicleLoot = true,
        -- Aktiviert oder deaktiviert das Erscheinen von Gegenständen in Überlebenden-Rucksäcken.
        EnableBagsLoot = true,
        -- Legt fest, wie viele Spritzen aus der Mod in der Welt erscheinen. Standard=Standard
        -- 1 = Deaktiviert
        -- 2 = Niedrig
        -- 3 = Standard
        -- 4 = Hoch
        LootSyringes = 3,
        -- Legt fest, wie viele Bücher über Laborausrüstung in der Welt erscheinen. Standard=Standard
        -- 1 = Deaktiviert
        -- 2 = Niedrig
        -- 3 = Standard
        -- 4 = Hoch
        LootEquipmentBooks = 3,
        -- Legt fest, wie viele Virologie- und Chemiebücher in der Welt erscheinen. Standard=Standard
        -- 1 = Deaktiviert
        -- 2 = Niedrig
        -- 3 = Standard
        -- 4 = Hoch
        LootVirologyBooks = 3,
        -- Legt fest, ob Virologiebücher nur an bestimmten Orten erscheinen oder über die gesamte Welt verteilt werden. Standard=Nur bestimmte Fundorte
        -- 1 = Fundorte erweitern
        -- 2 = Nur bestimmte Fundorte
        -- 3 = Häufig erscheinen lassen
        VirologyBooksSpawnMode = 2,
        -- Aktiviert oder deaktiviert die Alterung von Blut.  <LINE><BHC>Dies kann auf Multiplayer-Servern eine hohe CPU-Auslastung verursachen. Falls dies der Fall ist, sollte diese Funktion deaktiviert werden.
        BloodAgingMode = true,
        -- 14 ist der Standardwert der ursprünglichen Mod. Falls Probleme auftreten, reduziere diesen Wert oder deaktiviere die Blutalterung. Minimum=5 Maximum=21 Standard=14
        BloodAgingRadius = 14,
        -- Aktiviert die Wasserreinigung durch Hitze (Herde, Mikrowellen usw.). Wenn deaktiviert, ist die Wasserreinigung nur mit Chlortabletten möglich. <LINE><BHC>Dies kann auf Multiplayer-Servern eine hohe CPU-Auslastung verursachen. Falls dies der Fall ist, sollte diese Funktion deaktiviert werden.
        EnableWaterPurification = true,
        -- Der Radius, innerhalb dessen nach Laborkolben mit Wasser in Behältern zur Reinigung gesucht wird. Ticks onEveryTenMinutes. Minimum=5 Maximum=21 Standard=5
        WaterPurificationRadius = 5,
        -- Aktiviert oder deaktiviert das Erscheinen des Magazins zum Färben von Lampen. Wenn deaktiviert, können Spieler nicht lernen, wie man Lampen färbt.
        EnableLightPaints = true,
        -- Wenn aktiviert, erhält der Spieler jedes Mal Glasscherben als Material, wenn er Glas aus einem zerbrochenen Fenster entfernt.<LINE><LINE>Auch wenn diese Option deaktiviert ist, können Spieler weiterhin Glasscherben vom Boden aufheben.
        AllowWindowGlass = true,
        -- Erlaubt Spielern, Autopsien direkt auf dem Boden durchzuführen, ohne dass ein Tisch benötigt wird.
        AllowAutopsyOnGround = true,
        -- <BHC>Das Ändern dieser Option beeinflusst die Spielbalance. <RGB:1,1,1><LINE> Legt fest, wie viele Ticks benötigt werden, um eine Autopsie abzuschließen. Niedrigere Werte = schneller. Minimum=800 Maximum=1800 Standard=1200
        AutopsySpeed = 1200,
        -- Die maximale Anzahl an Stunden, bevor eine Leiche als zu stark verwest für eine Autopsie gilt. Minimum=2 Maximum=72 Standard=12
        AutopsyMaxHours = 12,
        -- <BHC>Das Ändern dieser Option beeinflusst die Spielbalance. <RGB:1,1,1><LINE> Legt fest, wie viele Ticks pro Fertigkeitsstufe in Erste Hilfe von der Autopsiezeit abgezogen werden. Minimum=0 Maximum=30 Standard=30
        TicksDecreasedByPerkLv = 30,
        -- <BHC>Das Ändern dieser Option beeinflusst die Spielbalance. <RGB:1,1,1><LINE> Legt den Geschwindigkeitsbonus bei einer Autopsie auf einem Obduktionstisch fest. Standard=50%
        -- 1 = Keiner
        -- 2 = 10%
        -- 3 = 20%
        -- 4 = 30%
        -- 5 = 40%
        -- 6 = 50%
        -- 7 = 60%
        TableSpeedBonus = 6,
        -- <BHC>Das Ändern dieser Option beeinflusst die Spielbalance. <RGB:1,1,1><LINE> Menge an Erfahrung, die bei einer Autopsie auf dem Boden gewonnen wird. Minimum=0 Maximum=15 Standard=15
        AutopsyGroundXP = 15,
        -- <BHC>Das Ändern dieser Option beeinflusst die Spielbalance. <RGB:1,1,1><LINE> Menge an Erfahrung, die bei einer Autopsie auf einem Tisch gewonnen wird. Minimum=0 Maximum=30 Standard=30
        AutopsyTableXP = 30,
        -- <BHC>Das Ändern dieser Option beeinflusst die Spielbalance. <RGB:1,1,1><LINE> Legt die Basis-EP fest, die in den Fertigkeiten Schlachten und Erste Hilfe gewonnen werden. Minimum=0 Maximum=30 Standard=15
        CollectPartXP = 15,
        -- <BHC>Das Ändern dieser Option beeinflusst die Spielbalance. <RGB:1,1,1><LINE> Legt die Basischance fest, ein Gehirn in perfektem Zustand zu entnehmen. Minimum=0 Maximum=15 Standard=10
        BrainHighOffset = 10,
        -- Legt den Hämophobie-Malus fest, der angewendet wird, wenn ein Charakter mit der Eigenschaft Hämophob eine Autopsie durchführt.<LINE> Beeinflusst die Chance, ein Gehirn in perfektem Zustand zu erhalten. Minimum=0 Maximum=30 Standard=10
        HemophobicDebuff = 10,
        -- Wenn aktiviert, nutzen sich Skalpelle bei Verwendung ab und können zerbrechen.
        AllowScalpelDegrade = false,
        -- Wenn aktiviert, nutzen sich Sägen bei Verwendung ab und können zerbrechen.
        AllowSawDegrade = true,
        -- Erlaubt Spielern, Leichen in einen Komposter zu legen, um Dünger herzustellen
        AllowBodyCompostage = true,
        -- Aktiviert/Deaktiviert die Startausrüstung für den Beruf Laborpraktikant <LINE><LINE> Wenn diese Option deaktiviert ist, startet der Beruf Laborpraktikant nicht mit Forschungsunterlagen
        StartingKit = true,
    },
    TOC = {
        -- Minimum=1 Maximum=10 Standard=1
        CicatrizationSpeed = 1,
        -- Minimum=0 Maximum=5 Standard=1
        WoundDirtynessMultiplier = 1,
        -- Minimum=1 Maximum=3 Standard=2
        SurgeonAbilityImportance = 2,
        EnableZombieAmputations = false,
        -- Minimum=0 Maximum=10 Standard=1
        ZombieAmputationDamageThreshold = 1,
        -- Minimum=0 Maximum=100 Standard=25
        ZombieAmputationDamageChance = 25,
        -- Eine Amputation, solange die Knox-Infektion unter diesem Prozentwert liegt, heilt immer. Standard 20. Minimum=1 Maximum=90 Standard=20
        CureWindow = 20,
        -- Zwischen dem Heilungsfenster und diesem Wert wird die Heilung zum Glücksspiel, das jede Stunde schlechter wird. 0 deaktiviert es. Minimum=0 Maximum=99 Standard=40
        LateGambleWindow = 40,
        -- Meldungen zu Schüttelfrost, Schweiß und Fieber, während die Infektion fortschreitet. Sie sind der einzige Hinweis.
        ShowSymptoms = true,
        -- Rechtsklick auf einen Biss oder Kratzer im Gesundheitsfenster liefert eine (fehlbare) Einschätzung. Auch mit dem Leitfaden zur Feldamputation möglich. Minimum=0 Maximum=10 Standard=2
        DiagnosisMinDoctor = 2,
        -- Aus: Ob du rechtzeitig warst, erfährst du auf die harte Tour.
        RevealOutcome = false,
        -- Skaliert die Chance auf eine grobe oder missglückte Amputation. 0 macht jede Operation sauber. Minimum=0,00 Maximum=5,00 Standard=1,00
        SurgeryRiskMultiplier = 1.0,
        -- Wie weit ein Patient ohne Betäubung zu hören ist. Zombies werden kommen. Minimum=0 Maximum=80 Standard=25
        ScreamRadius = 25,
        -- Wie stark Schlaftabletten bei einer Operation als Betäubung zählen, in Prozent (0 = gar nicht). Schmerzmittel zählen bis 60, Alkohol bis 50. Minimum=0 Maximum=50 Standard=30
        SleepingPillAnesthesia = 30,
        -- Zusätzlicher Ausdauerverbrauch beim Gehen mit Krücke, in Prozent des Standardwerts (100 = nach etwa einer Minute Gehen ohne Pause erschöpft, 0 = kein Zusatzverbrauch). Minimum=0 Maximum=300 Standard=100
        CrutchStaminaDrain = 100,
        -- Zusätzlicher Ausdauerverbrauch beim Kriechen, in Prozent des Standardwerts (100 = nach etwa 40 Sekunden erschöpft, 0 = kein Zusatzverbrauch). Minimum=0 Maximum=300 Standard=100
        CrawlStaminaDrain = 100,
        -- Charaktere, die mit einem Beinamputations-Merkmal beginnen, können bereits mit Krücken umgehen: ihr Verbrauch mit Krücke und beim Kriechen beträgt diesen Prozentsatz der obigen Werte (50 = die Hälfte). Minimum=0 Maximum=100 Standard=50
        AmputeeTraitStaminaDrain = 50,
        -- Amputations-Merkmale erscheinen nicht bei der Charaktererstellung. Charaktere, die sie bereits haben, behalten sie.
        HideAmputeeTraits = false,
        -- Erlaubt es, sich selbst den Oberarm oder Oberschenkel abzutrennen. Deutlich höheres Risiko zu scheitern oder mittendrin ohnmächtig zu werden.
        SelfAmputationHigh = false,
        DropSeveredLimbs = true,
        -- Füße, Unter- und Oberschenkel können amputiert werden. Zum Gehen braucht man dann eine Krücke oder eine Beinprothese.
        EnableLegAmputations = true,
        -- Ein verschmutzter Stumpf entzündet sich (normale Wundinfektion), verursacht Fieber und kann töten. Mit Alkohol reinigen und Antibiotika nehmen.
        SepsisEnabled = true,
        -- Minimum=1 Maximum=5 Standard=2
        SepsisSpeed = 2,
        -- Tage mit Schwäche, Hunger und Müdigkeit nach einer Amputation. Minimum=0 Maximum=14 Standard=5
        ConvalescenceDays = 5,
        PhantomPain = true,
        CarryPenalty = true,
        -- Jede Aktion nutzt die Prothese ab; repariere sie mit Kleber, Klebeband, Schweißstäben oder Schrauben, bevor sie kaputtgeht.
        ProsthesisWear = true,
        -- Wie schnell Prothesen verschleißen (1 = normal, 0,5 = halb so schnell, 2 = doppelt so schnell). Gilt auch für Kettensäge und Bajonett. Minimum=0,10 Maximum=5,00 Standard=1,00
        ProsthesisWearMultiplier = 1.0,
        ZombieCrawlerOnLegHit = true,
    },
    TrueSmoking = {
        -- Global burn speed for ALL smokables
        -- 25 = lasts forever · 100 = balanced · 200 = burns very fast Minimum=0,10 Maximum=3,00 Standard=1,00
        SmokingSpeed = 1.0,
        -- How strong each puff feels (nicotine hit + stress/boredom relief)
        -- 50 = weak puffs · 100 = normal · 200 = very strong Minimum=0,00 Maximum=3,00 Standard=1,00
        PuffStrength = 1.0,
        -- How much faster the smoke burns when walking, running or sprinting
        -- 25 = barely burns while moving · 100 = normal · 200 = burns fast when active Minimum=0,00 Maximum=3,00 Standard=1,00
        MovementBurn = 1.0,
        -- How quickly the cigarette goes out when standing still
        -- 0 = never goes out (always stays lit)
        -- 100 = goes out normally (needs relighting) Minimum=0,00 Maximum=3,00 Standard=1,00
        IdleBurnOut = 1.0,
        -- Multiplies all effects from smoking (nicotine, stress relief, boredom relief, etc.)
        -- 50 = half effects · 100 = normal · 200 = double effects Minimum=0,10 Maximum=3,00 Standard=1,00
        EffectMultiplier = 1.0,
        -- How much smoking reduces hunger
        -- 0 = no hunger reduction · 0.25 = subtle (default) · 1.0 = vanilla strength · 2.0 = double Minimum=0,00 Maximum=2,00 Standard=0,25
        HungerReduction = 0.25,
        -- How much smoking reduces fatigue
        -- 0 = no fatigue reduction · 0.25 = subtle (default) · 1.0 = vanilla strength · 2.0 = double Minimum=0,00 Maximum=2,00 Standard=0,25
        FatigueReduction = 0.25,
        -- Automatically lowers shemaghs, gas masks, etc. when smoking and re-equips them after
        ManageHeadGear = true,
        -- If the ember gets too weak, you can relight it instead of it dying completely
        SmokeRelighting = true,
        -- Enables the new smoking moodle which better reflects nicotine levels and withdrawal
        UseNewMoodle = true,
        -- Enable chance to cough when taking a puff
        Coughing = true,
        -- Chance (%) to cough per puff if player has the Smoker trait Minimum=0 Maximum=100 Standard=4
        CoughingChanceSmoker = 4,
        -- Chance (%) to cough per puff if player does NOT have the Smoker trait Minimum=0 Maximum=100 Standard=15
        CoughingChanceNonSmoker = 15,
        -- Chance to drop your lit cigarette when falling, climbing, or hit by zombies
        Dropping = true,
        -- Drop chance (%) if player has the Smoker trait Minimum=0 Maximum=100 Standard=6
        DropChanceSmoker = 6,
        -- Drop chance (%) if player does NOT have the Smoker trait (much clumsier!) Minimum=0 Maximum=100 Standard=35
        DropChanceNonSmoker = 35,
        -- Turns on nicotine tracking, withdrawal effects, and dynamic addiction
        UseNicotineSystem = true,
        -- Players can gain or lose the Smoker trait based on smoking habits
        DynamicSmokerTrait = true,
        -- How many in-game days of heavy smoking until player gains the Smoker trait Minimum=1 Maximum=60 Standard=10
        DaysToAddiction = 10,
        -- How many in-game days without smoking until player loses the Smoker trait Minimum=3 Maximum=90 Standard=30
        DaysToDetox = 30,
        -- How many in-game days it takes to reach peak withdrawal symptoms after quitting Minimum=1 Maximum=7 Standard=2
        DaysToPeakWithdrawal = 2,
        -- How quickly addiction and withdrawal decrease when player has the Smoker trait
        -- Higher = faster decay Minimum=0,10 Maximum=1,00 Standard=0,80
        SmokerTraitDecayMultiplier = 0.8,
        -- Enable debug logging and debug UI panel (for mod developers and troubleshooting)
        DebugMode = false,
    },
    NnC = {
        -- How often narcotics appear in world containers.
        -- REBOOT NEEDED AFTER CHANGE Standard=Uncommon
        -- 1 = Rare
        -- 2 = Uncommon
        -- 3 = Common
        -- 4 = Abundant
        Narcotics = 2,
        -- How often narcotics appear in vehicle containers.
        -- REBOOT NEEDED AFTER CHANGE Standard=Uncommon
        -- 1 = Rare
        -- 2 = Uncommon
        -- 3 = Common
        -- 4 = Abundant
        NarcoticsCar = 2,
        -- How often narcotics are carried by zombies.
        -- REBOOT NEEDED AFTER CHANGE Standard=Uncommon
        -- 1 = Rare
        -- 2 = Uncommon
        -- 3 = Common
        -- 4 = Abundant
        NarcoticsZombie = 2,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnBenzos = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnOpioids = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnPsychedelics = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnWeed = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnStimulants = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnSteroids = true,
        -- Indicates if you want the player to spawn in with drugs, if they have a drug trait. Example: Coke Head trait has you spawn in with Cocaine.
        -- REBOOT NEEDED AFTER CHANGE
        PlayerDrugSpawn = true,
        -- REBOOT NEEDED AFTER CHANGE
        ScreenEffects = true,
        -- Prints one group of the mod's internal counters to the console every ten in-game minutes. For troubleshooting; leave Off for normal play.
        -- REBOOT NEEDED AFTER CHANGE Standard=Off
        -- 1 = Off
        -- 2 = Addiction counters
        -- 3 = Active effect counters
        -- 4 = Overdose counters
        DevPrint = 1,
    },
    NepWrecks = {
        -- Vanilla default is 10, which is an entire welding torch. Minimum=0 Maximum=100 Standard=10
        FuelUsed = 10,
        -- If disabled you can use Safety Squints instead of a welding mask
        NeedMask = true,
        -- Mutliplies the amount of items created by salvaging Minimum=0,00 Maximum=100,00 Standard=1,00
        LootMult = 1.0,
        -- Prints additional debugging data to console
        DebugMode = false,
    },
    PushVehicle = {
        -- Allow vehicles to be turned by pushing near the front or rear section of either side. Disable this to restrict Push Vehicle to front and rear pushing only.
        AllowSidePushing = true,
        -- Multiplies the stamina consumed by each successful push. 1.0 keeps the original stamina cost; 0 disables stamina cost. Minimum=0,00 Maximum=10,00 Standard=1,00
        StaminaCostMultiplier = 1.0,
        -- Minimum time in seconds between successful pushes by the same player. 0 disables the cooldown. Minimum=0,00 Maximum=10,00 Standard=1,00
        PushCooldownSeconds = 1.0,
        -- Vehicles heavier than this cannot be pushed. Set to 0 for no weight limit. Minimum=0 Maximum=100000 Standard=0
        MaximumPushableWeight = 0,
    },
    AutomaticRefueling = {
        -- How much liters of fuel the pump will provide per ingame minute Minimum=1 Maximum=100 Standard=10
        LitersPerMinute = 10,
        -- The maximum distance a vehicle can move away from the pump, before it cuts off Minimum=1 Maximum=50 Standard=5
        MaxDistance = 5,
        -- Whether to remove the original pump-refuel and tsarslib option where you have to wait by the car
        RemoveOriginalOptions = true,
        -- Whether a pump can be damaged by driving off without having stopped the refuel process
        CanPumpBeDamaged = true,
        -- Whether a damaged pump can be repaired. Only relevant if "Pumps can be damaged" is enabled
        CanPumpBeRepaired = true,
        -- How many seconds in real-time it takes to repair a damaged pump. Only relevant if "Pumps can be damaged" is enabled Minimum=1 Maximum=60 Standard=5
        PumpRepairDuration = 5,
        -- The tile-radius in which the fuel pump sound will attract zombies (0 disables the sound) Minimum=0 Maximum=200 Standard=20
        PumpSoundRadius = 20,
    },
    GasPumpIndicator = {
        -- Adds the pump's remaining fuel to its right-click menu.
        -- Vanilla shows this number in debug mode only.
        ShowFuelAmount = false,
    },
    FCW = {
        -- If enabled, the car wash requires electricity (grid power or nearby generator) to function.
        RequireElectricity = true,
    },
    workingSeatbelt = {
        -- The percentage of damage reduced if a player wearing seatbelt takes damages from a car crash Minimum=0 Maximum=100 Standard=50
        seatbeltDamageReduction = 50,
        -- The percentage of fracture time reduced per fractured bodypart, if a fracture is resulted after a player wearing a seatbelt takes damages from a car crash. This doesn't actually prevent fractures unless set to 100 Minimum=0 Maximum=100 Standard=50
        seatbeltFractureReduction = 50,
        -- If enabled, there'll be a random chance for the player to get a chest fracture, if he crashes while the seatbelt is fastened
        seatbeltCausesChestFracture = true,
        -- The chance for the player to get a chest fracture if he takes damage from a car crash while seatbelt is fastened Minimum=0 Maximum=100 Standard=50
        chanceChestFracture = 50,
        -- The minimum crash strength that is required for a player to get a chest fracture while the seatbelt is buckled Minimum=0 Maximum=100 Standard=60
        chestFractureMinimumCrashStrength = 60,
        -- Defines the chest fracture time if a fracture is applied to the chest in a car crash, while the seatbelt is buckled Minimum=0 Maximum=100 Standard=3
        chestFractureTime = 3,
        -- Automatically forces the player into the seatbelt unfasten timed action if the player attempts to exit the vehicle while seatbelt is fastened. If set to false, the player will have to manually unfasten it before exiting
        exitVehicleAutoUnfasten = true,
        -- Automatically forces the player into the seatbelt unfasten timed action if the player attempts to switch seats while seatbelt is fastened. If set to false, the player will have to manually unfasten it before switching seats
        switchSeatAutoUnfasten = true,
        -- If enabled, a warning indicator will display on the vehicle's dashboard if the driver turns on a vehicle engine while not wearing a seatbelt, or unbuckles the seatbelt while the engine is running.
        seatbeltWarningIndicator = true,
        -- If enabled, a warning sound will play if the driver turns on a vehicle engine while not wearing a seatbelt, or unbuckles the seatbelt while the engine is running.
        seatbeltWarningChime = true,
        -- Whether or not players can right click the seatbelt indicator to toggle the chime on/off.
        playersToggleChime = true,
        -- The minimum vehicle speed for the seatbelt warning chime to start working (KM/H) Minimum=0 Maximum=100 Standard=15
        chimeMinimumSpeed = 15,
        -- If disabled, airbags will serve no function, nor will they affect/be affected by car crashes
        airbagModule = true,
        -- If enabled, certain vehicles won't have airbags according to Zomboid lore
        loreFriendlyAirbags = true,
        -- The minimum crash strength for an airbag to be deployed Minimum=0 Maximum=100 Standard=50
        airbagMinimumCrashStrength = 50,
        -- The percentage of damage reduced when an airbag is deployed Minimum=0 Maximum=100 Standard=50
        airbagDamageReduction = 50,
        -- The percentage of fracture time reduced per fractured bodypart, if a fracture is resulted after an airbag is deployed due to a car crash. This doesn't actually prevent fractures unless set to 100 Minimum=0 Maximum=100 Standard=50
        airbagFractureReduction = 50,
        -- If enabled, the damage reduction of airbags will be affected by their condition
        airbagsAffectedByCondition = true,
        -- If enabled, an alert will show above the player when the airbag deploys
        airbagDeploymentAlert = false,
        -- Whether or not the player can be thrown out of the windshield upon a severe car crash, if the windshield is broken and the player is not wearing a seatbelt.
        canPlayerBeEjected = false,
        -- The minimum crash strength for a player to get ejected out of the windshield Minimum=0 Maximum=100 Standard=65
        ejectMinimumCrashStrength = 65,
        -- The percentage of general health damage applied to a player when they are ejected out of the windshield Minimum=0 Maximum=100 Standard=85
        ejectDamage = 85,
    },
    MHP = {
        -- Fügt für verschmutzte Bandagen den Kontextmenü-Eintrag „Bandage ersetzen“ hinzu.
        EnableReplaceBandage = true,
        -- Zeigt den blauen Indikator an, wenn eine Bandage oder Schiene sicher entfernt werden kann.
        ShowSafeRemoveIndicator = true,
        -- Zeigt den lila Indikator an, wenn genähte Wunden überprüft werden sollten.
        ShowStitchInspectIndicator = true,
    },
    NeatLockpicking = {
        -- When off, vehicles use the vanilla hotwire action instead of the wire minigame.
        EnableHotwire = true,
        -- When on, locked windows can be opened with a lockpick, same as with a crowbar.
        EnableWindowLockpick = false,
        -- Minimum=3 Maximum=10 Standard=6
        PinCount = 6,
        -- Minimum=0 Maximum=100 Standard=50
        BreakChanceAtZeroSkill = 50,
        -- Minimum=0 Maximum=100 Standard=5
        BreakChanceMinimum = 5,
        NoiseOnFail = true,
        ResetPinsOnBreak = true,
        -- Minimum=0,10 Maximum=5,00 Standard=1,00
        BrokenLockpickDuration = 1.0,
        -- Minimum=1 Maximum=10 Standard=4
        RandomPinCountMin = 4,
        -- Minimum=1 Maximum=10 Standard=7
        RandomPinCountMax = 7,
        -- Minimum=3 Maximum=10 Standard=8
        ReinforcedDoorPinCount = 8,
        -- Degrees per second for the crowbar minigame on normal doors and windows. Default 180. Minimum=90 Maximum=900 Standard=180
        NormalDoorArrowSpeed = 180,
        -- Degrees per second for the crowbar minigame on security doors. Default 360. Minimum=180 Maximum=1800 Standard=360
        ReinforcedDoorArrowSpeed = 360,
        -- When on, a hit on a security door reverses the arrow direction.
        ReinforcedReverseArrowOnHit = true,
        -- Progress added per yellow-zone hit on security doors. Default 10%. Minimum=1 Maximum=100 Standard=10
        ReinforcedYellowHitValue = 10,
        -- Progress added per green-zone hit on security doors. Default 20%. Minimum=1 Maximum=100 Standard=20
        ReinforcedGreenHitValue = 20,
        -- When on, crowbar minigame progress slowly drops if you wait.
        CrowbarProgressDecayEnabled = true,
        -- Seconds between each decay tick. Default 2. Minimum=0,50 Maximum=10,00 Standard=2,00
        CrowbarProgressDecayInterval = 2.0,
        -- Progress removed each decay tick. Default 1%. Minimum=1 Maximum=10 Standard=1
        CrowbarProgressDecayAmount = 1,
        -- Multiplier on endurance lost per crowbar swing. Default 0.5 (half of the old drain). 1.0 is the previous rate. Minimum=0,10 Maximum=3,00 Standard=0,50
        CrowbarExhaustionMultiplier = 0.5,
        -- When on, pins bind after about 50% lift. The first pin in the sequence is stiffest. Off by default.
        PinResistanceEnabled = false,
    },
    NeatCrafting = {
        -- Wenn aktiviert, verwendet Neat Crafting Zutaten und Werkzeuge direkt aus erreichbaren Behältern, statt sie zuerst ins Hauptinventar des Charakters zu verschieben. Dies unterscheidet sich vom Vanilla-Crafting und kann einige Herstellungsvorgänge beschleunigen. Standard: Aus.
        CraftDirectFromAccessibleContainers = false,
    },
    CHStatusHUD = {
        -- Standardmäßig deaktiviert: Jeder Spieler entscheidet selbst, welche Werte sein HUD anzeigt, und die Optionen unten haben keine Wirkung. Aktiviere dies, um die folgende Liste für alle auf dem Server durchzusetzen – deaktivierte Werte können von Spielern nicht wieder eingeschaltet werden.
        RestrictStats = false,
        -- Das Verify-Menü im Rechtsklick liest jeden Wert direkt aus, auch vom Server gesperrte oder versteckte - das möchten manche Hardcore-Admins ihren Spielern nicht zeigen. Deaktivieren, um es komplett aus dem Rechtsklick-Menü aller Spieler zu entfernen.
        AllowVerifyTool = false,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Gesundheit aus dem HUD aller Spieler auszublenden.
        AllowHealth = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Nahrungsmittel aus dem HUD aller Spieler auszublenden.
        AllowFood = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Wasser aus dem HUD aller Spieler auszublenden.
        AllowWater = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Ausruhen aus dem HUD aller Spieler auszublenden.
        AllowRest = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Ausdauer aus dem HUD aller Spieler auszublenden.
        AllowEndurance = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Fitness aus dem HUD aller Spieler auszublenden.
        AllowFitness = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Stress aus dem HUD aller Spieler auszublenden.
        AllowStress = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Panik aus dem HUD aller Spieler auszublenden.
        AllowPanic = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Schmerzen aus dem HUD aller Spieler auszublenden.
        AllowPain = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Unglücklichkeit aus dem HUD aller Spieler auszublenden.
        AllowUnhappy = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Langeweile aus dem HUD aller Spieler auszublenden.
        AllowBoredom = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Temperatur aus dem HUD aller Spieler auszublenden.
        AllowBodyTemp = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Wut aus dem HUD aller Spieler auszublenden.
        AllowAnger = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Moral aus dem HUD aller Spieler auszublenden.
        AllowMorale = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Stress vom Nikotinentzug aus dem HUD aller Spieler auszublenden.
        AllowNicotine = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Untätigkeit aus dem HUD aller Spieler auszublenden.
        AllowIdleness = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Vernunft aus dem HUD aller Spieler auszublenden.
        AllowSanity = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Körperwärmeerzeugung aus dem HUD aller Spieler auszublenden.
        AllowHeatGen = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Nässe aus dem HUD aller Spieler auszublenden.
        AllowWetness = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Unwohlsein aus dem HUD aller Spieler auszublenden.
        AllowDiscomfort = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Lebensmittelvergiftung aus dem HUD aller Spieler auszublenden.
        AllowFoodSickness = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Gift aus dem HUD aller Spieler auszublenden.
        AllowPoison = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Übelkeit aus dem HUD aller Spieler auszublenden.
        AllowSickness = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Infiziert aus dem HUD aller Spieler auszublenden.
        AllowInfection = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Fieber aus dem HUD aller Spieler auszublenden.
        AllowFever = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Trunkenheit aus dem HUD aller Spieler auszublenden.
        AllowDrunk = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Traglast aus dem HUD aller Spieler auszublenden.
        AllowCarry = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Gewicht aus dem HUD aller Spieler auszublenden.
        AllowBodyWeight = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Kalorien aus dem HUD aller Spieler auszublenden.
        AllowCalories = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Proteine aus dem HUD aller Spieler auszublenden.
        AllowProteins = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Kohlenhydrate aus dem HUD aller Spieler auszublenden.
        AllowCarbs = true,
        -- Wirkt sich nur aus, während „Einschränken, welche Werte Spieler sehen können“ aktiviert ist. Deaktivieren, um Fett aus dem HUD aller Spieler auszublenden.
        AllowLipids = true,
        -- Spieler können optional Markierungen auf dem Balken aktivieren, die zeigen, wo die nächste Moodle-Stufe eines Werts einsetzt (z. B. Leichter Hunger/Hunger/Verhungern bei Nahrungsmittel). Deaktivieren, um diese Option für alle Spieler auszublenden, z. B. auf einem Hardcore-Server, bei dem die genauen Schwellenwerte verborgen bleiben sollen.
        AllowThresholdTicks = true,
    },
    BetterContainers = {
        -- Aktiviert das Naheinventar-System fur diesen Server.
        ProximityEnabled = true,
        -- Zwingt das Naheinventar dazu, nur fur Leichen zu funktionieren. Spieler konnen den Modus nicht wechseln.
        ForceCorpseOnly = false,
        -- Erlaubt Spielern, das Naheinventar per Tastenbelegung oder Mod-Optionen zu aktivieren oder zu deaktivieren.
        AllowToggleProximity = true,
        -- Erlaubt Spielern, zwischen dem Alle-Behalter-Modus und dem Nur-Leichen-Modus zu wechseln.
        AllowSwitchMode = true,
        -- Aktiviert die automatische Sperrfunktion. Wenn sie aktiv ist, springt das Naheinventar zum ausgewahlten Behalter zuruck, sofern es nicht absichtlich geandert wurde.
        AutoLockEnabled = true,
        -- Erlaubt Spielern, die automatische Sperre uber die Mod-Optionen zu aktivieren oder zu deaktivieren.
        AllowToggleAutoLock = true,
    },
    WhoseKeyIsThis = {
        -- On by default. Shows the name of a key lying on the ground nearby, above the key itself. When off, it is not shown even if a player has it enabled in their own mod options.
        AllowGroundKeys = true,
        -- On by default. When a key ring marked to be followed leaves a player's inventory - most often on the body they left behind - the last place it was seen is marked until it is picked up again. It is also what puts the key ring tab in the map's key list. When off, no player follows rings and no tab appears, however they have their own mod options set.
        TrackLostKeyRings = true,
        -- On by default. Multiplayer only. Following stops the moment another survivor takes the key ring out of your body and into their own pockets. Off, and the mark follows them instead. Dragging your body about or loading it into a car is not taking your ring, so the mark stays either way.
        StopWhenTaken = true,
        -- On by default. Multiplayer only, and only when "Stop following once another survivor takes it" above is on. Following stops once somebody moves the body well away from where it fell - dragged, loaded into a vehicle or stored in a container - even though the ring was never taken out of it. Off, and the mark follows the body wherever it goes. Shifting it out of a doorway is not enough to stop anything.
        MovedBodyCountsAsTaken = true,
        -- On by default. Multiplayer only. Someone who picks up a ring carrying another survivor's mark gets a right-click option to switch that mark off, which stops the follow on the other end too. Off, and the mark is not theirs to touch.
        TakerCanStop = true,
        -- Off by default, since it is a lot to ask in singleplayer. When on, distances, the map jump and the direction pointer only work while you carry a compass. Independent of the other rules. Renaming keys always works.
        RequireCompass = false,
        -- Off by default. When on, a key's location is only readable if you carry a paper map covering that spot - but once you have read a key's location it stays readable, map or not. Independent of the other rules.
        RequireMapItem = false,
        -- On by default. A key only shows its location if that part of the world map has already been uncovered - by walking there, or by a map you have read. Keys pointing into the blank stay hidden until you find the place. Independent of the other rules.
        RequireExplored = false,
    },
    CyesPushDoors = {
        -- Scales damage dealt to zombies.
        -- 0 disables damage but keeps other effects. Default: 1.0. Minimum=0,00 Maximum=2,00 Standard=1,00
        ZombieDamageMultiplier = 1.0,
        -- Scales targets per regular impact for all supported doors.
        -- Forced opening always affects its entire eligible crowd; sliding glass doors remain capped at 3. Minimum=0,25 Maximum=2,00 Standard=1,00
        ZombiesAffectedMultiplier = 1.0,
        -- Scales how many eligible zombies a character can push through before an entrance blocks.
        -- It also changes the pressure used to calculate regular and forced door wear. Garages are excluded. Default: 1.0. Minimum=0,50 Maximum=2,00 Standard=1,00
        DoorBlockCapacityMultiplier = 1.0,
        -- Chance for a selected eligible zombie to fall during regular, closing, or forced impacts; otherwise it staggers.
        -- Arm strain can reduce it. Sliding glass doors never knock zombies down. Default: 35%. Minimum=0 Maximum=100 Standard=35
        ZombieKnockdownChance = 35,
        -- Scales every durability loss caused by Push Doors!.
        -- 0 disables regular, forced, and garage wear, including random garage failure. Default: 1.0. Minimum=0,00 Maximum=3,00 Standard=1,00
        DoorWearMultiplier = 1.0,
        -- Extra wear multiplier for successful forced openings.
        -- Stacks with Door Wear; 0 disables only forced-opening wear. Default: 1.0. Minimum=0,00 Maximum=3,00 Standard=1,00
        ForcedOpeningDoorWearMultiplier = 1.0,
        -- Extra wear multiplier for garage doors.
        -- Stacks with Door Wear. Default: 1.0. Minimum=0,25 Maximum=3,00 Standard=1,00
        GarageDoorWearMultiplier = 1.0,
        -- Scales garage failure from Strength and existing damage while Door Wear is above 0.
        -- 0 disables random failure, not normal wear. Default: 1.0. Minimum=0,00 Maximum=3,00 Standard=1,00
        GarageFailureChanceMultiplier = 1.0,
        -- Scales vanilla Endurance consumed by successful CPD impacts.
        -- 0 disables CPD drain; current Endurance still affects CPD. Default: 1.0. Minimum=0,00 Maximum=3,00 Standard=1,00
        EnduranceCostMultiplier = 1.0,
        -- Scales the normal chance of fracturing one healthy part of the selected arm: hand, forearm, or upper arm.
        -- At critical endurance, with both arms already at the strain limit, or when the selected arm reaches the limit after the action, fracture risk is always 100%. Default: 1.0. Minimum=0,00 Maximum=2,00 Standard=1,00
        ForcedOpeningFractureRiskMultiplier = 1.0,
        -- Scales strain added to both arms by regular successful impacts and to the selected arm during forced opening.
        -- It also applies before garage-specific strain. Minimum=0,00 Maximum=3,00 Standard=1,00
        ArmStrainGainMultiplier = 1.0,
        -- Scales the 20.00 limit and every penalty threshold.
        -- Both arms at the limit block CPD effects. Default: 1.0. Minimum=0,25 Maximum=5,00 Standard=1,00
        ArmStrainUsageLimitMultiplier = 1.0,
        -- Extra strain multiplier for garage impacts.
        -- Stacks with Arm Strain Gain. Default: 1.0. Minimum=0,25 Maximum=3,00 Standard=1,00
        GarageArmStrainMultiplier = 1.0,
        -- Scales how arm strain reduces damage and knockdown chance.
        -- Default: 1.0. Minimum=0,00 Maximum=2,00 Standard=1,00
        ArmStrainPenaltyMultiplier = 1.0,
        -- Scales the anti-spam recovery between CPD impacts: 1.60s at 0-4.99 arm strain, 2.00s light, and 2.50s medium/high.
        -- Low Endurance can add extra recovery time. Default: 1.0. Minimum=0,25 Maximum=3,00 Standard=1,00
        ArmStrainRecoveryMultiplier = 1.0,
        -- Allows impacts to damage other valid PvP players. On normal doors, fence gates, and double entrances, a stronger target blocks the regular interaction but can be hit through forced opening. Sliding and garage doors do not use the player Strength block.
        DamagePlayers = true,
        -- Allows eligible door impacts to knock down other valid PvP players. Regular impacts use Player Knockdown Chance; forced opening has a 100% knockdown chance across its two-square impact band.
        KnockDownPlayers = true,
        -- Maximum chance for regular impacts after comparing Strength and Fitness.
        -- Winning one stat halves it; winning neither sets it to 0. Forced opening uses 100% while Knock Down Players is enabled. Default: 25%. Minimum=0 Maximum=100 Standard=25
        PlayerKnockdownChance = 25,
        -- Allows door impacts to damage and stun crawling zombies.
        AffectCrawlers = true,
        -- Allows doors, fences, and double doors to apply mod effects from either side.
        -- Disabled by default. Garages and sliding doors are unaffected.
        AllowImpactsFromBothSides = false,
        -- In MP, locks each player's personal feedback controls and enforces Global Impact Feedback.
        -- The forced-opening shortcut remains available.
        HideIndividualOptions = false,
        -- When personal feedback controls are locked, controls messages, custom animations, and sound effects for everyone.
        GlobalImpactFeedback = true,
    },
    DGMC_Bolt_Cutters = {
        -- ob das Schloss an Garagentoren aufgeschnitten werden kann
        Allow_Garage_Doors = true,
        -- ob das Schloss an Zauntoren aufgeschnitten werden kann
        Allow_Fence_Gates = true,
        -- ob Bolzenschneider zur Zerstörung von Zaunabschnitten eingesetzt werden können
        Allow_Fences = true,
        -- die prozentuale Chance, eine Ressource fallen zu lassen, wenn ein Zaunabschnitt zerstört wird, 0 zum Deaktivieren Minimum=0 Maximum=100 Standard=0
        Fence_Wire_Chance = 0,
        -- Wenn das Schloss an Sicherheitsläden über Türen und Fenstern aufgeschnitten werden kann, werden die Läden zerstört
        Allow_Shutters = true,
        -- Ein Charakter muss mindestens über diese Stärke verfügen, um einfache Aktionen ausführen zu können, wie zum Beispiel dünne Drahtzäune zu durchtrennen Minimum=0 Maximum=10 Standard=3
        Easy_Strength_Req = 3,
        -- Ein Charakter muss mindestens über diese Stärke verfügen, um mittelschwere Aktionen ausführen zu können, wie etwa das Aufschneiden von Schlössern Minimum=0 Maximum=10 Standard=5
        Medium_Strength_Req = 5,
        -- Ein Charakter muss mindestens über dieses Maß an Kraft verfügen, um herausfordernde Aktionen auszuführen, wie zum Beispiel das Durchtrennen dicker Zäune Minimum=0 Maximum=10 Standard=7
        Hard_Strength_Req = 7,
        -- Wie viele Sekunden dauert es, bis die Kraft berücksichtigt wird? Minimum=0 Maximum=60 Standard=22
        Base_Duration = 22,
        -- Wie viel Muskelbelastung wird angewendet, bevor die Kraft berücksichtigt wird? Minimum=0,00 Maximum=40,00 Standard=4,00
        Base_Muscle_Strain = 4.0,
        Debug_Logging = false,
    },
    ExerciseWithCorpses = {
        -- Check to enable, uncheck to disable
        scaleBool = false,
        -- Check to enable, uncheck to disable
        haloTextBool = true,
        -- Integer Value Only Minimum=1 Maximum=10 Standard=4
        exerciseStrXP = 4,
        -- Integer Value Only Minimum=1 Maximum=10 Standard=4
        exerciseFitXP = 4,
    },
    LGWalkieTalkies = {
        -- Wie schnell ein Funkgerät, das du bei dir trägst, seine Batterie verbraucht. 100 ist das normale Tempo, 50 lässt eine Batterie doppelt so lange halten, 0 heißt, sie wird nie leer. Minimum=0 Maximum=100 Standard=100
        BatteryUsagePercent = 100,
    },
    SprintDiveWindows = {
        -- Chance to botch the dive and hit the floor instead of landing on your feet. 0 means you never wipe out, 100 means you always do. Minimum=0 Maximum=100 Standard=30
        FailChance = 30,
        -- Chance to get cut by the glass when diving through a window. The chance of botching the dive itself is handled by the game's own vault over fence rules. Minimum=0 Maximum=100 Standard=60
        InjuryChance = 60,
        -- How long you must sprint before a dive is allowed. Higher means you need a longer run up. Minimum=0 Maximum=120 Standard=30
        MinSprintTime = 30,
        -- When you hit a window without enough of a run up, break the glass and risk getting cut. Turn this off to just bounce off the intact window, taking no injury.
        ShortSprintBreaksGlass = true,
        -- Play the game's normal sprint vault animation instead of the custom window smashing dive.
        VanillaAnimation = false,
        -- Prints debug messages to the console.
        Debug = false,
    },
    ImmersiveSuicide = {
        -- Wenn diese Option aktiviert ist, wird der Spieler nach einem Selbstmord immer zum Zombie, auch wenn er nicht infiziert ist.
        ForceZombification = false,
        -- Do you want a suicide confirmation popup to appear before performing a suicide?
        ShowConfirmationModal = true,
    },
    TrueSleep = {
        -- How much faster a solo napper rests compared to world time. 7 means a full night of rest fits into roughly one in-game hour. Minimum=1,00 Maximum=60,00 Standard=14,00
        SleepSpeed = 14.0,
        -- Solo naps cannot reduce fatigue below this remainder. Full rest is reserved for a proper night when everyone sleeps. Minimum=0 Maximum=90 Standard=15
        NapFloorPercent = 15,
        -- The server keeps restoring sleepers at normal speed on its own. With this on, Solo nap speed means the total rest speed instead of stacking on top of vanilla.
        CompensateVanilla = true,
        -- Minimum=0,00 Maximum=10,00 Standard=1,00
        EnduranceMult = 1.0,
        -- Automatically wake a solo napper once they hit the nap limit.
        WakeWhenRested = true,
        -- Small 'Sleeping 2/4' indicator with go-to-bed notifications.
        ShowHud = true,
        -- Minimum=0,10 Maximum=2,00 Standard=0,60
        FloorMult = 0.6,
        -- Minimum=0,10 Maximum=2,00 Standard=0,90
        BadBedMult = 0.9,
        -- Minimum=0,10 Maximum=2,00 Standard=1,00
        AverageBedMult = 1.0,
        -- Minimum=0,10 Maximum=2,00 Standard=1,10
        GoodBedMult = 1.1,
        -- Minimum=0,00 Maximum=0,50 Standard=0,05
        PillowBonus = 0.05,
    },
    TWF_QoL = {
        -- Wenn aktiviert, erhältst du bei gefundenen Wildpflanzen weiterhin die Nahrung, aber die automatisch zusätzlich erzeugten Samen werden ignoriert.
        -- Multiplayer: wird autoritativ über die Sandbox-Einstellung des Servers gesteuert.
        -- Einzelspieler: Die Mod-Optionen überschreiben diese Sandbox-Einstellung.
        ForagingIgnoreCollateralSeeds = false,
    },
    TWF_Resting = {
        -- Erlaubt Spielern, das Resting-Status-HUD über die Mod-Optionen zu aktivieren.
        -- Standard: deaktiviert.
        -- Aktiviere diese Option nur in Welten oder auf Servern, in denen das HUD erlaubt ist.
        AllowStatusHUD = false,
    },
    DGMC_Cleaning_Wipes = {
        -- Ob Sie Ihren Körper mit Reinigungstüchern reinigen können.
        Clean_Body = true,
        -- Ob man Kleidung mit Reinigungstüchern reinigen kann.
        Clean_Clothing = true,
        -- Ob man Nahkampfwaffen mit Reinigungstüchern reinigen kann.
        Clean_Weapons = true,
        -- Ob Sie beim Reinigen Ihres Körpers Make-up entfernen sollten.
        Remove_Makeup = true,
        -- Wie lange dauert die Reinigung mit Tüchern im Vergleich zum Waschen nur mit Wasser?  Niedriger für schneller, höher für langsamer. Minimum=0,00 Maximum=10,00 Standard=1,00
        Speed_Mult = 1.0,
        -- Beim Reinigen der Kleidung wird deren Feuchtigkeitsgrad maximal auf diesen oder den aktuellen Wert eingestellt.  Mit dem Standardwert würde beispielsweise Kleidung mit einem Feuchtigkeitsgehalt von 0 auf 25 eingestellt, während Kleidung, die bereits einen Feuchtigkeitsgehalt von 50 aufweist, auf 50 bleibt. Minimum=0 Maximum=100 Standard=25
        Wetness = 25,
        Debug_Logging = false,
    },
    TrueWeight = {
        -- If enabled, applies the mod creator's custom weight values. <LINE>Player custom sandbox settings above will ALWAYS override the preset if modified.
        UseModPreset = true,
        -- Multiplies the weight of ALL items in the game. <LINE>This calculation is applied AFTER any custom lists, sandbox categories, or mod presets. Minimum=0,00 Maximum=256,00 Standard=1,00
        GeneralMultiplier = 1.0,
        -- Format: ItemID:Weight;ItemID:Weight <LINE>(e.g., Nails:0.001;DuctTape:0.1)
        CustomWeights = "Key1:0;Key_Blank:0;KeyPadlock:0;CarKey:0;WalkieTalkie1:0.1;WalkieTalkie2:0.1;WalkieTalkie3:0.1;WalkieTalkie4:0.1;WalkieTalkie5:0.1;WalkieTalkieMakeShift:0.1;Padlock:0;CombinationPadlock:0;WalkieTalkie1_Electric:0.1;WalkieTalkie2_Electric:0.1;WalkieTalkie3_Electric:0.1;WalkieTalkie4_Electric:0.1;WalkieTalkie5_Electric:0.1;WalkieTalkieMakeShift_Electric:0.1",
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Accessory = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Ammo = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Animal = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        AnimalPart = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        AnimalPartWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Animals = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Appearance = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Armor = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Assembly = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Badger = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Bag = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Bandage = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Barricades = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Bear = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Beaver = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Blacksmithing = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Blade = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        BrokenWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Bug = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Bunny = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        CDs = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Camping = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Carpentry = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Cartography = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Carving = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Clothing = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Communications = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Container = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Cooking = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        CookingWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Cookware = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Corpse = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Debug = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Dog = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Duck = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Ears = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Electrical = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Electronics = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Entertainment = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Explosives = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Eye = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Farming = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        FireSource = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Firearm = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        FirstAid = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        FirstAidWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Fishing = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        FishingWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Food = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Fox = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Frog = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Furniture = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Gardening = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        GardeningWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Generic = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Glassmaking = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Goblin = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Hedgehog = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Hidden = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Home_VHS = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Household = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        HouseholdWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Instrument = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        InstrumentWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Item = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Junk = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        JunkWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Knapping = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        LightSource = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Literature = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        MaleBody = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Masonry = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Material = 0.05,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        MaterialWeapon = 0.05,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Medical = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Memento = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Meta = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Metalworking = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Miscellaneous = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Mole = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Music = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Object = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Outdoors = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Packing = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Paint = 0.05,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Player = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Pottery = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        ProtectiveGear = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Raccoon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        RecipeResource = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Repair = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Retail_VHS = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Security = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        SkillBook = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Slash = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Spear = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Spider = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Sports = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        SportsWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Squirrel = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Stab = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Swinging = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Tail = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Tailoring = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Teddy_Bear = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Tool = 0.05,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        ToolWeapon = 0.05,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Tools = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Trapping = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        UI = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Vehicle = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        VehicleMaintenance = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        VehicleMaintenanceWeapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Wall_Coverings = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Water = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        WaterContainer = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Weapon = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        WeaponCrafted = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        WeaponImprovised = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        WeaponPart = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Weaponry = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Welding = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        World = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Wound = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        ZedDmg = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        Zombie = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        bodywork = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        brakes = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        door = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        engine = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        gastank = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        lights = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        nodisplay = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        seat = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        suspension = 1.0,
        -- Minimum=0,00 Maximum=256,00 Standard=1,00
        tire = 1.0,
    },
    OverTheShoulder = {
        -- How often the character stumbles while running and looking back. A glance of about a second is safe, after that the risk grows over three seconds up to this rate and stays there. Looking ahead again lets it fade. <LINE> 15 is roughly one fall per minute of looking back, 100 is one every ten seconds, 1000 is one a second. Zero never falls. Minimum=0,00 Maximum=1000,00 Standard=100,00
        RunTripChance = 100.0,
        -- The same for a sprint. Minimum=0,00 Maximum=1000,00 Standard=180,00
        SprintTripChance = 180.0,
        -- The rates above are for a character with no skill. Each level of Sprinting cuts them by 6%, each level of Fitness by 4%, so level ten in both removes falls entirely. Graceful halves the rate, Clumsy raises it by half. <LINE> Off, the rates work exactly as set, skills and traits are ignored.
        TripSkillScaling = true,
        -- Helmets, goggles, gas masks and other worn items that narrow the field of view also shorten how far you can see behind you when looking over the shoulder. <LINE> Off, looking back reaches behind you whatever you wear. The normal field of view is narrowed by them as usual.
        WornItemsLimitLook = true,
        -- Holding the look over the shoulder for long makes the neck stiff and sore. A quick glance and the first three seconds are free. <LINE> 1 is the normal rate, 2 twice as fast, 0.5 half as fast. Zero turns neck pain off. Minimum=0,00 Maximum=10,00 Standard=1,00
        NeckStrainFactor = 1.0,
        -- Degrees the edge of the field of view goes past the line straight behind you when looking back. <LINE> 0 stops right at your back, 10 shows a little more of the other side. At night a small margin helps the area straight behind stay visible. Minimum=0 Maximum=10 Standard=5
        BackMargin = 5,
    },
    SNT = {
        -- Sets damage, accuracy and instant kills of all turrets (normal zombie: 1.0 health). Weak: damage x0.6, -15 percent hit chance, no instant kills - rifle needs 2-3 hits. Realistic (default): base values, 5 percent instant kills - rifle 1-2 hits. Strong: damage x2, +3 percent, 15 percent instant kills - rifle almost always 1 hit. Very strong: damage x3.5, +5 percent, 30 percent instant kills - almost always 1 hit. Extreme: damage x6, +10 percent, 75 percent instant kills. Lethal: every hit kills, +15 percent. Standard=Realistic
        -- 1 = Weak
        -- 2 = Realistic
        -- 3 = Strong
        -- 4 = Very strong
        -- 5 = Extreme
        -- 6 = Lethal
        TurretStrength = 2,
        -- If on, turrets need no ammo at all. Single shots or bursts are set on each rifle turret (right-click > Settings).
        UnlimitedAmmo = false,
        -- How much material the Junkyard Sentinel build menu asks for (turrets, sensor post, alarm lamp, barricade, fences, gates, watchtower). Hard: twice the material of Normal, Very hard: three times, Extreme: four times. Tools stay the same. Above Normal, turrets, sensor post and alarm lamp can only be made in the build menu, not in the crafting menu. Standard=Normal
        -- 1 = Normal
        -- 2 = Hard (x2 material)
        -- 3 = Very hard (x3 material)
        -- 4 = Extreme (x4 material)
        BuildDifficulty = 1,
        -- Raises every skill the Junkyard Sentinel build menu asks for by 1, 2 or 3 levels (at most 10). Example: the gun turrets need Electrical 4 on Normal, 6 on Very hard. Above Normal, turrets, sensor post and alarm lamp can only be made in the build menu, not in the crafting menu. Standard=Normal
        -- 1 = Normal
        -- 2 = Hard (+1 skill level)
        -- 3 = Very hard (+2 skill levels)
        -- 4 = Extreme (+3 skill levels)
        BuildSkill = 1,
        -- Size of a base square (Base tab: New base / Move base). Bases set earlier keep their size until they are moved. Standard=60 x 60 tiles
        -- 1 = 40 x 40 tiles
        -- 2 = 60 x 60 tiles
        -- 3 = 80 x 80 tiles
        -- 4 = 100 x 100 tiles
        -- 5 = 150 x 150 tiles
        BaseSize = 2,
        -- How many base squares one player may set. Admins have no limit. Minimum=1 Maximum=10 Standard=3
        BasesPerPlayer = 3,
        -- On: turrets, fences, gates, towers, barricades, sensor posts and alarm lamps of this mod can only be built inside an own base square (or one of an owner the player builds for). Admins can build anywhere.
        BuildOnlyInBases = false,
        -- Who can switch and configure a turret and take things out of it. Invited players (Moderator / Member / User) may what the server admin allows in Admin > Roles; members of the owner's safehouse count as Member when that switch is on there. Renaming and picking up always follow the groups. Admins may always do everything. Standard=Owner and invited players (Admin > Roles)
        -- 1 = Owner and invited players (Admin > Roles)
        -- 2 = Same, and always the owner's safehouse
        -- 3 = Everyone
        ControlAccess = 1,
        -- Active turrets one player can own. Extra turrets stay switched off. 0 = no limit. Minimum=0 Maximum=500 Standard=12
        MaxTurretsPerPlayer = 12,
        -- Only matters with an NPC mod (Project A-Life, Bandits, Roaming Survivors and others). What turrets do with NPCs unless the owner picks something else in the turret menu. Non-hostile means friendly or neutral towards the turret owner (companions, recruits, friendly survivors); hostile NPCs (raiders, hostile bandits) are shot. NPCs of mods the turret does not know count as non-hostile. Standard=Spare non-hostile NPCs
        -- 1 = Shoot all NPCs
        -- 2 = Spare non-hostile NPCs
        -- 3 = Spare all NPCs
        NpcDefault = 2,
        -- Rifle turret: maximum distance to a target in tiles. Minimum=3 Maximum=30 Standard=12
        Range = 12,
        -- Shotgun turret: maximum distance to a target in tiles. Minimum=2 Maximum=20 Standard=6
        SG_Range = 6,
        -- Sniper turret: maximum range in tiles. Hard cap is 30. Minimum=4 Maximum=30 Standard=22
        SN_Range = 22,
        -- Harpoon turret: maximum range in tiles. Minimum=3 Maximum=30 Standard=10
        HP_Range = 10,
        -- If on, every fired spear lands next to the target and can be picked up again. If off, fired spears are used up.
        HP_DropSpears = true,
        -- Only a separator - this box does nothing.
        UG_Separator = true,
        -- On (default): vanilla rifles, shotguns and the like work in the Universal Gun Turret too (useful on servers without a gun mod). Off: it only takes weapons from gun mods; vanilla firearms belong to the Sentinel Turrets. Pistols and revolvers never work.
        UG_AllowVanilla = true,
        -- The turret fires with the values of the weapon in it, measured against a vanilla weapon of the same class and the turret strength above. This multiplies the damage on top (1.0 = as calculated). Minimum=0,10 Maximum=5,00 Standard=1,00
        UG_DamageMult = 1.0,
        -- A weapon can deal at most this many times the damage of the matching Sentinel Turret (1.5 = 50 percent more). Keeps very strong mod weapons in check. Minimum=0,50 Maximum=5,00 Standard=1,50
        UG_MaxFactor = 1.5,
        -- Machine guns (M60, BAR and the like) deal this much more damage per round. They already fire at their real rate of fire in long bursts. Minimum=0 Maximum=200 Standard=25
        UG_MGBonus = 25,
        -- Only a separator - this box does nothing.
        SB_Separator = true,
        -- How much each barricade tile takes before zombies break it. A stick fence has 200. Applies to barricades built from now on. Minimum=50 Maximum=5000 Standard=400
        SB_Health = 400,
        -- Damage a zombie takes from the spikes each second while it touches the barricade - striking it or walking past (0 = none). A zombie has about 1 health: 0.02 = dead after about 50 seconds of contact, 0.04 = about 25 seconds. Minimum=0,00 Maximum=1,00 Standard=0,02
        SB_Damage = 0.02,
        -- Only a separator - this box does nothing.
        FN_Separator = true,
        -- How much each fence piece and gate tile takes before zombies break it. A stick fence has 200, the spike barricade 400. Applies to pieces built or repaired from now on. Minimum=50 Maximum=10000 Standard=600
        FN_Health = 600,
        -- Only a separator - this box does nothing. The settings below are for special cases and rarely need changing.
        ADV_Separator = true,
        -- Turrets and sensors already recognise NPCs of Project A-Life, Bandits, Roaming Survivors, Stay With Me and other mods using the common markers. For another NPC mod, add the marker its bodies carry, separated by ; - an animation variable by name (e.g. MyNpcMod) or a mod data key as md:Key.
        NPC_Markers = "",
        -- Weapons the turret refuses, separated by ; - e.g. MarzGuns.AA12;MarzGuns.M60 or a whole mod with MarzGuns.*
        UG_BlockList = "",
    },
    SNS = {
        -- Only a separator - this box does nothing.
        Separator = true,
        -- Max. distance in tiles between two linked sensor posts (default 30). Minimum=5 Maximum=60 Standard=30
        LinkRange = 30,
        -- Max. number of sensor posts in one network (default 15). Minimum=2 Maximum=30 Standard=15
        MaxPosts = 15,
        -- Max. distance in tiles from an alarm lamp to the nearest post of the network it is linked to (default 150). Far away posts only detect zombies while their area is loaded (a player nearby). Minimum=10 Maximum=1000 Standard=150
        LampRange = 150,
        -- How many sensor networks one player may own (default 5, 0 = no limit). Admins have no limit. Minimum=0 Maximum=50 Standard=5
        MaxNetworksPerPlayer = 5,
        -- How many other networks one sensor network can be bridged with (default 3, 0 = no bridges). An alarm also sounds on the lamps of bridged networks. Minimum=0 Maximum=10 Standard=3
        MaxBridges = 3,
        -- How many bridges in a row an alarm travels (default 5). Network A - B - C: depth 2 reaches C. Minimum=1 Maximum=10 Standard=5
        BridgeDepth = 5,
    },
    UndeadSurvivor = {
        -- Der Wert ist in Prozent, teilt aber die Chance mit anderen Outfits (Beispiel: Bei 100 hast du nie nur Zombies in diesem Outfit) Minimum=0,00 Maximum=100,00 Standard=0,04
        StalkerChance = 0.04,
        -- Zombies erscheinen erst in diesem Outfit, wenn in der aktuellen Welt so viele Tage überlebt wurden. Null bedeutet, dass es von Anfang an erscheinen kann. Minimum=0 Maximum=3650 Standard=180
        StalkerMinDays = 180,
        -- Der Wert ist in Prozent, teilt aber die Chance mit anderen Outfits (Beispiel: Bei 100 hast du nie nur Zombies in diesem Outfit) Minimum=0,00 Maximum=100,00 Standard=0,04
        NomadChance = 0.04,
        -- Zombies erscheinen erst in diesem Outfit, wenn in der aktuellen Welt so viele Tage überlebt wurden. Null bedeutet, dass es von Anfang an erscheinen kann. Minimum=0 Maximum=3650 Standard=0
        NomadMinDays = 0,
        -- Der Wert ist in Prozent, teilt aber die Chance mit anderen Outfits (Beispiel: Bei 100 hast du nie nur Zombies in diesem Outfit) Minimum=0,00 Maximum=100,00 Standard=0,04
        PrepperChance = 0.04,
        -- Zombies erscheinen erst in diesem Outfit, wenn in der aktuellen Welt so viele Tage überlebt wurden. Null bedeutet, dass es von Anfang an erscheinen kann. Minimum=0 Maximum=3650 Standard=0
        PrepperMinDays = 0,
        -- Der Wert ist in Prozent, teilt aber die Chance mit anderen Outfits (Beispiel: Bei 100 hast du nie nur Zombies in diesem Outfit) Minimum=0,00 Maximum=100,00 Standard=0,04
        HeadhunterChance = 0.04,
        -- Zombies erscheinen erst in diesem Outfit, wenn in der aktuellen Welt so viele Tage überlebt wurden. Null bedeutet, dass es von Anfang an erscheinen kann. Minimum=0 Maximum=3650 Standard=90
        HeadhunterMinDays = 90,
        -- Der Wert ist in Prozent, teilt aber die Chance mit anderen Outfits (Beispiel: Bei 100 hast du nie nur Zombies in diesem Outfit). Das Amazonen Outfit erscheint nur an weiblichen Zombies - für eine gleiche Spawn-Rate setze den Wert doppelt so hoch wie bei den anderen Outfits. Minimum=0,00 Maximum=100,00 Standard=0,08
        AmazonaChance = 0.08,
        -- Zombies erscheinen erst in diesem Outfit, wenn in der aktuellen Welt so viele Tage überlebt wurden. Null bedeutet, dass es von Anfang an erscheinen kann. Minimum=0 Maximum=3650 Standard=180
        AmazonaMinDays = 180,
    },
    AmmoLootDropVFE93B42 = {
        -- <RGB:1,1,1>The chance for each round type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 3 does not mean 3% of zombies.
        -- Many small chances add up. At 3 you
        -- get ammo from about 60% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get ammo from about
        -- 11% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop ammo. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=3,00
        DropRate = 3.0,
        -- <RGB:1,1,1>How many rounds you get each time
        -- ammo drops. You get between 1 and
        -- this many.
        -- 
        -- <RGB:0.100,0.800,1.000>This does not change how often you
        -- find ammo. Only the drop rate above
        -- does that. It changes how much you
        -- find each time.
        -- 
        -- Every round type gets its own
        -- number, so a body with two calibers
        -- gives a separate amount for each.
        -- 
        -- <RGB:0.800,1.000,0.000>At the default of 10, a body with
        -- ammo holds about 8 rounds. That is
        -- enough to be useful.
        -- 
        -- Set it to 1 if you want only one
        -- round at a time, like the old
        -- version of this mod.
        -- 
        -- <RGB:1.000,0.700,0.200>A body has limited space. If you set
        -- a big number, the body may fill up
        -- and you will get less than you asked
        -- for. Minimum=1 Maximum=99 Standard=10
        LooseRoundsMax = 10,
        -- <RGB:1,1,1>OFF: any zombie can drop ammo. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop ammo, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets9mm = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets45 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets44 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets38 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets357 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoShotgunShells = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo3030Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo223Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo762Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308BulletsLinked = true,
        Ammo57Bullets = true,
        Ammo46Bullets = true,
    },
    AmmoLootDropVFE93B42Box = {
        -- <RGB:1,1,1>The chance for each box type to drop
        -- from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.3 does not mean 0.3% of
        -- zombies. Many small chances add up.
        -- At 0.3 you get boxes from about 9%
        -- of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get boxes from about
        -- 1% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop boxes. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,30
        DropRate = 0.3,
        -- <RGB:1,1,1>OFF: any zombie can drop boxes. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop boxes, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets9mmBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets45Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets44Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets38Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets357Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoShotgunShellsBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo3030Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo308Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo223Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo762Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo22Box = true,
        Ammo57Box = true,
        Ammo46Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556BattlePack = true,
    },
    AmmoLootDropVFE93B42Carton = {
        -- <RGB:1,1,1>The chance for each carton type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 14 types on,
        -- that is 28 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.03 does not mean 0.03% of
        -- zombies. Many small chances add up.
        -- At 0.03 you get cartons from about
        -- 1% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>12 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get cartons from about
        -- 0% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 13 if you want almost every
        -- zombie to drop cartons. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,03
        DropRate = 0.03,
        -- <RGB:1,1,1>OFF: any zombie can drop cartons.
        -- This is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop cartons, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets9mmCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets45Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets44Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets38Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets357Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoShotgunShellsCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo3030Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo308Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo556Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo223Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo762Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo22Carton = true,
        Ammo57Carton = true,
        Ammo46Carton = true,
    },
    AmmoLootDropVFE93B42Magazine = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a magazine.
        -- 
        -- This is the total chance, not the
        -- chance for each magazine. All the
        -- magazines you turn on share it.
        -- Turning a caliber off changes which
        -- magazine you get, not how often you
        -- get one.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice. At
        -- 0.5 you get a magazine from about 1
        -- body in 100. The 32 magazines share
        -- that chance.
        -- 
        -- <RGB:1.000,0.700,0.200>The 5 base game magazines are in
        -- that count. This pack drops them so
        -- it can work on its own. If Ammo Loot
        -- Drop Magazine is also on, that mod
        -- drops them instead, and only the 27
        -- this pack adds share the chance
        -- here.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition you
        -- can fire straight away. It is worth
        -- more than the same rounds found
        -- loose. Raise this slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,50
        DropRate = 0.5,
        -- <RGB:1,1,1>OFF: any zombie can drop a magazine,
        -- even office workers and nurses.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop one, and only the
        -- kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- Pistols, shotguns, rifles - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- Pistols, shotguns - police, guards,
        -- bandits, bikers (10)
        -- Shotguns, rifles - farmers,
        -- fishermen (2)
        -- Pistols only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Magazines for belt fed and launcher
        -- guns drop from soldiers only. Nobody
        -- else in Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>How much ammunition is waiting in a
        -- magazine that drops.
        -- 
        -- It is a percent of what the magazine
        -- holds, and the amount is rolled each
        -- time, so you get between one round
        -- and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine saves you a
        -- reload. Set it low if you want the
        -- magazine to be the prize and the
        -- rounds to stay hard to find.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines. Minimum=0,00 Maximum=100,00 Standard=50,00
        MagazineLoaded = 50.0,
        -- M16 Magazine
        -- JS-14 Magazine
        Mags556Bullets = true,
        -- M15-22 Magazine
        -- K-33 Magazine
        -- R1022 Magazine
        -- Mk2 Magazine
        Mags22Bullets = true,
        -- FN-57 Magazine
        -- P90 Magazine
        Mags57Bullets = true,
        -- V-45 Magazine
        -- M1911 Magazine
        -- M10 Magazine
        -- MK23 Magazine
        MagsBullets45 = true,
        -- AA12 Drum
        MagsShotgunShells = true,
        -- MP7 Magazine
        Mags46Bullets = true,
        -- MK-17 Magazine
        -- FAL Magazine
        -- M14 Magazine
        -- R788 Magazine
        Mags308Bullets = true,
        -- V-9 Magazine
        -- CZ 75 Magazine
        -- G17 Magazine
        -- MP5 Magazine
        -- P229 Magazine
        -- TEC9 Magazine
        -- Uzi Magazine
        -- M9 Magazine
        MagsBullets9mm = true,
        -- AK-47 Magazine
        Mags762Bullets = true,
        -- Mini-14 Magazine
        Mags223Bullets = true,
        -- Cugir Md. 91 Magazine
        MagsBullets38 = true,
        -- AutoMag IV Magazine
        -- DE Magazine
        MagsBullets44 = true,
        -- M60 Belt Pouch
        Mags308BulletsLinked = true,
    },
    AmmoLootDropVFE93B42Weapon = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a gun at all.
        -- 
        -- It is not the chance of each gun.
        -- The chance is split across every
        -- caliber you leave on, so turning one
        -- off changes which gun drops and not
        -- how often one does.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice, so
        -- 0.1 leaves a gun on about one body
        -- in 500.
        -- 
        -- <RGB:1.000,0.700,0.200>71 of the 86 guns come from the base
        -- game or from a pack this one
        -- requires. This mod drops them so it
        -- can work on its own. If the mod that
        -- owns them is on too, only this
        -- pack's own 15 are left here sharing
        -- the chance.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,10
        DropRate = 0.1,
        -- <RGB:1,1,1>OFF: any zombie can drop guns. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop guns, and only
        -- the kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher guns drop from
        -- soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>ON: a gun that feeds from a magazine
        -- arrives with one. This is the normal
        -- setting.
        -- 
        -- 57 of the 86 guns take a magazine,
        -- and they share 30 between them.
        -- 
        -- <RGB:0.100,0.800,1.000>Magazines roll on their own as well,
        -- so you can find one without the gun.
        -- 
        -- <RGB:1.000,0.700,0.200>OFF: guns only. A rifle off a body
        -- is then no use until you find a
        -- magazine for it.
        -- 
        -- <RGB:1,1,1>Revolvers, shotguns and break
        -- actions take loose rounds and never
        -- needed one either way.
        DropMagazine = true,
        -- <RGB:1,1,1>How much ammunition is waiting in
        -- a magazine that drops.
        -- 
        -- It is a percent of what the
        -- magazine holds, and the amount is
        -- rolled each time, so you get
        -- between one round and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition
        -- you can fire straight away. It is
        -- worth more than the same rounds
        -- loose.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines,
        -- which is how they dropped before. Minimum=0,00 Maximum=100,00 Standard=50,00
        MagazineLoaded = 50.0,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets9mm = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets45 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets44 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets38 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets357 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsShotgunShells = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns3030Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns223Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns762Bullets = true,
        Guns22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308BulletsLinked = true,
        Guns57Bullets = true,
        Guns46Bullets = true,
    },
    AmmoLootDropVFEB42 = {
        -- <RGB:1,1,1>The chance for each round type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 13 types on,
        -- that is 26 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 3 does not mean 3% of zombies.
        -- Many small chances add up. At 3 you
        -- get ammo from about 55% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>9 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 4 types are left
        -- here, so you get ammo from about
        -- 22% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 14 if you want almost every
        -- zombie to drop ammo. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=3,00
        DropRate = 3.0,
        -- <RGB:1,1,1>How many rounds you get each time
        -- ammo drops. You get between 1 and
        -- this many.
        -- 
        -- <RGB:0.100,0.800,1.000>This does not change how often you
        -- find ammo. Only the drop rate above
        -- does that. It changes how much you
        -- find each time.
        -- 
        -- Every round type gets its own
        -- number, so a body with two calibers
        -- gives a separate amount for each.
        -- 
        -- <RGB:0.800,1.000,0.000>At the default of 10, a body with
        -- ammo holds about 8 rounds. That is
        -- enough to be useful.
        -- 
        -- Set it to 1 if you want only one
        -- round at a time, like the old
        -- version of this mod.
        -- 
        -- <RGB:1.000,0.700,0.200>A body has limited space. If you set
        -- a big number, the body may fill up
        -- and you will get less than you asked
        -- for. Minimum=1 Maximum=99 Standard=10
        LooseRoundsMax = 10,
        -- <RGB:1,1,1>OFF: any zombie can drop ammo. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop ammo, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets9mm = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets45 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets44 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets38 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets357 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoShotgunShells = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo3030Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo556Bullets = true,
        Ammo223Bullets = true,
        Ammo762Bullets = true,
        Ammo22Bullets = true,
        Ammo308BulletsLinked = true,
    },
    AmmoLootDropVFEB42Box = {
        -- <RGB:1,1,1>The chance for each box type to drop
        -- from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 13 types on,
        -- that is 26 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.3 does not mean 0.3% of
        -- zombies. Many small chances add up.
        -- At 0.3 you get boxes from about 8%
        -- of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>9 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 4 types are left
        -- here, so you get boxes from about
        -- 2% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 14 if you want almost every
        -- zombie to drop boxes. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,30
        DropRate = 0.3,
        -- <RGB:1,1,1>OFF: any zombie can drop boxes. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop boxes, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets9mmBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets45Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets44Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets38Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets357Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoShotgunShellsBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo3030Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo308Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556Box = true,
        Ammo223Box = true,
        Ammo762Box = true,
        Ammo22Box = true,
        Ammo556BattlePack = true,
    },
    AmmoLootDropVFEB42Carton = {
        -- <RGB:1,1,1>The chance for each carton type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 12 types on,
        -- that is 24 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.03 does not mean 0.03% of
        -- zombies. Many small chances add up.
        -- At 0.03 you get cartons from about
        -- 1% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>9 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 3 types are left
        -- here, so you get cartons from about
        -- 0% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 15 if you want almost every
        -- zombie to drop cartons. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,03
        DropRate = 0.03,
        -- <RGB:1,1,1>OFF: any zombie can drop cartons.
        -- This is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop cartons, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets9mmCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets45Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets44Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets38Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets357Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoShotgunShellsCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo3030Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo308Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo556Carton = true,
        Ammo223Carton = true,
        Ammo762Carton = true,
        Ammo22Carton = true,
    },
    AmmoLootDropVFEB42Magazine = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a magazine.
        -- 
        -- This is the total chance, not the
        -- chance for each magazine. All the
        -- magazines you turn on share it.
        -- Turning a caliber off changes which
        -- magazine you get, not how often you
        -- get one.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice. At
        -- 0.5 you get a magazine from about 1
        -- body in 100. The 23 magazines share
        -- that chance.
        -- 
        -- <RGB:1.000,0.700,0.200>The 5 base game magazines are in
        -- that count. This pack drops them so
        -- it can work on its own. If Ammo Loot
        -- Drop Magazine is also on, that mod
        -- drops them instead, and only the 18
        -- this pack adds share the chance
        -- here.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition you
        -- can fire straight away. It is worth
        -- more than the same rounds found
        -- loose. Raise this slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,50
        DropRate = 0.5,
        -- <RGB:1,1,1>OFF: any zombie can drop a magazine,
        -- even office workers and nurses.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop one, and only the
        -- kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- Pistols, shotguns, rifles - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- Pistols, shotguns - police, guards,
        -- bandits, bikers (10)
        -- Shotguns, rifles - farmers,
        -- fishermen (2)
        -- Pistols only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Magazines for belt fed and launcher
        -- guns drop from soldiers only. Nobody
        -- else in Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>How much ammunition is waiting in a
        -- magazine that drops.
        -- 
        -- It is a percent of what the magazine
        -- holds, and the amount is rolled each
        -- time, so you get between one round
        -- and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine saves you a
        -- reload. Set it low if you want the
        -- magazine to be the prize and the
        -- rounds to stay hard to find.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines. Minimum=0,00 Maximum=100,00 Standard=50,00
        MagazineLoaded = 50.0,
        -- CZ 75 Magazine
        -- G17 Magazine
        -- MP5 Magazine
        -- P229 Magazine
        -- TEC9 Magazine
        -- Uzi Magazine
        -- M9 Magazine
        MagsBullets9mm = true,
        -- AK-47 Magazine
        Mags762Bullets = true,
        -- M16 Magazine
        -- JS-14 Magazine
        Mags556Bullets = true,
        -- FAL Magazine
        -- M14 Magazine
        -- R788 Magazine
        Mags308Bullets = true,
        -- M1911 Magazine
        -- M10 Magazine
        -- MK23 Magazine
        MagsBullets45 = true,
        -- R1022 Magazine
        -- Mk2 Magazine
        Mags22Bullets = true,
        -- Mini-14 Magazine
        Mags223Bullets = true,
        -- Cugir Md. 91 Magazine
        MagsBullets38 = true,
        -- AutoMag IV Magazine
        -- DE Magazine
        MagsBullets44 = true,
        -- M60 Belt Pouch
        Mags308BulletsLinked = true,
    },
    AmmoLootDropVFEB42Weapon = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a gun at all.
        -- 
        -- It is not the chance of each gun.
        -- The chance is split across every
        -- caliber you leave on, so turning one
        -- off changes which gun drops and not
        -- how often one does.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice, so
        -- 0.1 leaves a gun on about one body
        -- in 500.
        -- 
        -- <RGB:1.000,0.700,0.200>20 of the 71 guns come from the base
        -- game or from a pack this one
        -- requires. This mod drops them so it
        -- can work on its own. If the mod that
        -- owns them is on too, only this
        -- pack's own 51 are left here sharing
        -- the chance.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,10
        DropRate = 0.1,
        -- <RGB:1,1,1>OFF: any zombie can drop guns. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop guns, and only
        -- the kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher guns drop from
        -- soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>ON: a gun that feeds from a magazine
        -- arrives with one. This is the normal
        -- setting.
        -- 
        -- 42 of the 71 guns take a magazine,
        -- and they share 21 between them.
        -- 
        -- <RGB:0.100,0.800,1.000>Magazines roll on their own as well,
        -- so you can find one without the gun.
        -- 
        -- <RGB:1.000,0.700,0.200>OFF: guns only. A rifle off a body
        -- is then no use until you find a
        -- magazine for it.
        -- 
        -- <RGB:1,1,1>Revolvers, shotguns and break
        -- actions take loose rounds and never
        -- needed one either way.
        DropMagazine = true,
        -- <RGB:1,1,1>How much ammunition is waiting in
        -- a magazine that drops.
        -- 
        -- It is a percent of what the
        -- magazine holds, and the amount is
        -- rolled each time, so you get
        -- between one round and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition
        -- you can fire straight away. It is
        -- worth more than the same rounds
        -- loose.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines,
        -- which is how they dropped before. Minimum=0,00 Maximum=100,00 Standard=50,00
        MagazineLoaded = 50.0,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets9mm = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets45 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets44 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets38 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets357 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsShotgunShells = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns3030Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns556Bullets = true,
        Guns223Bullets = true,
        Guns762Bullets = true,
        Guns22Bullets = true,
        Guns308BulletsLinked = true,
    },
    AmmoLootDropVFESB42 = {
        -- <RGB:1,1,1>The chance for each round type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 3 does not mean 3% of zombies.
        -- Many small chances add up. At 3 you
        -- get ammo from about 60% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get ammo from about
        -- 11% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop ammo. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=3,00
        DropRate = 3.0,
        -- <RGB:1,1,1>How many rounds you get each time
        -- ammo drops. You get between 1 and
        -- this many.
        -- 
        -- <RGB:0.100,0.800,1.000>This does not change how often you
        -- find ammo. Only the drop rate above
        -- does that. It changes how much you
        -- find each time.
        -- 
        -- Every round type gets its own
        -- number, so a body with two calibers
        -- gives a separate amount for each.
        -- 
        -- <RGB:0.800,1.000,0.000>At the default of 10, a body with
        -- ammo holds about 8 rounds. That is
        -- enough to be useful.
        -- 
        -- Set it to 1 if you want only one
        -- round at a time, like the old
        -- version of this mod.
        -- 
        -- <RGB:1.000,0.700,0.200>A body has limited space. If you set
        -- a big number, the body may fill up
        -- and you will get less than you asked
        -- for. Minimum=1 Maximum=99 Standard=10
        LooseRoundsMax = 10,
        -- <RGB:1,1,1>OFF: any zombie can drop ammo. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop ammo, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets9mm = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets45 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets44 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets38 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets357 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoShotgunShells = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo3030Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo223Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo762Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308BulletsLinked = true,
        Ammo545Bullets = true,
        Ammo76254Bullets = true,
    },
    AmmoLootDropVFESB42Box = {
        -- <RGB:1,1,1>The chance for each box type to drop
        -- from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.3 does not mean 0.3% of
        -- zombies. Many small chances add up.
        -- At 0.3 you get boxes from about 9%
        -- of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get boxes from about
        -- 1% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop boxes. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,30
        DropRate = 0.3,
        -- <RGB:1,1,1>OFF: any zombie can drop boxes. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop boxes, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets9mmBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets45Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets44Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets38Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets357Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoShotgunShellsBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo3030Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo308Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo223Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo762Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo22Box = true,
        Ammo545Box = true,
        Ammo76254Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556BattlePack = true,
    },
    AmmoLootDropVFESB42Carton = {
        -- <RGB:1,1,1>The chance for each carton type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 14 types on,
        -- that is 28 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.03 does not mean 0.03% of
        -- zombies. Many small chances add up.
        -- At 0.03 you get cartons from about
        -- 1% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>12 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get cartons from about
        -- 0% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 13 if you want almost every
        -- zombie to drop cartons. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,03
        DropRate = 0.03,
        -- <RGB:1,1,1>OFF: any zombie can drop cartons.
        -- This is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop cartons, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets9mmCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets45Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets44Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets38Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets357Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoShotgunShellsCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo3030Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo308Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo556Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo223Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo762Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo22Carton = true,
        Ammo545Carton = true,
        Ammo76254Carton = true,
    },
    AmmoLootDropVFESB42Magazine = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a magazine.
        -- 
        -- This is the total chance, not the
        -- chance for each magazine. All the
        -- magazines you turn on share it.
        -- Turning a caliber off changes which
        -- magazine you get, not how often you
        -- get one.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice. At
        -- 0.5 you get a magazine from about 1
        -- body in 100. The 36 magazines share
        -- that chance.
        -- 
        -- <RGB:1.000,0.700,0.200>The 5 base game magazines are in
        -- that count. This pack drops them so
        -- it can work on its own. If Ammo Loot
        -- Drop Magazine is also on, that mod
        -- drops them instead, and only the 31
        -- this pack adds share the chance
        -- here.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition you
        -- can fire straight away. It is worth
        -- more than the same rounds found
        -- loose. Raise this slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,50
        DropRate = 0.5,
        -- <RGB:1,1,1>OFF: any zombie can drop a magazine,
        -- even office workers and nurses.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop one, and only the
        -- kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- Pistols, shotguns, rifles - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- Pistols, shotguns - police, guards,
        -- bandits, bikers (10)
        -- Shotguns, rifles - farmers,
        -- fishermen (2)
        -- Pistols only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Magazines for belt fed and launcher
        -- guns drop from soldiers only. Nobody
        -- else in Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>How much ammunition is waiting in a
        -- magazine that drops.
        -- 
        -- It is a percent of what the magazine
        -- holds, and the amount is rolled each
        -- time, so you get between one round
        -- and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine saves you a
        -- reload. Set it low if you want the
        -- magazine to be the prize and the
        -- rounds to stay hard to find.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines. Minimum=0,00 Maximum=100,00 Standard=50,00
        MagazineLoaded = 50.0,
        -- PKM Box
        -- SV98 Magazine
        -- Dragunov Magazine
        -- SVT-40 Magazine
        Mags76254Bullets = true,
        -- Bizon Magazine
        -- Makarov Magazine
        -- PPSH-41 Drum
        -- VSS Magazine
        -- Vityaz Magazine
        -- CZ 75 Magazine
        -- G17 Magazine
        -- MP5 Magazine
        -- P229 Magazine
        -- TEC9 Magazine
        -- Uzi Magazine
        -- M9 Magazine
        MagsBullets9mm = true,
        -- Saiga-12 Magazine
        MagsShotgunShells = true,
        -- 5.45 Magazine
        Mags545Bullets = true,
        -- M16 Magazine
        -- M249 Box
        -- JS-14 Magazine
        Mags556Bullets = true,
        -- UMP-45 Magazine
        -- MK23 Magazine
        -- M1911 Magazine
        -- M10 Magazine
        MagsBullets45 = true,
        -- AK-47 Magazine
        Mags762Bullets = true,
        -- FAL Magazine
        -- M14 Magazine
        -- R788 Magazine
        Mags308Bullets = true,
        -- R1022 Magazine
        -- Mk2 Magazine
        Mags22Bullets = true,
        -- Mini-14 Magazine
        Mags223Bullets = true,
        -- Cugir Md. 91 Magazine
        MagsBullets38 = true,
        -- AutoMag IV Magazine
        -- DE Magazine
        MagsBullets44 = true,
        -- M60 Belt Pouch
        Mags308BulletsLinked = true,
    },
    AmmoLootDropVFESB42Weapon = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a gun at all.
        -- 
        -- It is not the chance of each gun.
        -- The chance is split across every
        -- caliber you leave on, so turning one
        -- off changes which gun drops and not
        -- how often one does.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice, so
        -- 0.1 leaves a gun on about one body
        -- in 500.
        -- 
        -- <RGB:1.000,0.700,0.200>71 of the 93 guns come from the base
        -- game or from a pack this one
        -- requires. This mod drops them so it
        -- can work on its own. If the mod that
        -- owns them is on too, only this
        -- pack's own 22 are left here sharing
        -- the chance.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Minimum=0,00 Maximum=100,00 Standard=0,10
        DropRate = 0.1,
        -- <RGB:1,1,1>OFF: any zombie can drop guns. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop guns, and only
        -- the kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher guns drop from
        -- soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>ON: a gun that feeds from a magazine
        -- arrives with one. This is the normal
        -- setting.
        -- 
        -- 61 of the 93 guns take a magazine,
        -- and they share 34 between them.
        -- 
        -- <RGB:0.100,0.800,1.000>Magazines roll on their own as well,
        -- so you can find one without the gun.
        -- 
        -- <RGB:1.000,0.700,0.200>OFF: guns only. A rifle off a body
        -- is then no use until you find a
        -- magazine for it.
        -- 
        -- <RGB:1,1,1>Revolvers, shotguns and break
        -- actions take loose rounds and never
        -- needed one either way.
        DropMagazine = true,
        -- <RGB:1,1,1>How much ammunition is waiting in
        -- a magazine that drops.
        -- 
        -- It is a percent of what the
        -- magazine holds, and the amount is
        -- rolled each time, so you get
        -- between one round and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition
        -- you can fire straight away. It is
        -- worth more than the same rounds
        -- loose.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines,
        -- which is how they dropped before. Minimum=0,00 Maximum=100,00 Standard=50,00
        MagazineLoaded = 50.0,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets9mm = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets45 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets44 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets38 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets357 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsShotgunShells = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns3030Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns223Bullets = true,
        Guns762Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308BulletsLinked = true,
        Guns545Bullets = true,
        Guns76254Bullets = true,
    },
    ReactiveSE = {
        -- Minimum IN-GAME HOURS before events can occur Minimum=1 Maximum=720 Standard=48
        MinEventCooldown = 48,
        -- Maximum IN-GAME HOURS before an event is guaranteed Minimum=2 Maximum=720 Standard=240
        MaxEventCooldown = 240,
        -- Probability of an event per 10-MINUTE CHECK after minimum cooldown Minimum=1 Maximum=20 Standard=4
        EventChance = 4,
        -- If enabled, probability stays flat. If disabled, probability increases until max cooldown (legacy)
        FlatProbability = true,
        -- Minimum distance (in tiles) from the player where sound events can spawn Minimum=120 Maximum=1000 Standard=200
        MinSoundRange = 200,
        -- Maximum distance (in tiles) from the player where sound events can spawn Minimum=120 Maximum=1000 Standard=600
        MaxSoundRange = 600,
        -- If a sound occurs within this distance, the player may panic or wake up. Sounds beyond this range will only be heard. Must be between the minimum and maximum sound range; otherwise it is adjusted automatically Minimum=120 Maximum=1000 Standard=300
        ReactionThresholdRange = 300,
        -- Probability an event spawns at close range Minimum=0 Maximum=100 Standard=20
        CloseDistanceChance = 20,
        -- Probability an event spawns at medium range Minimum=0 Maximum=100 Standard=40
        MediumDistanceChance = 40,
        -- Probability an event spawns at far range Minimum=0 Maximum=100 Standard=40
        FarDistanceChance = 40,
        -- Allow zombies to react to sound events
        EnableZombieHearing = true,
        -- [DEV] Enables debug logging and visual helpers
        EnableDebugMode = false,
    },
    ReactiveSEEvents = {
        -- Animal sounds occurring in the distance
        EnableAnimalEvents = true,
        -- Gunfights between survivors
        EnableGunfightEvents = true,
        -- Single shots heard in the distance
        EnableGunshotEvents = true,
        -- Distant screams of survivors
        EnableScreamEvents = true,
        -- Vehicles crashing or colliding
        EnableVehicleCrashEvents = true,
        -- Weather-related sounds such as lightning
        EnableWeatherEvents = true,
        -- Zombie noises occurring in the distance
        EnableZombieEvents = true,
    },
    ReactiveSEBehavior = {
        -- Adjust event chances based on the player's aggressive or passive behavior
        EnablePlayerStyle = true,
        -- Kills per day required to consider the player aggressive Minimum=10 Maximum=200 Standard=40
        AggressiveStyleKills = 40,
        -- Days without killing zombies required to consider the player passive Minimum=1 Maximum=7 Standard=2
        PassiveStyleDays = 2,
        -- Player may panic when a sound event happens within reaction range
        EnablePlayerReactionPanic = true,
        -- Sleeping player may wake up if a sound event happens nearby
        EnablePlayerReactionWakeUp = true,
    },
    ReactiveSEScenes = {
        -- Enable physical scenes generated from sound events
        EnableEventScenes = true,
        -- Chance for a sound event to generate a scene Minimum=0 Maximum=100 Standard=100
        EventSceneChance = 100,
        -- Hours before generated scenes are automatically cleaned up (0 = disabled) Minimum=0 Maximum=168 Standard=72
        SceneCleanupHours = 72,
        -- Events with scenes look for a place in towns, trailer parks and roads first. They only happen in forests or fields when there is no other place in range
        PreferTownsAndRoads = false,
        -- Generate corpse scenes when gunfight sounds occur
        EnableGunfightScene = true,
        -- Generate single corpse when gunshot sounds occur
        EnableGunshotScene = true,
        -- Generate corpse when scream sounds occur
        EnableScreamScene = true,
        -- Maximum zombies that may spawn with scream scenes (0 = disabled) Minimum=0 Maximum=10 Standard=3
        ScreamZombieCount = 3,
        -- Spawn crashed vehicles when crash sounds occur
        EnableVehicleCrashScene = true,
        -- Maximum condition of vehicles spawned in scenes Standard=Low
        -- 1 = Very Low
        -- 2 = Low
        -- 3 = Normal
        -- 4 = High
        -- 5 = Very High
        VehicleMaxCondition = 2,
        -- Chance that a spawned vehicle contains its key Minimum=0 Maximum=100 Standard=25
        VehicleKeyChance = 25,
        -- Spawn zombie groups when zombie sounds occur
        EnableZombieScene = true,
        -- Minimum number of zombies spawned in a Zombie event Minimum=1 Maximum=20 Standard=8
        ZombieSceneMin = 8,
        -- Maximum number of zombies spawned in a Zombie event Minimum=1 Maximum=20 Standard=16
        ZombieSceneMax = 16,
        -- Notify the player when a scene spawns nearby
        EnableSceneSpawnNotify = true,
        -- Player says something when a scene spawns nearby
        SceneSpawnNotifyText = true,
        -- Show the directional marker when a scene spawns nearby
        SceneSpawnNotifyMarker = true,
    },
    ReactiveSELoot = {
        -- Overall quality of loot found in scenes Standard=Dynamic
        -- 1 = Dynamic
        -- 2 = Poor
        -- 3 = Normal
        -- 4 = Rich
        LootQuality = 1,
        -- Maximum condition of weapons found in scenes Minimum=10 Maximum=100 Standard=100
        WeaponMaxCondition = 100,
        -- Chance that a ranged weapon appears in a scene Minimum=0 Maximum=100 Standard=10
        RangedWeaponChance = 10,
        -- Minimum probability that a backpack is stolen from a corpse. Applied during End Game. Minimum=0 Maximum=100 Standard=0
        MinBackpackStealChance = 0,
        -- Maximum probability that a backpack is stolen from a corpse (scales with World Tier). Applied during Early Game. Minimum=0 Maximum=100 Standard=70
        MaxBackpackStealChance = 70,
        -- Controls how scarce ammunition is in scenes Standard=Scarce
        -- 1 = None
        -- 2 = Scarce
        -- 3 = Normal
        -- 4 = Abundant
        AmmoScarcity = 2,
        -- Minimum number of items generated per SubKit (Dynamic Loot: Early Game) Minimum=1 Maximum=10 Standard=1
        SubKitCountMin = 1,
        -- Maximum number of items generated per SubKit (Dynamic Loot: End Game) Minimum=1 Maximum=10 Standard=3
        SubKitCountMax = 3,
    },
    ReactiveSEWorld = {
        -- Maximum number of corpses spawned in a scene Minimum=2 Maximum=8 Standard=3
        CorpseCount = 3,
        -- Defines the last day considered Early Game. Mid Game starts Minimum=1 Maximum=365 Standard=7
        WorldTierEarlyEnd = 7,
        -- Defines the last day considered Mid Game. Late Game starts Minimum=2 Maximum=365 Standard=30
        WorldTierMidEnd = 30,
        -- Defines the last day considered Late Game. End Game starts Minimum=3 Maximum=365 Standard=90
        WorldTierLateEnd = 90,
        -- On the vanilla map nothing across the Ohio river is reachable (north of Riverside and West Point, west and north of Louisville), so events never happen there. Enable only if a map mod adds content on that side
        AllowEventsBeyondOhio = false,
    },
    ReactiveSERadio = {
        -- Enable the Knox Relay radio station that broadcasts scene locations and survival stories
        EnableRadioFeature = true,
        -- Allow players to mark intel coordinates on their map via the radio context menu. Disable to prevent players from using this feature
        EnableMapMarker = true,
        -- Allow players to gain XP from listening to the morning show
        EnableMorningShowXP = true,
    },
    SIMBAproduz_TSY = {
        -- 0 = jederzeit; 1 = Tag und hellere Dämmerung; 2 = Nacht und dunklere Dämmerung. Morgen- und Abenddämmerung wechseln allmählich. Minimum=0 Maximum=2 Standard=0
        TimeMode = 0,
        -- Lässt Sprinter ohne festes Ziel gelegentlich schreien, solange sich ein Spieler innerhalb der Begegnungsreichweite befindet. Deaktivieren, um nur Schreie bei Zielerfassung, Jagd, kurzer Distanz oder einem Spielerruf zu behalten.
        EnablePresenceScreams = true,
        -- Bei jedem möglichen fernen Präsenzschrei wird einmal gewürfelt. 0 verhindert ihn; 100 behält die ursprüngliche Häufigkeit bei. Nach einem Fehlschlag beginnt ein neues normales Intervall. Andere Schreitypen bleiben unverändert. Minimum=0 Maximum=100 Standard=35
        PresenceScreamChance = 35,
        -- Spontane Präsenzschreie und zielgebundene Jagdschreie können nur auftreten, wenn sich ein Spieler innerhalb dieser Entfernung befindet. Der gesamte Bereich von 10 bis 300 Kacheln wird unterstützt. Minimum=10 Maximum=300 Standard=150
        FarRange = 150,
        -- Ermöglicht einen zusätzlichen Schrei, wenn ein Sprinter innerhalb von 8 Feldern eintritt, nachdem er weiter entfernt war. Deaktivieren Sie es, um den Lärm im Nahkampf zu reduzieren.
        EnableNearScream = true,
        -- Zeit ohne Ziel oder klare Sicht, bevor ein Wiederentdeckungsschrei auftreten kann. 0,04 = 144 Sekunden im Spiel; Echtzeit folgt der Tageslänge. Minimum=0,01 Maximum=0,20 Standard=0,04
        RediscoveryHours = 0.04,
        -- Pro zulässigem Verfolgungsintervall wird ein Wurf gemacht. 0 deaktiviert Verfolgungsschreie; Bei 100 ist jedes zulässige Intervall erfolgreich. Bei der Zielerfassung ist die Identifizierung immer gewährleistet. Minimum=0 Maximum=100 Standard=20
        ChaseScreechChance = 20,
        -- Intervall zwischen Verfolgungsjagden für denselben Sprinter. 0,03 = 108 Sekunden im Spiel. Niedrigere Werte sind lauter; Echtzeit folgt der Tageslänge. Minimum=0,00 Maximum=0,10 Standard=0,03
        ChaseCooldownHours = 0.03,
        -- Maximal bestätigte Schreie in einem Jagdkapitel. Mit der Identifizierung oder Wiederentdeckung beginnt ein Kapitel; Nach 0,1 Spielstunden kann ein stiller Sprinter einen zweiten Atemzug bekommen. Minimum=1 Maximum=20 Standard=3
        MaxScreamsPerChapter = 3,
        -- Multiplikator auf jede Mod-Stimme angewendet. 1.0 behält die beabsichtigte Mischung bei; Niedrigere Werte mildern es, höhere Werte verstärken es. Minimum=0,10 Maximum=3,00 Standard=1,00
        GlobalVolume = 1.0,
        -- Kontrolliert jeden Schrei außer dem Schrei aus nächster Nähe. 0,08 wird empfohlen; 0,10 ist der normale Wert; Werte über 0,10 verstärken es schrittweise bis zum Dreifachen. Minimum=0,01 Maximum=1,00 Standard=0,08
        FarVolume = 0.08,
        -- Lautstärkemultiplikator wird nur für Schreie aus nächster Nähe verwendet. 1,0 ist normal; Niedrigere Werte machen sie leiser und höhere Werte machen sie lauter. Minimum=0,10 Maximum=3,00 Standard=1,00
        NearVolume = 1.0,
        -- Maximaler Pitch-Offset, der von der stabilen Identität jedes Sprinters zugewiesen wird. 0 behält die Tonhöhe der Quelle bei; 7 erlaubt bis zu +/-7 %. Der gleiche Sprinter behält seine Stimme und Tonhöhe. Minimum=0 Maximum=15 Standard=7
        PitchVariation = 7,
        -- Nachdem ein Schrei bestätigt wurde, ertönt an der tatsächlichen Position des Sprinters ein Vanille-Weltgeräusch. Jeder Zombietyp innerhalb des Radius kann reagieren. Nur für Audio deaktivieren.
        AlertNearbyZombies = true,
        -- Hörradius für normale Zombies und Sprinter. Dies funktioniert nur, wenn die Anziehung aktiviert ist. Größere Werte können eine größere Horde bewegen. Minimum=10 Maximum=120 Standard=80
        AlertRadius = 80,
        -- Ein echter Spielerruf hat nur eine begrenzte Chance auf eine Antwort, und höchstens ein geeigneter Sprinter antwortet. Danach bleibt er 0,4 Spielstunden still; wiederholte Rufe können keine Antworten erzwingen.
        ShoutResponse = true,
        -- Maximale Distanz, über die ein teilnahmeberechtigter Sprinter antworten kann. Dies funktioniert nur, wenn Rufantworten aktiviert sind; Gebietsbeschränkungen können die Anzahl der Antworten verringern. Minimum=10 Maximum=120 Standard=50
        ShoutResponseRadius = 50,
        -- Bestätigte Schreie in der Nähe teilen sich ein Gebietsbudget. Größere Werte unterdrücken mehr überlappende Folgeschreie. Der Zielerkennungsschrei umgeht diese Grenze. Minimum=5 Maximum=80 Standard=35
        ClusterRadius = 35,
        -- Wie lange bleiben bestätigte Schreie im Nahbereichsbudget? 0,01 = 36 Sekunden im Spiel; Echtzeit folgt der Tageslänge. Minimum=0,00 Maximum=0,10 Standard=0,01
        ClusterCooldownHours = 0.01,
        -- Anzahl der bestätigten Schreie, die der Bereich aushalten kann, bevor Folgeschreie unterdrückt werden. Es sind immer noch Identifikationsschreie zu hören, später leise Schreie in der Nähe. Minimum=1 Maximum=10 Standard=1
        MaxClusterScreams = 1,
        -- Begrenzt, wie weit entfernte Sprinter mit festem Ziel vollständig ausgewertet werden. Spontane Stimmen nutzen die Stimmreichweite, die daher automatisch als Mindestwert gilt. Höhere Werte können mehr CPU beanspruchen. Minimum=50 Maximum=400 Standard=220
        MaxProcessDistance = 220,
        -- Niedrigere Werte reagieren früher und beanspruchen mehr CPU; Höhere Werte verteilen die Arbeit und reagieren später. 6 wird empfohlen. Das Timing hängt nicht von der Bildrate ab. Minimum=1 Maximum=20 Standard=6
        TickRate = 6,
        -- Nur beibehalten, damit alte Voreinstellungen geladen werden. Die Identifizierung erfolgt, wenn ein Sprinter einen Spieler als sein Verfolgungsziel festlegt; Dieser Wert hat keine Auswirkung. Minimum=0 Maximum=100 Standard=60
        ScreechChance = 60,
        -- Nur beibehalten, damit alte Voreinstellungen geladen werden. Jeder Schrei wird jetzt von der sich bewegenden 3D-Quelle des tatsächlichen Sprinters abgespielt; Dieser Wert hat keine Auswirkung.
        NearAsWorldSound = false,
        -- Nur beibehalten, damit alte Voreinstellungen geladen werden. Ein bestätigter Weltklang beginnt immer an der tatsächlichen Position und Etage des Sprinters; Dieser Wert hat keine Auswirkung.
        AlertAtScreamPosition = true,
    },
    StarvingZombies = {
        -- When enabled (checked), the size of the body has an effect on the distance.
        BodySizeImpactsSmell = true,
        -- When enabled (checked), only zombies in the same building as a body are capable of smelling it.
        BodyIndoorCheck = true,
        -- When enabled (checked), worn/attached items will be visible on the skeleton.
        -- This can look weird.
        AllowWornAttachedItems = false,
        -- When a body is consumed, every individual item has this chance of being destroyed. Minimum=0 Maximum=100 Standard=50
        ItemDestroyChance = 50,
        -- This value is used to calculate how long a body takes to be eaten.
        -- It is in real world seconds.
        -- The actual time taken to consume a corpse is adjusted by:
        -- - Size of the body relative(ish) to a human.
        -- - Number of zombies eating the body.
        -- - Current game speed. Minimum=60 Maximum=2147483647 Standard=1200
        BaseEatTime = 1200,
        -- Any body within this distance from a zombie will always be selected as a possible target. Minimum=0 Maximum=20 Standard=3
        BodyStartDistance = 3,
        -- Any body further than this distance from a zombie will never be selected as a target. Minimum=20 Maximum=200 Standard=100
        BodyMaxDistance = 100,
        -- Bodies will have their age (world hours) multiplied by this value, which is then added to Start Distance.
        -- Any body within this distance will be selected as a possible target. Minimum=0,00 Maximum=2,00 Standard=0,35
        BodyAgeMultiplier = 0.35,
        -- The current wind speed (km/h) is multiplied by this value, which is then added to the result of [Start Distance + Age Multiplier]. Minimum=0,00 Maximum=2,00 Standard=0,75
        BodyWindSpeedMultiplier = 0.75,
        -- This angle is used to determine whether a zombie falls inside an area that is projected from bodies in the direction of the wind, up to a distance of [Start Distance + Age Multiplier + Wind Speed Multiplier].
        -- Set to 0 to disable, causing wind direction to have no effect. Minimum=0 Maximum=90 Standard=55
        BodyDispersionAngle = 55,
        -- This value is divided by the current temperature, to get a multiplier that adjusts the result of [Start Distance + Age Multiplier].
        -- This value is in celsius.
        -- Set to 0 to disable temperature having an effect.
        -- At default, temperatures above 26C increase the distance bodies can be smelled by zombies, while temperatures below 26C decrease the distance. Minimum=0,00 Maximum=50,00 Standard=26,00
        BodyTemperaturePeak = 26.0,
        -- When enabled (checked), zombies will be able to smell players.
        CanSmellPlayer = true,
        -- Any player within this distance from a zombie will always be targeted. Minimum=0 Maximum=20 Standard=0
        PlayerStartDistance = 0,
        -- Any player further than this distance from a zombie will never be selected as a target. Minimum=0 Maximum=200 Standard=50
        PlayerMaxDistance = 10,
        -- The amount of blood on a player, and on items in their inventory, will be multiplied by this value, which is then added to Start Distance. Minimum=-1,00 Maximum=2,00 Standard=0,75
        PlayerBloodMultiplier = 0.75,
        -- The current wind speed (km/h) is multiplied by this value, which is then added to the result of [Start Distance + Blood Multiplier]. Minimum=0,00 Maximum=2,00 Standard=0,25
        PlayerWindSpeedMultiplier = 0.25,
        -- This angle is used to determine whether a zombie falls inside an area that is projected from players in the direction of the wind, up to a distance of [Start Distance + Blood Multiplier + Wind Speed Multiplier].
        -- Set to 0 disable, causing wind direction to have no effect. Minimum=0 Maximum=90 Standard=35
        PlayerDispersionAngle = 35,
    },
    WanderingZombies = {
        -- When enabled, lone zombies will use pathToSound, which causes them to attack objects in their path
        -- If using 'Always' with Destroyable World Fences, a lot of zombies will be found attacking fences, which makes things easier for awhile Standard=Indoors
        -- 1 = Always
        -- 2 = Indoors
        -- 3 = Random
        -- 4 = Never
        Destructive = 2,
        -- Zombies will try not to path further than this
        -- Does not account for needing to walk around objects(walls, etc) Minimum=10 Maximum=100 Standard=40
        MaxTravel = 40,
        -- Method used for ticks Standard=EveryOneMinute (in-game)
        -- 1 = Always
        -- 2 = OnTick (frame)
        -- 3 = EveryOneMinute (in-game)
        -- 4 = EveryTenMinutes (in-game)
        -- 5 = EveryHours (in-game)
        Counter = 3,
        -- How many times the chosen counter must occur before a zombie may wander Minimum=1 Maximum=9999999 Standard=5
        NumTicks = 5,
        -- Maximum ticks that can be added randomly to the above setting Minimum=0 Maximum=9999999 Standard=10
        RandTicks = 10,
        -- At what hour should lone zombies start wandering randomly
        -- If set to static, uses Start Hour: Max
        -- If set to random, Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownStartHour = 1,
        -- Refer to Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MinStartHour = 0,
        -- Refer to Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MaxStartHour = 0,
        -- Period of time lone zombies are allowed to wander for when the hour reaches Start Hour
        -- If set to static, uses Total Hours: Max
        -- If set to random, Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownTotalHours = 1,
        -- Refer to Total Hours tooltip for information Minimum=0 Maximum=24 Standard=0
        MinTotalHours = 0,
        -- Refer to Total Hours tooltip for information Minimum=0 Maximum=24 Standard=24
        MaxTotalHours = 24,
        -- Chance each zombie has of wandering randomly
        -- Chance is only rolled when the timer has elapsed and the zombie is ready to move
        -- If set to static, uses Random Chance: Max
        -- If set to random, Random Chance is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownWanderChance = 1,
        -- Refer to Random Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MinWanderChance = 0,
        -- Refer to Random Chance tooltip for information Minimum=0 Maximum=100 Standard=100
        MaxWanderChance = 100,
        -- At what hour should lone zombies start homing in on the nearest player
        -- If set to static, uses Homing Start Hour: Max
        -- If set to random, Homing Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHomingStartHour = 1,
        -- Refer to Homing Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MinHomingStartHour = 0,
        -- Refer to Homing Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MaxHomingStartHour = 0,
        -- Period of time lone zombies are allowed to home onto players when the hour reaches Homing Start Hour
        -- If set to static, uses Homing Total Hours: Max
        -- If set to random, Homing Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHomingTotalHours = 1,
        -- Refer to Homing Total Hours tooltip for information Minimum=0 Maximum=24 Standard=0
        MinHomingTotalHours = 0,
        -- Refer to Homing Total Hours tooltip for information Minimum=0 Maximum=24 Standard=24
        MaxHomingTotalHours = 24,
        -- Chance each zombie has of homing in on the nearest player
        -- Chance is only rolled when the timer has elapsed and the zombie is ready to move
        -- Max Travel applies to homing zombies
        -- If set to static, uses Homing Chance: Max
        -- If set to random, Homing Chance is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownToPlayers = 1,
        -- Refer to Homing Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MinToPlayers = 0,
        -- Refer to Homing Chance tooltip for information Minimum=0 Maximum=100 Standard=20
        MaxToPlayers = 20,
        -- Lone zombies inside this radius ignore the homing settings
        -- If set to static, uses Random Radius: Max
        -- If set to random, Random Radius is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownRadius = 1,
        -- Refer to Random Radius tooltip for information Minimum=0 Maximum=90 Standard=0
        MinRadius = 0,
        -- Refer to Random Radius tooltip for information Minimum=0 Maximum=90 Standard=70
        MaxRadius = 70,
        -- When enabled, lone zombies that are homing in on the player have their current path interrupted as soon as they're inside the Random Radius Standard=Off
        -- 1 = On
        -- 2 = Off
        -- 3 = Random
        RadiusInterrupt = 2,
        -- At what hour should lone zombies flee from the nearest player
        -- If set to static, uses Flee Start Hour: Max
        -- If set to random, Flee Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleeStartHour = 1,
        -- Refer to Flee Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MinFleeStartHour = 0,
        -- Refer to Flee Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MaxFleeStartHour = 0,
        -- Period of time lone zombies are allowed to flee from players when the hour reaches Flee Start Hour
        -- If set to static, uses Flee Total Hours: Max
        -- If set to random, Flee Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleeTotalHours = 1,
        -- Refer to Flee Total Hours tooltip for information Minimum=0 Maximum=24 Standard=0
        MinFleeTotalHours = 0,
        -- Refer to Flee Total Hours tooltip for information Minimum=0 Maximum=24 Standard=24
        MaxFleeTotalHours = 24,
        -- Chance each zombie has of moving away from the nearest player when inside Flee Radius
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- Max Travel applies to fleeing hordes
        -- If set to static, uses Flee Chance: Max
        -- If set to random, Flee Chance is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleePlayers = 1,
        -- Refer to Flee Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MinFleePlayers = 0,
        -- Refer to Flee Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MaxFleePlayers = 0,
        -- Lone zombies inside this radius move away from the player
        -- This takes priority over Random Radius
        -- If set to static, uses Flee Radius: Max
        -- If set to random, Flee Radius is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleeRadius = 1,
        -- Refer to Flee Radius tooltip for information Minimum=0 Maximum=90 Standard=0
        MinFleeRadius = 0,
        -- Refer to Flee Radius tooltip for information Minimum=0 Maximum=90 Standard=0
        MaxFleeRadius = 0,
        -- Allows zombies to form and move together as hordes
        -- Hordes use the rally group settings to function
        -- When Rally Group Size is set to 0, there is no limit on horde size
        -- Zeds will separate from a horde if they can't stay within Rally Travel Distance
        -- The options below have no effect if this is disabled
        Hordes = false,
        -- Allow hordes to merge when within Rally Travel Distance
        -- Horde merging does not respect Rally Group Size, they can grow to any size.
        Merge = false,
        -- When above zero, a horde is incapable of merging again until a cooldown has elapsed
        -- Time is in milliseconds
        -- Value is multipled by followers in a horde:
        -- (followers in horde) * (Merge Cooldown) Minimum=0 Maximum=9999999 Standard=3000
        MergeCooldown = 3000,
        -- When enabled, only zombies that share the same speed(sprinter, crawler, etc) will form a horde together
        -- Works with Random Zombies, but will incorrectly group together zombies until Random Zombies updates their speed
        GroupBySpeed = false,
        -- When enabled, sprinters are allowed to be in hordes
        AllowSprinters = true,
        -- When enabled, fast shamblers are allowed to be in hordes
        AllowFastShamblers = true,
        -- When enabled, slow shamblers are allowed to be in hordes
        AllowShamblers = true,
        -- When enabled, crawlers are allowed to be in hordes
        AllowCrawlers = true,
        -- When enabled, hordes will use pathToSound, which causes them to attack objects in their path
        -- If using 'Always' with Destroyable World Fences, a lot of zombies will be found attacking fences, which makes things easier for awhile Standard=Indoors
        -- 1 = Always
        -- 2 = Indoors
        -- 3 = Random
        -- 4 = Never
        HordeDestructive = 2,
        -- Hordes will try not to path further than this
        -- Does not account for needing to walk around objects(walls, etc) Minimum=10 Maximum=100 Standard=40
        HordeMaxTravel = 40,
        -- Method used for ticks Standard=EveryOneMinute (in-game)
        -- 1 = Always
        -- 2 = OnTick (frame)
        -- 3 = EveryOneMinute (in-game)
        -- 4 = EveryTenMinutes (in-game)
        -- 5 = EveryHours (in-game)
        HordeCounter = 3,
        -- How many times the chosen counter must occur before a horde may wander Minimum=1 Maximum=9999999 Standard=5
        HordeNumTicks = 5,
        -- Maximum ticks that can be added randomly to the above setting Minimum=0 Maximum=9999999 Standard=10
        HordeRandTicks = 10,
        -- Additional ticks are added based on the amount of followers in a horde:
        -- (followers in horde) * (Follower Ticks)
        -- Result is floored (rounded down) Minimum=0,00 Maximum=100,00 Standard=0,00
        FollowerTicks = 0.0,
        -- At what hour should hordes start wandering randomly
        -- If set to static, uses Start Hour: Max
        -- If set to random, Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeStartHour = 1,
        -- Refer to Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MinHordeStartHour = 0,
        -- Refer to Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MaxHordeStartHour = 0,
        -- Period of time hordes are allowed to wander for when the hour reaches Start Hour
        -- If set to static, uses Total Hours: Max
        -- If set to random, Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeTotalHours = 1,
        -- Refer to Total Hours tooltip for information Minimum=0 Maximum=24 Standard=0
        MinHordeTotalHours = 0,
        -- Refer to Total Hours tooltip for information Minimum=0 Maximum=24 Standard=24
        MaxHordeTotalHours = 24,
        -- Chance each horde has of wandering randomly
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- If set to static, uses Random Chance: Max
        -- If set to random, Random Chance is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeWanderChance = 1,
        -- Refer to Random Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MinHordeWanderChance = 0,
        -- Refer to Random Chance tooltip for information Minimum=0 Maximum=100 Standard=100
        MaxHordeWanderChance = 100,
        -- At what hour should hordes start homing in on the nearest player
        -- If set to static, uses Homing Start Hour: Max
        -- If set to random, Homing Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeHomingStartHour = 1,
        -- Refer to Homing Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MinHordeHomingStartHour = 0,
        -- Refer to Homing Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MaxHordeHomingStartHour = 0,
        -- Period of time hordes are allowed to home onto players when the hour reaches Homing Start Hour
        -- If set to static, uses Homing Total Hours: Max
        -- If set to random, Homing Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeHomingTotalHours = 1,
        -- Refer to Homing Total Hours tooltip for information Minimum=0 Maximum=24 Standard=0
        MinHordeHomingTotalHours = 0,
        -- Refer to Homing Total Hours tooltip for information Minimum=0 Maximum=24 Standard=24
        MaxHordeHomingTotalHours = 24,
        -- Chance each horde has of homing in on the nearest player
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- Max Travel applies to homing hordes
        -- If set to static, uses Homing Chance: Max
        -- If set to random, Homing Chance is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeToPlayers = 1,
        -- Refer to Homing Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MinHordeToPlayers = 0,
        -- Refer to Homing Chance tooltip for information Minimum=0 Maximum=100 Standard=20
        MaxHordeToPlayers = 20,
        -- Hordes inside this radius ignore the homing settings
        -- If set to static, uses Random Radius: Max
        -- If set to random, Random Radius is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeRadius = 1,
        -- Refer to Random Radius tooltip for information Minimum=0 Maximum=90 Standard=0
        MinHordeRadius = 0,
        -- Refer to Random Radius tooltip for information Minimum=0 Maximum=90 Standard=70
        MaxHordeRadius = 70,
        -- When enabled, hordes that are homing in on the player have their current path interrupted as soon as they're inside the Random Radius Standard=Off
        -- 1 = On
        -- 2 = Off
        -- 3 = Random
        HordeRadiusInterrupt = 2,
        -- At what hour should hordes flee from the nearest player
        -- If set to static, uses Flee Start Hour: Max
        -- If set to random, Flee Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleeStartHour = 1,
        -- Refer to Flee Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MinHordeFleeStartHour = 0,
        -- Refer to Flee Start Hour tooltip for information Minimum=0 Maximum=23 Standard=0
        MaxHordeFleeStartHour = 0,
        -- Period of time hordes are allowed to flee from players when the hour reaches Flee Start Hour
        -- If set to static, uses Flee Total Hours: Max
        -- If set to random, Flee Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleeTotalHours = 1,
        -- Refer to Flee Total Hours tooltip for information Minimum=0 Maximum=24 Standard=0
        MinHordeFleeTotalHours = 0,
        -- Refer to Flee Total Hours tooltip for information Minimum=0 Maximum=24 Standard=24
        MaxHordeFleeTotalHours = 24,
        -- Chance each horde has of moving away from the nearest player when inside Flee Radius
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- Max Travel applies to fleeing hordes
        -- If set to static, uses Flee Chance: Max
        -- If set to random, Flee Chance is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleePlayers = 1,
        -- Refer to Flee Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MinHordeFleePlayers = 0,
        -- Refer to Flee Chance tooltip for information Minimum=0 Maximum=100 Standard=0
        MaxHordeFleePlayers = 0,
        -- Hordes inside this radius move away from the player
        -- This takes priority over Random Radius
        -- If set to static, uses Flee Radius: Max
        -- If set to random, Flee Radius is randomised once per day using the below values (inclusive) Standard=Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleeRadius = 1,
        -- Refer to Flee Radius tooltip for information Minimum=0 Maximum=90 Standard=0
        MinHordeFleeRadius = 0,
        -- Refer to Flee Radius tooltip for information Minimum=0 Maximum=90 Standard=0
        MaxHordeFleeRadius = 0,
        -- Maximum amount of zeds that can be processed per update
        -- Update runs once per frame
        -- At 60fps, a zed limit of 20 would mean 1200 zeds per second are processed Minimum=1 Maximum=100 Standard=20
        UpdateZedLimit = 20,
        -- Maximum amount of milliseconds that the update can run for
        -- Update runs once per frame
        -- 16.67ms is the time limit per frame for a stable 60fps
        -- With a low zombie limit, it should not be necessary to change this value
        -- Horde updates have a hardcoded cap of 2ms that is separate from this value Minimum=1 Maximum=4 Standard=2
        UpdateMsLimit = 2,
        -- Monitor zed pathing to try and stop them walking outside the active area around a player
        TryStopVirtual = true,
        -- Minimum amount of hours a player needs to of survived before zeds will home in on them Minimum=0 Maximum=99999999 Standard=0
        HoursSurvived = 0,
    },
    WZS = {
        S1 = false,
        S2 = false,
        S3 = false,
        S4 = false,
        HS1 = false,
        HS2 = false,
        HS3 = false,
    },
    ZomVisFix = {
        -- let zombies revealed by this mod also detect the player (default: true)
        AffectZombieVision = true,
        -- a zombie's entire width needs to be unobscured in order to be revealed by this mod (default: false)
        HardMode = false,
    },
    ZCollision = {
        -- Wie viele Zombies pro Tick für die Hitbox-Kollision verarbeitet werden. Niedrigere Werte sorgen für flüssige Leistung bei allen. Minimum=3 Maximum=15 Standard=6
        MaxHitboxes = 6,
        -- Maximale Entfernung in Kacheln um den Spieler, in der Zombie-Hitboxen kollidieren. Minimum=3 Maximum=15 Standard=6
        MaxDistanceFromPlayer = 6,
        -- Hitbox-Kollisionsradius für standardmäßige laufende/verfolgende Zombies. Minimum=0,01 Maximum=0,99 Standard=0,46
        BaseRadius = 0.46,
        -- Kraft, die aufgewendet wird, um Standard-Zombies voneinander zu trennen. Minimum=0,01 Maximum=0,99 Standard=0,05
        BasePushForce = 0.05,
        -- Hitbox-Kollisionsradius, wenn ein Zombie getroffen, geschubst oder ins Wanken gebracht wird. Minimum=0,01 Maximum=0,99 Standard=0,65
        StunRadius = 0.65,
        -- Kraft, um sich bewegende Zombies von einem betäubten Zombie wegzuschieben. Minimum=0,01 Maximum=0,99 Standard=0,19
        StunPushForce = 0.19,
        -- Hitbox-Kollisionsradius, wenn ein Zombie stolpert, fällt oder in der Luft stirbt. Minimum=0,01 Maximum=0,99 Standard=0,75
        FallingRadius = 0.75,
        -- Kraft, um sich bewegende Zombies von einem stürzenden/sterbenden Zombie wegzuschieben. Minimum=0,01 Maximum=0,99 Standard=0,24
        FallingPushForce = 0.24,
        -- Markiert Zombies, bei denen die Kollision aktiviert ist. Dies dient nur zu Debugging-Zwecken und sollte für das normale Gameplay deaktiviert sein.
        DebugMode = false,
    },
    HorseMod = {
        -- Minimum=0,10 Maximum=10,00 Standard=1,00
        WalkSpeed = 1.0,
        -- Minimum=0,10 Maximum=10,00 Standard=1,00
        GallopSpeed = 1.0,
        -- Minimum=0,10 Maximum=2,00 Standard=1,00
        StaminaMultiplier = 1.0,
        RidingPainGrunt = true,
    },
    CompanionDogs = {
        -- Wie viel Vertrauen ein Hund (durch Füttern) erreichen muss, bevor er dein Begleiter wird. Minimum=1 Maximum=1000 Standard=100
        TameThreshold = 100,
        -- Höchstzahl an Hunden, die ein Spieler gleichzeitig gebunden halten kann. 0 = kein Limit. Ist die Grenze erreicht, lassen sich keine neuen Streuner zähmen (die Anfreunden-Option wird rot); Freilassen oder Verlieren gibt einen Platz frei. Minimum=0 Maximum=30 Standard=0
        MaxCompanions = 0,
        -- Erlaubt Begleithunden, Zombies in der Nähe anzugreifen.
        CombatEnabled = true,
        -- Skaliert den Schaden, den Begleithunde Zombies zufügen, zusätzlich zur Stärke der jeweiligen Rasse, zur Fähigkeitsstufe und zum Stärke-Gen. 1.0 ist der abgestimmte Standard; höher schlägt härter zu, 0 macht den Biss wirkungslos. Der schwache Caramelo-Mischling kann einen Zombie trotzdem nicht allein erledigen, egal wie hoch der Wert steht. Das ist so gewollt. Minimum=0,00 Maximum=5,00 Standard=1,00
        DogDamageMultiplier = 1.0,
        -- Begleiter brauchen Pflege: Füttere sie, um Hunger, Loyalität und Stress im Griff zu behalten. Ein vernachlässigter Hund gehorcht nicht.
        UpkeepEnabled = true,
        -- Skaliert, wie schnell ein Begleithund hungrig und durstig wird. 1.0 ist der abgestimmte Standard: Ein satter Hund braucht von voll bis am Verhungern etwa 3 Tage und Wasser ungefähr doppelt so oft. Höher bedeutet mehr Pflegeaufwand, niedriger weniger. 0 friert Hunger und Durst vollständig ein, der Hund braucht dann nie wieder Futter oder Wasser. Die Loyalität sinkt trotzdem, er will also weiterhin deine Aufmerksamkeit. Um das gesamte Pflegesystem abzuschalten, nutze stattdessen Bedürfnisse und Pflege. Minimum=0,00 Maximum=5,00 Standard=1,00
        NeedsRateMultiplier = 1.0,
        -- Loyalitätspunkte (0-100), die ein gepflegter Hund pro Spieltag verliert. Bei Hunger oder Durst sinkt sie schneller. Minimum=0,00 Maximum=100,00 Standard=12,00
        LoyaltyDecayPerDay = 12.0,
        -- Ein Hund ist ein Fleischfresser, den Bauch zu füllen reicht also nicht. Vergehen drei Tage ohne Eiweiß (Fleisch, Fisch, Ei oder Hundefutter, aus der Hand, aus einem Napf oder selbst erjagt), wird der Hund schwach: Er beißt mit halbem Schaden und ignoriert Befehle deutlich öfter. Eiweiß zahlt die Uhr nach Größe der Mahlzeit zurück: ein Steak oder ein Sack Hundefutter löscht die ganze Uhr auf einmal, ein Stückchen Speck nimmt nur ein paar Stunden weg, aber Stückchen summieren sich. Die Uhr steht still, solange der Hund im Zwinger ist, getragen wird oder Hofdienst leistet. Wie lang die Uhr läuft, legt 'Stunden ohne Eiweiß' fest.
        ProteinNeedEnabled = true,
        -- Wie lange ein Hund ohne Eiweiß auskommt, bevor er schwach wird, in Spielstunden. Standard 72, drei Tage. Niedriger macht Fleisch zur täglichen Pflicht, höher zur gelegentlichen Auffrischung. Eine Mahlzeit zahlt die Uhr anteilig zurück, also skaliert alles mit: bei 72 Stunden löscht ein Steak oder ein Sack Hundefutter sie weiterhin auf einmal, ein Stückchen Speck nimmt etwa dreieinhalb Stunden weg. Ohne 'Hunde brauchen Eiweiß' hat die Option keine Wirkung. Minimum=6 Maximum=168 Standard=72
        ProteinHours = 72,
        -- Der Hund überwacht einen weiten Bereich und warnt dich vor Zombies: ein leises Knurren bei entfernten oder wenigen, lautes Bellen bei nahen, vielen oder sichtbaren.
        SentinelEnabled = true,
        -- Deinen Hund zu streicheln und neben ihm zu schlafen lindert die Moodles Gelangweilt und Unglücklich ein wenig. Streicheln beruhigt außerdem den Hund und hebt seine Loyalität leicht an.
        BondingEnabled = true,
        -- Nachdem du neben deinem Hund geschlafen hast, wachst du eine Zeit lang Gut erholt auf: ein sanfter, zeitlich begrenzter Bonus, der Panik, Stress, Traurigkeit und Langeweile mildert und dich langsamer ermüden lässt. Schalte dies aus, um ihn zu deaktivieren.
        RestedBuffEnabled = true,
        -- Wie viele Spielstunden der Bonus Gut erholt nach dem Aufwachen neben deinem Hund anhält. Standard: 2. Minimum=0,50 Maximum=24,00 Standard=2,00
        RestedBuffHours = 2.0,
        -- Jede Rasse gibt ihr eigenes Moodle, solange ein satter, treuer Hund in der Nähe ist: Gute Gesellschaft, Mut, Feine Nase, Gewärmt und die anderen. Ausgeschaltet verschwinden das Symbol im HUD und der Bonus dahinter. Die Zustands-Moodles des Hundes (Hunger, Durst, krank, schwach) und Gut erholt bleiben davon unberührt.
        BreedMoodlesEnabled = true,
        -- Globaler Multiplikator auf allen Fähigkeits-XP (Spürsinn, Kampf, Gehorsam, Jagd). 1.0 ist normal; höher trainiert schneller. Minimum=0,10 Maximum=10,00 Standard=0,50
        SkillXPRate = 0.5,
        -- Hauptschalter für den Hofarbeitsmodus. Wenn aktiv, kannst du einen Hund einem ausgewiesenen Tiergehege zuweisen: Er bleibt im Gehege, beruhigt die Herde (und mindert so den Stress, der Milch und Wolle verringert) und vertreibt lautlos Zombies in der Nähe, selbstständig, auch wenn du weg bist.
        FarmCareEnabled = true,
        -- Hauptschalter für den Kunststück-Baum, den die Fähigkeit Gehorsam freischaltet: den Hund an eine Stelle schicken (Stufe 1), Zombies ablenken (Stufe 3), einen Gegenstand erschnüffeln (Stufe 5) und das Erschnüffelte apportieren, während du schläfst (Stufe 10). Gesperrte Kunststücke bleiben in den Menüs sichtbar, damit du siehst, was noch kommt.
        TricksEnabled = true,
        -- Das laute Bellen des Hundes (laute Wachwarnungen) ist echter Lärm, der Zombies in der Nähe anzieht (der symmetrische Preis). Leises Knurren lockt nie an. Ausschalten, damit Bellen keine Zombies anzieht.
        DogNoiseAttractsZombies = true,
        -- Zeigt den Namen jedes Begleithundes schwebend über seinem Kopf in der Welt an.
        ShowNameTags = true,
        -- Skaliert, wie oft streunende Hunde in der Welt auftauchen (Caramelo-Streuner, Golden Retriever und Polizei-Schäferhunde), wobei ihre relative Seltenheit erhalten bleibt. 1.0 ist die normale Rate; 2.0 verdoppelt alle Hunde-Spawns, 0 schaltet sie ab. Minimum=0,00 Maximum=5,00 Standard=1,00
        DogSpawnMultiplier = 1.0,
        -- Streunende, wilde und freigelassene Hunde können nicht getötet werden (weder von Zombies noch durch deine eigenen Schläge, Fahrzeuge, Hunger oder Feuer). Standardmäßig aus. Schalte es ein für eine mildere Welt, in der ein gefundener Streuner immer sicher zu zähmen ist. Begleithunde sind ohnehin unverwundbar.
        WildDogsInvincible = false,
        -- Mehrspieler-Server: Trennt ein Spieler die Verbindung, werden seine Hunde sicher aus der Welt genommen (Zustand und Bedürfnisse bleiben eingefroren erhalten) und bei der Rückkehr wieder eingesetzt. Der aktive Hund im Folgen-Modus erscheint an der Seite des Besitzers; Hunde im Bleiben- oder Bewachen-Modus sowie passive Hunde tauchen dort wieder auf, wo sie zurückgelassen wurden, sobald das Gebiet lädt. Standardmäßig an; ausschalten, um Hunde offline gegangener Spieler in der Welt zu belassen (unverwundbar und untätig).
        DespawnOnOwnerOffline = true,
        -- Multipliziert die Tragkraft der Satteltaschen. Bei 0 sind sie rein kosmetisch. Minimum=0,00 Maximum=5,00 Standard=1,00
        CargoCapacityMultiplier = 1.0,
        -- Erlaubt Begleithunden (einem Rüden und einer Hündin desselben Besitzers), sich zu paaren und Welpen zu bekommen. Deaktivieren blendet die Zuchtaktion aus.
        BreedingEnabled = true,
        -- Wie viele Spieltage eine trächtige Hündin trägt, bevor sie wirft. Minimum=1 Maximum=60 Standard=4
        GestationDays = 4,
        -- Wie viele Spieltage ein Welpe braucht, um erwachsen zu werden, wobei Bindung, Gene und Fähigkeiten erhalten bleiben. Welpen altern nur, während sie in Spielernähe geladen sind; Wachstum anhalten setzt dies für den jeweiligen Welpen außer Kraft. Minimum=1 Maximum=365 Standard=90
        MaturityDays = 90,
        -- Prozentchance pro Spieltag, dass ein erwachsener Rüde und eine Hündin desselben Besitzers in der Nähe von selbst Nachwuchs zeugen (stündlich ausgewürfelt). Es gelten dieselben Bedingungen wie bei der manuellen Zucht: satt, loyal, gesund, keine Abklingzeit, ein freier Hundeplatz und bei keinem der beiden gesperrte Zucht. Nur, solange sie in deiner Nähe geladen sind. 0 = aus. Minimum=0,00 Maximum=100,00 Standard=5,00
        BreedChancePerDay = 5.0,
        -- Läufst du in deinen eigenen Hund, kann er dich zu Fall bringen, genau wie ein Zusammenstoß mit einem Zombie (beim Sprinten stürzt du immer). Ausschalten, und dein Begleiter kollidiert nicht mehr mit dir: du läufst einfach durch ihn hindurch, ohne Stolpern und ohne ihn wegzuschieben. Streunende Hunde sind nicht betroffen.
        TripOverDogs = true,
        -- Das Tier kann Wunden und Krankheiten bekommen. Standard: an.
        VetCareEnabled = true,
        -- Alle kennen von Anfang an alle Rezepte der Tierarztpflege, ohne das Magazin des Mods.
        VetRecipesUnlocked = true,
        -- Das Tier kann an Krankheit, Hunger und Durst sterben. Standard: aus.
        Death = true,
        -- Chance, dass ein Biss des Tiers in einen Zombie seine Pfote verletzt. Standard 0,4 Prozent. Jede Kampfstufe des Tiers senkt sie um 5 Prozent dieses Werts, auf Stufe 10 ist sie halbiert. Minimum=0,00 Maximum=100,00 Standard=0,40
        VetWoundChance = 0.4,
        -- Prozentchance, dass jeder Zaunsprung dem Haustier eine verstauchte Pfote einbringt. Standard 0.5, 0 nie. Minimum=0,00 Maximum=100,00 Standard=0,50
        VetSprainChance = 0.5,
        -- Prozentuale Chance auf Würmer für je 6 Stunden mit verdorbenem Magen. Standard 10 Prozent. Minimum=0,00 Maximum=100,00 Standard=10,00
        VetWormsChance = 10.0,
        -- Chance, dass schlechtes Futter oder Wasser das Tier erbrechen lässt. Standard 25 Prozent. Minimum=0,00 Maximum=100,00 Standard=25,00
        VetSpoiledChance = 25.0,
        -- Chance, die Grippe zu bekommen: gewürfelt bei starkem Hunger und für jede Stunde neben einem kranken Hund. Standard 15 Prozent. Minimum=0,00 Maximum=100,00 Standard=15,00
        VetFluChance = 15.0,
        -- Wird für je 6 zusammenhängende Stunden im Freien gewürfelt. Drinnen wird der Zähler zurückgesetzt. Standard 1,5 Prozent. Minimum=0,00 Maximum=100,00 Standard=1,50
        VetHeartwormChance = 1.5,
        -- Chance, dass das Tier lebenslang gegen ein Fleisch allergisch ist, einmal pro Tier gewürfelt. Standard 5 Prozent. Minimum=0,00 Maximum=100,00 Standard=5,00
        VetAllergyChance = 5.0,
        -- Chance, dass jeder Biss im Kampf Flöhe oder Zecken einbringt. Standard 0,2 Prozent. Minimum=0,00 Maximum=100,00 Standard=0,20
        VetInfestChance = 0.2,
    },
    CompanionCat = {
        -- Legt fest, wie oft streunende Katzen in Häusern, Läden und Zoohandlungen auftauchen. 1.0 ist die normale Rate, 2.0 verdoppelt sie, 0 schaltet Katzen-Spawns ab. Unabhängig von der Hunde-Einstellung: streunende Hunde zu reduzieren oder abzuschalten wirkt sich nicht mehr auf Katzen aus. Minimum=0,00 Maximum=5,00 Standard=1,00
        CatSpawnMultiplier = 1.0,
    },
    LetMeDrive = {
        -- Aus: Alles läuft genau wie ohne Mod, zum Vergleichen.
        Enabled = true,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        EnabledByServer = false,
        -- Aus: Kartenarbeit anderer Mods läuft sofort, und Auslassen sowie die Blockade der Speicherbereinigung hören auf. Die Fahr-Regler darunter funktionieren weiter.
        Smoothing = true,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        SmoothingByServer = false,
        -- Empfohlen: auf "Der Bildratenbegrenzung des Spiels folgen" lassen. Aufgeschobene Arbeit nutzt nur die Zeit, die ein Frame bei dieser Bildrate übrig hat, sodass der Mod deine FPS nie darunter drückt. Standard=Der Bildratenbegrenzung des Spiels folgen
        -- 1 = Der Bildratenbegrenzung des Spiels folgen
        -- 2 = 244
        -- 3 = 240
        -- 4 = 165
        -- 5 = 144
        -- 6 = 120
        -- 7 = 95
        -- 8 = 90
        -- 9 = 75
        -- 10 = 60
        -- 11 = 55
        -- 12 = 45
        -- 13 = 30
        -- 14 = 24
        MinFps = 1,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        MinFpsByServer = false,
        -- Obergrenze der Millisekunden, die ein Frame für aufgeschobene Arbeit aufwenden darf, unabhängig von der Bildrate. Minimum=1 Maximum=8 Standard=4
        MaxBudgetMs = 4,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        MaxBudgetMsByServer = false,
        -- An: Kartenarbeit anderer Mods wird auch zu Fuß aufgeschoben. Wenn Gegenstände oder Leichen verschwinden oder du mitten in einer Aktion hängen bleibst, schalte das aus: Zu Fuß läuft diese Arbeit dann sofort, wie im Spiel ohne Mods.
        DeferOnFoot = true,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        DeferOnFootByServer = false,
        -- Manche Mods rufen während des Spiels collectgarbage auf. In dieser Engine ist das eine vollständige Java-Speicherbereinigung, ein sichtbares Einfrieren. Im Spiel blockiert, in der Konsolenzeile gezählt.
        GcShield = true,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        GcShieldByServer = false,
        -- Experimentell. Oberhalb dieser Geschwindigkeit laufen die Frame-Handler anderer Mods, die als schwer gemessen werden, nur noch jeden zweiten Frame. Für Effekte und Scanner in Ordnung, falsch für alles, das keinen Frame verpassen darf. Die Konsolenzeile markiert schwere Handler mit ! und zählt, was ausgelassen wurde. Minimum=0 Maximum=120 Standard=0
        ShedKmh = 0,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        ShedKmhByServer = false,
        -- Setzt das Auslassen aus, solange Tiere oder NPCs aus Mods geladen sind, damit Haustier- und NPC-Mods jeden Frame bekommen. Kostet pro Frame etwas Arbeit, solange ausgelassen würde.
        ShedGuard = false,
        -- Angehakt: Jeder Spieler nutzt den Wert darüber und kann ihn nicht ändern. Nicht angehakt: Jeder Spieler wählt selbst.
        ShedGuardByServer = false,
    },
    MKevMP = {
        -- Test phase tool. Writes where new zombies come from (mod spawn with mod name, vanilla room spawn, cell load, reanimation) and a zombie count around each player to Zomboid/Lua/mkev_zedmonitor_server.log and mkev_zedmonitor_client.log. Max 2 MB per file, one old file kept. Turn off when the tests are done.
        ZedMonitor = true,
    },
    IKnowIt = {
        -- Glühbirne oben rechts auf Medien, die Rezepte (oder bei VHS/CD eine Fertigkeit) beibringen.
        ShowTeachIcon = true,
        -- Oben rechts auf Skillbüchern: XP-Boost-Logo solange das Buch noch nicht gelesen ist (Lesen gibt einen XP-Multiplikator). Nach dem ersten kompletten Lesen das lila XP-Drop-Logo (Nachschlage-Belohnung: feste XP). Blass = Nachschlagen nicht mehr möglich.
        ShowXPIcon = true,
        -- Ball unten links auf ALLEN Medien, auf Höhe des Vanilla-Hakens. Rot = nicht lesbar, Orange = lesbar, aber noch nicht gelesen, Grün = bereits gelesen.
        ShowTrafficLight = true,
        -- Oben links bei Skillbüchern: ? = noch nicht nachgeschlagen, ! = bereits nachgeschlagen.
        ShowStudyMark = true,
        -- Größe der Overlay-Symbole in Prozent des Standard-Layouts (100 = Ball ca. halbe Icon-Größe). Bereich 50-200. Minimum=50 Maximum=200 Standard=100
        IconScale = 100,
        -- Fügt 'Nachschlagen' direkt unter 'Lesen' bei komplett gelesenen Skillbüchern in ihrer Level-Spanne hinzu. Jeder Buchtyp kann pro Charakter nur EINMAL nachgeschlagen werden, das Buch wird verbraucht. Max. +1 Level, nie über das Max-Level des Buchs.
        StudyEnabled = true,
        -- Fester Wert pro Band: dieser Prozentsatz des XP-Schritts am Einstiegslevel des Buchs (Std. 50: Bd.2 150, Bd.3 750, Bd.4 2250, Bd.5 3750). Band 1 gibt immer 75 XP. Minimum=10 Maximum=50 Standard=50
        StudyPercent = 50,
        -- Dauer des Nachschlagens = dieser Faktor x Dauer eines kompletten Lesens dieses Buchs (inkl. Traits, Lesebrille, Sitzplatz-Boni). Std. 0,5 = doppelt so schnell wie Lesen. Minimum=0,10 Maximum=2,00 Standard=0,50
        StudyTimeMultiplier = 0.5,
        -- Taschen, Schlüsselbunde, Erste-Hilfe-Sets usw. in Schränken/Leichen/Autos öffnen und einzelne Teile nehmen. Nichts öffnet sich automatisch.
        NestLootEnabled = true,
        -- Kleiner Pfeil links an Behälter-Zeilen im Loot-Fenster: Linksklick öffnet den Behälter als eigenen Tab. Ausschalten, falls ein UI-Mod (z. B. CleanUI) stört; 'Öffnen' im Rechtsklick-Menü bleibt.
        NestLootArrow = true,
        -- Untermenü 'Inhalt nehmen' an geschlossenen Behältern: Linksklick nimmt ein Teil, Rechtsklick markiert (Menü bleibt offen), dazu 'Markierte nehmen' und 'Alles nehmen'.
        NestLootMenu = true,
        -- Erlaubt Öffnen/Nehmen aus Behältern, die in einer Tasche in einem Schrank/Leiche/Auto liegen (z. B. Schlüsselbund in Handtasche im Schrank). Aus = 'erst die äußere Tasche nehmen'. Im MP erst testen.
        NestLootDeep = false,
        -- Zeigt im Item-Tooltip die IKnowIt-Symbole mit ihrer aktuellen Bedeutung (Ball, ? / !, XP-Boost / XP-Drop, Glühbirne) und den Medientyp.
        TooltipLegend = true,
        -- Lehrmedien bekommen im Inventar ein Präfix vor dem Namen: [Skillbuch] bei Skillbüchern, [Fertigkeit] (z. B. [Elektrotechnik]) bei Lehr-Videos/CDs und [Rezept] / [Rezepte] bei Rezeptmedien. Nur Anzeige, der echte Item-Name bleibt unverändert.
        TitlePrefix = true,
        -- Schneller lesen je nach Sitzplatz und Lesebrille (Boni addieren sich, kein Trait nötig). Ersetzt die Vanilla-Boni für Lesebrille und Sitzen (je 10 Prozent).
        ReadBonusEnabled = true,
        -- Bonus mit aufgesetzter Lesebrille, kommt zu jedem Sitzplatz-Bonus dazu. Standard 10. Minimum=0 Maximum=200 Standard=10
        ReadBonusGlasses = 10,
        -- Standard 25. Minimum=0 Maximum=200 Standard=25
        ReadBonusFloor = 25,
        -- Normale Stühle, Hocker, Bänke, Couches. Standard 50. Minimum=0 Maximum=200 Standard=50
        ReadBonusChair = 50,
        -- Gepolsterte Sessel (Lese-/Wohnzimmersessel) und Betten. Standard 60. Minimum=0 Maximum=200 Standard=60
        ReadBonusArmchair = 60,
        -- Sehr bequeme Betten (gute Betten) und die Toilette. Standard 70. Minimum=0 Maximum=200 Standard=70
        ReadBonusComfort = 70,
        -- Beim Gehen wird weitergelesen. Rennen oder Sprinten bricht das Lesen weiterhin ab. Kein Verdunkeln des Bildes.
        ReadWhileWalking = true,
        -- Faktor für das Lesetempo beim Gehen (0,5 = halbes Tempo, 1,0 = kein Abzug). Bereich 0,1-1,0. Minimum=0,10 Maximum=1,00 Standard=0,50
        WalkReadSpeed = 0.5,
        -- Beim Lesen von Lehrbüchern (auch Nachschlagen und Lesen beim Gehen) sinkt die Langeweile langsam. In Vanilla tun das nur Romane, Comics und Zeitschriften, Lehrbücher nicht.
        SkillBookBoredom = true,
        -- Punkte Langeweile (Skala 0-100), die pro Spielstunde Lesen wegfallen. Zum Vergleich: eine Fernsehzeile mit Unterhaltung nimmt 5 Punkte weg. Standard 10, Bereich 0-50. Minimum=0 Maximum=50 Standard=10
        SkillBookBoredomPerHour = 10,
    },
}
