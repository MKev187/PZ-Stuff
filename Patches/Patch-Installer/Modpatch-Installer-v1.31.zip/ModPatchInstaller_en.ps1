# ModPatchInstaller.ps1 - MKev's Modpatch Installer 1.31 for players
# Installs mkev_modpatcher 1.2 + mkevserverbootpatch 1.1.2 and (option 1) the MKev server setup.
# I Know It! is not installed by this installer (it comes from the Steam Workshop like every other collection mod).
# Author: MKev..
# Started by ModPatchInstaller.bat. Windows PowerShell 5.1 or newer. ASCII only.
#
# Test switches (environment variables, normally not set):
#   PZ_ZOMBOID          Zomboid folder (default %USERPROFILE%\Zomboid)
#   PZ_WORKSHOP         ';'-list of ...\steamapps\workshop\content\108600 folders (default: found via Steam)
#   PZ_SKIP_PROCCHECK   1 = do not check for a running game/server
#   PZ_CHOICE           menu choice 1..5 (no menu prompt)
#   PZ_CONFIRM          Y or N (answer for every Y/N question)
#   PZ_RESTORE_PICK     number of the backup to restore (1 = newest)
#   PZ_STAMP            fixed backup time stamp (tests only)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$script:Version   = '1.31'
$script:Src       = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:SetupSrc  = Join-Path $script:Src 'MKevServer_setup'
$script:Zomboid   = if ($env:PZ_ZOMBOID) { $env:PZ_ZOMBOID } else { Join-Path $env:USERPROFILE 'Zomboid' }
$script:Zomboid   = $script:Zomboid.TrimEnd('\','/')
$script:BackupRoot = Join-Path $script:Zomboid 'mkev_patch_backups'
$script:Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$script:DryRun    = $false
$script:Log       = New-Object System.Collections.Generic.List[string]
$script:Bak       = $null
$script:BakDone   = @{}
$script:Changes   = 0

# mod folders in this package: name, required
$script:ModSlots = @(
    @{ Name = 'mkev_modpatcher';     Required = $true; Stage = $false },
    @{ Name = 'mkevserverbootpatch'; Required = $true; Stage = $true  }
)
$script:PresetName = 'MKevServer'
$script:DefaultTxtMod = 'mkev_modpatcher'

# ------------------------------------------------------------------ helpers
function Say([string]$t) { Write-Host $t; $script:Log.Add($t) }
function Rel([string]$p) { if ($p.StartsWith($script:Zomboid)) { return $p.Substring($script:Zomboid.Length).TrimStart('\','/') } return $p }
function P([string]$rel) { return Join-Path $script:Zomboid $rel }

function Ask([string]$q) {
    if ($env:PZ_CONFIRM) { $a = $env:PZ_CONFIRM; Say ("  " + $q + " [Y/N]: " + $a + " (automatic)") }
    else { $a = Read-Host ("  " + $q + " [Y/N]") ; $script:Log.Add("  " + $q + " -> " + $a) }
    return ($a -match '^\s*[JjYy]')
}

function Assert-SafePath([string]$p) {
    $full = [System.IO.Path]::GetFullPath($p)
    if ($full -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { throw ("Safety stop: Workshop folders are never modified: " + $full) }
    $root = [System.IO.Path]::GetFullPath($script:Zomboid)
    if (-not $full.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) { throw ("Safety stop: target is outside the Zomboid folder: " + $full) }
}

function Read-Text([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    $bom = ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF)
    $text = $script:Utf8NoBom.GetString($bytes)
    if ($bom) { $text = $text.Substring(1) }
    $nl = if ($text.Contains("`r`n")) { "`r`n" } elseif ($text.Contains("`n")) { "`n" } else { "`r`n" }
    $endsNl = $text.EndsWith("`n")
    $lines = @($text -split "`r?`n")
    if ($endsNl) { if ($lines.Count -le 1) { $lines = @() } else { $lines = @($lines[0..($lines.Count - 2)]) } }
    return @{ Lines = $lines; Nl = $nl; Bom = $bom }
}

function Write-TextLines([string]$path, $lines, [string]$nl, [bool]$bom) {
    Assert-SafePath $path
    $dir = Split-Path -Parent $path
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $text = ($lines -join $nl) + $nl
    $enc = if ($bom) { New-Object System.Text.UTF8Encoding($true) } else { $script:Utf8NoBom }
    [System.IO.File]::WriteAllText($path, $text, $enc)
}

function Read-ListFile([string]$name, [string]$key) {
    $f = Join-Path $script:SetupSrc $name
    if (-not (Test-Path -LiteralPath $f)) { throw ("File missing in package: MKevServer_setup\" + $name) }
    foreach ($l in (Read-Text $f).Lines) { if ($l.StartsWith($key + '=')) { return $l.Substring($key.Length + 1) } }
    throw ("Line " + $key + "= missing in MKevServer_setup\" + $name)
}

function Split-List([string]$v, [string]$sep) { return ,@($v.Split($sep) | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' }) }

function Get-DirSig([string]$dir) {
    if (-not (Test-Path -LiteralPath $dir)) { return '' }
    $base = (Get-Item -LiteralPath $dir).FullName.TrimEnd('\','/')
    $items = Get-ChildItem -LiteralPath $dir -Recurse -File -Force | Sort-Object FullName | ForEach-Object {
        $_.FullName.Substring($base.Length).Replace('\','/') + '|' + (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash
    }
    return ($items -join "`n")
}

function Get-ModVersion([string]$dir) {
    foreach ($mi in @((Join-Path $dir '42\mod.info'), (Join-Path $dir 'mod.info'))) {
        if (Test-Path -LiteralPath $mi) {
            foreach ($l in (Read-Text $mi).Lines) { if ($l -match '^modversion=(.*)$') { return $Matches[1].Trim() } }
        }
    }
    return 'unknown'
}

# ------------------------------------------------------------------ backup
function New-BackupSession([string]$action) {
    $stamp = if ($env:PZ_STAMP) { $env:PZ_STAMP } else { Get-Date -Format 'yyyy-MM-dd_HHmmss' }
    $name = $stamp + '_' + $action
    $dir = Join-Path $script:BackupRoot $name
    $i = 2
    while (Test-Path -LiteralPath $dir) { $dir = Join-Path $script:BackupRoot ($name + '_' + $i); $i++ }
    $script:Bak = $dir
    $script:BakDone = @{}
}

function Ensure-BackupDir {
    if (-not (Test-Path -LiteralPath $script:Bak)) {
        Assert-SafePath $script:Bak
        New-Item -ItemType Directory -Force -Path (Join-Path $script:Bak 'files') | Out-Null
    }
}

# Back up a file or folder (relative to Zomboid) once per session, before it is changed.
function Backup-Item([string]$rel) {
    if ($script:DryRun) { return }
    if ($script:BakDone.ContainsKey($rel.ToLower())) { return }
    Ensure-BackupDir
    $src = P $rel
    $idx = Join-Path $script:Bak 'backup_index.txt'
    if (Test-Path -LiteralPath $src) {
        $dst = Join-Path (Join-Path $script:Bak 'files') $rel
        $parent = Split-Path -Parent $dst
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
        Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
        [System.IO.File]::AppendAllText($idx, ("existed`t" + $rel + "`r`n"), $script:Utf8NoBom)
        Say ("    Backup: " + $rel)
    } else {
        [System.IO.File]::AppendAllText($idx, ("created`t" + $rel + "`r`n"), $script:Utf8NoBom)
    }
    $script:BakDone[$rel.ToLower()] = $true
}

function Save-Log {
    if ($script:DryRun) { return }
    try {
        if (-not (Test-Path -LiteralPath $script:BackupRoot)) { New-Item -ItemType Directory -Force -Path $script:BackupRoot | Out-Null }
        $txt = ($script:Log -join "`r`n") + "`r`n"
        if ($script:Bak -and (Test-Path -LiteralPath $script:Bak)) { [System.IO.File]::WriteAllText((Join-Path $script:Bak 'installer_log.txt'), $txt, $script:Utf8NoBom) }
        $hdr = "==== " + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + " ModPatchInstaller " + $script:Version + "`r`n"
        [System.IO.File]::AppendAllText((Join-Path $script:BackupRoot 'installer_log.txt'), ($hdr + $txt), $script:Utf8NoBom)
    } catch { Write-Host ("  Note: could not save the log: " + $_.Exception.Message) }
}

# ------------------------------------------------------------------ checks
function Test-PzRunning {
    if ($env:PZ_SKIP_PROCCHECK) { Say "  Process check skipped (test mode)."; return $false }
    $hit = @()
    foreach ($n in @('ProjectZomboid64', 'ProjectZomboid32', 'ProjectZomboidServer')) {
        if (Get-Process -Name $n -ErrorAction SilentlyContinue) { $hit += ($n + '.exe') }
    }
    $javas = @()
    try { $javas = @(Get-CimInstance Win32_Process -Filter "Name='java.exe' OR Name='javaw.exe'" -ErrorAction Stop) }
    catch { $javas = @(Get-Process -Name java, javaw -ErrorAction SilentlyContinue | ForEach-Object { New-Object PSObject -Property @{ Name = $_.ProcessName + '.exe'; CommandLine = $null } }) }
    foreach ($j in $javas) {
        $cl = $j.CommandLine
        if ((-not $cl) -or ($cl -match '(?i)zomboid|zombie\.network|zombie\.gameStates|ProjectZomboid')) { $hit += ($j.Name + ' (probably a PZ server)') }
    }
    if ($hit.Count -gt 0) {
        Say "  ABORTED: Project Zomboid or the PZ server is still running:"
        foreach ($h in ($hit | Select-Object -Unique)) { Say ("    - " + $h) }
        Say "  Please close the game AND the server completely (server: type 'quit') and start the installer again."
        return $true
    }
    Say "  OK: game and server are not running."
    return $false
}

function Test-Package {
    $ok = $true
    foreach ($s in $script:ModSlots) {
        $d = Join-Path $script:Src $s.Name
        if ((-not (Test-Path -LiteralPath $d)) -and $s.Required) { Say ("  ERROR: folder missing in package: " + $s.Name); $ok = $false }
    }
    if (-not (Test-Path -LiteralPath $script:BootFixCore)) { Say "  ERROR: mkevserverbootpatch\tools\bootfix.ps1 is missing in the package."; $ok = $false }
    if (-not (Test-Path -LiteralPath $script:SetupSrc)) { Say "  ERROR: folder MKevServer_setup is missing in the package."; $ok = $false }
    return $ok
}

# ------------------------------------------------------------------ boot patch: self-healing fixes (F1-F3)
# mkevserverbootpatch 1.1.2 ships the 3 fixed script files. At install time they are checked against YOUR installed
# Workshop originals (read only): unchanged -> bundled file; mod updated -> fix rebuilt from the new file and checked;
# fixed by the author / file no longer loaded -> our override removed; check failed -> previous file kept + warning.
# Logic: mkevserverbootpatch\tools\bootfix.ps1 (same as tools\check_upstream.ps1 / .sh). Workshop folders are never written.
$script:BootFixCore = Join-Path (Join-Path (Join-Path $script:Src 'mkevserverbootpatch') 'tools') 'bootfix.ps1'
if (Test-Path -LiteralPath $script:BootFixCore) { . $script:BootFixCore }
$script:BootFixResult = @()

# Workshop content folders (108600 = Project Zomboid) of all Steam libraries. PZ_WORKSHOP overrides (';'-list).
function Get-WorkshopRoots {
    if ($env:PZ_WORKSHOP) { return @($env:PZ_WORKSHOP.Split(';') | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) }
    $libs = New-Object System.Collections.Generic.List[string]
    $steam = $null
    try { $steam = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name SteamPath -ErrorAction Stop).SteamPath } catch { }
    if ($steam) { $libs.Add($steam.Replace('/', '\')) }
    foreach ($d in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) { if ($d) { $libs.Add((Join-Path $d 'Steam')) } }
    foreach ($l in @($libs)) {
        $vdf = Join-Path $l 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($line in [System.IO.File]::ReadAllLines($vdf)) { if ($line -match '^\s*"path"\s*"(.+)"\s*$') { $libs.Add($Matches[1].Replace('\\', '\')) } }
        }
    }
    $roots = @()
    foreach ($l in $libs) {
        $r = Join-Path $l 'steamapps\workshop\content\108600'
        if ((Test-Path -LiteralPath $r) -and ($roots -notcontains $r)) { $roots += $r }
    }
    return $roots
}

function Format-BootFix($d) {
    $n = '    ' + $d.Fx.Id + ' ' + $d.Fx.Label + ': '
    switch ($d.Status) {
        'KEEP'           { return ($n + 'original unchanged - bundled fix used.') }
        'REBUILT'        { return ($n + ('original was updated ({0}) - fix rebuilt and checked.' -f $d.Src)) }
        'FIXED_UPSTREAM' { return ($n + ('fixed by the mod author ({0}) - our override is removed.' -f $d.Src)) }
        'NOT_LOADED'     { return ($n + 'the mod no longer loads this file - our override is removed.') }
        'MISSING'        { return ($n + 'mod not found in your Workshop folders - bundled fix used.') }
    }
    $why = (@{ braces = 'braces { } do not match'; tokens = 'error not fully fixed'; changes = 'unexpected changes'; read = 'file could not be read' })[$d.Why]
    return ('    WARNING {0}: original was updated ({1}), but the new fix failed the safety check ({2}). Previous file kept, nothing broken written. Please tell MKev.' -f ($d.Fx.Id + ' ' + $d.Fx.Label), $d.Src, $why)
}

# Copy the package folder to a temp stage and bring F1-F3 in line with the user's Workshop files.
function New-BootPatchStage([string]$from) {
    $stage = Join-Path ([System.IO.Path]::GetTempPath()) ('mkev_bootpatch_stage_' + [guid]::NewGuid().ToString('N'))
    Copy-Item -LiteralPath $from -Destination $stage -Recurse -Force
    $script:BootFixResult = @()
    $roots = @()
    try {
        $roots = @(Get-WorkshopRoots)
        $dec = @(Get-BfDecisions $roots)
        Set-BfFixes $stage $dec (Join-Path (P 'mods') 'mkevserverbootpatch')
        foreach ($d in $dec) { $script:BootFixResult += (Format-BootFix $d) }
    } catch {
        $script:BootFixResult += ('    WARNING: boot fix check failed (' + $_.Exception.Message + ') - bundled files are installed unchanged.')
        Remove-Item -LiteralPath $stage -Recurse -Force
        Copy-Item -LiteralPath $from -Destination $stage -Recurse -Force
    }
    if ($roots.Count -eq 0) { $script:BootFixResult += '    Note: no Steam Workshop folder found (set PZ_WORKSHOP if it is somewhere else). Bundled fixes are used.' }
    return $stage
}


# ------------------------------------------------------------------ steps
function Install-Mods {
    Say ""
    Say "  [Mods] Target: Zomboid\mods"
    $modsDir = P 'mods'
    if (-not (Test-Path -LiteralPath $modsDir)) {
        if ($script:DryRun) { Say "    (would create folder Zomboid\mods)" }
        else { Assert-SafePath $modsDir; New-Item -ItemType Directory -Force -Path $modsDir | Out-Null }
    }
    foreach ($s in $script:ModSlots) {
        $n = $s.Name
        $from = Join-Path $script:Src $n
        $stage = $null
        if ($s.Stage) {
            $stage = New-BootPatchStage $from
            $from = $stage
            Say ("    " + $n + " - boot fixes checked against your Workshop files:")
            foreach ($l in $script:BootFixResult) { Say $l }
        }
        try {
            $to = Join-Path $modsDir $n
            Assert-SafePath $to
            $newVer = Get-ModVersion $from
            if ((Get-DirSig $from) -eq (Get-DirSig $to)) { Say ("    " + $n + " " + $newVer + ": already up to date, nothing changed."); continue }
            $oldVer = if (Test-Path -LiteralPath $to) { Get-ModVersion $to } else { 'not installed' }
            if ($script:DryRun) { Say ("    " + $n + ": would be installed (" + $oldVer + " -> " + $newVer + ")."); $script:Changes++; continue }
            Backup-Item ('mods\' + $n)
            if (Test-Path -LiteralPath $to) { Remove-Item -LiteralPath $to -Recurse -Force }
            Copy-Item -LiteralPath $from -Destination $to -Recurse -Force
            if ((Get-DirSig $from) -ne (Get-DirSig $to)) { throw ("Copy of " + $n + " is not identical.") }
            Say ("    " + $n + ": installed (" + $oldVer + " -> " + $newVer + ").")
            $script:Changes++
        } finally {
            if ($stage -and (Test-Path -LiteralPath $stage)) { Remove-Item -LiteralPath $stage -Recurse -Force }
        }
    }
}


# Replace Mods= / WorkshopItems= / Map= in servertest.ini, keep every other line byte-identical.
function Merge-ServerIni {
    Say ""
    Say "  [Server settings] Zomboid\Server\servertest.ini (only Mods=, WorkshopItems=, Map=)"
    $want = [ordered]@{
        'Mods'          = (Read-ListFile 'MKevServer_modlist.txt' 'Mods')
        'WorkshopItems' = (Read-ListFile 'MKevServer_workshopitems.txt' 'WorkshopItems')
        'Map'           = (Read-ListFile 'MKevServer_map.txt' 'Map')
    }
    $path = P 'Server\servertest.ini'
    $exists = Test-Path -LiteralPath $path
    if ($exists) { $t = Read-Text $path; $lines = New-Object System.Collections.Generic.List[string]; foreach ($l in $t.Lines) { $lines.Add($l) }; $nl = $t.Nl; $bom = $t.Bom }
    else { $lines = New-Object System.Collections.Generic.List[string]; $nl = "`r`n"; $bom = $false; Say "    File missing -> will be created (only these three lines; the game adds the rest on the first server start)." }
    $changed = $false
    foreach ($k in $want.Keys) {
        $sep = ';'
        $newLine = $k + '=' + $want[$k]
        $idx = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i].StartsWith($k + '=')) { $idx = $i; break } }
        if ($idx -ge 0) {
            $oldVal = $lines[$idx].Substring($k.Length + 1)
            if ($lines[$idx] -ceq $newLine) { Say ("    " + $k + "=: already correct (" + (Split-List $want[$k] $sep).Count + " entries)."); continue }
            $old = Split-List $oldVal $sep; $new = Split-List $want[$k] $sep
            $removed = @($old | Where-Object { $new -notcontains $_ })
            $added = @($new | Where-Object { $old -notcontains $_ })
            Say ("    " + $k + "=: will be replaced (" + $old.Count + " -> " + $new.Count + " entries, new: " + $added.Count + ", removed: " + $removed.Count + ", order as on the MKev server).")
            if ($removed.Count -gt 0) { Say ("      removed (the player's own entries): " + ($removed -join ', ')) }
            $lines[$idx] = $newLine
            # remove duplicate later lines of the same key (game uses one)
            for ($j = $lines.Count - 1; $j -gt $idx; $j--) { if ($lines[$j].StartsWith($k + '=')) { $lines.RemoveAt($j); Say ("      duplicate " + $k + "= line removed.") } }
        } else {
            Say ("    " + $k + "=: missing -> will be added (" + (Split-List $want[$k] $sep).Count + " entries).")
            $lines.Add($newLine)
        }
        $changed = $true
    }
    if (-not $changed) { return }
    $script:Changes++
    if ($script:DryRun) { Say "    (dry run: nothing written; all other lines stay unchanged)"; return }
    Backup-Item 'Server\servertest.ini'
    Write-TextLines $path $lines $nl $bom
    Say "    saved. All other settings (passwords, ports, names ...) unchanged."
}

function Install-FileCopy([string]$fromName, [string]$rel, [string]$label) {
    $from = Join-Path $script:SetupSrc $fromName
    $to = P $rel
    Say ""
    Say ("  [" + $label + "] Zomboid\" + $rel)
    if (-not (Test-Path -LiteralPath $from)) { throw ("File missing in package: MKevServer_setup\" + $fromName) }
    Assert-SafePath $to
    if ((Test-Path -LiteralPath $to) -and ((Get-FileHash -Algorithm SHA256 -LiteralPath $from).Hash -eq (Get-FileHash -Algorithm SHA256 -LiteralPath $to).Hash)) { Say "    already identical, nothing changed."; return }
    $script:Changes++
    if ($script:DryRun) { Say ("    would be " + $(if (Test-Path -LiteralPath $to) { 'replaced' } else { 'created' }) + " (content: MKevServer_setup\" + $fromName + ")."); return }
    Backup-Item $rel
    $dir = Split-Path -Parent $to
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    Copy-Item -LiteralPath $from -Destination $to -Force
    Say "    saved."
}

# pz_modlist_settings.cfg: add or replace only the line of our preset, keep every other preset.
function Merge-Preset {
    Say ""
    Say ("  [Mod preset] Zomboid\Lua\pz_modlist_settings.cfg (preset '" + $script:PresetName + "')")
    $f = Join-Path $script:SetupSrc 'MKevServer_preset.txt'
    $our = $null
    foreach ($l in (Read-Text $f).Lines) { if ($l.StartsWith($script:PresetName + ':')) { $our = $l } }
    if (-not $our) { throw "Preset line missing in MKevServer_setup\MKevServer_preset.txt" }
    $path = P 'Lua\pz_modlist_settings.cfg'
    $lines = New-Object System.Collections.Generic.List[string]; $nl = "`r`n"; $bom = $false
    if (Test-Path -LiteralPath $path) { $t = Read-Text $path; foreach ($l in $t.Lines) { $lines.Add($l) }; $nl = $t.Nl; $bom = $t.Bom }
    else { $lines.Add('!fav!:') }
    $idx = -1
    for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i].StartsWith($script:PresetName + ':')) { $idx = $i; break } }
    $foreign = @($lines | Where-Object { $_ -match '^[^:]+:' -and -not $_.StartsWith('!fav!:') -and -not $_.StartsWith($script:PresetName + ':') } | ForEach-Object { $_.Split(':')[0] })
    if ($idx -ge 0 -and $lines[$idx] -ceq $our) { Say "    already up to date, nothing changed."; return }
    if ($idx -ge 0) { $lines[$idx] = $our; Say "    existing preset will be updated." } else { $lines.Add($our); Say "    preset will be added." }
    if ($foreign.Count -gt 0) { Say ("    your own presets are kept: " + ($foreign -join ', ')) }
    $script:Changes++
    if ($script:DryRun) { Say "    (dry run: nothing written)"; return }
    Backup-Item 'Lua\pz_modlist_settings.cfg'
    Write-TextLines $path $lines $nl $bom
    Say "    saved."
}

# mods\default.txt: add mkev_modpatcher to the mods block, nothing else.
function Merge-DefaultTxt {
    Say ""
    Say ("  [Local mod list] Zomboid\mods\default.txt (add " + $script:DefaultTxtMod + ")")
    $path = P 'mods\default.txt'
    $id = $script:DefaultTxtMod
    if (-not (Test-Path -LiteralPath $path)) {
        $lines = @('VERSION = 1,', '', 'mods', '{', ('    mod = ' + $id + ','), '}', '', 'maps', '{', '}')
        $nl = "`r`n"; $bom = $false
        Say "    File missing -> will be created."
    } else {
        $t = Read-Text $path; $nl = $t.Nl; $bom = $t.Bom
        $lines = New-Object System.Collections.Generic.List[string]; foreach ($l in $t.Lines) { $lines.Add($l) }
        $inMods = $false; $close = -1; $found = $false; $start = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            $s = $lines[$i].Trim()
            if (-not $inMods -and $s -eq 'mods') { $start = $i; continue }
            if ($start -ge 0 -and -not $inMods -and $close -lt 0 -and $s -eq '{') { $inMods = $true; continue }
            if ($inMods) {
                if ($s -eq '}') { $close = $i; $inMods = $false; break }
                if ($s -match '^mod\s*=\s*\\?([^,]+?)\s*,?\s*$' -and $Matches[1] -eq $id) { $found = $true }
            }
        }
        if ($found) { Say "    already listed, nothing changed."; return }
        if ($close -lt 0) { Say "    WARNING: unknown layout of default.txt, not changed. (The mod adds itself when you join a server.)"; return }
        $lines.Insert($close, ('    mod = ' + $id + ','))
        Say "    will be appended to the end of the mod list (no other change)."
    }
    $script:Changes++
    if ($script:DryRun) { Say "    (dry run: nothing written)"; return }
    Backup-Item 'mods\default.txt'
    Write-TextLines $path $lines $nl $bom
    Say "    saved."
}

# Option 2: ready-made files for the player, no existing config is touched.
function Write-SetupFolder {
    $dst = P 'MKevServer_setup'
    Say ""
    Say "  [Templates] Zomboid\MKevServer_setup\"
    Assert-SafePath $dst
    $files = @('MKevServer_modlist.txt', 'MKevServer_workshopitems.txt', 'MKevServer_map.txt', 'MKevServer_SandboxVars.lua', 'MKevServer_preset.txt', 'MKevServer_README.txt')
    $same = $true
    foreach ($f in $files) {
        $a = Join-Path $script:SetupSrc $f; $b = Join-Path $dst $f
        if (-not (Test-Path -LiteralPath $b) -or (Get-FileHash -Algorithm SHA256 -LiteralPath $a).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $b).Hash) { $same = $false }
    }
    if ($same) { Say "    already up to date, nothing changed."; return }
    $script:Changes++
    if ($script:DryRun) { Say "    (dry run: nothing written)"; return }
    Backup-Item 'MKevServer_setup'
    if (-not (Test-Path -LiteralPath $dst)) { New-Item -ItemType Directory -Force -Path $dst | Out-Null }
    foreach ($f in $files) { Copy-Item -LiteralPath (Join-Path $script:SetupSrc $f) -Destination (Join-Path $dst $f) -Force; Say ("    " + $f) }
}

# ------------------------------------------------------------------ restore
function Get-Backups {
    if (-not (Test-Path -LiteralPath $script:BackupRoot)) { return @() }
    return @(Get-ChildItem -LiteralPath $script:BackupRoot -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'backup_index.txt') } | Sort-Object Name -Descending)
}

function Invoke-Restore {
    $list = @(Get-Backups)
    if ($list.Count -eq 0) { Say "  No backups found in Zomboid\mkev_patch_backups."; return }
    Say "  Available backups (newest first):"
    for ($i = 0; $i -lt $list.Count; $i++) { Say ("    " + ($i + 1) + ") " + $list[$i].Name) }
    $pick = if ($env:PZ_RESTORE_PICK) { $env:PZ_RESTORE_PICK } else { Read-Host "  Choose a number (empty = cancel)" }
    $n = 0
    if (-not [int]::TryParse(("" + $pick).Trim(), [ref]$n) -or $n -lt 1 -or $n -gt $list.Count) { Say "  Cancelled."; return }
    $b = $list[$n - 1].FullName
    $entries = @()
    foreach ($l in (Read-Text (Join-Path $b 'backup_index.txt')).Lines) { if ($l -match "^(existed|created)`t(.+)$") { $entries += ,@($Matches[1], $Matches[2]) } }
    Say ("  Backup " + $list[$n - 1].Name + " restores the state from BEFORE that run:")
    foreach ($e in $entries) { Say ("    " + $(if ($e[0] -eq 'existed') { 'restore: ' } else { 'remove (was new): ' }) + $e[1]) }
    if (-not (Ask "Restore?")) { Say "  Cancelled, nothing changed."; return }
    New-BackupSession 'before_restore'
    foreach ($e in $entries) {
        $rel = $e[1]; $target = P $rel
        Assert-SafePath $target
        Backup-Item $rel
        if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
        if ($e[0] -eq 'existed') {
            $parent = Split-Path -Parent $target
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
            Copy-Item -LiteralPath (Join-Path (Join-Path $b 'files') $rel) -Destination $target -Recurse -Force
        }
        Say ("    done: " + $rel)
    }
    Say ("  Restored. The state before this restore is saved in: " + (Rel $script:Bak))
}

# ------------------------------------------------------------------ menu
function Show-Info1 {
    Say ""
    Say "  INSTALL & SET UP - this is exactly what happens:"
    Say "   1. Copy the mods to Zomboid\mods: mkev_modpatcher, mkevserverbootpatch."
    Say "      The boot patch brings its 3 script fixes. If a mod was updated, they are"
    Say "      rebuilt from your Workshop files (read only, never modified)."
    Say "   2. Zomboid\Server\servertest.ini: the lines Mods=, WorkshopItems= and Map="
    Say "      are replaced COMPLETELY by the list of the MKev server (load order)."
    Say "      Your previous entries in these three lines will be gone."
    Say "      All other settings (passwords, ports, server name ...) stay as they are."
    Say "      If the file does not exist, it is created with only these three lines."
    Say "   3. Zomboid\Server\servertest_SandboxVars.lua is replaced by the settings of the"
    Say "      MKev server."
    Say "   4. Zomboid\Lua\pz_modlist_settings.cfg: mod preset 'MKevServer' is"
    Say "      added/updated, your own presets stay."
    Say "   5. Zomboid\mods\default.txt: mkev_modpatcher is appended (nothing else)."
    Say "   Everything is backed up first to Zomboid\mkev_patch_backups\<date_time>\"
    Say "   (restore it with menu option 3)."
}

function Run-Setup([bool]$dry) {
    $script:DryRun = $dry
    if (-not $dry) { New-BackupSession 'setup' }
    Install-Mods
    Merge-ServerIni
    Install-FileCopy 'MKevServer_SandboxVars.lua' 'Server\servertest_SandboxVars.lua' 'Sandbox settings'
    Merge-Preset
    Merge-DefaultTxt
}

function Main {
    Say ""
    Say ("  MKev's Modpatch Installer " + $script:Version + "  (author MKev)")
    Say "  ================================================================"
    Say ("  Package : " + $script:Src)
    Say ("  Zomboid : " + $script:Zomboid)
    Say ""
    Say "   1) Install & set up   (recommended)"
    Say "   2) Install only, do not set up (patch + template files only)"
    Say "   3) Restore backup"
    Say "   4) Quit"
    Say "   5) Dry run: only show what 1) would change"
    $c = if ($env:PZ_CHOICE) { $env:PZ_CHOICE } else { Read-Host "  Choice [1]" }
    $c = ("" + $c).Trim(); if ($c -eq '') { $c = '1' }
    $script:Log.Add("  Choice: " + $c)
    if ($c -eq '4') { Say "  Quit, nothing changed."; return 0 }
    if (@('1', '2', '3', '5') -notcontains $c) { Say "  Invalid choice, nothing changed."; return 1 }
    Say ""
    if (Test-PzRunning) { return 1 }
    if (-not (Test-Path -LiteralPath $script:Zomboid)) {
        Say ("  ABORTED: Zomboid folder not found: " + $script:Zomboid)
        Say "  Please start Project Zomboid once and close it again."
        return 1
    }
    if ($script:Zomboid -match '(?i)[\\/]steamapps[\\/]workshop([\\/]|$)') { Say "  ABORTED (safety stop): the Zomboid folder is inside a Workshop folder."; return 1 }
    if ($c -eq '3') { Invoke-Restore; Save-Log; return 0 }
    if (-not (Test-Package)) { return 1 }
    if ($c -eq '5') {
        Say "  DRY RUN - nothing will be written:"
        Run-Setup $true
        Say ""
        Say ("  Dry run finished: " + $script:Changes + " change(s) would be made.")
        return 0
    }
    if ($c -eq '1') {
        Show-Info1
        Say ""
        if (-not (Ask "Do you agree? Install and set up now?")) { Say "  Cancelled, nothing changed."; return 0 }
        Run-Setup $false
    } else {
        Say "  INSTALL ONLY, DO NOT SET UP: only the patches are copied,"
        Say "  no existing setting is changed."
        $script:DryRun = $false
        New-BackupSession 'install_only'
        Install-Mods
        Write-SetupFolder
        Say ""
        Say "  Ready-made files for setting up yourself are in Zomboid\MKevServer_setup\ :"
        Say "    MKevServer_modlist.txt        -> line Mods= (load order) for your servertest.ini"
        Say "    MKevServer_workshopitems.txt  -> line WorkshopItems= for your servertest.ini"
        Say "    MKevServer_map.txt            -> line Map= for your servertest.ini"
        Say "    MKevServer_SandboxVars.lua    -> sandbox settings (use as <servername>_SandboxVars.lua)"
        Say "    MKevServer_preset.txt         -> line for Zomboid\Lua\pz_modlist_settings.cfg"
        Say "    MKevServer_README.txt         -> instructions"
    }
    Say ""
    Say "  Installed versions:"
    foreach ($s in $script:ModSlots) { $d = P ('mods\' + $s.Name); if (Test-Path -LiteralPath $d) { Say ("    " + $s.Name + ": " + (Get-ModVersion $d)) } }
    Say ""
    if ($script:Bak -and (Test-Path -LiteralPath $script:Bak)) { Say ("  DONE. Backup: " + $script:Bak) } else { Say "  DONE. Everything was already up to date, nothing changed." }
    Say "  To play: keep the Workshop collection subscribed, start the game and join the server."
    Save-Log
    return 0
}

try { $rc = Main } catch { Say ("  ERROR: " + $_.Exception.Message); if ($script:Bak) { Say ("  Backup to restore from (menu option 3): " + $script:Bak) }; Save-Log; $rc = 1 }
exit $rc
