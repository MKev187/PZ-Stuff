@echo off
setlocal EnableExtensions
title MKev's Modpatch Installer 1.31
rem ==================================================================
rem  MKev's Modpatch Installer 1.31 - for players of the MKev server
rem  Author: MKev.
rem  Just double-click. First you pick the language (English/Deutsch),
rem  then ModPatchInstaller_en.ps1 or ModPatchInstaller_de.ps1 in the
rem  same folder does the actual work (menu, backup, checks).
rem  Test/skip switch: set PZ_LANG=en or PZ_LANG=de to skip the question.
rem ==================================================================
set "LANGSEL="
if /i "%PZ_LANG%"=="en" set "LANGSEL=en"
if /i "%PZ_LANG%"=="de" set "LANGSEL=de"
if defined LANGSEL goto langdone
echo.
echo   MKev's Modpatch Installer 1.31
echo   ================================================================
echo   Select language / Sprache waehlen:
echo.
echo     1) English
echo     2) Deutsch
echo.
choice /c 12 /n /m "  Press 1 or 2 / Taste 1 oder 2 druecken: "
if errorlevel 2 (set "LANGSEL=de") else (set "LANGSEL=en")
echo.
:langdone
if "%LANGSEL%"=="de" goto usede
if not exist "%~dp0ModPatchInstaller_en.ps1" goto missingen
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ModPatchInstaller_en.ps1"
goto done
:usede
if not exist "%~dp0ModPatchInstaller_de.ps1" goto missingde
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ModPatchInstaller_de.ps1"
goto done
:missingen
echo  ERROR: ModPatchInstaller_en.ps1 is missing. Please extract the whole zip.
set "RC=1"
goto finish
:missingde
echo  FEHLER: ModPatchInstaller_de.ps1 fehlt. Bitte das Zip komplett entpacken.
set "RC=1"
goto finish
:done
set "RC=%ERRORLEVEL%"
:finish
echo.
if not defined PZ_NOPAUSE pause
endlocal & exit /b %RC%
