# Upstream notes (bugs in other mods that MKev-ModPatcher works around or documents)

## U1 Plysken Underground Revolution (PUR, WS 3776279483)
- 42.1/media/lua/server/BuildingObjects/PUR_DigCursor.lua:134 `function PUR.armDigCursor(player)`. PUR is only created in client/ files,
  so a dedicated server throws "attempted index of non-table" on every start.
- Suggested fix: `PUR = PUR or {}` at the top of the file (or move the table init to shared/).
- Workaround: mkevmp_purserverguard.lua (dedicated server only, only if PUR is active).

## U2 Project A-Life NPCs (WS 3803984183), no patch
- ALifeArmor.wear -> addHoleFromZombieAttacks/addHole -> server ItemStats NPE ("o.square is null"). NPC clothing holes are not synced.
- 2026-10-25 19:19 (MEZ): second path, ALifeLootWear.lua:187 (condition) → Clothing.setCondition → Unwear → server NPE in ContainerID.set (o.square null) while ALifeDeathDrops processes a dying NPC shell. Caught by A-Life's pcall; log-only.

## U3 Sentry Turret Upgrade (WS 3633082678), no patch
- require "ST_SP_TurretUtil"/"ST_MP_*" without the folder prefix -> "require failed" (cosmetic in MP).

## U4 82jeepJ10 (WS 2886832257) vs 84jeepXJ (WS 3409287192): file-path collision (old docs/upstream/01)
- 84jeepXJ ships media/scripts/vehicles/template_JP82_spareTires.txt (defines JP84SpareTires), which replaces 82jeepJ10's file
  of the same name -> "template JP82SpareTires not found". Fix for the 84jeepXJ author: rename the file to template_JP84_spareTires.txt.
- Workaround: mkevmp_template_jp82_sparetires_restore.txt + mkevmp_jp82guard.lua.

## U5 FunctionalAppliances2 (WS 3042138819) / Authentic Z (WS 2335368829): pre-42.20 soda OnCreate (old docs/upstream/05)
- FA_items_food.txt:626 and the AuthenticZ item files still use SpecialLootSpawns.OnCreateSodaCan (now ItemCodeOnCreate.onCreateSodaCan).
- Workaround: mkevmp_sodacanalias.lua (dormant, both mods are inactive right now).

## U6 KI5 gunracks only in legacy media/ (old docs/upstream/03)
- 93mustangSSP (3001592312) SSP93Gunrack and 87chevySuburban (3196180339) SUB87Gunrack are defined only in the root media/ folder,
  which B42 does not load when versioned folders exist. Workaround: mkevmp_template_ki5_gunracks.txt.

## U7 Stale KI5/damnlib template references (old docs/upstream/02 and /04)
- P19ABigTrunkCompartment2 (86oshkoshP19A), DAMN67commando* (67commando 42.20; damnlib 42.13+ commented them out), and the
  12 names in mkevmp_template_stubs_stale_refs.txt. Empty stubs: no parts are added, the load error goes away.

## U8 Broken % in sandbox translations (T8)
- TrueSmoking: 4 EN tooltips "(%)"; the same unescaped % is also in CN/JP/KR/PTBR/RU/TR/UA Sandbox.json and in
  PTBR/RU/UA Moodles.json. WeightReduction: EN ReductionPercent(+_tooltip). Fix for the authors: write %% (vanilla convention).
- Workaround: Translate/EN/Sandbox.json (EN only).
- Same warning type, not patched yet: NeatLockpicking, M13ReadingTweaks, TrueSleep, ExplosivesOptions, BadlandsFence, NM_FancyDevice.

## U6 Project A-Life NPCs (WS 3803984183, v1.4.6) + vanilla B42 42.20: PlayerDropHeldItems ClassCastException on NPC window climbs
- Symptom (client, MP): `ERROR: Multiplayer INetworkPacket.send> Exception thrown java.lang.ClassCastException: IsoZombie cannot be cast to IsoPlayer
  at PlayerDropHeldItemsPacket.setData(PlayerDropHeldItemsPacket.java:35). Message: Packet "PlayerDropHeldItems" send failed`,
  then `WARN EquipPacket.set get invalid arguments`. Every one adds 1 to the red ERROR popup counter (ExceptionLogger.logException).
- Stack: PlayerDropHeldItemsPacket.setData:35 <- INetworkPacket.send:233/249 <- IsoGameCharacter.dropHeavyItems:15469
  <- IsoGameCharacter.climbThroughWindow:8387 <- IsoZombie.tryThump:3669 (walking into an open/broken window) or ThumpState.execute:201
  (thumped window breaks/opens).
- Engine cause: `dropHeavyItems()` sends `PlayerDropHeldItems` + `Equip` for any `GameClient.client && isLocal()` character with ANY item in
  a hand (not only heavy items); the packet casts `values[0]` to IsoPlayer. Vanilla zombies never hold hand items, so only mods that put
  items in zombie hands trigger it. In this pack: A-Life NPC shells (IsoZombie) with weapons. No other active mod sets hand items on zombies (grep of all 323 WorkshopItems).
- A-Life already guards its OWN climbs: ALifeObstacleTraversal.lua:250-276 (enterWindowClimb/enterWindowFrameClimb call
  TraversalHands.prepare(shell, true)) and ALifeTraversalHands.lua:40/45-63 empties hands near windows only while `ProjectALifePathActive == true`.
  Gap: engine-driven climbs (IsoZombie.tryThump while in PathFind/WalkToward/Lunge without ProjectALifePathActive, and ThumpState) are not covered.
- Repro: MP dedicated server, A-Life NPC with a weapon in hand, NPC walks or chases through an open/broken window (or breaks a window by thumping)
  while it is owned/simulated by the client -> exception on that client.
- Suggested fix for the author: in an OnZombieUpdate hook (runs before tryThump/state machine), call `TraversalHands.prepare(shell, true)` when the
  shell is in a moving state or ThumpState and faces a climbable window/frame/thumpable window, not only when ProjectALifePathActive. Or drop the
  `data.ProjectALifePathActive ~= true` early return in ALifeTraversalHands.lua:40 for shells in engine movement states.
  Vanilla-side fix (TIS): in dropHeavyItems guard the send with `this instanceof IsoPlayer`.
- Workaround: mkevmp_alifewindowhands.lua (v1.2; v1.5.2 widened to radius 1 tile around the shell, no facing check, because the shell can
  step next to a window and climb within the same update after OnZombieUpdate ran; 4 misses seen 2026-10-26 18:39-18:42 with the 1.2 check).

## U7 Vanilla B42 (42.21) ISInsertMagazine:start() on MP clients: magazine becomes nil -> setJobDelta on nil
- Symptom (client, MP): `attempted index: setJobDelta of non-table: null` at ISInsertMagazine.lua:35 (update, every frame) and
  :128 (perform), also possible at :117 (stop). Seen 25.10.2026 17:42:45, 10 errors in one reload. The Only Cure+ (WS 3818733381,
  shared/TOC/ExpActions.lua:122, WrapUpdate) shows up in the stack only because it wraps update(); it is not the cause.
- Cause: `ISInsertMagazine:start()` does `if isClient() and self.magazine then self.magazine = self.character:getInventory():getItemById(self.magazine:getID()) end`.
  That only searches the main inventory. If the magazine is not there yet on the client (likely: the transfer that
  `ISInventoryPaneContextMenu.transferIfNeeded()` queued just before is still being synced from the server), the result is nil, and
  update/perform/stop index nil. The magazine object was valid when the action was created (all callers in the pack check it:
  vanilla OnPressReloadButton, Hot Brass Tactical Reload TacticalReload.lua:94-96, VFE_RadialMenu.lua:192-195).
  Exact trigger (which reload path, magazine in a bag or not) is a hunch, not proven from the log: the lines before the error carry no hint.
- Suggested vanilla fix (TIS): keep the old reference when the lookup fails (`self.magazine = inv:getItemById(id) or self.magazine`), or nil-guard
  the three setJobDelta calls.
- Workaround: mkevmp_insertmagguard.lua (v1.3).

## U8 NeatLockpicking (WS 3783535220): setVariable("bDoShove") on a read-only variable, every frame
- Symptom (client): WARN `AnimationVariableSlotCallback.trySetValue> Trying to set read-only variable "bdoshove"`, ~130 lines per
  second while the lockpick or crowbar UI is open. Seen 25.10.2026 18:31:00-18:31:21 (2711 lines). No gameplay effect, only log spam.
- Cause: `NeatLockpick_InputLock.lua:139` (suppressCombat, called from OnPlayerUpdate), `NeatCrowbarPanel.lua:232` (suppressShove,
  called from OnTick) and `NeatCrowbarPanel.lua:922` (OnTick hold branch) call `player:setVariable("bDoShove", "false")`.
  In B42 bDoShove is bound to IsoPlayer.isDoShove() and read-only; `setDoShove(false)`, which the same code already calls, is enough.
- Suggested fix for the author: delete the three `setVariable("bDoShove", ...)` lines.
- Workaround: mkevmp_neatlockshovequiet.lua (v1.3) covers the first two; the hold branch (only while Space is held right after
  the crowbar panel closes) stays. If the author changes suppressCombat/suppressShove, re-check the override against the new code.

## U9 Realistic Army Zombies (WS 1902435140, id realisticarmyzombiesb42, 42.0/ folder, modversion 42.2): 3 clothing files missing
- Symptom (server): `PZXmlParserException ... "media/clothing/clothingItems/Jacket_M65_Green.xml"` caused by FileNotFoundException,
  26.10.2026 07:51:42 MEZ (FileSystemImpl.updateAsyncTransactions), when an army zombie with that outfit item is created.
- Cause: `42.0/media/fileGuidTable.xml` (and the copy in `42.0/`) maps GUIDs eb8d1f35-M65GREEN-..., eb8d1f35-GREENHOT-... and
  fce4e0fd-PATROLGREEN-... to `clothingItems/Jacket_M65_Green.xml`, `Jacket_ArmyCamoGreenHot.xml` and `Hat_PatrolCapGreen.xml`;
  `42.0/media/clothing/clothing.xml` uses them (M65 3x, GreenHot 2x, PatrolCap 1x), but none of the three files is in the mod, in
  vanilla 42.x or in any other mod of the pack. No item script uses them either.
- Suggested fix for the author: add the three clothingItem XMLs (and textures, if they were meant to be new looks), or remove the
  three GUIDs from clothing.xml and fileGuidTable.xml.
- Workaround: three stand-in XMLs with the same GUIDs and vanilla looks (v1.4). Remove them once the author ships the real files
  (check: the files appear under 42.0/media/clothing/clothingItems/).

## U10 Maskarad's Summer Car (WS 3790160840, id MaskaradsSummerCar, 42/ folder, modversion 0.0.1): car lift entity not in module Base
- Symptom (server): 40x `GameEntityFactory.CreateIsoEntityFromCellLoading> GameEntityException: ISO_ENTITY[anonymous] EntityScript not found,
  script: WorkshopCarLift` (ServerChunkLoader -> IsoChunk.LoadBrandNew -> CellLoader.AddObject), 26.10.2026 ~15:40 MEZ, first session on a
  fresh world. It only shows when chunks are generated for the first time, which is why the old save never logged it.
- Cause: `42/media/scripts/MSC_Building.txt` declares `entity WorkshopCarLift` inside `module MaskaradsSummerCar` and binds the vanilla
  sprites location_business_machinery_01_0/1/2/11/12/13 to it. SpriteConfigManager writes the short name `EntityScriptName=WorkshopCarLift`
  onto those sprites, and ScriptBucketCollection.getScript() resolves names without a dot in module `Base` only, so every map-placed lift
  fails to get its entity (it stays a plain object). Player-built lifts work because crafting passes the script object directly.
  The matching xuiSkin style ES_MSC_CarLift3 is already in `module Base` (MSC_CarLiftXui.txt).
- Suggested fix for the author: change `module MaskaradsSummerCar` to `module Base` in MSC_Building.txt (nothing references
  `MaskaradsSummerCar.WorkshopCarLift`).
- Workaround history: v1.5 overrode MSC_Building.txt with that one-line change; removed again in v1.5.1 because on an existing world the
  renamed entity blocks client joins (`[SpriteConfigs] Missing dictionary script on client: MaskaradsSummerCar.WorkshopCarLift`, stale
  SpriteConfig entries keep isLoaded). Note for the author: ship the module change only with a hint that it needs a fresh world (or keep
  the old entity name registered); the fix itself is still correct. Original file reference: /workspace/pz/workshop/3790160840/MSC_Building.orig.txt (2026-10-21).

## U11 Brita's Armor Pack (WS 3780298456, id BritasArmorPackB42, 42/ folder, modversion 1.4.9): obsolete NV stubs stay in the WorldDictionary
- Symptom (client, MP join): 6x `ERROR: General ... DictionaryDataClient.parseCurrentInfoSet> Warning client has no script for dictionary info:
  Base.NV_PNV_57` (also NV_PVS21, NV_PVS7, NV_PVS5, NV_GPNVG_18, Hat_Sam_NV), 26.10.2026 15:44:56 MEZ, fresh world.
- Cause: `42/media/scripts/BritaArmor/items/clothing.txt` keeps `item NV_PVS7 { Obsolete = true, }` etc. for the old names (migrated to
  *_ON by `BritaArmor_NVCompat.lua`). In 42.2x `GameEntityScript.InitLoadPP` registers the item with WorldDictionary before `Obsolete` is
  read, so the dedicated server stores them as live items; the client's ScriptBucket skips obsolete scripts and cannot resolve them.
  Nothing else references the old names.
- Suggested fix for the author: drop the six `Obsolete` stubs (the Lua migration only needs the name table) or keep them as full items.
- Workaround: v1.5 `mkevmp_brita_nv_legacy.txt` re-defines the six stubs with `Obsolete = false` and the body of the matching *_ON item.
  Remove it once Brita drops or changes the stubs (check clothing.txt for `item NV_PVS7`).

## U12 Realistic Army Zombies (WS 1902435140, 42.0/ folder) + Extra Bombs 2 (WS 3652008781, 42/ folder): pre-42.20 OnCreate names
- RAZ `media/scripts/clothes/Mask.txt` (Hat_GasMaskArmy, Hat_GasMaskArmyHood): `OnCreate = SpecialLootSpawns.OnCreateGasMask`.
- Extra Bombs 2 `media/scripts/ExtraBombs2_items.txt` (ExtraBombsMag): `OnCreate = SpecialLootSpawns.OnCreateRecipeMagazine`.
- Since 42.20 vanilla uses `ItemCodeOnCreate.onCreateGasMask` / `ItemCodeOnCreate.onCreateRecipeMagazine`. Log: `no such function "SpecialLootSpawns.OnCreate..."`
  on each spawn (client and server, 27.10.2026). Fix upstream: change the two OnCreate lines to the ItemCodeOnCreate names.
- Workaround: mkev_modpatcher 1.7 `mkevmp_oncreatealias.lua` (alias, removable once both mods are fixed).


## U13 Vanilla 42.21 (TIS) + Spoiling Liquids (WS 3777483891): OnFillContainer gets a loot definition instead of the bag container
- Where: `zombie.inventory.ItemPickerJava` rollItemInternal / rollProceduralItemInternal (bag branch): `rollContainerItemInternal(..., inventoryContainer, ..., containerDist.bags)`
  is followed by `LuaEventManager.triggerEvent("OnFillContainer", "Container", spawnItem.getType(), containerDist.bags)`. The last argument should be
  `inventoryContainer.getItemContainer()` (as in the else branch two lines below).
- Effect: every mod handler that indexes the container throws "attempted index: X of non-table: ItemPickerJava$ItemPickerContainer" on the server
  (seen 27.-29.10.2026: Spoiling Liquids isFreezer, Computer Mod - New Music Integration AddItem, Low Condition Guns getItems). Those bags miss the mod processing.
- Report to TIS: pass the bag's ItemContainer. Report to Spoiling Liquids: add `if not instanceof(container, "ItemContainer") then return end` at the top of
  `spoilage.onFillContainer` (its handler is local and registered in shared/, so our guard cannot reach it).
- Workaround here: `mkevmp_fillcontainerguard.lua` (covers handlers registered after it: CMNM, Low Condition Guns). Remove once TIS fixes it.

## U14 Vanilla Vehicles Replacer (KI5) (WS 3423424077) on a dedicated server: swap of existing vehicles aborts
- Where: VVR `42/media/lua/server/VVR/Replace.lua`, `replaceSpawned` (called from `onSpawnVehicleStart` when `vehicle:isCreated()`):
  `vehicle:setScriptName(...)` then `vehicle:scriptReloaded(true)`. On the dedicated server `BaseVehicle.scriptReloaded` calls
  `Bullet.removeVehicle(int)`, which has no native there -> `java.lang.UnsatisfiedLinkError` (log: Replace.lua:188).
- Effect: script name changed, skin/params restore never runs, server and clients disagree about the seat layout -> client log floods with
  VehicleUpdatePacket / VehicleFullUpdatePacket BufferUnderflowException in VehiclePassengers.parse (tracker T38, 1239x on 30.10.2026).
- Report to KI5/VVR author: on a dedicated server (`isServer() and not isClient()`) skip `replaceSpawned`, or swap existing vehicles by
  removing and re-spawning them instead of `scriptReloaded(true)`.
- Workaround here: `mkevmp_vvrspawnguard.lua` (dedicated server only). Since 1.1_vvr vanilla vehicles are replaced again: new ones and
  existing ones without physics by VVR itself, existing ones with physics by remove + respawn on the same square (VVR swaps the new one).
  0.1.8-0.1.11 kept existing vehicles unchanged, which left vanilla vehicles in the world.
  Remove once VVR or TIS fixes it.

## U15 Spongie's Clothing (WS 2684285534, mod id SpnCloth): two Tweed jackets with an unknown BodyLocation
- Where: `42.18/media/scripts/SpongieClothing/Jackets.txt`, item `Jacket_Tweed` (`BodyLocation = base:jacket_suit`) and item
  `Jacket_TweedOPEN` (`BodyLocation = base:JACKET_OPEN`). B42.22 resolves the value with `ItemBodyLocation.get(ResourceLocation.of(...))`;
  neither id is registered (vanilla: `base:jacketsuit`; Spongie's Open Jackets [BASE] registers `SpnOpenCloth:JACKET_OPEN`), so the
  item has no body location. Spongie's own validation: all other BodyLocations of the mod are valid.
- Effect: every hover over a "Tweedjacke" throws `NullPointerException ... Clothing.getBodyLocation() is null at Clothing.DoTooltip(Clothing.java:233)`
  (578x on the MKev client, 10.11.2026 04:31-04:33). Wearing the jacket is probably affected too (not tested).
- Report to the Spongie author: `Jacket_Tweed` -> `BodyLocation = base:jacketsuit`, `Jacket_TweedOPEN` -> `BodyLocation = SpnOpenCloth:JACKET_OPEN`
  (as the other OPEN jackets of the mod).
- Workaround here: `mkevmp_spongie_tweedfix.lua` (1.1b) sets these two values with `DoParam` only while the location is missing.
  Remove once Spongie fixes it.
