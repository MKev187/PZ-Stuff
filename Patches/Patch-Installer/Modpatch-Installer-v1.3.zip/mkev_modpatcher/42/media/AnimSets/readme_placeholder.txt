placeholder - this folder is intentionally empty.
the pz animation system (advancedanimator, 42.21) scans media\AnimSets and media\actiongroups
of every mod, in the common folder and in the version folder, and logs a NoSuchFileException
for every missing one. only .xml files are read there, this .txt is ignored. no game data here.
