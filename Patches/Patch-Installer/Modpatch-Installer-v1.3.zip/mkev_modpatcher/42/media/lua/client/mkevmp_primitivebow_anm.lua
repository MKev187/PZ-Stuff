-- MKev-ModPatcher: restores the draw model switch of Archery Nexus [Fixed]'s Primitive Bow (tracker T36, v1.6).
--
-- Problem: Archery Nexus [Fixed] (ArcheryNexusFixed, Workshop 3731579266) and Archery Nexus [RadBows] Upgrade
--   (ArcheryNexus_RB, Workshop 3781962845) both ship media/lua/client/ArcheryNexus_ANM.lua. RB loads later,
--   so the game only runs RB's file. RB's file animates RadArchery's CompoundBowHeavyBlack only. Fixed's
--   handler (Primitive_Bow: model REX5_MD_BOW while an arrow is nocked, Primitive_Bow otherwise) never runs.
--
-- Fix: Fixed's handler again, under a new file name, so both handlers run.
--   - Touches only items of type "Primitive_Bow". RB's handlers touch only "CompoundBowHeavyBlack",
--     so the two never fight over the same item and never reset each other's model.
--   - Compares with the item's current sprite (not a per-player cache), so swapping between two bows,
--     dropping or re-equipping cannot leave a stale model. resetEquippedHandsModels() runs only on a change.
--   - Every local player (split screen too); the original only handled player 0.
--   - Active only when ArcheryNexusFixed AND ArcheryNexus_RB are both enabled (without RB, Fixed's own file
--     already does this) and the model script Base.REX5_MD_BOW exists. Otherwise nothing is registered.
-- Purely visual on the local client, exactly like the original. No items, no world data.

local ITEM_TYPE = "Primitive_Bow"
local SPRITE_DRAWN = "REX5_MD_BOW"   -- model from ArcheryNexusFixed media/scripts/Primitive_Bow_LDR.txt
local SPRITE_IDLE = "Primitive_Bow"  -- WeaponSprite of Base.Primitive_Bow (ArcheryNexus.txt)

local function log(msg, key)
    local M = MKevModPatcher
    if M and M.log then M.log(msg, false, "primitivebow_" .. key) else print("[MKev-ModPatcher] " .. msg) end
end

local function modActive(id)
    local M = MKevModPatcher
    if M and M.isModActive then return M.isModActive(id) end
    local ok, mods = pcall(getActivatedMods)
    if not ok or not mods then return false end
    return mods:contains(id) or mods:contains("\\" .. id)
end

local function modelExists()
    local ok, sm = pcall(getScriptManager)
    if not ok or not sm or not sm.getModelScript then return true end -- cannot check: trust the mod list
    local ok2, ms = pcall(sm.getModelScript, sm, "Base." .. SPRITE_DRAWN)
    if ok2 and ms then return true end
    local ok3, ms2 = pcall(sm.getModelScript, sm, SPRITE_DRAWN)
    return ok3 and ms2 ~= nil
end

local failed = false
local installed = false

local function update(player)
    if failed or not player then return end
    if player.isLocalPlayer and not player:isLocalPlayer() then return end
    local bow = player:getPrimaryHandItem()
    if not bow or bow:getType() ~= ITEM_TYPE then return end
    local ok, err = pcall(function()
        local want = (bow:getCurrentAmmoCount() > 0) and SPRITE_DRAWN or SPRITE_IDLE
        if bow:getWeaponSprite() ~= want then
            bow:setWeaponSprite(want)
            player:resetEquippedHandsModels()
        end
    end)
    if not ok then
        failed = true -- never spam: stop after the first error and say so once
        log("Primitive Bow draw model switch disabled after error: " .. tostring(err), "error")
    end
end

local function install()
    if installed then return end
    if not modActive("ArcheryNexusFixed") or not modActive("ArcheryNexus_RB") then return end
    if not modelExists() then
        log("Primitive Bow draw model switch NOT active: model " .. SPRITE_DRAWN .. " not found", "nomodel")
        return
    end
    installed = true
    Events.OnPlayerUpdate.Add(update)
    log("Primitive Bow draw model switch active (ArcheryNexusFixed + ArcheryNexus_RB)", "active")
end

if Events and Events.OnGameStart then Events.OnGameStart.Add(install) end
