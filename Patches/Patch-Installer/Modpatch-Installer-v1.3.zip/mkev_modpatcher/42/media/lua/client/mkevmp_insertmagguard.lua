-- UPSTREAM-WORKAROUND: vanilla B42 ISInsertMagazine loses its magazine on MP clients (UPSTREAM.md U7, tracker T20).
-- Remove once the game fixes ISInsertMagazine:start().
--
-- Problem (B42 42.21, MP client only):
--   ISInsertMagazine:start() replaces self.magazine with
--   self.character:getInventory():getItemById(self.magazine:getID()). That lookup only covers the main
--   inventory. If the magazine is not (yet) there on this client, for example while the transfer queued
--   by ISInventoryPaneContextMenu.transferIfNeeded() is still being synced from the server, it returns nil.
--   update() (line 35), perform() (line 128) and stop() (line 117) then call self.magazine:setJobDelta()
--   on nil: "attempted index: setJobDelta of non-table: null", once per frame until the action ends.
--   Every one is a Lua error on the client (red error counter). The reload itself is done by the
--   server's own copy of the action, so only the client errors.
--   Seen 25.10.2026 17:42:45 (10 errors in one reload). The Only Cure+ (ExpActions.lua:122) is only in
--   the stack because it wraps update(); it is not the cause.
--
-- Fix: wrap start(). If the re-lookup returns nil, put back the magazine object the action was created
--   with. On the client that object is only used for setJobDelta() (the progress display); the server
--   does the real reload (loadAmmo() only runs when not isClient()). Nothing else changes: when the
--   lookup succeeds, the vanilla result is kept.
--
-- Scope: MP client only. SP and the server never re-resolve the magazine, so they are untouched.

local function mpClient()
    return type(isClient) == "function" and isClient() and not (type(isServer) == "function" and isServer())
end

local function install()
    if not mpClient() then return end
    if type(ISInsertMagazine) ~= "table" or type(ISInsertMagazine.start) ~= "function" then return end
    if ISInsertMagazine.mkevmpInsertMagGuard then return end

    local og_start = ISInsertMagazine.start
    function ISInsertMagazine:start()
        local original = self.magazine
        og_start(self)
        if self.magazine == nil and original ~= nil then
            self.magazine = original
            local M = MKevModPatcher
            if M and M.log then
                M.log("ISInsertMagazine: magazine not in main inventory yet, kept original", true, "insertmag")
            end
        end
    end
    ISInsertMagazine.mkevmpInsertMagGuard = true
end

-- OnGameStart: every client Lua file (vanilla, VFE, The Only Cure+, ...) is loaded and isClient() is reliable.
if Events and Events.OnGameStart then Events.OnGameStart.Add(install) end
