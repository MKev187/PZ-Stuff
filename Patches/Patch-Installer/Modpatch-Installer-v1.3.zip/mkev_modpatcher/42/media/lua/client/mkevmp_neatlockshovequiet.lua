-- UPSTREAM-WORKAROUND: NeatLockpicking (WS 3783535220) floods the client log with
-- 'Trying to set read-only variable "bdoshove"' (UPSTREAM.md U8, tracker T21). Remove once the mod drops the call.
--
-- Problem (B42 42.21, client):
--   NeatLockpick_InputLock.suppressCombat(player) (called from OnPlayerUpdate, every frame while the lockpick
--   UI is open) and NeatCrowbarPanel:suppressShove() (called from OnTick while the crowbar panel is open) both run
--   player:setVariable("bDoShove", "false"). In B42 bDoShove is an engine-bound read-only animation variable, so
--   the call does nothing except log one WARN line. Seen 25.10.2026 18:31:00-18:31:21: 2711 lines in 21 s.
--   The same functions already call player:setDoShove(false), which is the real (working) setter.
--
-- Fix: replace both functions with copies of the original bodies minus the setVariable("bDoShove") line.
--   Behaviour is identical (the removed call never had an effect); only the log spam goes away.
--   Not covered: the anonymous OnTick "hold" branch in NeatCrowbarPanel.lua (~line 922, only while Space is held
--   right after the crowbar panel closes); it cannot be replaced without overriding the whole file.
--
-- Scope: client only, only if NeatLockpicking's globals exist. Applied at OnGameStart, after all client files loaded.

local function install()
    local IL = NeatLockpick_InputLock
    if type(IL) == "table" and type(IL.suppressCombat) == "function" and not IL.mkevmpShoveQuiet then
        function IL.suppressCombat(playerObj)
            if not playerObj then return end
            pcall(function()
                if playerObj.setDoShove then playerObj:setDoShove(false) end
                if playerObj.setForceShove then playerObj:setForceShove(false) end
                if playerObj.setInitiateAttack then playerObj:setInitiateAttack(false) end
                if playerObj.setIsAiming then playerObj:setIsAiming(false) end
                if playerObj.nullifyAiming then playerObj:nullifyAiming() end
                if playerObj.setIgnoreAttacking then playerObj:setIgnoreAttacking(true) end
                if playerObj.setBannedAttacking then playerObj:setBannedAttacking(true) end
            end)
        end
        IL.mkevmpShoveQuiet = true
    end

    local CP = NeatCrowbarPanel
    if type(CP) == "table" and type(CP.suppressShove) == "function" and not CP.mkevmpShoveQuiet then
        function CP:suppressShove()
            local p = self.playerObj
            if not p then return end
            pcall(function()
                if p.setDoShove then p:setDoShove(false) end
                if p.setForceShove then p:setForceShove(false) end
                if p.setInitiateAttack then p:setInitiateAttack(false) end
                if p.nullifyAiming then p:nullifyAiming() end
            end)
        end
        CP.mkevmpShoveQuiet = true
    end
end

if Events and Events.OnGameStart then Events.OnGameStart.Add(install) end
