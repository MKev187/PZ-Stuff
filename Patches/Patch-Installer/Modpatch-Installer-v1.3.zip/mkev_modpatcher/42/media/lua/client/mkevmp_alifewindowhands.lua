-- UPSTREAM-WORKAROUND: A-Life NPC window climb without free hands (UPSTREAM.md U6, tracker T19).
-- Remove once Project A-Life NPCs (WS 3803984183) or the game fixes it.
--
-- Problem (B42 42.20/42.21, client only):
--   IsoGameCharacter.dropHeavyItems() runs on every window climb. On a client it sends a
--   PlayerDropHeldItems packet for ANY local character that has something in its hands.
--   PlayerDropHeldItemsPacket.setData() casts that character to IsoPlayer. A-Life NPCs are
--   IsoZombie "shells" that hold weapons, so the cast fails:
--   ClassCastException IsoZombie -> IsoPlayer. The exception is caught, so nothing breaks in the game,
--   but ExceptionLogger counts it and shows the red "ERROR <n>" box on the bottom right.
--   A-Life already empties the hands (ProjectALife.TraversalHands.prepare) before its OWN climbs
--   and while its own path is active. The engine's own climbs are not covered: IsoZombie.tryThump
--   while walking, and ThumpState once a window breaks or opens.
--
-- Fix: OnZombieUpdate fires in IsoZombie.updateInternal BEFORE the state machine moves the shell and
--   BEFORE tryThump. For an armed A-Life NPC that is close to a climbable window we call A-Life's own
--   TraversalHands.prepare(shell, true): it stores the held items, empties the hands for ~1.2 s and
--   A-Life puts the same items back afterwards. Nothing is removed from the inventory, no packet is sent.
--
-- 1.5.2 (T19 reopened 2026-10-26, 4x in 4 min with 1.5.1):
--   * The 1.2 check only looked at the 4 edges of the shell's CURRENT square, needed "facing" and an
--     exact moving state. But the shell can step onto the next square in the same update (state machine
--     runs after OnZombieUpdate) and tryThump then climbs a window that was one tile away, and thumpable
--     windows are climbed without a facing check. Now: every edge of the 3x3 squares around the shell
--     (radius 1 tile) is checked, no facing test, and moving / thumping / any "climb"/"thump" action
--     state counts.
--   * No isLocal() pre-check any more: A-Life's prepare() has its own authority check (AIFence).
--   * Always-on log: one "guard active" line at game start, plus a rate-limited summary (at most every
--     10 min, only when something changed): prevented / refused / missed / errors.
--     missed = an armed A-Life NPC was seen in a climb action - the case the guard should have caught.
--
-- Scope: MP client only, only if ProjectALifeNPCs is active, only for A-Life actors that hold something.
-- Normal zombies leave on the first check (empty hands). Server and SP are untouched.

local M = MKevModPatcher

local function alifeActive()
    if M and M.isModActive then return M.isModActive("ProjectALifeNPCs") end
    return false
end

local function mpClient()
    return type(isClient) == "function" and isClient() and not (type(isServer) == "function" and isServer())
end

local function log(msg)
    if M and M.log then M.log(msg) else print("[MKev-ModPatcher] " .. tostring(msg)) end
end

local STATE_NAMES = { "PathFindState", "LungeState", "LungeNetworkState", "WalkTowardState", "WalkTowardNetworkState" }
local movingStates = nil
local thumpState = nil
local DIRS = nil
local RESCAN_MS = 250
local SUMMARY_MS = 600000 -- 10 min
local cache = setmetatable({}, { __mode = "k" })
local stats = { prepared = 0, refused = 0, missed = 0, errors = 0 }
M.alifeWindowHandsStats = stats
local lastSummaryMs = 0
local lastSummary = ""
local missSeen = setmetatable({}, { __mode = "k" })

local function resolve()
    if movingStates ~= nil then return end
    local list = {}
    local classes = { PathFindState = PathFindState, LungeState = LungeState, LungeNetworkState = LungeNetworkState,
        WalkTowardState = WalkTowardState, WalkTowardNetworkState = WalkTowardNetworkState }
    for _, name in ipairs(STATE_NAMES) do
        local cls = classes[name]
        if cls ~= nil and cls.instance ~= nil then
            local ok, inst = pcall(cls.instance)
            if ok and inst ~= nil then list[#list + 1] = inst end
        end
    end
    if ThumpState ~= nil and ThumpState.instance ~= nil then
        local ok, inst = pcall(ThumpState.instance)
        if ok then thumpState = inst end
    end
    if IsoDirections ~= nil then
        DIRS = { IsoDirections.N, IsoDirections.E, IsoDirections.S, IsoDirections.W }
    end
    movingStates = list
end

local function isa(obj, name)
    local ok, res = pcall(instanceof, obj, name)
    return ok and res == true
end

local function canClimb(obj, shell)
    if obj == nil or obj.canClimbThrough == nil then return false end
    local ok, res = pcall(obj.canClimbThrough, obj, shell)
    return ok and res == true
end

local function actionState(shell)
    if shell.getActionStateName == nil then return "" end
    local ok, name = pcall(shell.getActionStateName, shell)
    if not ok or name == nil then return "" end
    return string.lower(tostring(name))
end

-- All window / window frame / thumpable window objects on the edges of the 3x3 squares around the shell.
local function windowsNear(shell, square, now)
    local entry = cache[shell]
    if entry ~= nil and entry.square == square and now < entry.untilMs then return entry.list end
    local list, seen = {}, {}
    local cell = getCell and getCell() or nil
    if DIRS ~= nil and cell ~= nil then
        local x, y, z = square:getX(), square:getY(), square:getZ()
        for dx = -1, 1 do
            for dy = -1, 1 do
                local sq = (dx == 0 and dy == 0) and square or cell:getGridSquare(x + dx, y + dy, z)
                if sq ~= nil and sq.getAdjacentSquare ~= nil then
                    for _, dir in ipairs(DIRS) do
                        local other = sq:getAdjacentSquare(dir)
                        if other ~= nil then
                            local w = sq:getWindowTo(other)
                            if w == nil then w = sq:getWindowFrameTo(other) end
                            if w == nil then w = sq:getWindowThumpableTo(other) end
                            if w ~= nil and not seen[w] then
                                seen[w] = true
                                list[#list + 1] = w
                            end
                        end
                    end
                end
            end
        end
    end
    cache[shell] = { square = square, untilMs = now + RESCAN_MS, list = list }
    return list
end

local function inMovingState(shell)
    for i = 1, #movingStates do
        if shell:isCurrentState(movingStates[i]) then return true end
    end
    return false
end

local function thumpingWindow(shell)
    if thumpState == nil or not shell:isCurrentState(thumpState) then return false end
    local target = shell:getThumpTarget()
    if target == nil then return false end
    if isa(target, "IsoWindow") or isa(target, "IsoWindowFrame") then return true end
    if isa(target, "IsoThumpable") then
        local ok, res = pcall(target.isWindow, target)
        return ok and res == true
    end
    return false
end

-- true = the engine may start a window climb for this shell within the next update
local function needsFreeHands(shell, state)
    if thumpingWindow(shell) then return true end
    local busy = inMovingState(shell) or (thumpState ~= nil and shell:isCurrentState(thumpState))
        or string.find(state, "climb", 1, true) ~= nil
        or string.find(state, "thump", 1, true) ~= nil
    if not busy then return false end
    local square = shell:getCurrentSquare()
    if square == nil then return false end
    local list = windowsNear(shell, square, getTimestampMs())
    for i = 1, #list do
        if canClimb(list[i], shell) then return true end
    end
    return false
end

local function summary(now)
    if now - lastSummaryMs < SUMMARY_MS then return end
    lastSummaryMs = now
    local s = string.format("A-Life window guard: prevented=%d refused=%d missed=%d errors=%d",
        stats.prepared, stats.refused, stats.missed, stats.errors)
    if s ~= lastSummary then
        lastSummary = s
        log(s)
    end
end

local function onZombieUpdate(shell)
    -- cheap exits first: normal zombies have empty hands
    if shell:getPrimaryHandItem() == nil and shell:getSecondaryHandItem() == nil then return end
    local data = shell:getModData()
    if data == nil or data.ProjectALifeActor ~= true then return end
    if shell:isDead() then return end
    local hands = ProjectALife and ProjectALife.TraversalHands
    if hands == nil or type(hands.prepare) ~= "function" then return end
    resolve()
    local state = actionState(shell)
    if string.find(state, "climb", 1, true) ~= nil then
        -- already climbing with something in the hands: the guard came too late for this one
        if not missSeen[shell] then
            missSeen[shell] = true
            stats.missed = stats.missed + 1
        end
    else
        missSeen[shell] = nil
    end
    local ok, need = pcall(needsFreeHands, shell, state)
    if not ok then
        stats.errors = stats.errors + 1
        if stats.errors == 1 then log("A-Life window guard: check failed: " .. tostring(need)) end
        need = false
    end
    if need then
        local done, res = pcall(hands.prepare, shell, true)
        if done and res == true then
            stats.prepared = stats.prepared + 1
        else
            stats.refused = stats.refused + 1
        end
    end
    summary(getTimestampMs())
end

local installed = false
local function install()
    if installed or not mpClient() or not alifeActive() then return end
    if Events == nil or Events.OnZombieUpdate == nil then return end
    Events.OnZombieUpdate.Add(onZombieUpdate)
    installed = true
    lastSummaryMs = getTimestampMs()
    log("A-Life window guard active (client, v" .. tostring(MKEV_MODPATCHER_VERSION) .. ", radius 1 tile)")
end

if Events and Events.OnGameStart then Events.OnGameStart.Add(install) end
