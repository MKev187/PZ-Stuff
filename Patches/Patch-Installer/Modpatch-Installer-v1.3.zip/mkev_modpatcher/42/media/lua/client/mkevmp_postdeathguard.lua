-- MKev-ModPatcher 0.1.10: post-death guard (client only).
-- Problem (30.10.2026, 23:47 CET): after death the vanilla death screen (ISPostDeathUI) showed, but neither
-- "New character" nor "Quit" reacted, no Lua error was logged, the client had to be closed with Alt+F4.
-- Vanilla ignores every button click while MainScreen.instance:isReallyVisible() is true, and an invisible
-- always-on-top panel of another mod over the bottom-centre buttons would swallow the click as well.
-- This file:
--   1. keeps the death screen on top (setAlwaysOnTop + bringToTop, once per second while it is shown),
--   2. logs with prefix [MKev-PDG]: MainScreen state and all visible always-on-top UI elements (type names),
--      and for every left click while the death screen is open the topmost UI element under the mouse,
--   3. wraps onRespawn / onExit / onQuitToDesktop: logs each click; if MainScreen is flagged visible although the
--      click reached the death screen (= the flag is wrong), hides MainScreen and continues with the vanilla handler,
--   4. fallback: 10 s after death without a successful click a small always-on-top window with
--      "Neuer Charakter" / "Spiel beenden" appears; it calls the vanilla handlers.
-- Everything runs in pcall. If ISPostDeathUI does not exist nothing is changed. Own code, no other mod file is touched.
-- 0.1.11: MP client only. Single player (and the main menu) are left completely vanilla, because since 0.1.11 the
--         mod can be in the player's local default mod list and would otherwise also run in single player games.
if type(isServer) == "function" and isServer() then return end

MKevPostDeathGuard = MKevPostDeathGuard or {}
local G = MKevPostDeathGuard
if G.loaded then return end
G.loaded = true

local FALLBACK_MS = 10000
local TOP_MS = 1000
local SNAPSHOT_MS = 4000
local MAX_CLICK_LOGS = 25
local MAX_LIST = 25

G.active = false     -- a local death screen is open
G.deathMs = 0
G.success = false    -- one of the vanilla handlers was reached
G.clickLogs = 0
G.lastTopMs = 0
G.snapshotDone = false
G.mouseWasDown = false
G.fallback = nil

local function log(msg)
    print("[MKev-PDG] " .. tostring(msg))
end
G.log = log

-- MP client only (0.1.11): no-op in single player, on a coop host's own process check isClient() as well.
function G.mpClient()
    if type(isClient) ~= "function" or not isClient() then return false end
    if type(isServer) == "function" and isServer() then return false end
    return true
end

local function nowMs()
    if type(getTimestampMs) == "function" then
        local ok, v = pcall(getTimestampMs)
        if ok and type(v) == "number" then return v end
    end
    return os.time() * 1000
end

local function try(obj, method, ...)
    if obj == nil then return nil end
    local args = { ... }
    local ok, v = pcall(function() return obj[method](obj, unpack(args)) end)
    if ok then return v end
    return nil
end

local function mainScreenVisible()
    local ms = MainScreen and MainScreen.instance
    if not ms then return false end
    return try(ms, "isReallyVisible") == true
end
G.mainScreenVisible = mainScreenVisible

-- Lua type name of a Java UIElement (Type field of the ISUIElement table), else the Java class name.
local function typeName(el)
    local t = try(el, "getTable")
    if type(t) == "table" then
        if type(t.Type) == "string" then return t.Type end
        if type(t.name) == "string" then return "?" .. t.name end
    end
    local ok, s = pcall(function() return tostring(el) end)
    if ok and s then return (string.gsub(s, "@.*$", "")) end
    return "?"
end
G.typeName = typeName

local function rectOf(el)
    local x = try(el, "getAbsoluteX") or try(el, "getX") or 0
    local y = try(el, "getAbsoluteY") or try(el, "getY") or 0
    local w = try(el, "getWidth") or 0
    local h = try(el, "getHeight") or 0
    return x, y, w, h
end

local function uiList()
    if not UIManager or type(UIManager.getUI) ~= "function" then return nil end
    local ok, list = pcall(UIManager.getUI)
    if ok then return list end
    return nil
end

local function onTopFlag(el)
    local v = try(el, "isAlwaysOnTop")
    if v == nil then
        local t = try(el, "getTable")
        if type(t) == "table" then v = t.alwaysOnTop end
    end
    return v == true
end

-- List of visible always-on-top elements (type, rect), at most MAX_LIST.
function G.snapshot(reason)
    local list = uiList()
    local n = list and (try(list, "size") or 0) or 0
    local parts, count = {}, 0
    for i = 0, n - 1 do
        local okE, el = pcall(function() return list:get(i) end)
        if okE and el and try(el, "isVisible") == true and onTopFlag(el) then
            count = count + 1
            if #parts < MAX_LIST then
                local x, y, w, h = rectOf(el)
                parts[#parts + 1] = typeName(el) .. "(" .. math.floor(x) .. "," .. math.floor(y) .. ","
                    .. math.floor(w) .. "x" .. math.floor(h) .. ")"
            end
        end
    end
    log("snapshot " .. tostring(reason) .. ": MainScreen.isReallyVisible=" .. tostring(mainScreenVisible())
        .. " ui_elemente=" .. n .. " immer_oben_sichtbar=" .. count .. " -> " .. table.concat(parts, " "))
end

-- Topmost visible element under the mouse (UIManager list: later = drawn on top; alwaysOnTop wins).
function G.elementAt(mx, my)
    local list = uiList()
    local n = list and (try(list, "size") or 0) or 0
    local best, bestTop = nil, false
    for i = 0, n - 1 do
        local okE, el = pcall(function() return list:get(i) end)
        if okE and el and try(el, "isVisible") == true then
            local x, y, w, h = rectOf(el)
            if mx >= x and my >= y and mx < x + w and my < y + h then
                local top = onTopFlag(el)
                if best == nil or top or not bestTop then best, bestTop = el, top end
            end
        end
    end
    return best
end

local function deathPanel()
    local inst = ISPostDeathUI and ISPostDeathUI.instance
    if type(inst) ~= "table" then return nil end
    for _, p in pairs(inst) do
        if type(p) == "table" and try(p, "isReallyVisible") == true then return p end
    end
    return nil
end
G.deathPanel = deathPanel

local function keepOnTop(panel)
    if not panel then return end
    pcall(function() panel:setAlwaysOnTop(true) end)
    pcall(function() panel:bringToTop() end)
    if panel.quitToDesktopDialog then
        pcall(function() panel.quitToDesktopDialog:setAlwaysOnTop(true) end)
        pcall(function() panel.quitToDesktopDialog:bringToTop() end)
    end
end

---------------------------------------------------------------------------------------------------------------
-- Fallback window
---------------------------------------------------------------------------------------------------------------
local function closeFallback()
    if G.fallback then
        pcall(function() G.fallback:setVisible(false) end)
        pcall(function() G.fallback:removeFromUIManager() end)
        G.fallback = nil
    end
end
G.closeFallback = closeFallback

function G.fallbackAction(what)
    log("fallback-fenster: " .. what .. " geklickt")
    local panel = deathPanel() or G.lastPanel
    closeFallback()
    if not panel then
        log("fallback: kein Todesbildschirm mehr gefunden")
        return
    end
    if what == "respawn" and type(panel.onRespawn) == "function" then
        pcall(panel.onRespawn, panel)
    elseif what == "quit" and type(panel.onQuitToDesktop) == "function" then
        pcall(panel.onQuitToDesktop, panel)
        keepOnTop(panel)
    end
end

local function openFallback()
    if G.fallback or not ISPanel or not ISButton then return end
    local ok, err = pcall(function()
        local w, h = 320, 112
        local sw = getCore():getScreenWidth()
        local sh = getCore():getScreenHeight()
        local p = ISPanel:new((sw - w) / 2, math.floor(sh * 0.30), w, h)
        p:initialise()
        p.backgroundColor = { r = 0, g = 0, b = 0, a = 0.85 }
        p.borderColor = { r = 1, g = 1, b = 1, a = 0.4 }
        p.moveWithMouse = true
        local title = ISLabel:new(10, 8, 20, "MKev-Patcher: Knoepfe reagieren nicht?", 1, 1, 1, 1, UIFont.Small, true)
        title:initialise()
        p:addChild(title)
        local b1 = ISButton:new(10, 40, 145, 28, "Neuer Charakter", p, function() G.fallbackAction("respawn") end)
        b1:initialise()
        p:addChild(b1)
        local b2 = ISButton:new(165, 40, 145, 28, "Spiel beenden", p, function() G.fallbackAction("quit") end)
        b2:initialise()
        p:addChild(b2)
        local hint = ISLabel:new(10, 80, 20, "(ruft die normalen Knoepfe auf)", 0.8, 0.8, 0.8, 1, UIFont.Small, true)
        hint:initialise()
        p:addChild(hint)
        p:addToUIManager()
        p:setAlwaysOnTop(true)
        p:bringToTop()
        G.fallback = p
    end)
    if ok then
        log("fallback-fenster geoeffnet (" .. math.floor(FALLBACK_MS / 1000) .. " s ohne erfolgreichen Klick)")
    else
        log("fallback-fenster Fehler: " .. tostring(err))
    end
end
G.openFallback = openFallback

---------------------------------------------------------------------------------------------------------------
-- Wrappers around the vanilla handlers
---------------------------------------------------------------------------------------------------------------
local function wrapHandler(name, label)
    local orig = ISPostDeathUI[name]
    if type(orig) ~= "function" then return false end
    ISPostDeathUI[name] = function(self, ...)
        local vis = false
        pcall(function()
            vis = mainScreenVisible()
            log("klick " .. label .. " erreicht: MainScreen.isReallyVisible=" .. tostring(vis))
            if vis then
                -- The click reached the death screen, so MainScreen is not really in front: the flag is wrong.
                MainScreen.instance:setVisible(false)
                log("MainScreen war faelschlich als sichtbar markiert -> ausgeblendet, weiter mit Vanilla")
            end
            G.success = true
            closeFallback()
        end)
        return orig(self, ...)
    end
    return true
end

function G.install()
    if G.installed then return true end
    if not G.mpClient() then return false end
    if type(ISPostDeathUI) ~= "table" then return false end
    G.installed = true
    local origPre = ISPostDeathUI.prerender
    if type(origPre) == "function" then
        ISPostDeathUI.prerender = function(self, ...)
            local r = origPre(self, ...)
            pcall(function()
                G.lastPanel = self
                local t = nowMs()
                if t - G.lastTopMs >= TOP_MS then
                    G.lastTopMs = t
                    keepOnTop(self)
                end
            end)
            return r
        end
    end
    local a = wrapHandler("onRespawn", "Neuer Charakter")
    local b = wrapHandler("onExit", "Hauptmenue")
    local c = wrapHandler("onQuitToDesktop", "Spiel beenden")
    log("aktiv (prerender=" .. tostring(type(origPre) == "function") .. " respawn=" .. tostring(a)
        .. " exit=" .. tostring(b) .. " quit=" .. tostring(c) .. ")")
    return true
end

---------------------------------------------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------------------------------------------
function G.onPlayerDeath(playerObj)
    pcall(function()
        if playerObj == nil then return end
        if not G.mpClient() then return end
        if type(playerObj.isLocalPlayer) == "function" and not playerObj:isLocalPlayer() then return end
        G.install()
        G.active = true
        G.deathMs = nowMs()
        G.success = false
        G.clickLogs = 0
        G.snapshotDone = false
        G.lastTopMs = 0
        log("tod erkannt: spieler=" .. tostring(try(playerObj, "getUsername") or "?")
            .. " MainScreen.isReallyVisible=" .. tostring(mainScreenVisible()))
    end)
end

function G.onTick()
    if not G.active then return end
    local ok, err = pcall(function()
        local t = nowMs()
        local panel = deathPanel()
        if panel then keepOnTop(panel) end
        if not G.snapshotDone and t - G.deathMs >= SNAPSHOT_MS then
            G.snapshotDone = true
            G.snapshot(panel and "todesbildschirm_offen" or "todesbildschirm_NICHT_sichtbar")
        end
        -- Left click edge: which element is under the mouse?
        local down = type(isMouseButtonDown) == "function" and isMouseButtonDown(0) == true
        if down and not G.mouseWasDown and G.clickLogs < MAX_CLICK_LOGS then
            G.clickLogs = G.clickLogs + 1
            local mx = type(getMouseX) == "function" and getMouseX() or -1
            local my = type(getMouseY) == "function" and getMouseY() or -1
            local el = G.elementAt(mx, my)
            log("mausklick bei " .. mx .. "," .. my .. " oberstes_element=" .. (el and typeName(el) or "-")
                .. " MainScreen.isReallyVisible=" .. tostring(mainScreenVisible()))
        end
        G.mouseWasDown = down
        if not G.success and not G.fallback and panel and t - G.deathMs >= FALLBACK_MS then
            openFallback()
        end
        if G.fallback then pcall(function() G.fallback:bringToTop() end) end
        -- Respawned or left: stop watching.
        local p = type(getPlayer) == "function" and getPlayer() or nil
        if p and try(p, "isDead") == false and t - G.deathMs > 2000 then
            G.active = false
            closeFallback()
            log("neuer Charakter aktiv, Waechter aus")
        end
    end)
    if not ok then
        G.active = false
        closeFallback()
        log("Fehler im Waechter, deaktiviert: " .. tostring(err))
    end
end

if Events then
    if Events.OnGameStart then Events.OnGameStart.Add(function() pcall(G.install) end) end
    if Events.OnPlayerDeath then Events.OnPlayerDeath.Add(G.onPlayerDeath) end
    if Events.OnTick then Events.OnTick.Add(G.onTick) end
end
