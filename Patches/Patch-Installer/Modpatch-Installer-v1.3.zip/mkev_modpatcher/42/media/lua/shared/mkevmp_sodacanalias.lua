-- UPSTREAM-WORKAROUND: FunctionalAppliances2 / Authentic Z use the pre-42.20 soda OnCreate (UPSTREAM.md U5).
-- B42.20 renamed the vanilla soda-can OnCreate to ItemCodeOnCreate.onCreateSodaCan.
-- FunctionalAppliances2 (FA_items_food.txt:626) and Authentic Z (items_AuthenticZ_Edited.txt) still reference
-- SpecialLootSpawns.OnCreateSodaCan -> "no such function" errors. Alias the old name.
-- v1.1: applied only if one of those mods is active. Neither is in the current Mods= list (25.10.2026),
-- so this file is dormant but kept for when they come back.
local TARGETS = { "FunctionalAppliances2", "Authentic Z - Current", "AuthenticZLite", "AuthenticZBackpacks+" }
local function needed()
    local M = MKevModPatcher
    if not (M and M.isModActive) then return true end -- helper missing: behave like 2.5.0
    for _, id in ipairs(TARGETS) do
        if M.isModActive(id) then return true end
    end
    return false
end
local function applySodaAlias(final)
    if not needed() then return end
    SpecialLootSpawns = SpecialLootSpawns or {}
    if SpecialLootSpawns.OnCreateSodaCan ~= nil then return end
    if ItemCodeOnCreate and ItemCodeOnCreate.onCreateSodaCan then
        SpecialLootSpawns.OnCreateSodaCan = ItemCodeOnCreate.onCreateSodaCan
    elseif final then
        local m = "soda alias: ItemCodeOnCreate.onCreateSodaCan not found - vanilla renamed it again?"
            .. " Alias NOT applied."
        local M = MKevModPatcher
        if M and M.log then M.log(m, false, "sodawarn") else print("[MKev-ModPatcher] " .. m) end
    end
end
applySodaAlias(false)
-- In case ItemCodeOnCreate loads after this file, retry once the game boots.
if Events and Events.OnGameBoot then Events.OnGameBoot.Add(function() applySodaAlias(true) end) end
