-- UPSTREAM-WORKAROUND (UPSTREAM.md U13): vanilla 42.21 passes a loot-table object to OnFillContainer (tracker T40).
-- ItemPickerJava.rollItemInternal / rollProceduralItemInternal: when a spawned bag is filled from its container's
-- "bags" distribution, the game fires OnFillContainer("Container", bagType, containerDist.bags). The third argument
-- is then an ItemPickerJava$ItemPickerContainer (a loot definition), not the bag's ItemContainer. Lua cannot index
-- that class at all, so every mod handler that touches the container fails on the server:
--   Computer Mod - New Music Integration (WS 3798792768) CMNM_Loot.lua:48  container.AddItem
--   Low Condition Guns (WS 3579180724) LowConditionGuns.lua:103            container:getItems()
--   Spoiling Liquids (WS 3777483891) SpoilingLiquids.lua:360              container:isFreezer()  (NOT covered, see below)
-- Fix: wrap Events.OnFillContainer.Add/Remove so handlers registered after this file are skipped for that one bad
-- call. Real ItemContainer calls pass through unchanged. The bag itself is already filled by the game; only the
-- broken event call is dropped. Handlers registered before this file loads (Spoiling Liquids, shared/, earlier in
-- the load order, local function) cannot be reached from here and stay upstream.
local M = MKevModPatcher or {}

local function install()
    if not (Events and Events.OnFillContainer) then return end
    local ev = Events.OnFillContainer
    if ev._mkevmpGuard then return end
    local origAdd, origRemove = ev.Add, ev.Remove
    if type(origAdd) ~= "function" then return end
    local wrapped = {}
    local skipped = 0
    ev.Add = function(fn, ...)
        if type(fn) ~= "function" then return origAdd(fn, ...) end
        local w = wrapped[fn]
        if not w then
            w = function(roomName, containerType, container, ...)
                if container ~= nil and not instanceof(container, "ItemContainer") then
                    skipped = skipped + 1
                    if skipped == 1 and M.log then
                        M.log("OnFillContainer guard: skipped a non-ItemContainer call (vanilla bag-loot bug, T40).",
                            false, "fillguard_first")
                    end
                    return
                end
                return fn(roomName, containerType, container, ...)
            end
            wrapped[fn] = w
        end
        return origAdd(w, ...)
    end
    if type(origRemove) == "function" then
        ev.Remove = function(fn, ...)
            local w = wrapped[fn]
            if w then
                wrapped[fn] = nil
                return origRemove(w, ...)
            end
            return origRemove(fn, ...)
        end
    end
    ev._mkevmpGuard = true
    if M.log then M.log("OnFillContainer guard active.", true, "fillguard_on") end
end

install()
