-- UPSTREAM-WORKAROUND (UPSTREAM.md U15): Spongie's Clothing (WS 2684285534, mod id SpnCloth), the two "Tweedjacke"
-- items have a BodyLocation that is not registered in B42.22:
--   Spongie.Jacket_Tweed     BodyLocation = base:jacket_suit (vanilla id: base:jacketsuit, JACKET_SUIT)
--   Spongie.Jacket_TweedOPEN BodyLocation = base:JACKET_OPEN  (registered id is SpnOpenCloth:JACKET_OPEN from
--                                                             Spongie's Open Jackets [BASE], mod id SpnOpenClothBase)
-- Item.DoParam resolves the value with ItemBodyLocation.get(ResourceLocation.of(value)); an unknown id gives null.
-- Every hover over such a jacket then throws a NullPointerException in Clothing.DoTooltip (getBodyLocation() is null).
-- InventoryItem.getBodyLocation() reads scriptItem.getBodyLocation(), so fixing the script item also fixes every
-- jacket that already exists in the world or in an inventory.
-- Fix: set the correct BodyLocation on the script item with DoParam (as other mods in the pack do, e.g. B42PackMule).
-- Only if SpnCloth is active, only while the location is still missing (idempotent, no change once Spongie fixes it),
-- Jacket_TweedOPEN only if SpnOpenClothBase is active. Runs on OnGameBoot, OnInitGlobalModData, OnGameStart and
-- OnServerStarted (server and client, after the item scripts are loaded); later calls do nothing. All calls in pcall.
-- One log line per fixed item. Own code (MKev-ModPatcher). No Spongie file is copied or modified.
local M = MKevModPatcher or {}

local function say(msg, onceKey)
    if M.log then M.log(msg, false, onceKey) else print("[MKev-ModPatcher] " .. tostring(msg)) end
end

local function active(id)
    if M.isModActive then return M.isModActive(id) == true end
    if type(getActivatedMods) ~= "function" then return false end
    local ok, r = pcall(function()
        local mods = getActivatedMods()
        return mods:contains(id) or mods:contains("\\" .. id)
    end)
    return ok and r == true
end

local FIXES = {
    { item = "Spongie.Jacket_Tweed", loc = "base:jacketsuit" },
    { item = "Spongie.Jacket_TweedOPEN", loc = "SpnOpenCloth:JACKET_OPEN", needs = "SpnOpenClothBase" },
}

local state = { fixed = 0, done = {} }
MKevModPatcherTweedFix = state -- read-only status for debugging

local function getScript(full)
    if not (ScriptManager and ScriptManager.instance) then return nil end
    local ok, s = pcall(function() return ScriptManager.instance:getItem(full) end)
    if ok then return s end
    return nil
end

local function bodyLoc(s)
    local ok, loc = pcall(function() return s:getBodyLocation() end)
    if ok then return loc end
    return nil
end

local function run()
    if not active("SpnCloth") then return end
    for _, f in ipairs(FIXES) do
        if not state.done[f.item] and (f.needs == nil or active(f.needs)) then
            local s = getScript(f.item)
            if s ~= nil then
                if bodyLoc(s) ~= nil then
                    state.done[f.item] = true -- already valid (e.g. fixed upstream): leave it alone
                else
                    local ok, err = pcall(function() s:DoParam("BodyLocation = " .. f.loc) end)
                    if ok and bodyLoc(s) ~= nil then
                        state.done[f.item] = true
                        state.fixed = state.fixed + 1
                        say("Spongie tweed fix: " .. f.item .. " BodyLocation -> " .. f.loc .. ".", "tweed_" .. f.item)
                    else
                        say("Spongie tweed fix: " .. f.item .. " could not be fixed (" .. f.loc .. " "
                            .. (ok and "not registered" or tostring(err)) .. ").", "tweedfail_" .. f.item)
                    end
                end
            end
        end
    end
end

local function safeRun() pcall(run) end

if Events then
    for _, name in ipairs({ "OnGameBoot", "OnInitGlobalModData", "OnGameStart", "OnServerStarted" }) do
        if Events[name] then Events[name].Add(safeRun) end
    end
end
