-- UPSTREAM-WORKAROUND (UPSTREAM.md U14): Vanilla Vehicles Replacer (KI5) on a dedicated server (tracker T37/T38).
-- 1.1_vvr (Hotfix VVR): the guard no longer keeps vanilla vehicles. Every vanilla vehicle VVR can replace is replaced.
-- Background: VVR swaps a vanilla vehicle in its OnSpawnVehicleStart handler (setScriptName + scriptReloaded(true)).
-- For a vehicle that already has physics (getController() ~= nil; seen on the dedicated server for vehicles loaded
-- with their chunk) scriptReloaded calls Bullet.removeVehicle, a native the dedicated server does not have
-- (UnsatisfiedLinkError in VVR replaceSpawned). The swap then stops half way (T37) and clients get vehicle sync
-- errors (T38). 0.1.8 - 0.1.11 therefore skipped VVR for every existing vehicle, which left vanilla vehicles in the
-- world. Now, ONLY on a dedicated server (isServer() and not isClient()) and ONLY for VVR's server/VVR/Replace.lua
-- handler:
--   * New vehicle (isCreated() == false): VVR runs unchanged (replaceNew). If it has no square yet (VVR would
--     return early), it is also queued and checked again once it is in the world.
--   * Existing vehicle without physics (getController() == nil): VVR runs unchanged (replaceSpawned keeps
--     condition, rust, blood, parts). scriptReloaded does not touch Bullet in this case.
--   * Existing VANILLA vehicle with physics that VVR has a replacement for: VVR is not called (T37 path). The
--     vehicle is queued and a few ticks later removed (vehicle:permanentlyRemove(), the server skips Bullet there)
--     and spawned again with the same vanilla script on the same square (addVehicleDebug, as the vanilla admin
--     spawn does). The new vehicle is brand new, so VVR's own replaceNew swaps it to the KI5 vehicle.
--     Not respawned: vehicles with someone inside, towing or towed. Items stored in a respawned vanilla vehicle
--     are lost (the new one gets fresh vanilla loot). Each square + script is respawned at most once per run.
--   * Non-vanilla vehicles: VVR runs unchanged (it returns on its own).
-- One log line per replaced / failed / kept vanilla vehicle (script, target, x,y); max 20 lines per 60 s, the rest
-- is counted. Clients, coop host and single player are not touched. All new calls are in pcall; on an error the
-- vehicle is kept and one line is logged. Own code (MKev-ModPatcher). No VVR file is copied or modified.
local M = MKevModPatcher or {}

local function say(msg, onceKey)
    if M.log then M.log(msg, false, onceKey) else print("[MKev-ModPatcher] " .. tostring(msg)) end
end

local function isDedicated()
    return type(isServer) == "function" and type(isClient) == "function" and isServer() and not isClient()
end

-- True if fn was defined in VVR's server Replace.lua (path compared case-insensitive, / and \ both accepted).
local function isVvrHandler(fn)
    if type(getFilenameOfClosure) ~= "function" then return false end
    local ok, file = pcall(getFilenameOfClosure, fn)
    if not ok or type(file) ~= "string" then return false end
    file = string.lower(string.gsub(file, "\\", "/"))
    return string.find(file, "/lua/server/vvr/replace.lua", 1, true) ~= nil
end

local state = { hooked = 0, direct = 0, queued = 0, replaced = 0, failed = 0, kept = 0, suppressed = 0 }
MKevModPatcherVvrGuard = state -- read-only status for debugging

-- Rate-limited per-vehicle log: max 20 lines per 60 s window, the rest is counted and reported with the next line.
local RATE_MAX, RATE_WINDOW_MS = 20, 60000
local rate = { start = nil, n = 0 }
local function nowMs()
    if type(getTimestampMs) == "function" then
        local ok, t = pcall(getTimestampMs)
        if ok and type(t) == "number" then return t end
    end
    return nil
end
local function vlog(msg)
    local t = nowMs()
    if t == nil then
        -- no clock: hard cap per server run
        if rate.n >= 200 then state.suppressed = state.suppressed + 1; return end
    elseif rate.start == nil or t - rate.start >= RATE_WINDOW_MS then
        if state.suppressed > 0 then
            say("VVR guard: " .. state.suppressed .. " more vehicle lines suppressed (rate limit).")
            state.suppressed = 0
        end
        rate.start, rate.n = t, 0
    end
    if rate.n >= RATE_MAX then state.suppressed = state.suppressed + 1; return end
    rate.n = rate.n + 1
    say("VVR guard: " .. msg)
end

local function call(obj, method, ...)
    local ok, r = pcall(obj[method], obj, ...)
    if ok then return r end
    return nil
end

local function scriptOf(v)
    local ok, s = pcall(function() return v:getScriptName() end)
    if ok and type(s) == "string" then return s end
    return "?"
end

local function posOf(v)
    local ok, x, y = pcall(function() return math.floor(v:getX()), math.floor(v:getY()) end)
    if ok then return tostring(x) .. "," .. tostring(y) end
    return "?,?"
end

local function isVanilla(v)
    local ok, VU = pcall(require, "YAPZLib/VehicleUtils")
    if not ok or type(VU) ~= "table" or type(VU.isVanilla) ~= "function" then return false end
    local ok2, r = pcall(VU.isVanilla, v)
    return ok2 and r == true
end

-- True if VVR has a replacement table for this script (same name handling as VVR: Smashed / Burnt variants).
local function hasMapping(script)
    local ok, Data = pcall(require, "VVR/Data")
    if not ok or type(Data) ~= "table" or type(Data.Tab) ~= "table" then return false end
    if Data.Tab[script] then return true end
    if string.find(script, "Smashed", 1, true) or string.find(script, "Burnt", 1, true) then
        local sv = SandboxVars and SandboxVars.VVR
        if string.find(script, "Burnt", 1, true) and not (sv and sv.NoBurnt) then return false end
        return true -- VVR parses these names itself (parseSmashed / parseBurnt)
    end
    return false
end

local function isBusy(v)
    if call(v, "hasPassenger") == true then return true end
    if call(v, "getDriver") ~= nil then return true end
    if call(v, "getVehicleTowing") ~= nil then return true end
    if call(v, "getVehicleTowedBy") ~= nil then return true end
    return false
end

-- Respawn queue (dedicated server only). Processed from OnTick, at most 2 vehicles per tick, earliest 2 ticks after
-- queueing.
local queue, inQueue, tried = {}, {}, {}
local tick = 0

local function enqueue(v, why)
    if inQueue[v] then return end
    inQueue[v] = true
    queue[#queue + 1] = { v = v, why = why, at = tick + 2, tries = 0 }
    state.queued = state.queued + 1
end

local function respawn(item)
    local v = item.v
    local okS, sq = pcall(function() return v:getSquare() end)
    if not okS then return "drop" end
    if sq == nil then
        item.tries = item.tries + 1
        if item.tries > 30 then
            state.kept = state.kept + 1
            vlog("kept " .. scriptOf(v) .. " at " .. posOf(v) .. " (no square after 30 ticks, " .. item.why .. ")")
            return "drop"
        end
        item.at = tick + 1
        return "retry"
    end
    if not isVanilla(v) then return "drop" end -- already replaced (VVR) or removed
    local script = scriptOf(v)
    local pos = posOf(v)
    if isBusy(v) then
        state.kept = state.kept + 1
        vlog("kept " .. script .. " at " .. pos .. " (occupied or towing, retried on next chunk load)")
        return "drop"
    end
    local okP, x, y, z = pcall(function() return sq:getX(), sq:getY(), sq:getZ() end)
    if not okP then return "drop" end
    local key = tostring(x) .. "," .. tostring(y) .. "," .. tostring(z) .. ":" .. script
    if tried[key] then return "drop" end
    tried[key] = true
    local dir = call(v, "getDir")
    if type(addVehicleDebug) ~= "function" then
        state.failed = state.failed + 1
        vlog("FAILED " .. script .. " at " .. pos .. " (addVehicleDebug missing, vehicle kept)")
        return "drop"
    end
    local okR, errR = pcall(function() v:permanentlyRemove() end)
    if not okR then
        state.failed = state.failed + 1
        vlog("FAILED " .. script .. " at " .. pos .. " (remove: " .. tostring(errR) .. ")")
        return "drop"
    end
    local okA, nv = pcall(addVehicleDebug, script, dir, nil, sq)
    if not okA or nv == nil then
        state.failed = state.failed + 1
        vlog("FAILED " .. script .. " at " .. pos .. " (respawn: " .. tostring(okA and "nil" or nv) .. ")")
        return "drop"
    end
    local target = scriptOf(nv)
    if isVanilla(nv) then
        state.failed = state.failed + 1
        vlog("FAILED " .. script .. " at " .. pos .. " (respawned, VVR kept " .. target .. ")")
    else
        state.replaced = state.replaced + 1
        vlog("replaced " .. script .. " -> " .. target .. " at " .. pos .. " (" .. item.why .. ", respawn)")
    end
    return "drop"
end

local function onTick()
    tick = tick + 1
    if #queue == 0 then return end
    local done, i = 0, 1
    while i <= #queue and done < 2 do
        local item = queue[i]
        if item.at <= tick then
            local ok, r = pcall(respawn, item)
            if ok and r == "retry" then
                i = i + 1
            else
                if not ok then
                    state.failed = state.failed + 1
                    vlog("FAILED " .. scriptOf(item.v) .. " at " .. posOf(item.v) .. " (" .. tostring(r) .. ")")
                end
                inQueue[item.v] = nil
                table.remove(queue, i)
            end
            done = done + 1
        else
            i = i + 1
        end
    end
end

local function guarded(fn)
    return function(vehicle, ...)
        if vehicle == nil then return fn(vehicle, ...) end
        local okC, created = pcall(function() return vehicle:isCreated() end)
        if not okC then return fn(vehicle, ...) end
        if not created then
            -- new vehicle: VVR replaceNew. Without a square VVR returns early -> check again once it is in the world.
            local okS, sq = pcall(function() return vehicle:getSquare() end)
            if okS and sq == nil and isVanilla(vehicle) and hasMapping(scriptOf(vehicle)) then
                enqueue(vehicle, "new without square")
            end
            return fn(vehicle, ...)
        end
        if not isVanilla(vehicle) then return fn(vehicle, ...) end -- VVR returns on its own
        local okP, ctrl = pcall(function() return vehicle:getController() end)
        if okP and ctrl == nil then
            -- existing vehicle without physics: scriptReloaded does not call Bullet -> VVR replaceSpawned directly.
            local before, pos = scriptOf(vehicle), posOf(vehicle)
            local okF, err = pcall(fn, vehicle, ...)
            local after = scriptOf(vehicle)
            if not okF then
                state.failed = state.failed + 1
                vlog("FAILED " .. before .. " at " .. pos .. " (VVR: " .. tostring(err) .. ")")
            elseif after ~= before then
                state.direct = state.direct + 1
                vlog("replaced " .. before .. " -> " .. after .. " at " .. pos .. " (existing, VVR)")
            end
            return
        end
        -- existing vanilla vehicle with physics: VVR would end in Bullet.removeVehicle (T37) -> respawn instead.
        if hasMapping(scriptOf(vehicle)) then
            enqueue(vehicle, "existing")
        end
    end
end

local function install()
    if not isDedicated() then return end
    if not (Events and Events.OnSpawnVehicleStart) then
        say("VVR spawn guard: event OnSpawnVehicleStart missing, guard not active.", "vvrguard_noevent")
        return
    end
    local ev = Events.OnSpawnVehicleStart
    if ev._mkevmpVvrGuard then return end
    local origAdd, origRemove = ev.Add, ev.Remove
    if type(origAdd) ~= "function" then
        say("VVR spawn guard: OnSpawnVehicleStart.Add not found, guard not active.", "vvrguard_noadd")
        return
    end
    local wrapped = {}
    ev.Add = function(fn, ...)
        if type(fn) ~= "function" or not isVvrHandler(fn) then return origAdd(fn, ...) end
        local w = wrapped[fn]
        if not w then
            w = guarded(fn)
            wrapped[fn] = w
            state.hooked = state.hooked + 1
        end
        return origAdd(w, ...)
    end
    if type(origRemove) == "function" then
        ev.Remove = function(fn, ...)
            local w = wrapped[fn]
            if w then
                wrapped[fn] = nil
                return origRemove(w, ...)
            end
            return origRemove(fn, ...)
        end
    end
    ev._mkevmpVvrGuard = true
    if Events.OnTick then Events.OnTick.Add(onTick) end
end

-- After all Lua is loaded: report once if VVR is active but its handler was not caught.
local function report()
    if not isDedicated() then return end
    local active = M.isModActive and M.isModActive("VVR")
    if not active then return end
    if state.hooked > 0 then
        say("VVR spawn guard active (dedicated server, 1.1_vvr: vanilla vehicles are replaced).", "vvrguard_on")
    else
        say("VVR spawn guard: VVR is active but its spawn handler was not found - guard not active, nothing changed.",
            "vvrguard_miss")
    end
end

install()
if Events and Events.OnServerStarted then Events.OnServerStarted.Add(report) end
