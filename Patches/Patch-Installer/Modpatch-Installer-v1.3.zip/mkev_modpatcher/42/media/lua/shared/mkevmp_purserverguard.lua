-- UPSTREAM-WORKAROUND: PUR server-load guard (UPSTREAM.md U1). Remove once PUR fixes it.
-- Plysken Underground Revolution (mod id PUR, WS 3776279483) ships
-- 42.1/media/lua/server/BuildingObjects/PUR_DigCursor.lua, which at line 134 defines
-- `function PUR.armDigCursor(player)`. The PUR table is only created by its client/ files,
-- which a dedicated server never loads -> "attempted index of non-table" on every server start.
-- Only on a dedicated server and only if PUR is active, provide an empty PUR table so that file loads.
-- Clients and SP are untouched (PUR's client files create PUR themselves with `PUR = PUR or {}`).
-- Verified 25.10.2026: no Plysken sister mod (PFR, PIP, PSC, PSR, PWS) tests for the PUR global.
local function purActive()
    local M = MKevModPatcher
    if M and M.isModActive then return M.isModActive("PUR") end
    return true -- helper missing: behave like the 2.6.0 draft
end
if isServer() and not isClient() and purActive() then
    PUR = PUR or {}
end
