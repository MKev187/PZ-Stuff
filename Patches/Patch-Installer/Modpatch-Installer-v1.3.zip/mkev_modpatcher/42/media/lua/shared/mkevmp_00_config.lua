-- MKev-ModPatcher (mod id mkev_modpatcher): shared settings and helpers.
-- Successor of MKevPackPatches 2.5.0. Never run both mods at the same time.
-- verbose = true -> also log "everything OK" lines. Default false = quiet: only the version line
-- and real problems or fallbacks are logged. Edit this one line to switch.
MKevModPatcher = MKevModPatcher or {}
local M = MKevModPatcher
if M.verbose == nil then M.verbose = false end
M._once = M._once or {}

-- log(msg, onlyVerbose, onceKey): onceKey prevents duplicates when both OnGameBoot and OnServerStarted fire.
function M.log(msg, onlyVerbose, onceKey)
    if onlyVerbose and not M.verbose then return end
    if onceKey then
        if M._once[onceKey] then return end
        M._once[onceKey] = true
    end
    print("[MKev-ModPatcher] " .. tostring(msg))
end

-- isModActive("ModID"): true if the mod is in the active list. B42 may store ids with a leading backslash.
function M.isModActive(id)
    if type(getActivatedMods) ~= "function" then return false end
    local ok, mods = pcall(getActivatedMods)
    if not ok or not mods then return false end
    return mods:contains(id) or mods:contains("\\" .. id)
end

-- Clash check: the old patch mod must not be active together with this one.
local function clashCheck()
    if M.isModActive("MKevPackPatches") then
        M.log("WARNING: MKevPackPatches is active too. Remove it from Mods= - MKev-ModPatcher replaces it.",
            false, "clash")
    end
end
if Events and Events.OnGameBoot then Events.OnGameBoot.Add(clashCheck) end
if Events and Events.OnServerStarted then Events.OnServerStarted.Add(clashCheck) end
