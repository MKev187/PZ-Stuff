-- MKev-ModPatcher 0.1.10: zombie spawn monitor (tracker T47, debug tool for the test phase).
-- 0.1.10: time stamps in German local time (CET/CEST, Europe/Berlin) instead of UTC; A-Life NPC bodies
--         (ProjectALifeNPCs shells) and Starving Zombies skeleton templates are no longer counted as zombies
--         (not in SPAWN / LADEN / ZAEHLUNG / LUA_AUFRUF), only as one AUSGEFILTERT summary line per minute.
-- Goal: for every zombie that appears, write down where it came from:
--   lua:<Mod>[<WorkshopID>] file:line  - a mod called a Lua spawn function (wrapped below)
--   vanilla_raum                        - B42 room spawn when a player sees a room for the first time (OnSeeNewRoom)
--   vanilla_raum_spaet                  - same room, zombies added later when its chunk streams in
--   reanimation                         - reanimated player
--   laden                               - everything else: virtual zombie became real (chunk/cell load, population
--                                         manager, story spawns of the map). Summed per area and minute.
-- Plus a zombie count around every player every 10 s (radius 30 / 80), written only when it changes.
-- Output (folder Zomboid\Lua): mkev_zedmonitor_server.log (dedicated server),
-- mkev_zedmonitor_client.log (MP client).
-- Size limits: max 120 new lines per minute, identical lines merged ("x N" once per 60 s), hard cap 2 MB per file, then
-- the file is moved to *.1.log (only one old file is kept). The game only allows file names ending in .log/.txt.
-- Switch: Sandbox option MKevMP.ZedMonitor (default on).
-- 0.1.11: only dedicated server (incl. a coop host's server process) and MP client. Single player and the main menu
--         stay untouched (no wrappers, no log file), because the mod can now be in the player's local mod list.
-- When off only one boolean check per wrapped spawn call is left.
-- Every wrapper calls the original function with the original arguments and returns its original results.
-- Own code (MKev-ModPatcher). No other mod file is copied or modified.
local M = MKevModPatcher or {}

MKevZedMonitor = MKevZedMonitor or {}
local Z = MKevZedMonitor
if Z.loaded then return end
Z.loaded = true

local CAP_BYTES = 2 * 1024 * 1024
local MAX_LINES_PER_MIN = 120
local CENSUS_MS = 10000
local FLUSH_MS = 1000
local RESOLVE_MS = 250
local ROOM_WINDOW_MS = 250
local ROOM_LATE_MS = 120000
local QUEUE_MAX = 3000
local CELL = 256

Z.on = false         -- set from the sandbox at start; wrappers stay idle until then
Z.depth = 0          -- > 0 while a wrapped spawn function runs
Z.ctx = nil          -- source text of the running wrapped call
Z.queue = {}
Z.created = {}
Z.known = {}
Z.players = {}
Z.rooms = {}
Z.lastRoomMs = -1
Z.lastRoomName = nil

local function say(msg)
    local m = "zedmonitor: " .. tostring(msg)
    if M.log then M.log(m, false, nil) else print("[MKev-ModPatcher] " .. m) end
end

local function nowMs()
    if type(getTimestampMs) == "function" then
        local ok, v = pcall(getTimestampMs)
        if ok and type(v) == "number" then return v end
    end
    return os.time() * 1000
end

-- Days since 1970-01-01 for a civil date (proleptic Gregorian).
local function daysFromCivil(y, m, d)
    if m <= 2 then y = y - 1 end
    local era = math.floor(y / 400)
    local yoe = y - era * 400
    local mp = (m + 9) % 12
    local doy = math.floor((153 * mp + 2) / 5) + d - 1
    local doe = yoe * 365 + math.floor(yoe / 4) - math.floor(yoe / 100) + doy
    return era * 146097 + doe - 719468
end

local function civilFromDays(z)
    z = z + 719468
    local era = math.floor(z / 146097)
    local doe = z - era * 146097
    local yoe = math.floor((doe - math.floor(doe / 1460) + math.floor(doe / 36524) - math.floor(doe / 146096)) / 365)
    local y = yoe + era * 400
    local doy = doe - (365 * yoe + math.floor(yoe / 4) - math.floor(yoe / 100))
    local mp = math.floor((5 * doy + 2) / 153)
    local d = doy - math.floor((153 * mp + 2) / 5) + 1
    local m = mp < 10 and mp + 3 or mp - 9
    if m <= 2 then y = y + 1 end
    return y, m, d
end

-- EU rule: summer time (UTC+2) from the last Sunday of March 01:00 UTC to the last Sunday of October 01:00 UTC.
local function lastSundayUtc(y, m)
    local d31 = daysFromCivil(y, m, 31)
    local wd = (d31 + 4) % 7 -- 0 = Sunday (1970-01-01 was a Thursday)
    return (d31 - wd) * 86400 + 3600
end

-- "YYYY-MM-DD HH:MM:SS" in Europe/Berlin for epoch seconds; second value = "CET" or "CEST".
local function berlinTime(sec)
    sec = math.floor(sec)
    local y = civilFromDays(math.floor(sec / 86400))
    local off, zone = 3600, "CET"
    if sec >= lastSundayUtc(y, 3) and sec < lastSundayUtc(y, 10) then off, zone = 7200, "CEST" end
    local l = sec + off
    local days = math.floor(l / 86400)
    local rest = l - days * 86400
    local yy, mm, dd = civilFromDays(days)
    local hh = math.floor(rest / 3600)
    local mi = math.floor((rest - hh * 3600) / 60)
    local ss = rest - hh * 3600 - mi * 60
    return string.format("%04d-%02d-%02d %02d:%02d:%02d", yy, mm, dd, hh, mi, ss), zone
end
Z.berlinTime = berlinTime

local function stamp()
    local okB, b = pcall(berlinTime, nowMs() / 1000)
    if okB and type(b) == "string" then return b end
    local ok, s = pcall(os.date, "%Y-%m-%d %H:%M:%S")
    if ok and type(s) == "string" then return s .. "Z" end
    return tostring(nowMs())
end

-- obj:method() with pcall; nil on any problem.
local function try(obj, method)
    if obj == nil then return nil end
    local ok, v = pcall(function() return obj[method](obj) end)
    if ok then return v end
    return nil
end

local function num(v)
    if type(v) ~= "number" then return 0 end
    return math.floor(v + 0.5)
end

---------------------------------------------------------------------------------------------------------------
-- Not real zombies: A-Life NPC bodies (IsoZombie shells of ProjectALifeNPCs) and Starving Zombies skeleton
-- templates (addZombiesInOutfit + setSkeleton(true), turned into a corpse right away). Same markers as
-- ProjectALife Calm.isNpc: modData ProjectALifeOwned / ProjectALifeActor or animation variable ALifeUID.
---------------------------------------------------------------------------------------------------------------
Z.filtered = { npc_shell = 0, skelett = 0 }

local function srcKind(src)
    if type(src) ~= "string" then return nil end
    local l = string.lower(src)
    if string.find(l, "projectalife", 1, true) or string.find(l, "alifeshell", 1, true) then return "npc_shell" end
    if string.find(l, "starving", 1, true) then return "skelett" end
    return nil
end
Z.srcKind = srcKind

-- "npc_shell", "skelett" or nil. Never raises.
local function ignoreKind(zed, src)
    if zed == nil then return srcKind(src) end
    local ok, kind = pcall(function()
        if zed:isSkeleton() == true then return "skelett" end
        return nil
    end)
    if ok and kind then return kind end
    ok, kind = pcall(function()
        if zed:hasModData() then
            local md = zed:getModData()
            if md and (md.ProjectALifeOwned == true or md.ProjectALifeActor == true) then return "npc_shell" end
        end
        local uid = zed:getVariableString("ALifeUID")
        if uid ~= nil and uid ~= "" then return "npc_shell" end
        return nil
    end)
    if ok and kind then return kind end
    return srcKind(src)
end
Z.ignoreKind = ignoreKind

local function countFiltered(kind)
    Z.filtered[kind] = (Z.filtered[kind] or 0) + 1
end

---------------------------------------------------------------------------------------------------------------
-- Log file: buffered, deduplicated, rate limited, capped, one rotation file.
---------------------------------------------------------------------------------------------------------------
local Log = { name = nil, old = nil, bytes = 0, pending = {}, seen = {}, seenOrder = {}, lines = 0, dropped = 0 }
Z.Log = Log

local function countBytes(name)
    if type(getFileReader) ~= "function" then return 0 end
    local ok, r = pcall(getFileReader, name, false)
    if not ok or not r then return 0 end
    local n = 0
    local ok2 = pcall(function()
        local line = r:readLine()
        while line ~= nil and n < CAP_BYTES do
            n = n + #line + 2
            line = r:readLine()
        end
    end)
    pcall(function() r:close() end)
    if not ok2 then return 0 end
    return n
end

local function rotate()
    local okR, r = pcall(getFileReader, Log.name, false)
    local okW, w = pcall(getFileWriter, Log.old, true, false)
    if okR and r and okW and w then
        pcall(function()
            local line = r:readLine()
            while line ~= nil do
                w:writeln(line)
                line = r:readLine()
            end
        end)
    end
    if okR and r then pcall(function() r:close() end) end
    if okW and w then pcall(function() w:close() end) end
    local okN, n = pcall(getFileWriter, Log.name, true, false)
    if okN and n then
        local head = stamp() .. " ROTATION alte Datei -> " .. tostring(Log.old)
        pcall(function() n:writeln(head) n:close() end)
        Log.bytes = #head + 2
    else
        Log.bytes = 0
    end
end

function Log.open(name)
    Log.name = name .. ".log"
    Log.old = name .. ".1.log"
    Log.bytes = countBytes(Log.name)
    if Log.bytes >= CAP_BYTES then rotate() end
end

-- Queue a line. key = dedupe key (nil = never merged). Repeats within the 60 s window are only counted.
function Log.add(key, text)
    if not Log.name then return end
    if key then
        local s = Log.seen[key]
        if s then
            s.n = s.n + 1
            return
        end
        Log.seen[key] = { n = 0, text = text }
        Log.seenOrder[#Log.seenOrder + 1] = key
    end
    if Log.lines >= MAX_LINES_PER_MIN then
        Log.dropped = Log.dropped + 1
        return
    end
    Log.lines = Log.lines + 1
    Log.pending[#Log.pending + 1] = stamp() .. " " .. text
end

-- Once per minute: write the "x N" lines for merged repeats, the drop counter, reset the window.
function Log.minute()
    for i = 1, #Log.seenOrder do
        local s = Log.seen[Log.seenOrder[i]]
        if s and s.n > 0 then
            Log.pending[#Log.pending + 1] = stamp() .. " WIEDERHOLT x" .. s.n .. " in 60 s: " .. s.text
        end
    end
    if Log.dropped > 0 then
        Log.pending[#Log.pending + 1] = stamp() .. " LIMIT " .. Log.dropped
            .. " Zeilen in dieser Minute nicht geschrieben (max "
            .. MAX_LINES_PER_MIN .. ")"
    end
    Log.seen, Log.seenOrder, Log.lines, Log.dropped = {}, {}, 0, 0
end

function Log.flush()
    if not Log.name or #Log.pending == 0 then return end
    local lines = Log.pending
    Log.pending = {}
    local ok, w = pcall(getFileWriter, Log.name, true, true)
    if not ok or not w then return end
    pcall(function()
        for i = 1, #lines do
            w:writeln(lines[i])
            Log.bytes = Log.bytes + #lines[i] + 2
        end
    end)
    pcall(function() w:close() end)
    if Log.bytes >= CAP_BYTES then rotate() end
end

---------------------------------------------------------------------------------------------------------------
-- Source of a Lua call: walk the Kahlua call frames, first frame outside this file = the caller.
---------------------------------------------------------------------------------------------------------------
local function describePath(path, line)
    local p = string.gsub(tostring(path), "\\", "/")
    local file = string.match(p, "([^/]+)$") or p
    local ws, mod = string.match(p, "/108600/(%d+)/mods/([^/]+)/")
    local where
    if ws then
        where = mod .. "[" .. ws .. "]"
    else
        mod = string.match(p, "/mods/([^/]+)/")
        where = mod and (mod .. "[lokal]") or "vanilla"
    end
    if line and line > 0 then file = file .. ":" .. line end
    return where .. " " .. file
end

local function callerSource()
    local ok, res = pcall(function()
        local co = getCurrentCoroutine()
        local top = getCallframeTop(co)
        local chain = {}
        for i = top - 1, 0, -1 do
            local cf = getCoroutineCallframeStack(co, i)
            local fname = cf and getFilenameOfCallframe(cf)
            if fname and not string.find(string.lower(fname), "mkevmp_zedmonitor", 1, true) then
                local ln = type(getLineNumber) == "function" and getLineNumber(cf) or 0
                chain[#chain + 1] = describePath(fname, ln)
                if #chain >= 2 then break end
            end
        end
        return chain
    end)
    if ok and type(res) == "table" and #res > 0 then
        local s = "lua:" .. res[1]
        if res[2] then s = s .. " <- " .. res[2] end
        return s
    end
    return "lua:unbekannt"
end
Z.describePath = describePath

---------------------------------------------------------------------------------------------------------------
-- Players
---------------------------------------------------------------------------------------------------------------
local function playerList()
    local out = {}
    if type(getOnlinePlayers) == "function" then
        local ok, list = pcall(getOnlinePlayers)
        if ok and list then
            local n = try(list, "size") or 0
            for i = 0, n - 1 do
                local okP, p = pcall(function() return list:get(i) end)
                if okP and p then out[#out + 1] = p end
            end
        end
    end
    if #out == 0 and type(getPlayer) == "function" then
        local ok, p = pcall(getPlayer)
        if ok and p then out[1] = p end
    end
    return out
end

local function playerName(p)
    return tostring(try(p, "getUsername") or try(p, "getDisplayName") or "?")
end

local function nearest(players, x, y)
    local best, bestD = nil, nil
    for i = 1, #players do
        local px, py = try(players[i], "getX"), try(players[i], "getY")
        if px and py then
            local d = (px - x) * (px - x) + (py - y) * (py - y)
            if not bestD or d < bestD then best, bestD = players[i], d end
        end
    end
    if not best then return "-", -1 end
    return playerName(best), num(math.sqrt(bestD))
end

local function roomInfo(sq)
    local room = try(sq, "getRoom")
    if not room then return nil, nil end
    local def = try(room, "getRoomDef")
    return tostring(try(room, "getName") or try(def, "getName") or "?"), def and try(def, "getID") or nil
end

---------------------------------------------------------------------------------------------------------------
-- Wrappers around the global Lua spawn functions (server side only, 0.1.11).
---------------------------------------------------------------------------------------------------------------
local SPAWNERS = {
    "addZombiesInOutfit", "addZombiesInOutfitArea", "addZombieSitting", "addZombiesEating",
    "createHordeFromTo", "createHordeInAreaTo", "spawnHorde", "createZombie", "addVirtualZombie",
}
Z.orig = Z.orig or {}

local function argText(...)
    local n = select("#", ...)
    local parts = {}
    for i = 1, math.min(n, 6) do
        local v = select(i, ...)
        local t = type(v)
        if t == "number" then parts[#parts + 1] = tostring(num(v))
        elseif t == "string" then parts[#parts + 1] = v
        elseif t == "boolean" then parts[#parts + 1] = tostring(v)
        else parts[#parts + 1] = t end
    end
    return table.concat(parts, ",")
end

local function finish(ok, ...)
    Z.depth = Z.depth - 1
    if Z.depth <= 0 then Z.depth = 0 Z.ctx = nil end
    if not ok then error((...), 0) end
    return ...
end

local function makeWrapper(name, orig)
    return function(...)
        if not Z.on then return orig(...) end
        local ok = pcall(function(...)
            local src = callerSource()
            if Z.depth == 0 then Z.ctx = src end
            if srcKind(src) then return end -- A-Life NPC body / Starving skeleton: no LUA_AUFRUF line
            local x, y = select(1, ...), select(2, ...)
            local who, dist = "-", -1
            if type(x) == "number" and type(y) == "number" then who, dist = nearest(playerList(), x, y) end
            Log.add(nil, "LUA_AUFRUF " .. name .. "(" .. argText(...) .. ") quelle=" .. src .. " spieler=" .. who
                .. " dist=" .. dist)
        end, ...)
        if not ok then Z.ctx = Z.ctx or "lua:unbekannt" end
        Z.depth = Z.depth + 1
        return finish(pcall(orig, ...))
    end
end

function Z.installWrappers()
    local G = _G
    if type(G) ~= "table" then return 0 end
    local n = 0
    for i = 1, #SPAWNERS do
        local name = SPAWNERS[i]
        local cur = G[name]
        if cur ~= nil and not Z.orig[name] then
            Z.orig[name] = cur
            G[name] = makeWrapper(name, cur)
            n = n + 1
        end
    end
    return n
end

---------------------------------------------------------------------------------------------------------------
-- Server events
---------------------------------------------------------------------------------------------------------------
local function onZombieCreate(zombie)
    if not Z.on or zombie == nil then return end
    if #Z.queue >= QUEUE_MAX then
        Z.queueDropped = (Z.queueDropped or 0) + 1
        return
    end
    local t = nowMs()
    local src
    if Z.depth > 0 then
        src = Z.ctx or "lua:unbekannt"
    elseif Z.lastRoomMs >= 0 and t - Z.lastRoomMs <= ROOM_WINDOW_MS then
        src = "vanilla_raum"
    else
        src = "laden"
    end
    if try(zombie, "isReanimatedPlayer") == true then src = "reanimation" end
    Z.queue[#Z.queue + 1] = { z = zombie, src = src, t = t }
    Z.created[zombie] = true
end

local function onSeeNewRoom(room)
    if not Z.on or room == nil then return end
    pcall(function()
        Z.lastRoomMs = nowMs()
        local def = try(room, "getRoomDef")
        local id = def and try(def, "getID")
        Z.lastRoomName = tostring(try(room, "getName") or try(def, "getName") or "?")
        if id then Z.rooms[id] = Z.lastRoomMs end
        if Z.side == "client" then
            Z.clientRooms = Z.clientRooms or {}
            if #Z.clientRooms < 50 then
                Z.clientRooms[#Z.clientRooms + 1] = { id = id, name = Z.lastRoomName, t = Z.lastRoomMs,
                    x = num(try(def, "getX")), y = num(try(def, "getY")), zz = num(try(def, "getZ")) }
            end
        end
    end)
end

-- Turn queued zombies into grouped lines once they have a position.
local loadAgg = {}
local function resolveQueue(t)
    if #Z.queue == 0 then return end
    local keep, groups, order = {}, {}, {}
    for i = 1, #Z.queue do
        local e = Z.queue[i]
        if t - e.t < RESOLVE_MS then
            keep[#keep + 1] = e
        else
            local x, y, zz = try(e.z, "getX"), try(e.z, "getY"), try(e.z, "getZ")
            local kind = ignoreKind(e.z, e.src)
            if kind then
                countFiltered(kind)
            elseif x and y then
                local rname, rid = roomInfo(try(e.z, "getCurrentSquare"))
                local src = e.src
                if src == "laden" and rid and Z.rooms[rid] and t - Z.rooms[rid] <= ROOM_LATE_MS then
                    src = "vanilla_raum_spaet"
                end
                if src == "laden" then
                    local key = math.floor(x / 100) .. "," .. math.floor(y / 100)
                    local a = loadAgg[key]
                    if not a then a = { n = 0, x = num(x), y = num(y), inRoom = 0 } loadAgg[key] = a end
                    a.n = a.n + 1
                    if rname then a.inRoom = a.inRoom + 1 end
                else
                    local key = src .. "|" .. tostring(rname) .. "|" .. math.floor(x / 10) .. "," .. math.floor(y / 10)
                    local g = groups[key]
                    if not g then
                        g = { src = src, n = 0, x = num(x), y = num(y), z = num(zz), room = rname, outfits = {} }
                        groups[key] = g
                        order[#order + 1] = key
                    end
                    g.n = g.n + 1
                    if #g.outfits < 3 then g.outfits[#g.outfits + 1] = tostring(try(e.z, "getOutfitName") or "?") end
                end
            elseif t - e.t < 5000 then
                keep[#keep + 1] = e
            end
        end
    end
    Z.queue = keep
    if #order > 0 then
        local players = playerList()
        for i = 1, #order do
            local g = groups[order[i]]
            local who, dist = nearest(players, g.x, g.y)
            Log.add(nil, "SPAWN quelle=" .. g.src .. " anzahl=" .. g.n .. " bei=" .. g.x .. "," .. g.y .. "," .. g.z
                .. " raum=" .. tostring(g.room or "-") .. " spieler=" .. who .. " dist=" .. dist
                .. " outfits=" .. table.concat(g.outfits, "/"))
        end
    end
end

local function flushLoadAgg()
    local players = playerList()
    local n = 0
    local rest, restN = 0, 0
    for key, a in pairs(loadAgg) do
        n = n + 1
        if n <= 10 then
            local who, dist = nearest(players, a.x, a.y)
            Log.add("laden|" .. key .. "|" .. a.n,
                "LADEN (virtuell->echt / Zelle geladen) anzahl=" .. a.n .. " davon_in_raeumen=" .. a.inRoom
                .. " gebiet=" .. key .. " (100er-Raster) bei=" .. a.x .. "," .. a.y
                .. " spieler=" .. who .. " dist=" .. dist)
        else
            rest = rest + 1
            restN = restN + a.n
        end
    end
    if rest > 0 then Log.add(nil, "LADEN weitere " .. rest .. " Gebiete mit zusammen " .. restN .. " Zombies") end
    loadAgg = {}
    local f = Z.filtered
    if (f.npc_shell or 0) > 0 or (f.skelett or 0) > 0 then
        Log.add(nil, "AUSGEFILTERT (keine echten Zombies, nicht mitgezaehlt) npc_shell=" .. (f.npc_shell or 0)
            .. " skelett=" .. (f.skelett or 0))
        Z.filtered = { npc_shell = 0, skelett = 0 }
    end
    if (Z.queueDropped or 0) > 0 then
        Log.add(nil, "WARTESCHLANGE voll, " .. Z.queueDropped .. " Zombies nicht zugeordnet")
        Z.queueDropped = 0
    end
end

-- Census: zombies within 30 / 80 tiles of each player; write only on change.
local function zombieList()
    local cell = type(getCell) == "function" and getCell() or nil
    return cell and try(cell, "getZombieList") or nil
end

local function census()
    local list = zombieList()
    local players = Z.side == "client" and { getPlayer() } or playerList()
    if not list or #players == 0 then return end
    local n = try(list, "size") or 0
    local pos = {}
    for i = 1, #players do
        local p = players[i]
        pos[i] = { x = try(p, "getX") or 0, y = try(p, "getY") or 0, r30 = 0, r80 = 0, fresh = 0 }
    end
    local newKnown = {}
    for j = 0, n - 1 do
        local zed = list:get(j)
        local zx, zy = zed:getX(), zed:getY()
        if ignoreKind(zed, nil) then zx = nil end
        for i = 1, zx and #pos or 0 do
            local q = pos[i]
            local dx, dy = zx - q.x, zy - q.y
            local d2 = dx * dx + dy * dy
            if d2 <= 6400 then
                q.r80 = q.r80 + 1
                newKnown[zed] = true
                if d2 <= 900 then
                    q.r30 = q.r30 + 1
                    if not Z.known[zed] and not Z.created[zed] then q.fresh = q.fresh + 1 end
                end
            end
        end
    end
    local first = Z.firstCensusDone ~= true
    Z.known, Z.created, Z.firstCensusDone = newKnown, {}, true
    for i = 1, #players do
        local name = playerName(players[i])
        local q = pos[i]
        local cx, cy = math.floor(q.x / CELL), math.floor(q.y / CELL)
        local last = Z.players[name]
        local reasons = {}
        if not last then reasons[#reasons + 1] = "START" end
        if last and (last.cx ~= cx or last.cy ~= cy) then reasons[#reasons + 1] = "ZELLWECHSEL" end
        local d30 = last and (q.r30 - last.r30) or 0
        local d80 = last and (q.r80 - last.r80) or 0
        if last and (math.abs(d30) >= 3 or math.abs(d80) >= 5) then reasons[#reasons + 1] = "AENDERUNG" end
        if d80 >= 10 then reasons[#reasons + 1] = "SPRUNG" end
        if q.fresh > 0 and not first and last then
            reasons[#reasons + 1] = (Z.side == "client" and "NEU_IN_30=" or "NEU_OHNE_EVENT=") .. q.fresh
        end
        if #reasons > 0 then
            Log.add(nil, "ZAEHLUNG " .. table.concat(reasons, ",") .. " spieler=" .. name .. " pos=" .. num(q.x) .. ","
                .. num(q.y) .. " zelle=" .. cx .. "," .. cy .. " r30=" .. q.r30 .. " (" .. d30 .. ") r80=" .. q.r80
                .. " (" .. d80 .. ")")
        end
        Z.players[name] = { cx = cx, cy = cy, r30 = q.r30, r80 = q.r80 }
    end
end

-- Client only: after a new room was seen, count the zombies inside it 3 s later.
local function clientRooms(t)
    if not Z.clientRooms or #Z.clientRooms == 0 then return end
    local keep = {}
    local list = nil
    for i = 1, #Z.clientRooms do
        local r = Z.clientRooms[i]
        if t - r.t < 3000 then
            keep[#keep + 1] = r
        else
            list = list or zombieList()
            local cnt = 0
            local n = list and (try(list, "size") or 0) or 0
            for j = 0, n - 1 do
                local zed = list:get(j)
                local _, rid = roomInfo(try(zed, "getCurrentSquare"))
                if rid and rid == r.id then cnt = cnt + 1 end
            end
            if cnt > 0 then
                Log.add(nil, "RAUM_GESEHEN raum=" .. tostring(r.name) .. " bei=" .. r.x .. "," .. r.y .. "," .. r.zz
                    .. " zombies_drin_nach_3s=" .. cnt)
            else
                Z.emptyRooms = (Z.emptyRooms or 0) + 1
            end
        end
    end
    Z.clientRooms = keep
end

local nextFlush, nextCensus, nextMinute = 0, 0, 0
local function onTick()
    if not Z.on then return end
    local t = nowMs()
    if t < nextFlush then return end
    nextFlush = t + FLUSH_MS
    pcall(resolveQueue, t)
    if Z.side == "client" then pcall(clientRooms, t) end
    if t >= nextCensus then
        nextCensus = t + CENSUS_MS
        pcall(census)
    end
    if t >= nextMinute then
        if nextMinute > 0 then
            pcall(flushLoadAgg)
            if (Z.emptyRooms or 0) > 0 then
                Log.add(nil, "RAEUME ohne Zombies gesehen: " .. Z.emptyRooms)
                Z.emptyRooms = 0
            end
            Log.minute()
        end
        nextMinute = t + 60000
    end
    Log.flush()
end
Z.onTick = onTick
Z.onZombieCreate = onZombieCreate
Z.onSeeNewRoom = onSeeNewRoom

---------------------------------------------------------------------------------------------------------------
-- Start
---------------------------------------------------------------------------------------------------------------
local function sandboxOn()
    local sv = SandboxVars
    if type(sv) == "table" and type(sv.MKevMP) == "table" and sv.MKevMP.ZedMonitor ~= nil then
        return sv.MKevMP.ZedMonitor == true
    end
    return true
end

local function isSrv() return type(isServer) == "function" and isServer() end
local function isCli() return type(isClient) == "function" and isClient() end

-- Wrappers are installed at load time on the server so mods that look the function up when they
-- call it are caught. They stay idle (one boolean check) until the sandbox value is known.
-- 0.1.11: server only (was: server and single player). In the main menu and single player nothing is wrapped.
if isSrv() and not isCli() then pcall(Z.installWrappers) end

local function start(side)
    if Z.side then return end
    Z.side = side
    Z.on = sandboxOn()
    if not Z.on then
        say("off (Sandbox MKevMP.ZedMonitor = false)")
        return
    end
    Log.open(side == "client" and "mkev_zedmonitor_client" or "mkev_zedmonitor_server")
    local wrapped = {}
    for k in pairs(Z.orig) do wrapped[#wrapped + 1] = k end
    table.sort(wrapped)
    local _, zone = pcall(function() local _, zn = berlinTime(nowMs() / 1000) return zn end)
    Log.add(nil, "START seite=" .. side .. " version=" .. tostring(MKEV_MODPATCHER_VERSION)
        .. " zeit=" .. tostring(zone or "?") .. "(Europe/Berlin)"
        .. " groesse_alt=" .. Log.bytes
        .. " gewrappt=" .. (#wrapped > 0 and table.concat(wrapped, ",") or "-"))
    if Events then
        if Events.OnTick then Events.OnTick.Add(onTick) end
        if Events.OnSeeNewRoom then Events.OnSeeNewRoom.Add(onSeeNewRoom) end
        if side ~= "client" and Events.OnZombieCreate then Events.OnZombieCreate.Add(onZombieCreate) end
        if side ~= "client" and not Events.OnZombieCreate then
            Log.add(nil, "HINWEIS OnZombieCreate fehlt, nur Zaehlung aktiv")
        end
    end
    say("on, log Zomboid/Lua/" .. tostring(Log.name))
end
Z.start = start

if Events then
    if Events.OnServerStarted then Events.OnServerStarted.Add(function() if isSrv() then start("server") end end) end
    if Events.OnGameStart then
        Events.OnGameStart.Add(function()
            if isCli() and not isSrv() then start("client") end -- 0.1.11: single player no longer starts
        end)
    end
end
