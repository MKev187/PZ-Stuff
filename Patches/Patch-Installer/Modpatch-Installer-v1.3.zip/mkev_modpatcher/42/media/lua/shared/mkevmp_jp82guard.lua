-- UPSTREAM-WORKAROUND: safety net for the JP82SpareTires restore (UPSTREAM.md U4).
-- Remove together with media/scripts/vehicles/mkevmp_template_jp82_sparetires_restore.txt.
-- The restored template references JP82.Create/Init/InstallComplete/UninstallComplete.SpareTire,
-- normally generated at runtime by damnlib for '82 Jeep J10 (mod id 82jeepJ10, WS 2886832257).
-- This guard ONLY fills missing entries with vanilla Vehicles.*.Default and never overwrites existing ones.
-- v1.1: runs only if 82jeepJ10 is active (otherwise nothing uses JP82 and no fallback line is logged).
local function log(m, v, k)
    local M = MKevModPatcher
    if M and M.log then M.log(m, v, k) elseif not v then print("[MKev-ModPatcher] " .. m) end
end
local function jeepActive()
    local M = MKevModPatcher
    if M and M.isModActive then return M.isModActive("82jeepJ10") end
    return true -- helper missing: behave like 2.5.0
end
local function guard()
    if not jeepActive() then return end
    if type(Vehicles) ~= "table" then return end
    JP82 = JP82 or {}
    local filled = {}
    for _, k in ipairs({ "Create", "Init", "InstallComplete", "UninstallComplete" }) do
        JP82[k] = JP82[k] or {}
        if JP82[k].SpareTire == nil then
            local fb = Vehicles[k] and Vehicles[k].Default
            if fb then JP82[k].SpareTire = fb; table.insert(filled, k) end
        end
    end
    if #filled > 0 then
        local msg = "JP82 guard: filled missing SpareTire fn(s) with vanilla Default: " .. table.concat(filled, ",")
        log(msg, false, "jp82fill")
    else
        log("JP82 guard: OK (damnlib SpareTire functions present)", true, "jp82ok")
    end
end
if Events and Events.OnGameBoot then Events.OnGameBoot.Add(guard) end
if Events and Events.OnServerStarted then Events.OnServerStarted.Add(guard) end
