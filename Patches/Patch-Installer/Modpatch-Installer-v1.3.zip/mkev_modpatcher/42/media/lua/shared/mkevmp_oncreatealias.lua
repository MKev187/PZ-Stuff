-- UPSTREAM-WORKAROUND (UPSTREAM.md U12): pre-42.20 OnCreate names in Realistic Army Zombies and Extra Bombs 2 (tracker T39).
-- B42.20 moved the vanilla OnCreate helpers from the Lua table SpecialLootSpawns to the Java class ItemCodeOnCreate.
-- Still using the old names (42.21, checked 27.10.2026):
--   Realistic Army Zombies (WS 1902435140, id realisticarmyzombiesb42) 42.0/media/scripts/clothes/Mask.txt
--     RAZ.Hat_GasMaskArmy, RAZ.Hat_GasMaskArmyHood: OnCreate = SpecialLootSpawns.OnCreateGasMask
--   Extra Bombs 2 (WS 3652008781, id ExtraBombs2) 42/media/scripts/ExtraBombs2_items.txt
--     ExtraBombs.ExtraBombsMag: OnCreate = SpecialLootSpawns.OnCreateRecipeMagazine
-- Every spawn logs 'no such function "SpecialLootSpawns.OnCreate..."' and the item misses its vanilla setup
-- (army gas masks get no filterType/usedDelta, the magazine no literature title). Alias the old names to vanilla.
-- Only adds missing keys; never replaces a function another mod already put there. Applied only if one of the mods is active.
local ALIASES = {
    { old = "OnCreateGasMask",        new = "onCreateGasMask",        mods = { "realisticarmyzombiesb42" } },
    { old = "OnCreateRecipeMagazine", new = "onCreateRecipeMagazine", mods = { "ExtraBombs2" } },
}
local function needed(mods)
    local M = MKevModPatcher
    if not (M and M.isModActive) then return true end
    for _, id in ipairs(mods) do
        if M.isModActive(id) then return true end
    end
    return false
end
local function applyOnCreateAliases(final)
    for _, a in ipairs(ALIASES) do
        if needed(a.mods) then
            SpecialLootSpawns = SpecialLootSpawns or {}
            if SpecialLootSpawns[a.old] == nil then
                if ItemCodeOnCreate and ItemCodeOnCreate[a.new] then
                    SpecialLootSpawns[a.old] = ItemCodeOnCreate[a.new]
                elseif final then
                    local m = "OnCreate alias: ItemCodeOnCreate." .. a.new .. " not found - vanilla renamed it again?"
                        .. " SpecialLootSpawns." .. a.old .. " NOT aliased."
                    local M = MKevModPatcher
                    if M and M.log then M.log(m, false, "oncreatewarn_" .. a.old) else print("[MKev-ModPatcher] " .. m) end
                end
            end
        end
    end
end
applyOnCreateAliases(false)
if Events and Events.OnGameBoot then Events.OnGameBoot.Add(function() applyOnCreateAliases(true) end) end
