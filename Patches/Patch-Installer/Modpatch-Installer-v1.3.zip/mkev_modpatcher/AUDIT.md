# v1.1 audit: references to mods (25.10.2026)
Basis: /workspace/pz/new/servertest.ini (Mods= 370 entries, 323 WorkshopItems), read-only scan of all 12,065 script files in
Steam workshop 108600 on MKev-PC, and the watcher log 25.10. 02:35 (without a patch active). The client and server Workshop copies of
all 16 target mods are identical (file count and size; translation and template files also by MD5).

| Part | Target mod (id / WS) | Active? | Still needed? | Without the target mod | v1.1 decision |
|---|---|---|---|---|---|
| SSP93Gunrack template | 93mustangSSP / 3001592312 | yes | yes (8x not found) | unused template, no error | kept |
| SUB87Gunrack template | 87chevySuburban / 3196180339 | yes | yes (4x) | unused template, no error | kept |
| JP82SpareTires restore | 82jeepJ10 / 2886832257 (collision with 84jeepXJ 3409287192) | yes / yes | yes (12x); 42.20 file still identical | unused template | kept |
| JP82 guard (Lua) | 82jeepJ10 | yes | yes (safety net) | 2.5.0 created JP82 + logged a fallback line | guarded (isModActive) |
| P19ABigTrunkCompartment2 stub | 86oshkoshP19A / 2566953935 | yes | yes (12x) | unused | kept |
| DAMN67commando/Police/T50 stubs | 67commando / 2478247379 | yes | yes (4x each) | unused | kept |
| 1500WaterTruckTank | 78amgeneralM35A2 / 90pierceArrow | yes | yes (4x) | unused | kept |
| B700Mudflaps, B700SideStorage | 87fordB700 / 3110911330 | yes | yes (12x each) | unused | kept |
| F1502Roofrack, F1502SpareTires, F3502Roofrack | 93fordF350 / 3073430075 | yes | yes | unused | kept |
| SUB93TrunkDoorWrecker | 93chevySuburban(+Expanded) / 3152529790 | yes | yes (8x) | unused | kept |
| V300TrunkDoorViewports | 84gageV300 / 3171184800 | yes | yes (8x) | unused | kept |
| VL200Louver | 89volvo200 / 3292659291 | yes | yes (8x) | unused | kept |
| DAMNSpareTireRoof | 76chevyKseries 42.20 ("not found in: null") | yes | partly (may not silence it) | unused | kept |
| BR89SpareTiresPD | 89fordBronco / 2886833398 | NO (not installed) | no | harmless: empty, defined nowhere else, nothing references it | kept provisionally |
| DAMN85chevyImpalaPD | 85chevyCaprice / 3413704851 | NO (not installed) | no | harmless (as above) | kept provisionally |
| Soda alias (Lua) | FunctionalAppliances2 / 3042138819, Authentic Z / 2335368829 | NO (subscribed, not in Mods=) | no | 2.5.0 created the alias anyway (harmless) | guarded, dormant |
| PUR server guard | PUR / 3776279483 | yes | yes (T2) | the 2.6.0 draft would have created a stray global PUR | guarded |
| % fix Sandbox.json | TrueSmoking / 3423984426, WeightReduction / 3774841057 | yes | yes (T8) | unused translation keys, no error | new |

Nothing had to be removed. Empty template stubs are safe only while no loaded mod defines the same name; if one did,
a stub loaded last would replace the real template. Re-check after vehicle mod updates (the watcher shows "not found" lines
again only if a reference changes; a new real definition would not show up, so repeat this scan per iteration).
Case check: every reference to another mod (template names, function names, translation keys, mod ids) matches the on-disk
spelling exactly. The patch references no foreign file paths.

# v1.4 addition (26.10.2026): Realistic Army Zombies stand-in clothing items
| Part | Target mod (id / WS) | Active? | Still needed? | Without the target mod | v1.4 decision |
|---|---|---|---|---|---|
| clothingItems/Jacket_M65_Green.xml, Jacket_ArmyCamoGreenHot.xml, Hat_PatrolCapGreen.xml | realisticarmyzombiesb42 / 1902435140 | yes | yes (1x FileNotFound 26.10. 07:51, server) | GUIDs unknown, files never loaded, no error | added |
- Path case: `clothing/clothingItems/<Name>.xml` copies the exact case of the paths in the target mod's fileGuidTable.xml (Linux lookup is case-sensitive). Client and server Workshop copies of 1902435140 are hash-identical (118 files).
- Not a full-file override: none of the three paths exists in the target mod, vanilla or another active mod (searched client + server Workshop and vanilla clothingItems on MKev-PC).

# v1.5 / v1.5.1 (26.10.2026): Summer Car car lift module (removed in 1.5.1) and Brita NV legacy items
| Part | Target mod (id / WS) | Active? | Still needed? | Without the target mod | decision |
|---|---|---|---|---|---|
| 42/media/scripts/MSC_Building.txt (override, module Base) | MaskaradsSummerCar / 3790160840 | yes | 40 log errors on fresh-world chunk generation, but the module move breaks client joins on any world that already registered MaskaradsSummerCar.WorkshopCarLift (SpriteConfigs dictionary) | - | **removed in 1.5.1** (T29 regression; both-modules copy is fatal: SpriteConfigManager double entry -> world load aborted) |
| 42/media/scripts/mkevmp_brita_nv_legacy.txt (6 legacy NV items, Obsolete=false) | BritasArmorPackB42 / 3780298456 | yes (Mods= #192) | yes, 6 client errors per join 26.10. | the items would point to Brita clothing XMLs/icons that are missing; keep it only while Brita is in the pack | keep |

# 0.1.11 (31.10.2026): connect notice
| Part | Target | Active? | Needed? | Without target | decision |
|---|---|---|---|---|---|
| client/mkevmp_connectnotice.lua + Translate/EN/UI.json | vanilla ConnectToServer.connect (main menu), OnGameStart (MP client) | always (client) | yes, MKev request 31.10. | ConnectToServer missing -> no menu hook, game fallback only; UI classes missing -> nothing shown | added |
- Wrap keeps the exact vanilla signature (11 parameters + self) and passes every argument unchanged; fail-open on any error.
- No server code, no network packets, no sandbox option. New client file changes the mod checksum like any new file (server + clients must have 0.1.11).
- Follow-up 31.10.: local mod list add (MP client only, once per session, add-only via vanilla ActiveMods "default" + saveModsFile; skip in SP, coop host, server, mods disabled; fails safe with log).

| Part (main menu / SP audit, 0.1.11) | Main menu | Single player | decision |
|---|---|---|---|
| shared/mkevmp_00_config, version | log lines only | log lines only | ok |
| shared/mkevmp_fillcontainerguard | wraps Events.OnFillContainer.Add, passes real ItemContainer calls unchanged | same, only drops the broken vanilla call | ok (harmless) |
| shared/mkevmp_jp82guard, oncreatealias, sodacanalias | only if target mod active | only if target mod active | ok |
| shared/mkevmp_purserverguard, vvrspawnguard | dedicated server only | dedicated server only | ok |
| shared/mkevmp_zedmonitor | wrapped spawn functions at load (idle) | started + wrote log file | **guarded**: server / MP client only |
| client/mkevmp_postdeathguard | nothing (OnGameStart) | installed on death screen | **guarded**: MP client only |
| client/mkevmp_insertmagguard, alifewindowhands | MP client only | MP client only | ok |
| client/mkevmp_neatlockshovequiet, primitivebow_anm | only with target mod | only with target mod, identical behaviour | ok |
| client/mkevmp_connectnotice | menu hook (intended) | nothing | ok |
| scripts (vehicle templates/stubs, Brita NV items), clothing XMLs, sandbox option | passive definitions | passive; Brita NV items exist without Brita but nothing spawns them; option page MKevMP visible in SP sandbox | ok (limitation noted) |
