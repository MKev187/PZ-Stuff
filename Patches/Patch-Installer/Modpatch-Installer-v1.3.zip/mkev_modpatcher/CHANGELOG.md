# Changelog - MKev-ModPatcher (mod id `mkev_modpatcher`)

Version scheme (from 2026-10-30): internal builds are `0.1.<n>`, the official Steam release will start at `1.0`.
Mapping of the older internal builds: 1.1 ... 1.8 = 0.1.1 ... 0.1.8 (installed 1.8 is unchanged and stays labeled 1.8).
The last digit goes up with every iteration. The mod id and folder name never change,
so the `Mods=` entry stays `mkev_modpatcher`.

## v1.2 - 2026-11-11
1.2 = 1.1b without functional change (bundled with MKev's Modpatch Installer v1.3).
### Changed
- `mod.info`: `versionMin=42.21` (was `42.20.0`, decision of 10.11.2026: new versions raise versionMin to 42.21), still no
  `versionMax`, so later game updates do not lock the mod. modversion `1.2`.
- `mod.info` name: `MKev's Modpatcher` (was `MKev-ModPatcher v1.1b`; display name only, id `mkev_modpatcher` unchanged).
- `mkevmp_version.lua`: `1.2` (log: `[MKev-ModPatcher] version 1.2 loaded`). README.
- Server and all clients need the same version (1.2), because the Lua checksum changes with the version file.

## v1.1b (Hotfix Tweed jacket) - 2026-11-10
1.1b = 1.1_vvr + this fix. The VVR guard change of 1.1_vvr is kept unchanged.
### Added
- `42/media/lua/shared/mkevmp_spongie_tweedfix.lua` (UPSTREAM U15; request by MKev 10.11.2026): Spongie's Clothing (WS 2684285534) gives
  `Spongie.Jacket_Tweed` the BodyLocation `base:jacket_suit` and `Spongie.Jacket_TweedOPEN` `base:JACKET_OPEN`. Neither id exists in B42.22,
  so `getBodyLocation()` is null and every hover over a "Tweedjacke" threw a NullPointerException at `Clothing.DoTooltip(Clothing.java:233)`
  (578x on 10.11.2026 04:31-04:33). The file sets `base:jacketsuit` and `SpnOpenCloth:JACKET_OPEN` (only if SpnOpenClothBase is active)
  on the script items with `DoParam`, only if SpnCloth is active and only while the location is still missing. It checks the result
  (non-null) and logs one line per fixed item: `[MKev-ModPatcher] Spongie tweed fix: <item> BodyLocation -> <id>.`
  Runs on OnGameBoot, OnInitGlobalModData, OnGameStart and OnServerStarted (idempotent). `InventoryItem.getBodyLocation()` reads the
  script item, so jackets that already exist are fixed too (42.22 decompile).
- `mkevmp_version.lua`: `1.1b`. `mod.info`: name/modversion `1.1b`, one sentence in the description. README / UPSTREAM (U15).

## v1.1_vvr (Hotfix VVR) - 2026-11-10 (until 1.1b)
Version scheme from 2026-11-10: builds start at `1.1` (no more `0.x`). 1.1_vvr = 0.1.11 + this VVR hotfix only.
### Changed
- `42/media/lua/shared/mkevmp_vvrspawnguard.lua` (tracker T37/T38, UPSTREAM U14; request by MKev 10.11.2026): the VVR spawn guard
  no longer keeps vanilla vehicles. 0.1.8 - 0.1.11 skipped VVR for every vehicle with `isCreated() == true` on the dedicated
  server, so vanilla vehicles that VVR did not catch at their first spawn stayed vanilla (e.g. `Base.StepVan_MobileLibrary`,
  client log 10.11.2026 02:21). Now, dedicated server only, VVR handler only:
  - new vehicle: VVR unchanged; without a square (VVR returns early) it is also queued and checked once it is in the world;
  - existing vehicle without physics (`getController() == nil`): VVR `replaceSpawned` runs (keeps condition, rust, blood, parts);
  - existing vanilla vehicle with physics that VVR has a replacement for (the T37 `Bullet.removeVehicle` path): VVR is not
    called; the vehicle is removed with `permanentlyRemove()` (server skips Bullet) and spawned again with the same vanilla
    script on the same square with `addVehicleDebug`, so VVR's own `replaceNew` swaps the new vehicle. Occupied, towing or
    towed vehicles are kept. Items in such a vehicle are lost. Each square + script at most once per server run.
  - one log line per vehicle: `[MKev-ModPatcher] VVR guard: replaced <script> -> <target> at x,y (...)`, `FAILED ...`,
    `kept ...`; max 20 lines per 60 s, then `N more vehicle lines suppressed`. Startup line: `VVR spawn guard active
    (dedicated server, 1.1_vvr: vanilla vehicles are replaced).` (always shown now, was verbose-only).
- `mkevmp_version.lua`: version marker `1.1_vvr`. `mod.info`: name/modversion `1.1_vvr`, VVR sentence of the description.
- README.md / UPSTREAM.md: version line and U14 workaround text. No other file changed.

## 0.1.11 - 2026-10-31 (installed until 1.1_vvr)
### Added
- `42/media/lua/client/mkevmp_connectnotice.lua`: connect notice window (request by MKev 31.10.2026). Short loading notice with title and
  OK button, German if `Translator.getLanguage()` is DE, English for every other language. Text: loading this server can take a while
  because of the amount of mod data; while Windows shows the hourglass or the spinning loading circle, do not press keys and do not click
  into the game window; this can happen before and after "Click to start" (the game's own UI_ClickToSkip label is inserted), it is
  temporary and gets shorter with every start.
  When it shows (B42.21 research, ConnectToServerState / GameLoadingState):
  1. Main menu, before the connect: `ConnectToServer.connect` is wrapped (exact 11-parameter vanilla signature, server list, direct IP
     and password dialogs all end there). The vanilla connect only starts after OK. Needs mkev_modpatcher in the client's local mod
     list (mods\default.txt). Coop (`connectCoop`) is not touched.
  2. Fallback in game: `OnGameStart`, MP client only (not single player, not coop host), when there was no menu OK for this connect.
     The window lies over the whole screen (clicks into the world are swallowed), the character is held with setBlockMovement until OK
     (previous state restored, OnTick watchdog releases it if the window vanishes). An MP game cannot be paused.
  Not possible: a Lua window during the download or the loading screen. The server's mod Lua is loaded in
  `ConnectToServerState.Finish` (ResetLua) and the next frame enters `GameLoadingState`, which suspends the Lua UI
  (`UIManager.suspend`) and clears it with `UIManager.init()` in `exit()`; "Click to start" is drawn in Java without a Lua hook.
  Once per connect: the confirm time is kept in `Zomboid/Lua/mkev_connectnotice.txt` (Lua state is reset during the connect);
  menu: no second window within 10 min after OK (retry after a failed connect); game: a menu OK younger than 60 min counts for this
  connect and is then marked as used. All code in pcall, fail-open (any error -> vanilla connect runs unchanged).
  Log: `[MKev-ModPatcher] connectnotice: shown (...)` / `confirmed (...)`.
- Local mod list (follow-up request by MKev 31.10.2026): players who only subscribed to the Workshop collection have the mod only in the
  server's mod list, not in their local default list, so the main-menu window could not run for them. Now, on an MP client (not single
  player, not coop host, not the server), once per session at `OnGameStart`, `mkevmp_connectnotice.lua` adds `mkev_modpatcher` to the local
  default mod list with the same vanilla API the mod selector uses: `ActiveMods.getById("default"):setModActive("mkev_modpatcher", true)`
  and `saveModsFile()` (Java: ZomboidFileSystem.saveModsFile -> ActiveModsFile.write -> Zomboid\mods\default.txt). No file is written by
  hand. Add-only: nothing is removed, reordered or changed, the map list stays (setModActive appends at the end only if missing).
  Already present (also with the B42 leading backslash) -> nothing is saved. In an MP session the game has just re-read default.txt
  into ActiveMods "default" during the connect (ZomboidFileSystem.loadMods -> loadTranslationMods -> readDefaultModsTxt), so the saved
  list is the player's current file plus our id. If saving fails, our id is taken back out of memory. Skipped when mods are disabled in
  the game options. Log: `connectnotice: added to local modlist` / `already active` / `failed: <reason>`.
  Effect: when the player leaves the server to the main menu, the game reloads the default list and its Lua (IngameState.exit ->
  loadMods("default") -> LuaManager), so the main-menu window works from the next connect on, no game restart needed. If the game is
  closed directly from the server, it works from the next game start. The very first join of a new player still uses the in-game fallback.
- `42/media/lua/shared/Translate/EN/UI.json`: the texts (both languages as separate keys, EN is always loaded; own `{click}` placeholder
  instead of `%1`, because the game formats every getText result and would log a warning for a missing argument). ASCII fallbacks in Lua.
### Installer (package, not part of the mod files; request by MKev 31.10.2026)
- `patcher.bat` renamed to `ModPatchInstaller.bat` (thin wrapper) + `ModPatchInstaller.ps1` (logic, Windows PowerShell 5.1+). Audience:
  players who subscribe to the Workshop collection - mkev_modpatcher, mkevserverbootpatch and iknowit are not on the Workshop but are in
  the server `Mods=`, so they must be installed locally to join.
- Menu: 1 "Installieren & Einrichten" (default; info screen + J/N first): installs the mods to `Zomboid\mods`, REPLACES the `Mods=`,
  `WorkshopItems=` and `Map=` lines of `Zomboid\Server\servertest.ini` with the MKev server lists in load order (player's own entries in
  those three lines are removed and listed in the log; every other line stays byte-identical, file created with only those lines if
  missing), installs `servertest_SandboxVars.lua`, adds/updates the modlist preset `MKevServer` in `Zomboid\Lua\pz_modlist_settings.cfg`
  (other presets kept) and appends `mkev_modpatcher` to `mods\default.txt` (add-only). 2 "Installieren & nicht Einrichten": mods only,
  no existing config touched, ready-made files in `Zomboid\MKevServer_setup\`. 3 restore a backup. 4 exit. 5 dry run.
- Safety: refuses while ProjectZomboid64.exe or a PZ java server runs; every write is backed up first to
  `Zomboid\mkev_patch_backups\<stamp>_<action>\` (index + log); never writes outside `Zomboid` or into a Workshop folder; idempotent.
- Bundled data (`MKevServer_setup\`): only the three lists, the SandboxVars and the preset - no passwords, ports, names or tokens.
- Optional slot `intensiveCare` (installed when the folder is in the package, skipped otherwise).

### Changed
- Main menu / single player audit (the mod can now sit in the local default list, so it also loads in the main menu and in new single
  player games): `mkevmp_zedmonitor.lua` now wraps spawn functions only on the server and starts only on the server or an MP client
  (before: also single player, which wrote mkev_zedmonitor_server.log in SP). `mkevmp_postdeathguard.lua` now acts only on an MP client
  (before: also single player). All other files were already harmless there: they check for their target mod (JP82, PUR, soda,
  OnCreate aliases, Primitive Bow, A-Life), are MP-client-only (insert magazine) or dedicated-server-only (PUR, VVR), or only pass
  through unchanged calls (OnFillContainer guard, NeatLockpicking quiet). The scripts (vehicle templates/stubs, Brita NV items, 3 clothing
  XMLs) are passive definitions that nothing uses unless the target mod is active.
- mod.info / mkevmp_version.lua: version 0.1.11, description extended. mkevserverbootpatch unchanged (1.0.2).
- Checks: Lua 5.1 syntax ok, luacheck 1.2.0 0 warnings (changed files), connect notice + mod list mock test 107/107,
  main menu / single player guard test 12/12, 0.1.10 regression tests ok.

## 0.1.10 - 2026-10-31 (installed until 0.1.11)
### Added
- `42/media/lua/client/mkevmp_postdeathguard.lua`: post-death guard. Cause: on 2026-10-30 23:47 CET the death screen buttons
  (New character / Quit) did not react, no Lua error, Alt+F4 was needed. Vanilla ISPostDeathUI ignores every click while
  `MainScreen.instance:isReallyVisible()` is true, and an invisible always-on-top panel would swallow the clicks too.
  The guard: keeps the death screen always on top (once per second, also the quit confirm dialog); logs `[MKev-PDG]` lines
  (death, snapshot 4 s after death with MainScreen flag and all visible always-on-top UI elements with type and rect,
  every left click with the topmost UI element under the mouse, max 25); wraps onRespawn / onExit / onQuitToDesktop
  (logs each click; if MainScreen is flagged visible although the click arrived, hides MainScreen and continues with the
  vanilla handler); after 10 s without a successful click a small always-on-top window "Neuer Charakter" / "Spiel beenden"
  calls the vanilla handlers. All in pcall, no change if ISPostDeathUI is missing; turns itself off on any error.
### Changed
- Zombie spawn monitor: time stamps in Europe/Berlin local time (CET/CEST, EU summer-time rule, computed from
  getTimestampMs) instead of UTC; START line shows `zeit=CET(Europe/Berlin)`.
- Zombie spawn monitor: A-Life NPC bodies (modData ProjectALifeOwned/ProjectALifeActor or variable ALifeUID, or spawned from
  ProjectALife code) and Starving Zombies skeleton templates (isSkeleton, or spawned from Starving Zombies code) are no
  longer counted in SPAWN / LADEN / ZAEHLUNG and get no LUA_AUFRUF line; one `AUSGEFILTERT npc_shell=N skelett=N` line per minute.
- mod.info / mkevmp_version.lua: version 0.1.10, description extended. mkevserverbootpatch unchanged (1.0.2).

## 0.1.9 - 2026-10-30 (installed until 0.1.10)
### Added
- `42/media/lua/shared/mkevmp_zedmonitor.lua` (tracker T47): zombie spawn monitor for the test phase. Server / single player:
  wraps the global Lua spawn functions (addZombiesInOutfit, addZombiesInOutfitArea, addZombieSitting, addZombiesEating,
  createHordeFromTo, createHordeInAreaTo, spawnHorde, createZombie, addVirtualZombie - only the ones that exist); the caller
  (mod folder, Workshop ID, file:line, 2 frames) is read from the Kahlua call frames. Every wrapper calls the original with the
  original arguments and returns all original results; errors of the original are passed on. `Events.OnZombieCreate`
  (42.21: fired in VirtualZombieManager.createRealZombieAlways) classifies each new real zombie as lua:<mod>, vanilla_raum
  (OnSeeNewRoom in the same moment), vanilla_raum_spaet (zombie in a room seen <= 120 s ago), reanimation or laden
  (virtual -> real / cell load, summed per 100x100 area and minute). Census every 10 s: zombies within 30/80 tiles per player,
  written only on change (>=3 / >=5), on cell change, jump >= 10 or new zombies within 30 tiles without create event.
  Client: own count + "room seen -> zombies inside after 3 s". Logs: `Zomboid/Lua/mkev_zedmonitor_server.log` and
  `_client.log`; max 120 lines/min, identical lines merged ("WIEDERHOLT xN in 60 s"), 2 MB cap, then moved to
  `*.1.log` (one old file; the game only allows .log/.txt names, so not `.log.1`). All calls in pcall.
  Checks: Lua 5.1 (lupa) ok, luacheck 1.2.0 0 warnings, mock test 25/25.
- `42/media/sandbox-options.txt`: option `MKevMP.ZedMonitor` (boolean, default true), EN translation in Sandbox.json.
- Empty `media/AnimSets` + `media/actiongroups` placeholders in `common/` and `42/` (same reason as bootpatch 1.0.2).
### Changed
- mod.info / mkevmp_version.lua: version 0.1.9, description extended.

## 1.8 (= 0.1.8) - 2026-10-30
### Added
- `42/media/lua/shared/mkevmp_vvrspawnguard.lua` (tracker T37/T38, UPSTREAM U14): Vanilla Vehicles Replacer (KI5) (3423424077) swaps vanilla
  vehicles in its `OnSpawnVehicleStart` handler. For a vehicle that already exists (`isCreated()`), it sets the new script and calls
  `scriptReloaded(true)`. On the dedicated server this fails in `BaseVehicle.scriptReloaded` -> `Bullet.removeVehicle` (native missing,
  UnsatisfiedLinkError, VVR `Replace.lua:188`), the swap stops half way, and clients then fail to parse that vehicle's seats
  (VehicleUpdatePacket / VehiclePassengers BufferUnderflowException, 1239x in one session on 30.10.). The file wraps
  `Events.OnSpawnVehicleStart.Add/Remove`, but ONLY when `isServer() and not isClient()`, and only for the handler defined in
  `lua/server/VVR/Replace.lua` (checked with `getFilenameOfClosure`). Calls for existing vehicles are skipped, so they keep their current script.
  New vehicles are still replaced. Other handlers, clients, host and single player are untouched. Logs once on the first skip; logs one line at
  server start if VVR is active but its handler was not caught (then nothing is changed). Own code, no VVR file copied or changed.
  Checks: Lua 5.1 compile ok, luacheck 1.2.0 0 warnings, mock test 12/12 (dedicated/client/SP/host, new vs existing, Remove, second load,
  missing event/Add/getFilenameOfClosure, VVR inactive).
### Changed
- mod.info / mkevmp_version.lua: version 1.8, description extended (VVR guard), "game 42.20" -> "game 42.21".

## 1.7 - 2026-10-27 (installed 2026-10-30)
### Added
- `42/media/lua/shared/mkevmp_oncreatealias.lua` (tracker T39, UPSTREAM U12): Realistic Army Zombies (1902435140, `RAZ.Hat_GasMaskArmy`,
  `RAZ.Hat_GasMaskArmyHood`) and Extra Bombs 2 (3652008781, `ExtraBombs.ExtraBombsMag`) still use the pre-42.20 OnCreate names
  `SpecialLootSpawns.OnCreateGasMask` / `SpecialLootSpawns.OnCreateRecipeMagazine`. In 42.21 these live in the Java class
  `ItemCodeOnCreate` (`onCreateGasMask`, `onCreateRecipeMagazine`), so every spawn logged `no such function` and the items skipped their
  vanilla setup (army gas masks: no filterType/usedDelta; magazine: no literature title). The file aliases the old names to the vanilla
  functions, only if the key is still empty and only when one of the two mods is active; logs one warning at boot if vanilla renamed them again.
  Same pattern as the soda alias. Mock test: alias set, existing keys untouched, inactive mods = no change, missing vanilla = one warning.
- `42/media/lua/shared/mkevmp_fillcontainerguard.lua` (added 2026-10-30, tracker T40, UPSTREAM U13): vanilla 42.21 fires
  `OnFillContainer("Container", bagType, containerDist.bags)` when a spawned bag is filled from its container's `bags` loot list, so the third
  argument is a loot definition (`ItemPickerJava$ItemPickerContainer`) instead of the bag's `ItemContainer`. Every mod handler that touches it
  failed on the server (Computer Mod - New Music Integration `CMNM_Loot.lua:48`, Low Condition Guns `LowConditionGuns.lua:103`, Spoiling Liquids
  `SpoilingLiquids.lua:360`; 48 server stack traces in 5 sessions 27.-29.10.). The file wraps `Events.OnFillContainer.Add/Remove`: handlers registered
  after it skip only calls whose container is not an `ItemContainer`; real calls pass through unchanged, Remove still works. Covers CMNM and Low
  Condition Guns (both register later). Spoiling Liquids registers a local function in shared/ before this file loads and stays upstream.
  Mock test: real container passes, loot definition skipped, Remove works, second load is a no-op.
### Changed
- mod.info / mkevmp_version.lua: version 1.7, description extended.

## 1.6 - 2026-10-26
### Added
- `42/media/lua/client/mkevmp_primitivebow_anm.lua` (tracker T36): Archery Nexus [Fixed] (3731579266) and Archery Nexus [RadBows] Upgrade
  (3781962845) both ship `media/lua/client/ArcheryNexus_ANM.lua`. RB loads later, so only RB's copy runs (CompoundBowHeavyBlack only)
  and the Primitive Bow never switched to its drawn model `REX5_MD_BOW`. The new file re-adds Fixed's handler under its own name:
  only items of type `Primitive_Bow`, compares with the item's current sprite (no stale per-player cache, works for split screen too),
  `resetEquippedHandsModels()` only on a change, stops after the first error with one log line. Registered on OnGameStart only when
  both mods are active and model Base.REX5_MD_BOW exists. Log: `Primitive Bow draw model switch active (ArcheryNexusFixed + ArcheryNexus_RB)`.
  RB's handlers touch only CompoundBowHeavyBlack, so the two never fight. Mock test: drawn/idle/swap/heavy bow unchanged.
### Changed
- mod.info / mkevmp_version.lua: version 1.6. loadAfter: WeightReduction dropped (removed from the pack), ArcheryNexusFixed and
  ArcheryNexus_RB added. Description: WeightReduction tooltip fix no longer mentioned (keys stay in Sandbox.json, unused, harmless).
- Pack changes delivered with 1.6 (apply_v16.ps1, not part of this folder): 10 mods removed (NewMusicGRHPRB, NewMusicGRMCM,
  MutiesContextMenuIcons, SandboxSettings, NicksInventorySelectionFix, NicksSledgehammerFix, WeightReduction, ReducedWeightWalkieTalkies,
  ZeroWeightKeys_B42, WL_WeaponSlings), Realistic Army Zombies / Undead Survivor / Ammo Loot Drop moved into the zombie block, TrueWeight
  takes over the weight values (Material/MaterialWeapon/Paint/Tool/ToolWeapon 0.05, CustomWeights keys/padlocks 0, walkies 0.1).
- T19 window guard from 1.5.2 unchanged.

## 1.5.2 - 2026-10-26
### Fixed
- `42/media/lua/client/mkevmp_alifewindowhands.lua` (tracker T19 reopened: 4x `ClassCastException IsoZombie -> IsoPlayer` in
  `PlayerDropHeldItemsPacket.setData` via `climbThroughWindow` 18:39-18:42 with 1.5.1, paths `IsoZombie.tryThump` and `ThumpState.execute`).
  The 1.2 check only looked at the 4 edges of the shell's current square, required `isFacingObject(0.8)` and an exact moving state.
  OnZombieUpdate runs before the state machine moves the shell, so a shell one tile in front of a window could step next to it and
  climb in the same update; thumpable windows are climbed by the engine without any facing check. Now: all edges of the 3x3 squares
  around the shell (radius 1 tile), no facing test, moving OR thump state OR an action state containing climb/thump counts; the
  `isLocal()` pre-check was dropped (A-Life's `TraversalHands.prepare` checks authority itself).
### Added
- Always-on log: `A-Life window guard active (client, v1.5.2, radius 1 tile)` once at game start, and at most every 10 minutes (only
  when a counter changed) `A-Life window guard: prevented=<n> refused=<n> missed=<n> errors=<n>`.
### Changed
- mod.info / mkevmp_version.lua: version 1.5.2. Nothing else changed from 1.5.1.

## 1.5.1 - 2026-10-26
### Removed
- `42/media/scripts/MSC_Building.txt` (Maskarad's Summer Car override from 1.5, tracker T29 regression). Moving the entity to
  `module Base` blocked every client join on the existing world: `WorldDictionaryException: [SpriteConfigs] Missing dictionary script on
  client: MaskaradsSummerCar.WorkshopCarLift`. Cause (B42 ScriptsDictionary.ScriptRegister): stored SpriteConfig entries keep
  `isLoaded` from WorldDictionary.bin; `parseLoadList()` only resets the fresh load list, so an entry whose script disappeared stays
  `isLoaded = true` and the client must still have that script. The world from 15:15 had registered MaskaradsSummerCar.WorkshopCarLift,
  v1.5 added Base.WorkshopCarLift on top (both id'd, same version hash).
- Rejected alternative (plan A): keep both entities (original file + a copy in module Base). SpriteConfigManager keys ObjectInfos by the
  short entity name and refuses sprites bound twice ("double entry, script: WorkshopCarLift" / "Sprite ... is duplicate"); that sets
  SpriteConfigManager.HasLoadErrors and IsoWorld.init aborts with "World loading could not proceed, there are script load errors" on server
  and client. Unsafe, not shipped.
- Effect: Summer Car is original again (MaskaradsSummerCar.WorkshopCarLift exists, map lifts in new chunks again log "EntityScript not found:
  WorkshopCarLift" as before 1.5 - harmless log noise, U10 stays the proper fix). The stale Base.WorkshopCarLift SpriteConfig entry that the
  1.5 boot wrote into this world's WorldDictionary.bin is NOT cleaned up by the game (see above); see tracker T29 for the one-flag fix.
### Changed
- mod.info: version 1.5.1, MaskaradsSummerCar removed from `loadAfter` (no override any more). Everything else is unchanged from 1.5
  (Brita NV legacy items, JP82 spare tire guard, all 1.4 content).

## 1.5 - 2026-10-26
### Added
- `42/media/scripts/MSC_Building.txt`: override of the same file from Maskarad's Summer Car (WS 3790160840). The only change is
  `module MaskaradsSummerCar` -> `module Base`; the entity body is byte-identical. Fixes 40x `GameEntityException: EntityScript not found,
  script: WorkshopCarLift` on the server when new chunks with vanilla car lifts are generated (first seen after the 2026-10-26 wipe).
  The file name keeps the original's mixed case on purpose, because an override must match the original relative path.
- `42/media/scripts/mkevmp_brita_nv_legacy.txt` (tracker T31, UPSTREAM U11): Brita's Armor Pack (WS 3780298456, BritasArmorPackB42 1.4.9)
  keeps six pre-1.4 night-vision names (Base.Hat_Sam_NV, NV_PVS5, NV_PNV_57, NV_PVS7, NV_PVS21, NV_GPNVG_18) only as `Obsolete = true`
  stubs plus a Lua migration table. No distribution, recipe, outfit or other mod (PNV 3470491629 included) uses the old names; they exist
  only for old saves. B42 puts each item into the WorldDictionary in `InitLoadPP`, before `Obsolete` is parsed, so the server keeps the
  stubs in the dictionary while the client's ScriptBucket drops obsolete scripts -> 6x "Warning client has no script for dictionary info"
  on every join (seen 26.10. 15:44 on the fresh world). The file adds a second body for each stub with `Obsolete = false` and the exact
  body of Brita's matching *_ON item, so server and client have identical scripts. Nothing spawns them; Brita's own migration
  (BritaArmor_NVCompat.lua) still swaps any old item for *_ON. Needs BritasArmorPackB42.
### Changed
- mod.info: version 1.5, `loadAfter` now also lists MaskaradsSummerCar and BritasArmorPackB42.

## 1.4 - 2026-10-26 (installed 26.10. 11:42 MEZ)
### Added
- `42/media/clothing/clothingItems/Jacket_M65_Green.xml`, `Jacket_ArmyCamoGreenHot.xml`, `Hat_PatrolCapGreen.xml`
  (tracker T27, UPSTREAM U9): Realistic Army Zombies (WS 1902435140, id realisticarmyzombiesb42) lists these three paths in its
  fileGuidTable.xml and uses their GUIDs in its army outfits (clothing.xml), but does not ship the files. Server log 26.10. 07:51:
  PZXmlParserException / FileNotFoundException for Jacket_M65_Green.xml when such a zombie spawns; the garment is then missing.
  The stand-ins carry the mod's own GUIDs and copy the look of vanilla Jacket_ArmyOliveDrab, Jacket_ArmyCamoGreen and
  Hat_BaseballCapArmy. Visual-only (the mod has no item script for them either, so nothing new drops as loot; vanilla code
  skips visuals without a script item). Folder/file names keep the exact case of the mod's fileGuidTable paths (needed on Linux).
  Unused when Realistic Army Zombies is not active.
### Changed
- Version 1.4 (mod.info name/modversion/description, MKEV_MODPATCHER_VERSION).

## 1.3 - 2026-10-25 (installed 25.10. 19:45 MEZ)
### Added
- `42/media/lua/client/mkevmp_insertmagguard.lua` (tracker T20, UPSTREAM U7): MP client only. Wraps vanilla
  `ISInsertMagazine:start()` at OnGameStart. When the client-side re-lookup `getInventory():getItemById(magazine:getID())`
  returns nil (magazine not yet in the main inventory on this client), the original magazine reference is kept instead of nil.
  Stops "attempted index: setJobDelta of non-table: null" in ISInsertMagazine update/perform/stop (Lua error spam, red error
  counter). The server's own copy of the action still does the real reload; SP and server are untouched.
- `42/media/lua/client/mkevmp_neatlockshovequiet.lua` (tracker T21, UPSTREAM U8): client only, only if NeatLockpicking
  (WS 3783535220) is loaded. Replaces `NeatLockpick_InputLock.suppressCombat` and `NeatCrowbarPanel:suppressShove` at
  OnGameStart with identical copies minus `setVariable("bDoShove", "false")` (read-only in B42, never had an effect).
  Stops the 'Trying to set read-only variable "bdoshove"' flood (~130 lines/s while the lockpick/crowbar UI is open).
### Changed
- Version 1.3 (mod.info name/modversion/description, MKEV_MODPATCHER_VERSION).

## 1.2 - 2026-10-25 (installed 08:54 MEZ)
### Added
- `42/media/lua/client/mkevmp_alifewindowhands.lua` (tracker T19, UPSTREAM U6): MP client only, only if ProjectALifeNPCs is active.
  When a LOCAL A-Life NPC shell (IsoZombie with ProjectALifeActor) holds an item and is about to climb a window the engine way
  (moving state + climbable window/frame/thumpable window on an adjacent edge that it faces, or ThumpState on a window),
  it calls A-Life's own `ProjectALife.TraversalHands.prepare(shell, true)`. That stores the held items, empties the hands for ~1.2 s,
  and A-Life's per-frame loop re-equips them after the climb. Prevents vanilla `IsoGameCharacter.dropHeavyItems()` from
  sending a PlayerDropHeldItems packet with an IsoZombie -> ClassCastException -> red "ERROR n" popup (ExceptionLogger).
  No inventory change, no packets, normal zombies exit on the first check (empty hands).
### Changed
- Version 1.2 (mod.info name/modversion, MKEV_MODPATCHER_VERSION).

## 1.1 - 2026-10-25 (DRAFT, not installed)
Successor of MKevPackPatches 2.5.0 (+ the unreleased 2.6.0 draft). Do NOT run it together with MKevPackPatches.

### Added
- `Translate/EN/Sandbox.json`: escapes `%` as `%%` (the vanilla B42 convention) in 6 sandbox texts that make the
  Translator log UnknownFormatConversion / MissingFormatArgument warnings (tracker T8):
  - TrueSmoking (WS 3423984426, 42.20 folder): CoughingChanceSmoker_tooltip, CoughingChanceNonSmoker_tooltip,
    DropChanceSmoker_tooltip, DropChanceNonSmoker_tooltip
  - WeightReduction (WS 3774841057, 42 folder): ReductionPercent, ReductionPercent_tooltip
  Only these keys are overridden; wording is unchanged. The game merges translation files per mod, and the last loaded mod wins.
- `mkevmp_purserverguard.lua` (from the 2.6.0 draft): empty `PUR` table on dedicated servers so
  PUR_DigCursor.lua:134 no longer fails at server start (T2 / U1). New in 1.1: only if PUR is active.
- `mkevmp_00_config.lua`: `MKevModPatcher.isModActive(id)` helper, plus a log warning if MKevPackPatches is active as well.
- mod.info: `incompatible=MKevPackPatches`, `loadAfter=TrueSmoking,WeightReduction`.

### Changed
- New name "MKev-ModPatcher v1.1", new id `mkev_modpatcher`, version 1.1, log prefix `[MKev-ModPatcher]`.
- All file names are now lowercase with an `mkevmp_` prefix (Linux rule). The globals are `MKevModPatcher` and
  `MKEV_MODPATCHER_VERSION`, so nothing collides with the old MKev_*.lua files or with `MKevCfg`.
- JP82 spare-tire guard: runs only if 82jeepJ10 is active. Without it, it no longer creates JP82 or logs a fallback line.
- Soda-can alias: applied only if FunctionalAppliances2 or Authentic Z (Current/Lite/Backpacks+) is active. Neither
  is in Mods= right now, so it stays dormant.

### Unchanged
- All vehicle template bodies are byte-identical to 2.5.0 (only the files were renamed and a header comment added):
  KI5 gunracks (SSP93Gunrack, SUB87Gunrack), JP82SpareTires restore (still byte-identical to 82jeepJ10 42.20),
  P19A/DAMN67 stubs, and 12 stale-reference stubs.

### Not included from 2.5.0 packaging
- Install-MKevPackPatches.bat, tools/, docs/ and versions/ belong to the old package. A new friend installer is
  built only after MKev approves.
