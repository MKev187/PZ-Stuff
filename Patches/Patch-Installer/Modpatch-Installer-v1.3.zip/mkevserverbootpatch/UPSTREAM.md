# Upstream notes (nothing sent - for MKev, only if he wants to report them)

| # | Mod (WS) | Problem | Suggested upstream fix |
|---|---|---|---|
| S1 | Archery Nexus [Fixed] (3731579266) | `recipes_fletching.txt` "Assemble A Primitive Hunting Bow": `Carpentry:3` is not a B42 perk ID | use `Woodwork:3` |
| S2 | Mad Crafter (3418701509) | `recipes_MCR_1Handed.txt` (42.12 + 42.15): `Electrical:` in SkillRequired/AutoLearnAny/xpAward | use `Electricity:` (category = Electrical can stay) |
| S3 | Zombie Virus Vaccine (3615135168) | `LabSounds.txt` (42.14 + 42.20) line 106 `//` comment; B42 script parser only strips `/* */` -> sound Injection_A never registered | use `/* */` or remove the line |
| S4 | Sentry Turret Upgrade (3633082678) | require without folder prefix: server `ST_MP_TurretUtil`; client MP `ST_MP_BulletTracer`, `ST_MP_MuzzleFlash`, `ST_MP_GunSmoke`; client SP `ST_SP_TurretUtil` etc. (same as mkev_modpatcher UPSTREAM U3) | `require "MultiPlayer/ST_MP_TurretUtil"` etc., or move the files to the lua root |
| S5 | Jeep 82 J10 (2886832257) | `82jeepJ10t.txt:218` uses `template = JP82SpareTires/part/JP82SpareTireRear`, B42 template only has DAMNSpareTire/DAMNSpareTireRoof -> J10 truck has no spare tire slot | KI5: add the part to the template. **Local fix belongs to mkev_modpatcher (v1.4 candidate, it owns the JP82 template), not here.** |
| S6 | J&G uniforms (3315302991, 3457969588, 3616192072, 3299457564), The Only Cure+ (3818733381) | `module Base { imports { Base } }` -> "module Base imports itself" (12x) | drop the self import. Purely cosmetic, the engine skips it. |
| S7 | Realistic Army Zombies (1902435140) | `recipes_armygasmask.txt`: commented-out recipe closed with `/*` instead of `*/` -> unknown script object "/*" | close with `*/`. Cosmetic, the recipe was meant to be off. |
| S8 | Vanilla 42.21 (TIS) | fluid container names 'Large Bucket' / 'Fuel Pump' contain spaces (auto-sanitized) | vanilla, cosmetic |
