# MKevServerBootPatch 1.1.2 (id `mkevserverbootpatch`)

Author: MKev. Small local patch for the MKev B42 server pack (game 42.21+, tested log 42.22). Fixes boot-log errors of other mods.
Separate from `mkev_modpatcher`. Load it at the very END of `Mods=`, after `mkev_modpatcher`.
Server and every client need the same version (script checksums).

| # | Mod (WS) | Fix | File in this mod |
|---|---|---|---|
| F1 | Archery Nexus [Fixed] (3731579266) | recipe skill `Carpentry:3` -> `Woodwork:3` | `42/media/scripts/recipes/recipes_fletching.txt` |
| F2 | Mad Crafter (3418701509, 42.15) | `Electrical:` -> `Electricity:` (6x, 2 recipes) | `42/media/scripts/recipes/recipes_MCR_1Handed.txt` |
| F3 | Zombie Virus Vaccine (3615135168, 42.20) | `//` comment -> `/* */`, restores sound `Injection_A` | `42/media/scripts/sounds/LabSounds.txt` |
| F5/F6 | this mod | empty `media/AnimSets` + `media/actiongroups` placeholders (common + 42) | placeholders |

Since 1.1.1 F1-F3 are bundled in the mod. No installer step is needed: copy the `mkevserverbootpatch` folder into the
`mods` folder of the server (Windows or Linux) and of every client. The files override the originals by file name
(same relative path `media/scripts/...`, loaded after the original mods). Workshop files are never modified.

Each bundled file is the original file with only the listed text changed (SHA256 original / result):

| Fix | Original (Workshop) | Bundled file |
|---|---|---|
| F1 | `68B87D921EAEB41D2799919BDB75446FB9EBCFAD98376174A7D89FAEF0096678` | `05A17570A07265A578E893CB6E0CF70A5DF61EF9ECC0304C791B0F24A7FFB251` |
| F2 | `7B4591967E8FC50B337E6C210D2BC0C28B9CC5ECBC565CE41DE2567FD437CFEF` | `2D8F91B399309286738C33745A4960B5F0A851DF134C1704FFC5875E667E1209` |
| F3 | `85F28B209C94105F597900691C92E8E52D277871175E9B36241C974309F18FCD` | `5B674938425FB04DFC6FA85419D2678C57778B32F4ED4FE6EC63F1B02DDBF1FE` |

## Self-healing when the original mods update

The bundled files are the defaults. ModPatchInstaller 1.2 and newer (every install), `tools/check_upstream.ps1 -Fix` (Windows) and
`sh tools/check_upstream.sh --fix` (Linux) use the same logic and keep the fixes right without a new BootPatch version.
Per fix they look for the file the game really loads: the highest `42.x` version folder of the mod (capped by
`PZ_GAMEBUILD`, e.g. `42.22`), else `common`. Folder and file names are compared case-insensitively.

| Case | Status | What happens |
|---|---|---|
| Original unchanged (known SHA256) | `KEEP` | bundled file stays |
| Original changed, error still in it | `REBUILT` | fix is rebuilt from the new original: only the token edit (F1 `Carpentry:` -> `Woodwork:`, F2 `Electrical:` -> `Electricity:` in SkillRequired/AutoLearnAll/AutoLearnAny/xpAward lines, F3 top-level `//` lines -> `/* */`). BOM and CRLF/LF are kept. Checked: error tokens gone, only the intended lines changed, braces balanced. Then written into this mod. |
| Original changed, error gone | `FIXED_UPSTREAM` | the author fixed it: our override is removed, the original is used |
| Mod found, but it no longer loads this file | `NOT_LOADED` | our override is removed |
| Mod not in the Workshop folders (e.g. other PC) | `MISSING` | bundled file stays, note only |
| Rebuilt file fails a check | `FAIL` | warning; the file installed before stays, nothing broken is written, the install never aborts |

`MANIFEST.sha256` is rewritten after every change. The installer makes a backup before it overwrites (restore with mode 3).
Without `-Fix` / `--fix` both tools are a dry run and write nothing. Workshop folders: `-Workshop` / arguments,
else `PZ_WORKSHOP`, else the default Steam paths. Exit code: 0 nothing to do or done, 2 dry run found changes, 3 a FAIL.
**Server admins need no extra step:** put the `mkevserverbootpatch` folder into `Zomboid/mods/`, add it to `Mods=`, done.
Nothing has to be added to a start script. The bundled fixes are active right away.
`tools/check_upstream.sh` (Linux) and `tools/check_upstream.ps1` (Windows) are optional tools for admins who want to check
or refresh the fixes by hand after a mod update; nobody has to set them up. If an admin uses `--fix` and a fix changes,
the clients need the same `mkevserverbootpatch` files (script checksums): run the installer on each client, or copy the folder.

F4 (Sentry Turret Upgrade 3633082678 shim) was removed in 1.1.0: that mod (SentryTurret042) is no longer in the pack.
Linux servers: case problems of other mods (files not found because of upper/lower case) are not part of this mod. For them,
MKev's Modpatch Installer v1.3 brings the optional Linux-Guard (`Linux-Guard/start-server.sh`, see its `Guide.txt`).

Upstream notes: `UPSTREAM.md`. German: `README_DE.md`.
