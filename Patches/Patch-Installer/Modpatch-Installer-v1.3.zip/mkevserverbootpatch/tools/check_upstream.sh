#!/bin/sh
# MKevServerBootPatch v1.1.2 - check / self-heal for Linux servers. Author: MKev.
# Same logic as tools/bootfix.ps1 (ModPatchInstaller 1.2+, check_upstream.ps1).
#
# Usage: sh check_upstream.sh [--fix] [WORKSHOP_CONTENT_108600 ...]
#   without --fix: dry run, shows what would happen, writes NOTHING.
#   --fix: writes only into THIS mod folder (the folder above tools/). Workshop folders are only read.
# Workshop folders: arguments, else $PZ_WORKSHOP (';' or ':' list), else common Steam / server paths.
# PZ_GAMEBUILD=42.22 caps the version folder the game would load (default: highest 42.x folder of the mod).
#
# Per fix: KEEP (original unchanged, bundled file stays) | REBUILT (original changed, fix rebuilt + checked)
# | FIXED_UPSTREAM / NOT_LOADED (our override is removed) | MISSING (mod not found, bundled file stays)
# | FAIL (rebuilt file failed the checks, current file stays, nothing broken is written).
# Exit code: 0 nothing to do / done, 2 dry run found changes to apply, 3 at least one FAIL.
LC_ALL=C; export LC_ALL
FIX=0; ROOTS=''
for a in "$@"; do
  case "$a" in
    --fix) FIX=1 ;;
    -h|--help) sed -n '2,16p' "$0"; exit 0 ;;
    *) ROOTS="$ROOTS
$a" ;;
  esac
done
if [ -z "$ROOTS" ]; then
  if [ -n "$PZ_WORKSHOP" ]; then ROOTS=$(printf '%s\n' "$PZ_WORKSHOP" | tr ';:' '\n\n')
  else ROOTS="/serverdata/serverfiles/steamapps/workshop/content/108600
$HOME/Steam/steamapps/workshop/content/108600
$HOME/.steam/steam/steamapps/workshop/content/108600
$HOME/.local/share/Steam/steamapps/workshop/content/108600"
  fi
fi
IFS='
'
HERE=$(cd "$(dirname "$0")" && pwd); MODROOT=$(dirname "$HERE")
case "$MODROOT" in */steamapps/workshop/*) echo "Safety stop: this mod folder is inside a Workshop folder."; exit 1 ;; esac
TMP=$(mktemp -d) || exit 1; trap 'rm -rf "$TMP"' EXIT

sha() { if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | cut -c1-64; else shasum -a 256 "$1" | cut -c1-64; fi | tr a-f A-F; }
lc() { printf '%s' "$1" | tr 'A-Z' 'a-z'; }
# case-insensitive child: ci DIR NAME d|f
ci() {
  [ -d "$1" ] || return 1; want=$(lc "$2")
  for c in "$1"/* "$1"/.[!.]*; do
    [ -e "$c" ] || continue; b=${c##*/}
    [ "$(lc "$b")" = "$want" ] || continue
    if [ "$3" = d ] && [ -d "$c" ]; then printf '%s\n' "$c"; return 0; fi
    if [ "$3" = f ] && [ -f "$c" ]; then printf '%s\n' "$c"; return 0; fi
  done
  return 1
}
cipath() { # BASE REL d|f
  p=$1; rest=$2
  while [ -n "$rest" ]; do
    seg=${rest%%/*}; if [ "$seg" = "$rest" ]; then rest=''; t=$3; else rest=${rest#*/}; t=d; fi
    p=$(ci "$p" "$seg" "$t") || return 1
  done
  printf '%s\n' "$p"
}
# highest 42.x folder (<= PZ_GAMEBUILD if set)
bestver() {
  for c in "$1"/*; do [ -d "$c" ] && printf '%s\n' "${c##*/}"; done | awk -v cap="$PZ_GAMEBUILD" '
    function key(s,  a,n,i,k){ n=split(s,a,"."); k=""; for(i=1;i<=4;i++){ k=k sprintf("%010d", (i<=n)?a[i]+0:0) } return k }
    $0 ~ /^42(\.[0-9]+)?(\.[0-9]+)?(\.[0-9]+)?$/ { if (cap ~ /^[0-9]+(\.[0-9]+)?(\.[0-9]+)?(\.[0-9]+)?$/ && key($0) > key(cap)) next
      if (best=="" || key($0) > key(best)) best=$0 }
    END { if (best!="") print best }'
}
# find source: sets FOUND (file|mod|none), SRC, REL
findsrc() { # WS MOD SUB
  FOUND=none; SRC=''; REL=''
  for r in $ROOTS; do
    m=$(cipath "$r" "$1/mods/$2" d) || continue
    mrel="$1/mods/${m##*/}"
    v=$(bestver "$m")
    if [ -n "$v" ] && p=$(cipath "$m/$v" "$3" f); then FOUND=file; SRC=$p; REL="$mrel/$v/$3"; return; fi
    if c=$(ci "$m" common d) && p=$(cipath "$c" "$3" f); then FOUND=file; SRC=$p; REL="$mrel/${c##*/}/$3"; return; fi
    FOUND=mod; REL=$mrel; return
  done
}
# token edit: edit KIND FROM TO IN OUT -> prints number of edited lines
edit() {
  trail=1; [ -s "$4" ] && [ "$(tail -c1 "$4" | od -An -tx1 | tr -d ' \n')" != "0a" ] && trail=0
  awk -v kind="$1" -v from="$2" -v to="$3" -v trail="$trail" -v statf="$TMP/edits" '
    function isw(c){ return c ~ /[A-Za-z0-9_]/ }
    function repl(s,  out,i,f){ f=from ":"; out=""
      while ((i=index(s,f))>0) { if (i>1 && isw(substr(s,i-1,1))) { out=out substr(s,1,i+length(f)-1); s=substr(s,i+length(f)); continue }
        out=out substr(s,1,i-1) to ":"; s=substr(s,i+length(f)) } return out s }
    function block(s,in_,  i,two){ i=1; while (i<length(s)) { two=substr(s,i,2)
        if (!in_ && two=="/*") { in_=1; i+=2; continue } if (in_ && two=="*/") { in_=0; i+=2; continue } i++ } return in_ }
    function trimws(s){ sub(/^[ \t]+/,"",s); sub(/[ \t]+$/,"",s); return s }
    { lines[NR]=$0 }
    END { n=NR; ed=0; inb=0
      for (k=1;k<=n;k++) { ln=lines[k]; bom=""
        if (k==1 && substr(ln,1,3)=="\357\273\277") { bom=substr(ln,1,3); ln=substr(ln,4) }
        cr=""; if (substr(ln,length(ln),1)=="\r") { cr="\r"; ln=substr(ln,1,length(ln)-1) }
        nw=ln
        if (kind=="skill") { if (ln ~ /^[ \t]*([Ss][Kk][Ii][Ll][Ll][Rr][Ee][Qq][Uu][Ii][Rr][Ee][Dd]|[Aa][Uu][Tt][Oo][Ll][Ee][Aa][Rr][Nn][Aa][Ll][Ll]|[Aa][Uu][Tt][Oo][Ll][Ee][Aa][Rr][Nn][Aa][Nn][Yy]|[Xx][Pp][Aa][Ww][Aa][Rr][Dd])[ \t]*=/) nw=repl(ln) }
        else { if (!inb && match(ln, /^[ \t]*\/\//)) { lead=substr(ln,1,RLENGTH-2); rest=trimws(substr(ln,RLENGTH+1)); gsub(/\*\//,"* /",rest); nw=lead "/* " rest " */" }
               else inb=block(ln,inb) }
        if (nw!=ln) ed++
        printf "%s%s%s", bom, nw, cr
        if (k<n || trail) printf "\n" }
      print ed > statf }' "$4" > "$5"
  cat "$TMP/edits"
}
braces_ok() { awk 'BEGIN{d=0;bad=0} { n=length($0); for(i=1;i<=n;i++){c=substr($0,i,1); if(c=="{")d++; else if(c=="}"){d--; if(d<0)bad=1}} } END{ exit (bad||d!=0) }' "$1"; }
cnt() { tr -cd "$1" < "$2" | wc -c | tr -d ' '; }
nlines() { awk 'END{print NR}' "$1"; }
# transform KIND FROM TO SRC OUT -> TSTAT = OK|CLEAN|FAIL, TWHY
transform() {
  TWHY=''
  e=$(edit "$1" "$2" "$3" "$4" "$5")
  if [ "$e" = 0 ]; then TSTAT=CLEAN; return; fi
  if ! braces_ok "$4"; then TSTAT=FAIL; TWHY=braces; return; fi
  e2=$(edit "$1" "$2" "$3" "$5" "$TMP/again")
  if [ "$e2" != 0 ]; then TSTAT=FAIL; TWHY=tokens; return; fi
  # only the edited lines differ, line ends kept
  d=$(awk 'NR==FNR { a[FNR]=$0; na=FNR; next } { if (FNR in a) { if (a[FNR]!=$0) { diff++; if ((substr(a[FNR],length(a[FNR]),1)=="\r") != (substr($0,length($0),1)=="\r")) bad=1 } } else bad=1; nb=FNR }
       END { if (na!=nb) bad=1; print (bad ? -1 : diff+0) }' "$4" "$5")
  if [ "$d" != "$e" ]; then TSTAT=FAIL; TWHY=changes; return; fi
  if ! braces_ok "$5" || [ "$(cnt '{' "$4")" != "$(cnt '{' "$5")" ] || [ "$(cnt '}' "$4")" != "$(cnt '}' "$5")" ]; then TSTAT=FAIL; TWHY=braces; return; fi
  TSTAT=OK
}
manifest() {
  mf="$MODROOT/MANIFEST.sha256"; [ -f "$mf" ] || return 0
  { grep -v -E '  (42/media/scripts/recipes/recipes_fletching\.txt|42/media/scripts/recipes/recipes_MCR_1Handed\.txt|42/media/scripts/sounds/LabSounds\.txt)$' "$mf" | grep -v '^$'
    for rel in 42/media/scripts/recipes/recipes_fletching.txt 42/media/scripts/recipes/recipes_MCR_1Handed.txt 42/media/scripts/sounds/LabSounds.txt; do
      [ -f "$MODROOT/$rel" ] && printf '%s  %s\n' "$(sha "$MODROOT/$rel" | tr A-F a-f)" "$rel"; done
  } | awk '{ print substr($0,67) "\t" $0 }' | sort | cut -f2- > "$TMP/mf" && cat "$TMP/mf" > "$mf"
}

pending=0; failed=0; wrote=0
fixone() { # ID LABEL WS MOD SUB DST KIND FROM TO SRCSHA
  findsrc "$3" "$4" "$5"; dst="$MODROOT/$6"
  if [ "$FOUND" = none ]; then echo "$1 $2: MISSING - mod not found in the Workshop folders, bundled fix stays."; return; fi
  if [ "$FOUND" = mod ]; then
    if [ -f "$dst" ]; then
      if [ $FIX = 1 ]; then rm -f "$dst"; wrote=1; echo "$1 $2: NOT_LOADED - the mod no longer loads this file ($REL), override removed."
      else pending=1; echo "$1 $2: NOT_LOADED - the mod no longer loads this file ($REL), override would be removed."; fi
    else echo "$1 $2: NOT_LOADED - the mod no longer loads this file ($REL), no override present."; fi
    return
  fi
  transform "$7" "$8" "$9" "$SRC" "$TMP/out"
  if [ "$(sha "$SRC")" = "${10}" ]; then
    if [ -f "$dst" ] && cmp -s "$TMP/out" "$dst"; then echo "$1 $2: KEEP - original unchanged ($REL), bundled fix fits."; return; fi
    if [ $FIX = 1 ]; then mkdir -p "$(dirname "$dst")"; cat "$TMP/out" > "$TMP/new" && mv -f "$TMP/new" "$dst"; wrote=1; echo "$1 $2: KEEP - original unchanged ($REL), bundled fix restored."
    else pending=1; echo "$1 $2: KEEP - original unchanged ($REL), bundled fix would be restored."; fi
    return
  fi
  case "$TSTAT" in
    CLEAN)
      if [ -f "$dst" ]; then
        if [ $FIX = 1 ]; then rm -f "$dst"; wrote=1; echo "$1 $2: FIXED_UPSTREAM - the mod author fixed it ($REL), override removed."
        else pending=1; echo "$1 $2: FIXED_UPSTREAM - the mod author fixed it ($REL), override would be removed."; fi
      else echo "$1 $2: FIXED_UPSTREAM - the mod author fixed it ($REL), no override present."; fi ;;
    FAIL)
      failed=1; echo "WARNING $1 $2: FAIL - original changed ($REL), but the rebuilt file failed the check ($TWHY). Current file kept, nothing written. Please report to MKev." ;;
    OK)
      if [ -f "$dst" ] && cmp -s "$TMP/out" "$dst"; then echo "$1 $2: REBUILT - original changed ($REL), override already up to date."; return; fi
      if [ $FIX = 1 ]; then mkdir -p "$(dirname "$dst")"; cat "$TMP/out" > "$TMP/new" && mv -f "$TMP/new" "$dst"; wrote=1; echo "$1 $2: REBUILT - original changed ($REL), fix rebuilt and written."
      else pending=1; echo "$1 $2: REBUILT - original changed ($REL), fix would be rebuilt."; fi ;;
  esac
}
n=0; for r in $ROOTS; do [ -d "$r" ] && n=$((n+1)); done
[ $n = 0 ] && echo "Note: no Workshop folder found (give it as argument or set PZ_WORKSHOP)."
fixone F1 'Archery Nexus [Fixed]' 3731579266 ArcheryNexusFixed media/scripts/recipes/recipes_fletching.txt 42/media/scripts/recipes/recipes_fletching.txt skill Carpentry Woodwork 68B87D921EAEB41D2799919BDB75446FB9EBCFAD98376174A7D89FAEF0096678
fixone F2 'Mad Crafter' 3418701509 MadCrafter media/scripts/recipes/recipes_MCR_1Handed.txt 42/media/scripts/recipes/recipes_MCR_1Handed.txt skill Electrical Electricity 7B4591967E8FC50B337E6C210D2BC0C28B9CC5ECBC565CE41DE2567FD437CFEF
fixone F3 'Zombie Virus Vaccine' 3615135168 ZVirusVaccine42BETA media/scripts/sounds/LabSounds.txt 42/media/scripts/sounds/LabSounds.txt comment '' '' 85F28B209C94105F597900691C92E8E52D277871175E9B36241C974309F18FCD
[ $wrote = 1 ] && manifest
if [ $failed = 1 ]; then echo "RESULT WARN - see WARNING lines"; exit 3; fi
if [ $pending = 1 ]; then echo "RESULT CHANGES - run again with --fix to apply (server stopped, same files on all clients)"; exit 2; fi
if [ $FIX = 1 ] && [ $wrote = 1 ]; then echo "RESULT FIXED - restart the server; clients need the same mkevserverbootpatch files"; exit 0; fi
echo "RESULT OK - nothing to change"; exit 0
