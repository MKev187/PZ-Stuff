# MKev's Modpatch Installer v1.32 - README

Autor: MKev.

*English version: [ReadMe_EN.md](ReadMe_EN.md)*

**Inhalt:** `mkev_modpatcher` 1.2, `mkevserverbootpatch` 1.1.2, `Linux-Guard` 1.0.0 (optional, Linux-Server), `MKevServer_setup` (Server-Dateien + Preset, Stand MKev-Server 09.11.2026).
**Basis:** Build 42.22.2, Collection 3827894199 "MKev Zomboid Modlist B42.22": 376 Mods / 325 WorkshopItems, Map `Muldraugh, KY`.
I Know It! wird nicht mitgeliefert. Es kommt wie alle Collection-Mods aus dem Steam Workshop (3836594593).

## Benutzung

1. Spiel und Server komplett beenden. Sonst bricht der Installer ab.
2. Zip komplett entpacken und `ModPatchInstaller.bat` doppelklicken.
3. **Zuerst die Sprache wählen:** Taste `1` für English oder `2` für Deutsch.
4. Im Menü Fragen mit `J` oder `N` beantworten. `Y` gilt auch als „ja“.

## Die zwei Modi

| Punkt | Was passiert |
|---|---|
| **1** Installieren & Einrichten | **Bestehende Server-Dateien anpassen.** Zeigt erst alle Änderungen, fragt J/N und sichert vorher alles. Logins und Ports bleiben erhalten. |
| **2** Installieren & nicht Einrichten | **Separater Ordner.** Nur die zwei Patches und fertige Vorlagen nach `Zomboid\MKevServer_setup` (Modliste, WorkshopItems, Map, SandboxVars, Preset, Anleitung). Keine Einstellung wird geändert. |
| **3** Backup wiederherstellen | Stellt den Zustand vor einem Lauf wieder her. |
| **4** Beenden | |
| **5** Probelauf | Zeigt nur an, was Punkt 1 ändern würde. Schreibt nichts. |

### Was Punkt 1 genau macht

- Kopiert `mkev_modpatcher` und `mkevserverbootpatch` nach `Zomboid\mods`.
- `Zomboid\Server\servertest.ini`: Es werden NUR die Zeilen `Mods=`, `WorkshopItems=` und `Map=` ersetzt. Passwörter, Ports, Servername und alle anderen Zeilen bleiben unverändert.
- `servertest_SandboxVars.lua` wird durch die Einstellungen des MKev-Servers ersetzt. Die alte Datei liegt im Backup.
- Fügt das Mod-Preset „MKevServer“ in `Zomboid\Lua\pz_modlist_settings.cfg` hinzu. Eigene Presets bleiben.
- Trägt `mkev_modpatcher` in `Zomboid\mods\default.txt` ein.

## Dedicated Server

- Die Ordner `mkev_modpatcher` und `mkevserverbootpatch` aus dem Zip in den `Zomboid/mods/`-Ordner deines Servers kopieren (der Ordner mit `Server/` und `Saves/`) und `mkev_modpatcher;mkevserverbootpatch` in die `Mods=`-Zeile der Server-.ini eintragen.
- **Nur Linux-Server, optional:** `Linux-Guard/` behebt Mod-Dateien, die Linux wegen Groß- und Kleinschreibung nicht findet (kleingeschriebene Verknüpfungen, nichts wird umbenannt). Welcher der 3 Fälle zu deinem Host passt: `Linux-Guard/Guide.txt`. Nichts muss bearbeitet werden.

## Hinweise

- **Boot-Patch:** Die 3 Skript-Fixes sind ab BootPatch 1.1.1 fester Bestandteil des Mods, deshalb läuft der Mod auch auf Linux-Servern ohne Installer (Ordner `mkevserverbootpatch` nach `Zomboid/mods/` kopieren). Bei jeder Installation vergleicht der Installer die Fixes mit deinen Workshop-Originalen (nur gelesen): unverändert → mitgelieferte Datei bleibt; nach einem Mod-Update wird der Fix neu geschrieben und geprüft; hat der Autor den Fehler behoben, wird unser Override entfernt. Besteht ein neu geschriebener Fix die Prüfung nicht, bleibt die bisherige Datei und es kommt eine „WARNUNG“; die Installation läuft trotzdem. Details: `mkevserverbootpatch/README_DE.md`.
- **Andere Steam-Bibliothek (für den Abgleich der Boot-Fixes):** Setz die Umgebungsvariable `PZ_WORKSHOP` auf `...\steamapps\workshop\content\108600`.
- **Backups:** liegen unter `Zomboid\mkev_patch_backups\<Datum_Uhrzeit>\` (Menüpunkt 3).
- **Sprachabfrage überspringen:** Setz `PZ_LANG=en` oder `PZ_LANG=de`, oder starte `ModPatchInstaller_en.ps1` bzw. `ModPatchInstaller_de.ps1` direkt.
- Änderungen (v1.32, v1.31, v1.3b, v1.3, v1.2, v1.1b, v1.1 und v1.0) stehen in `CHANGELOG.md`.
