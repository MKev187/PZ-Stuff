# MKev's Modpatch Installer v1.32 - README

Author: MKev.

*Deutsche Version: [ReadMe_DE.md](ReadMe_DE.md)*

**Contents:** `mkev_modpatcher` 1.2, `mkevserverbootpatch` 1.1.2, `Linux-Guard` 1.0.0 (optional, Linux servers), and `MKevServer_setup` (server files and preset, MKev server state of 2026-11-09).
**Base:** build 42.22.2 and collection 3827894199 "MKev Zomboid Modlist B42.22", with 376 mods / 325 WorkshopItems and map `Muldraugh, KY`.
I Know It! is not included. Like all collection mods, it comes from the Steam Workshop (3836594593).

## How to use

1. Close the game and the server completely, otherwise the installer aborts.
2. Extract the whole zip, then double-click `ModPatchInstaller.bat`.
3. **Choose the language first:** press `1` for English or `2` for Deutsch.
4. Answer the questions with `Y` or `N`. `J` is also accepted as "yes".

## The two modes

| Option | What it does |
|---|---|
| **1** Install & set up | **Adapts your existing server files.** It first shows all changes, asks Y/N and backs everything up. Logins and ports are kept. |
| **2** Install only | **Separate folder.** It copies only the two patches and ready-made templates to `Zomboid\MKevServer_setup` (mod list, WorkshopItems, map, SandboxVars, preset, instructions). No setting is changed. |
| **3** Restore backup | Puts back the state from before a run. |
| **4** Quit | |
| **5** Dry run | Only shows what option 1 would change. It writes nothing. |

### What option 1 does exactly

- Copies `mkev_modpatcher` and `mkevserverbootpatch` to `Zomboid\mods`.
- `Zomboid\Server\servertest.ini`: ONLY the lines `Mods=`, `WorkshopItems=` and `Map=` are replaced. Passwords, ports, the server name and all other lines stay unchanged.
- Replaces `servertest_SandboxVars.lua` with the MKev server settings. The old file is kept in the backup.
- Adds the mod preset "MKevServer" to `Zomboid\Lua\pz_modlist_settings.cfg`. Your own presets are kept.
- Adds `mkev_modpatcher` to `Zomboid\mods\default.txt`.

## Dedicated server

- Copy the folders `mkev_modpatcher` and `mkevserverbootpatch` from the zip into the `Zomboid/mods/` folder of your server (the folder that contains `Server/` and `Saves/`) and add `mkev_modpatcher;mkevserverbootpatch` to the `Mods=` line of the server .ini.
- **Linux servers only, optional:** `Linux-Guard/` fixes mod files that Linux does not find because of upper and lower case (lowercase links, nothing is renamed). Which of the 3 setups fits your host: `Linux-Guard/Guide.txt`. Nothing has to be edited.

## Notes

- **Boot patch:** since BootPatch 1.1.1 the 3 script fixes are fixed parts of the mod. So the mod also works on Linux servers without the installer (copy the folder `mkevserverbootpatch` to `Zomboid/mods/`). At every install the installer compares the fixes with your Workshop originals (read only): unchanged -> bundled file stays; after a mod update the fix is rewritten and checked; if the author fixed the error, our override is removed. If a rewritten fix fails the check, the previous file stays and a "WARNING" is shown; the install still runs. Details: `mkevserverbootpatch/README.md`.
- **Other Steam library (for the boot fix check):** set the environment variable `PZ_WORKSHOP` to `...\steamapps\workshop\content\108600`.
- **Backups:** they are stored in `Zomboid\mkev_patch_backups\<date_time>\` (menu option 3).
- **Skip the language question:** set `PZ_LANG=en` or `PZ_LANG=de`, or start `ModPatchInstaller_en.ps1` or `ModPatchInstaller_de.ps1` directly.
- Changes (v1.32, v1.31, v1.3b, v1.3, v1.2, v1.1b, v1.1 and v1.0) are listed in `CHANGELOG.md`.
