SandboxVars = {
    VERSION = 6,
    -- Changing this also sets the "Population Multiplier" in Advanced Zombie Options. Default = Normal
    -- 1 = Insane
    -- 2 = Very High
    -- 3 = High
    -- 4 = Normal
    -- 5 = Low
    -- 6 = None
    Zombies = 4,
    -- How zombies are distributed across the map. Default = Urban Focused
    -- 1 = Urban Focused
    -- 2 = Uniform
    Distribution = 1,
    -- Controls whether some randomization is applied to zombie distribution.
    ZombieVoronoiNoise = true,
    -- How frequently new zombies are added to the world. Default = None
    -- 1 = High
    -- 2 = Normal
    -- 3 = Low
    -- 4 = None
    ZombieRespawn = 4,
    -- Zombie allowed to migrate to empty cells.
    ZombieMigrate = true,
    -- Default = 1 Hour, 30 Minutes
    -- 1 = 15 Minutes
    -- 2 = 30 Minutes
    -- 3 = 1 Hour
    -- 4 = 1 Hour, 30 Minutes
    -- 5 = 2 Hours
    -- 6 = 3 Hours
    -- 7 = 4 Hours
    -- 8 = 5 Hours
    -- 9 = 6 Hours
    -- 10 = 7 Hours
    -- 11 = 8 Hours
    -- 12 = 9 Hours
    -- 13 = 10 Hours
    -- 14 = 11 Hours
    -- 15 = 12 Hours
    -- 16 = 13 Hours
    -- 17 = 14 Hours
    -- 18 = 15 Hours
    -- 19 = 16 Hours
    -- 20 = 17 Hours
    -- 21 = 18 Hours
    -- 22 = 19 Hours
    -- 23 = 20 Hours
    -- 24 = 21 Hours
    -- 25 = 22 Hours
    -- 26 = 23 Hours
    -- 27 = Real-time
    DayLength = 4,
    StartYear = 1,
    -- Month in which the game starts. Default = July
    -- 1 = January
    -- 2 = February
    -- 3 = March
    -- 4 = April
    -- 5 = May
    -- 6 = June
    -- 7 = July
    -- 8 = August
    -- 9 = September
    -- 10 = October
    -- 11 = November
    -- 12 = December
    StartMonth = 7,
    -- Day of the month in which the games starts.
    StartDay = 9,
    -- Hour of the day in which the game starts. Default = 9 AM
    -- 1 = 7 AM
    -- 2 = 9 AM
    -- 3 = 12 PM
    -- 4 = 2 PM
    -- 5 = 5 PM
    -- 6 = 9 PM
    -- 7 = 12 AM
    -- 8 = 2 AM
    -- 9 = 5 AM
    StartTime = 9,
    -- Whether the time of day changes naturally, or it's always day/night. Default = Normal
    -- 1 = Normal
    -- 2 = Endless Day
    -- 3 = Endless Night
    DayNightCycle = 1,
    -- Whether weather changes or remains at a single state. Default = Normal
    -- 1 = Normal
    -- 2 = No Weather
    -- 3 = Endless Rain
    -- 4 = Endless Storm
    -- 5 = Endless Snow
    -- 6 = Endless Blizzard
    ClimateCycle = 1,
    -- Whether fog occurs naturally, never occurs, or is always present. Default = Normal
    -- 1 = Normal
    -- 2 = No Fog
    -- 3 = Endless Fog
    FogCycle = 1,
    -- How long after the default start date (July 9, 1993) that plumbing fixtures (eg. sinks) stop being infinite sources of water. Default = 0 - 30 Days
    -- 1 = Instant
    -- 2 = 0 - 30 Days
    -- 3 = 0 - 2 Months
    -- 4 = 0 - 6 Months
    -- 5 = 0 - 1 Year
    -- 6 = 0 - 5 Years
    -- 7 = 2 - 6 Months
    -- 8 = 6 - 12 Months
    -- 9 = Disabled
    WaterShut = 2,
    -- How long after the default start date (July 9, 1993) that the world's electricity turns off for good. Default = 14 - 30 Days
    -- 1 = Instant
    -- 2 = 14 - 30 Days
    -- 3 = 14 Days - 2 Months
    -- 4 = 14 Days - 6 Months
    -- 5 = 14 Days - 1 Year
    -- 6 = 14 Days - 5 Years
    -- 7 = 2 - 6 Months
    -- 8 = 6 - 12 Months
    -- 9 = Disabled
    ElecShut = 2,
    -- How long alarm batteries can last for after the power shuts off. Default = 0 - 30 Days
    -- 1 = Instant
    -- 2 = 0 - 30 Days
    -- 3 = 0 - 2 Months
    -- 4 = 0 - 6 Months
    -- 5 = 0 - 1 Year
    -- 6 = 0 - 5 Years
    AlarmDecay = 2,
    -- How long after the default start date (July 9, 1993) that plumbing fixtures (eg. sinks) stop being infinite sources of water. Min: -1 Max: 2147483647 Default: 14
    WaterShutModifier = 3,
    -- How long after the default start date (July 9, 1993) that the world's electricity turns off for good. Min: -1 Max: 2147483647 Default: 14
    ElecShutModifier = 22,
    -- How long alarm batteries can last for after the power shuts off. Min: -1 Max: 2147483647 Default: 14
    AlarmDecayModifier = 14,
    -- Any food that can rot or spoil. Min: 0.00 Max: 4.00 Default: 0.80
    FoodLootNew = 0.8,
    -- All other items that can be read, including books, fliers, and newspapers. Min: 0.00 Max: 4.00 Default: 0.60
    LiteratureLootNew = 0.6,
    -- Books that provide skill XP multipliers. Min: 0.00 Max: 4.00 Default: 0.60
    SkillBookLoot = 0.6,
    -- Items that teach recipes. Min: 0.00 Max: 4.00 Default: 0.60
    RecipeResourceLoot = 0.6,
    -- Medicine, bandages and first aid tools. Min: 0.00 Max: 4.00 Default: 0.60
    MedicalLootNew = 0.6,
    -- Fishing Rods, Tents, camping gear etc. Min: 0.00 Max: 4.00 Default: 0.60
    SurvivalGearsLootNew = 0.6,
    -- Canned and dried food, beverages. Min: 0.00 Max: 4.00 Default: 0.60
    CannedFoodLootNew = 0.6,
    -- Weapons that are not tools in other categories. Min: 0.00 Max: 4.00 Default: 0.60
    WeaponLootNew = 0.6,
    -- Also includes weapon attachments. Min: 0.00 Max: 4.00 Default: 1.20
    RangedWeaponLootNew = 1.2,
    -- Loose ammo, boxes and magazines. Min: 0.00 Max: 4.00 Default: 0.60
    AmmoLootNew = 0.6,
    -- Vehicle parts and the tools needed to install them. Min: 0.00 Max: 4.00 Default: 0.60
    MechanicsLootNew = 0.6,
    -- Everything else. Also affects foraging for all items in Town/Road zones. Min: 0.00 Max: 4.00 Default: 0.80
    OtherLootNew = 0.8,
    -- All wearable items that are not containers. Min: 0.00 Max: 4.00 Default: 0.60
    ClothingLootNew = 0.6,
    -- Backpacks and other wearable/equippable containers, eg. cases. Min: 0.00 Max: 4.00 Default: 0.60
    ContainerLootNew = 0.6,
    -- Keys for buildings/cars, key rings, and locks. Min: 0.00 Max: 4.00 Default: 0.40
    KeyLootNew = 0.4,
    -- VHS tapes and CDs. Min: 0.00 Max: 4.00 Default: 0.60
    MediaLootNew = 0.6,
    -- Spiffo items, plushies, and other collectible keepsake items eg. Photos. Min: 0.00 Max: 4.00 Default: 0.60
    MementoLootNew = 0.6,
    -- Items that are used in cooking, including those (eg. knives) which can be weapons. Does not include food. Includes both usable and unusable items. Min: 0.00 Max: 4.00 Default: 0.60
    CookwareLootNew = 0.6,
    -- Items and weapons that are used as ingredients for crafting or building. This is a general category that does not include items belonging to other categories such as Cookware or Medical. Does not include Tools. Min: 0.00 Max: 4.00 Default: 0.60
    MaterialLootNew = 0.6,
    -- Items and weapons which are used in both animal and plant agriculture, such as Seeds, Trowels, or Shovels. Min: 0.00 Max: 4.00 Default: 0.60
    FarmingLootNew = 0.6,
    -- Items and weapons which are Tools but don't fit in other categories such as Mechanics or Farming. Min: 0.00 Max: 4.00 Default: 0.60
    ToolLootNew = 0.6,
    -- <BHC> [!] It is recommended that you DO NOT change this. [!] <RGB:1,1,1>   Can be used to adjust the number of rolls made on loot tables when spawning loot. Will not reduce the number of rolls below 1. Can negatively affect performance if set to high values. It is highly recommended that this not be changed. Min: 0.10 Max: 100.00 Default: 1.00
    RollsMultiplier = 1.0,
    -- A comma-separated list of item types that won't spawn as ordinary loot.
    LootItemRemovalList = "",
    -- If enabled, items on the Loot Item Removal List, or that have their rarity set to 'None', will not spawn in randomised world stories.
    RemoveStoryLoot = false,
    -- If enabled, items on the Loot Item Removal List, or that have their rarity set to 'None', will not spawn worn by, or attached to, zombies.
    RemoveZombieLoot = false,
    -- If greater than 0, the spawn of loot is increased relative to the number of nearby zombies,  with the effect multiplied by this number. Min: 0 Max: 20 Default: 0
    ZombiePopLootEffect = 0,
    -- Min: 0.00 Max: 0.20 Default: 0.05
    InsaneLootFactor = 0.05,
    -- Min: 0.05 Max: 0.60 Default: 0.20
    ExtremeLootFactor = 0.2,
    -- Min: 0.20 Max: 1.00 Default: 0.60
    RareLootFactor = 0.6,
    -- Min: 0.60 Max: 2.00 Default: 1.00
    NormalLootFactor = 1.0,
    -- Min: 1.00 Max: 3.00 Default: 2.00
    CommonLootFactor = 2.0,
    -- Min: 2.00 Max: 4.00 Default: 3.00
    AbundantLootFactor = 3.0,
    -- The global temperature. Default = Normal
    -- 1 = Very Cold
    -- 2 = Cold
    -- 3 = Normal
    -- 4 = Hot
    -- 5 = Very Hot
    Temperature = 3,
    -- How often it rains. Default = Normal
    -- 1 = Very Dry
    -- 2 = Dry
    -- 3 = Normal
    -- 4 = Rainy
    -- 5 = Very Rainy
    Rain = 3,
    -- Number of days until the erosion system (which adds vines, long grass, new trees etc. to the world) will reach 100% growth. Default = Slow (200 Days)
    -- 1 = Very Fast (20 Days)
    -- 2 = Fast (50 Days)
    -- 3 = Normal (100 Days)
    -- 4 = Slow (200 Days)
    -- 5 = Very Slow (500 Days)
    ErosionSpeed = 4,
    -- For a custom Erosion Speed. Zero means use the Erosion Speed option. Maximum is 36,500 days (approximately 100 years). Min: -1 Max: 36500 Default: 0
    ErosionDays = 0,
    -- The speed of plant growth. Default = Normal
    -- 1 = Very Fast
    -- 2 = Fast
    -- 3 = Normal
    -- 4 = Slow
    -- 5 = Very Slow
    Farming = 3,
    -- How long it takes for food to break down in a composter. Default = 2 Weeks
    -- 1 = 1 Week
    -- 2 = 2 Weeks
    -- 3 = 3 Weeks
    -- 4 = 4 Weeks
    -- 5 = 6 Weeks
    -- 6 = 8 Weeks
    -- 7 = 10 Weeks
    -- 8 = 12 Weeks
    CompostTime = 2,
    -- How fast the player's hunger, thirst, and fatigue will decrease. Default = Normal
    -- 1 = Very Fast
    -- 2 = Fast
    -- 3 = Normal
    -- 4 = Slow
    -- 5 = Very Slow
    StatsDecrease = 3,
    -- The abundance of items found in Foraging mode. Default = Normal
    -- 1 = Very Poor
    -- 2 = Poor
    -- 3 = Normal
    -- 4 = Abundant
    -- 5 = Very Abundant
    NatureAbundance = 3,
    -- How likely the player is to activate a house alarm when breaking into a new house. Default = Sometimes
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    Alarm = 4,
    -- How frequently the doors of homes and buildings will be locked when discovered. Default = Very Often
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    LockedHouses = 6,
    -- Spawn with Chips, a Water Bottle, a Small Backpack, a Baseball Bat, and a Hammer.
    StarterKit = false,
    -- Nutritional value of food affects the player's condition. Turning this off will stop the player gaining or losing weight.
    Nutrition = true,
    -- How fast that food will spoil, inside or outside of a fridge. Default = Normal
    -- 1 = Very Fast
    -- 2 = Fast
    -- 3 = Normal
    -- 4 = Slow
    -- 5 = Very Slow
    FoodRotSpeed = 3,
    -- How effective a fridge will be at keeping food fresh for longer. Default = Normal
    -- 1 = Very Low
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Very High
    -- 6 = No decay
    FridgeFactor = 3,
    -- When greater than 0, loot will not respawn in zones that have been visited within this number of in-game hours. Min: 0 Max: 2147483647 Default: 0
    SeenHoursPreventLootRespawn = 0,
    -- When greater than 0, after X hours, all containers in towns and trailer parks in the world will respawn loot. To spawn loot a container must have been looted at least once. Loot respawn is not impacted by visibility or subsequent looting. Min: 0 Max: 2147483647 Default: 0
    HoursForLootRespawn = 0,
    -- Containers with a number of items greater, or equal to, this setting will not respawn. Min: 0 Max: 2147483647 Default: 5
    MaxItemsForLootRespawn = 5,
    -- Items will not respawn in buildings that players have barricaded or built in.
    ConstructionPreventsLootRespawn = true,
    -- A comma-separated list of item types that will be removed after HoursForWorldItemRemoval hours.
    WorldItemRemovalList = "Base.Hat, Base.Glasses, Base.Maggots, Base.Slug, Base.Slug2, Base.Snail, Base.Worm, Base.Dung_Mouse, Base.Dung_Rat",
    -- Number of hours since an item was dropped on the ground before it is removed.  Items are removed the next time that part of the map is loaded.   Zero means items are not removed. Min: 0.00 Max: 2147483647.00 Default: 24.00
    HoursForWorldItemRemoval = 24.0,
    -- If true, any items *not* in WorldItemRemovalList will be removed.
    ItemRemovalListBlacklistToggle = false,
    -- How long after the end of the world to begin. This will affect starting world erosion and food spoilage. Does not affect the starting date. Default = 0
    -- 1 = 0
    -- 2 = 1
    -- 3 = 2
    -- 4 = 3
    -- 5 = 4
    -- 6 = 5
    -- 7 = 6
    -- 8 = 7
    -- 9 = 8
    -- 10 = 9
    -- 11 = 10
    -- 12 = 11
    -- 13 = 12
    TimeSinceApo = 1,
    -- How much water plants will lose per day, and their ability to avoid disease. Default = Normal
    -- 1 = Very High
    -- 2 = High
    -- 3 = Normal
    -- 4 = Low
    -- 5 = Very Low
    PlantResilience = 3,
    -- The yield of plants when harvested. Default = Normal
    -- 1 = Very Poor
    -- 2 = Poor
    -- 3 = Normal
    -- 4 = Abundant
    -- 5 = Very Abundant
    PlantAbundance = 3,
    -- Recovery from being tired after performing actions. Default = Normal
    -- 1 = Very Fast
    -- 2 = Fast
    -- 3 = Normal
    -- 4 = Slow
    -- 5 = Very Slow
    EndRegen = 3,
    -- How regularly a helicopter passes over the Event Zone. Default = Once
    -- 1 = Never
    -- 2 = Once
    -- 3 = Sometimes
    -- 4 = Often
    Helicopter = 2,
    -- How often zombie-attracting metagame events like distant gunshots will occur. Default = Sometimes
    -- 1 = Never
    -- 2 = Sometimes
    -- 3 = Often
    MetaEvent = 2,
    -- How often events during the player's sleep, like nightmares, occur. Default = Never
    -- 1 = Never
    -- 2 = Sometimes
    -- 3 = Often
    SleepingEvent = 2,
    -- How much fuel is consumed by generators per in-game hour. Min: 0.00 Max: 100.00 Default: 0.10
    GeneratorFuelConsumption = 0.1,
    -- The chance of electrical generators spawning on the map. Default = Rare
    -- 1 = None (not recommended)
    -- 2 = Insanely Rare
    -- 3 = Extremely Rare
    -- 4 = Rare
    -- 5 = Normal
    -- 6 = Common
    -- 7 = Abundant
    GeneratorSpawning = 4,
    -- How often a looted map will have notes on it, written by a deceased survivor. Default = Sometimes
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    AnnotatedMapChance = 4,
    -- Adds free points during character creation. Min: -100 Max: 100 Default: 0
    CharacterFreePoints = 0,
    -- Gives player-built constructions extra hit points so they are  more resistant to zombie damage. Default = Normal
    -- 1 = Very Low
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Very High
    ConstructionBonusPoints = 3,
    -- The level of ambient lighting at night. Default = Normal
    -- 1 = Pitch Black
    -- 2 = Dark
    -- 3 = Normal
    -- 4 = Bright
    NightDarkness = 3,
    -- The time from dusk to dawn. Default = Normal
    -- 1 = Always Night
    -- 2 = Long
    -- 3 = Normal
    -- 4 = Short
    -- 5 = Always Day
    NightLength = 3,
    -- If survivors can get broken limbs from impacts, zombie damage, falls etc.
    BoneFracture = true,
    -- The impact that injuries have on your body, and their healing time. Default = Normal
    -- 1 = Low
    -- 2 = Normal
    -- 3 = High
    InjurySeverity = 2,
    -- How long, in hours, before dead zombie bodies disappear from the world.  If 0, maggots will not spawn on corpses. Min: -1.00 Max: 2147483647.00 Default: 216.00
    HoursForCorpseRemoval = 216.0,
    -- The impact that nearby decaying bodies has on the player's health and emotions. Default = Normal
    -- 1 = None
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Insane
    DecayingCorpseHealthImpact = 3,
    -- Whether nearby "living" zombies have the same impact on the player's health and emotions.
    ZombieHealthImpact = false,
    -- How much blood is sprayed on floors and walls by injuries. Default = Normal
    -- 1 = None
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Ultra Gore
    BloodLevel = 3,
    -- How quickly clothing degrades, becomes dirty, and bloodied. Default = Normal
    -- 1 = Disabled
    -- 2 = Slow
    -- 3 = Normal
    -- 4 = Fast
    ClothingDegradation = 3,
    -- If fires spread when started.
    FireSpread = true,
    -- Number of in-game days before rotten food is removed from the map.  -1 means rotten food is never removed. Min: -1 Max: 2147483647 Default: -1
    DaysForRottenFoodRemoval = -1,
    -- If enabled, generators will work on exterior tiles.  This will allow, for example, the powering of gas pumps.
    AllowExteriorGenerator = true,
    -- Maximum intensity of fog. Default = Normal
    -- 1 = Normal
    -- 2 = Moderate
    -- 3 = Low
    -- 4 = None
    MaxFogIntensity = 1,
    -- Maximum intensity of rain. Default = Normal
    -- 1 = Normal
    -- 2 = Moderate
    -- 3 = Low
    MaxRainFxIntensity = 1,
    -- If snow will accumulate on the ground.  If disabled, snow will still show on vegetation and rooftops.
    EnableSnowOnGround = true,
    -- If melee attacking slows you down.
    AttackBlockMovements = true,
    -- The chance of finding randomized buildings on the map (eg. burnt out houses,  ones containing loot stashes or dead bodies). Default = Rare
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    -- 7 = Always Tries
    SurvivorHouseChance = 3,
    -- The chance of road stories (eg. police roadblocks) spawning. Default = Rare
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    -- 7 = Always Tries
    VehicleStoryChance = 3,
    -- The chance of stories specific to map zones (eg. a campsite in a forest) spawning. Default = Rare
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    -- 7 = Always Tries
    ZoneStoryChance = 3,
    -- Allows you to select from every piece of clothing in the game when customizing your character
    AllClothesUnlocked = false,
    -- If tainted water will show a warning marking it as such.
    EnableTaintedWaterText = true,
    -- If vehicles will spawn.
    EnableVehicles = true,
    -- How frequently vehicles can be discovered on the map. Default = Low
    -- 1 = None
    -- 2 = Very Low
    -- 3 = Low
    -- 4 = Normal
    -- 5 = High
    CarSpawnRate = 3,
    -- General engine loudness to zombies. Min: 0.00 Max: 100.00 Default: 1.00
    ZombieAttractionMultiplier = 1.0,
    -- Whether found vehicles are locked, need keys to start etc.
    VehicleEasyUse = false,
    -- How full the gas tank of discovered vehicles will be. Default = Low
    -- 1 = Very Low
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Very High
    -- 6 = Full
    InitialGas = 2,
    -- If enabled, gas pumps will never run out of fuel
    FuelStationGasInfinite = false,
    -- The minimum amount of gasoline that can spawn in gas pumps. Check the "Advanced" box below to use a custom amount. Min: 0.00 Max: 1.00 Default: 0.00
    FuelStationGasMin = 0.0,
    -- The maximum amount of gasoline that can spawn in gas pumps. Check the "Advanced" box below to use a custom amount. Min: 0.00 Max: 1.00 Default: 0.80
    FuelStationGasMax = 0.8,
    -- The chance, as a percentage, that individual gas pumps will initially have no fuel. Min: 0 Max: 100 Default: 20
    FuelStationGasEmptyChance = 20,
    -- How likely cars will be locked Default = Sometimes
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    LockedCar = 4,
    -- How gas-hungry vehicles are. Min: 0.00 Max: 100.00 Default: 1.00
    CarGasConsumption = 1.0,
    -- General condition discovered vehicles will be in. Default = Normal
    -- 1 = Very Low
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Very High
    CarGeneralCondition = 2,
    -- The amount of damage dealt to vehicles that crash. Default = Normal
    -- 1 = Very Low
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Very High
    CarDamageOnImpact = 3,
    -- Damage received by the player from being crashed into. Default = None
    -- 1 = None
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    -- 5 = Very High
    DamageToPlayerFromHitByACar = 1,
    -- If traffic jams consisting of wrecked cars  will appear on main roads.
    TrafficJam = true,
    -- How frequently discovered vehicles have active alarms. Default = Rare
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    CarAlarm = 3,
    -- If the player can get injured from being in a car accident.
    PlayerDamageFromCrash = true,
    -- How many in-game hours before a wailing siren shuts off. Min: 0.00 Max: 168.00 Default: 0.00
    SirenShutoffHours = 0.0,
    -- The chance of finding a vehicle with gas in its tank. Default = Normal
    -- 1 = Low
    -- 2 = Normal
    -- 3 = High
    ChanceHasGas = 2,
    -- Whether a player can discover a car that has been cared for  after the Knox infection struck. Default = Low
    -- 1 = None
    -- 2 = Low
    -- 3 = Normal
    -- 4 = High
    RecentlySurvivorVehicles = 2,
    -- If certain melee weapons will be able to strike multiple zombies in one hit.
    MultiHitZombies = true,
    -- Chance of being bitten when a zombie attacks from behind. Default = High
    -- 1 = Low
    -- 2 = Medium
    -- 3 = High
    RearVulnerability = 2,
    -- If zombies will head towards the sound of vehicle sirens.
    SirenEffectsZombies = true,
    -- Speed at which animals stats (hunger, thirst etc.) reduce. Default = Normal
    -- 1 = Ultra Fast
    -- 2 = Very Fast
    -- 3 = Fast
    -- 4 = Normal
    -- 5 = Slow
    -- 6 = Very Slow
    AnimalStatsModifier = 4,
    -- Speed at which animals stats (hunger, thirst etc.) reduce while in meta. Default = Normal
    -- 1 = Ultra Fast
    -- 2 = Very Fast
    -- 3 = Fast
    -- 4 = Normal
    -- 5 = Slow
    -- 6 = Very Slow
    AnimalMetaStatsModifier = 4,
    -- How long animals will be pregnant for before giving birth. Default = Normal
    -- 1 = Ultra Fast
    -- 2 = Very Fast
    -- 3 = Fast
    -- 4 = Normal
    -- 5 = Slow
    -- 6 = Very Slow
    AnimalPregnancyTime = 4,
    -- Speed at which animals age. Default = Normal
    -- 1 = Ultra Fast
    -- 2 = Very Fast
    -- 3 = Fast
    -- 4 = Normal
    -- 5 = Slow
    -- 6 = Very Slow
    AnimalAgeModifier = 4,
    -- Default = Normal
    -- 1 = Ultra Fast
    -- 2 = Very Fast
    -- 3 = Fast
    -- 4 = Normal
    -- 5 = Slow
    -- 6 = Very Slow
    AnimalMilkIncModifier = 4,
    -- Default = Normal
    -- 1 = Ultra Fast
    -- 2 = Very Fast
    -- 3 = Fast
    -- 4 = Normal
    -- 5 = Slow
    -- 6 = Very Slow
    AnimalWoolIncModifier = 4,
    -- The chance of finding animals in farm. Default = Often
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    -- 7 = Always
    AnimalRanchChance = 5,
    -- The number of hours grass will regrow after being  eaten by an animal or cut by the player. Min: 1 Max: 9999 Default: 240
    AnimalGrassRegrowTime = 240,
    -- If a meta (ie. not actually visible in-game) fox may attack  your chickens if the hutch's door is left open at night.
    AnimalMetaPredator = false,
    -- If on, animals will only mate during their breeding season (if any).  Otherwise they can reproduce/lay eggs all year round.
    AnimalMatingSeason = true,
    -- How long before baby animals will hatch from eggs. Default = Normal
    -- 1 = Ultra Fast
    -- 2 = Very Fast
    -- 3 = Fast
    -- 4 = Normal
    -- 5 = Slow
    -- 6 = Very Slow
    AnimalEggHatch = 4,
    -- If true, animal calls will attract nearby zombies.
    AnimalSoundAttractZombies = true,
    -- The chance of animals leaving tracks. Default = Sometimes
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    AnimalTrackChance = 4,
    -- The chance of creating a path for animals to be hunted. Default = Sometimes
    -- 1 = Never
    -- 2 = Extremely Rare
    -- 3 = Rare
    -- 4 = Sometimes
    -- 5 = Often
    -- 6 = Very Often
    AnimalPathChance = 4,
    -- The frequency and intensity of eg. rats in infested buildings. Min: 0 Max: 50 Default: 25
    MaximumRatIndex = 25,
    -- How long it takes for the Maximum Vermin Index to be reached. Min: 0 Max: 365 Default: 90
    DaysUntilMaximumRatIndex = 90,
    -- If a piece of media hasn't been fully seen or read, this setting determines whether it's displayed fully, displayed as "???", or hidden completely. Default = Completely hidden
    -- 1 = Fully revealed
    -- 2 = Shown as ???
    -- 3 = Completely hidden
    MetaKnowledge = 3,
    -- If true, you will be able to see any recipes that can be done with a station, even if you haven't learnt them yet.
    SeeNotLearntRecipe = true,
    -- If a building has more than this amount of rooms it will not be looted. Min: 0 Max: 200 Default: 50
    MaximumLootedBuildingRooms = 50,
    -- If poison can be added to food. Default = True
    -- 1 = True
    -- 2 = False
    -- 3 = Only bleach poisoning is disabled
    EnablePoisoning = 1,
    -- If/when maggots can spawn in corpses. Default = In and Around Bodies
    -- 1 = In and Around Bodies
    -- 2 = In Bodies Only
    -- 3 = Never
    MaggotSpawn = 1,
    -- The higher the value, the longer lightbulbs last before breaking.  If 0, lightbulbs will never break.  Does not affect vehicle headlights. Min: 0.00 Max: 1000.00 Default: 2.00
    LightBulbLifespan = 2.0,
    -- The abundance of fish in rivers and lakes. Default = Poor
    -- 1 = Very Poor
    -- 2 = Poor
    -- 3 = Normal
    -- 4 = Abundant
    -- 5 = Very Abundant
    FishAbundance = 2,
    -- When a skill is at this level or above, television/VHS/other media  will not provide XP for it. Min: 0 Max: 10 Default: 3
    LevelForMediaXPCutoff = 3,
    -- When a skill is at this level or above, scrapping furniture does not provide XP for the relevant skill. Does not apply to Electrical. Min: 0 Max: 10 Default: 0
    LevelForDismantleXPCutoff = 0,
    -- Number of days before old blood splats are removed. Removal happens when map chunks are loaded. 0 means they will never disappear. Min: 0 Max: 365 Default: 0
    BloodSplatLifespanDays = 0,
    -- Number of days before one can benefit from reading previously read literature items. Min: 1 Max: 365 Default: 45
    LiteratureCooldown = 45,
    -- If there are diminishing returns on bonus trait points provided from selecting multiple negative traits. Default = None
    -- 1 = None
    -- 2 = 1 point penalty for every 3 negative traits selected
    -- 3 = 1 point penalty for every 2 negative traits selected
    -- 4 = 1 point penalty for every negative trait selected after the first
    NegativeTraitsPenalty = 1,
    -- The number of in-game minutes it takes to read one page of a skill book. Min: 0.00 Max: 60.00 Default: 2.00
    MinutesPerPage = 0.2,
    -- When enabled, crops and herbs grown inside buildings will die. Does not affect houseplants.
    KillInsideCrops = true,
    -- When enabled, the growth of plants is affected by seasons.
    PlantGrowingSeasons = true,
    -- <BHC> [!] It is recommended that you DO NOT change this. Changing this can result in performance issues. [!] <RGB:1,1,1>   When enabled, dirt can be placed, and farming performed on other than the ground level.
    PlaceDirtAboveground = false,
    -- The speed of plant growth. Min: 0.10 Max: 100.00 Default: 1.00
    FarmingSpeedNew = 1.0,
    -- The abundance of harvested crops. Min: 0.10 Max: 10.00 Default: 1.00
    FarmingAmountNew = 1.0,
    -- The chance that any building will already be looted when found. Check the "Advanced" box below to use a custom number. Min: 0 Max: 200 Default: 25
    MaximumLooted = 25,
    -- How long it takes for Maximum Looted Building Chance to be reached. Min: 0 Max: 3650 Default: 90
    DaysUntilMaximumLooted = 90,
    -- The chance that any rural building will already be looted when found. Check the "Advanced" box below to use a custom number. Min: 0.00 Max: 2.00 Default: 0.50
    RuralLooted = 0.5,
    -- The maximum loot that won't spawn when Days Until Maximum Diminished Loot is reached. Check the "Advanced" box below to use an exact percentage. Min: 0 Max: 100 Default: 20
    MaximumDiminishedLoot = 20,
    -- How long it takes for Maximum Diminished Loot Percentage to be reached. Min: 0 Max: 3650 Default: 3650
    DaysUntilMaximumDiminishedLoot = 3650,
    -- Functions as a multiplier when applying muscle strain from swinging weapons or carrying heavy loads. Min: 0.00 Max: 10.00 Default: 0.70
    MuscleStrainFactor = 0.7,
    -- Functions as a multiplier when applying discomfort from worn items. Min: 0.00 Max: 10.00 Default: 0.80
    DiscomfortFactor = 0.8,
    -- If greater than zero damage can be taken from serious wound infections. Min: 0.00 Max: 10.00 Default: 1.00
    WoundInfectionFactor = 1.0,
    -- If true clothing with randomized tints will not be so dark to be virtually black.
    NoBlackClothes = true,
    -- Disables the failure chances when climbing sheet ropes or over walls.
    EasyClimbing = false,
    -- The maximum hours of fuel that can be placed in a campfire, wood stove etc. Min: 1 Max: 168 Default: 8
    MaximumFireFuelHours = 8,
    -- Replaces Chance-To-Hit mechanics with Chance-To-Damage calculations.  This mode prioritizes player aiming. Default = Zombies only
    -- 1 = Disabled
    -- 2 = Zombies only
    -- 3 = All types of target
    FirearmUseDamageChance = 2,
    -- A multiplier for the distance at which zombies can hear gunshots. Min: 0.20 Max: 2.00 Default: 1.00
    FirearmNoiseMultiplier = 1.0,
    -- Multiplier for firearm jamming chance. 0 disables jamming. Min: 0.00 Max: 10.00 Default: 1.00
    FirearmJamMultiplier = 1.0,
    -- Multiplier for Moodle effects on hit chance. 0 disables Moodle penalty. Min: 0.00 Max: 10.00 Default: 1.00
    FirearmMoodleMultiplier = 1.0,
    -- Multiplier for the effects of weather (wind, rain and fog) on hit chance. 0 disables weather effect. Min: 0.00 Max: 10.00 Default: 1.00
    FirearmWeatherMultiplier = 1.0,
    -- Enable to have headgear like welding masks affect hit chance
    FirearmHeadGearEffect = true,
    -- Chance to turn a dirt floor into a clay floor. Applies to lakes. Min: 0.00 Max: 1.00 Default: 0.05
    ClayLakeChance = 0.05,
    -- Chance to turn a dirt floor into a clay floor. Applies to rivers. Min: 0.00 Max: 1.00 Default: 0.05
    ClayRiverChance = 0.05,
    -- Min: 1 Max: 100 Default: 20
    GeneratorTileRange = 1,
    -- How many levels both above and below a generator it can provide with electricity. Min: 1 Max: 15 Default: 3
    GeneratorVerticalPowerRange = 1,
    -- Maximum number of game days (after the radio becomes active) to reach the extraction point.   0 to disable the deadline. Min: 0 Max: 180 Default: 0
    WQS_DeadlineDays_opt = 0,
    -- Duration of the extraction event in game hours.   Recommended 3 or 4 hours Min: 3 Max: 48 Default: 3
    WQS_ExtractionEventHoursDuration_opt = 3,
    -- Governs the overall difficulty of the extraction event. Min: 0.10 Max: 4.00 Default: 1.00
    WQS_ExtractionEventDifficulty_opt = 1.0,
    -- Number of game days that must pass before the radio signal becomes active.  0 to disable this option and have signal already active at start. Min: 0 Max: 365 Default: 0
    WQS_WaitForSignalDuration_opt = 0,
    -- How many repeater antennas you must build in various places of the map to get enough radio signal strength.  0 to disable this option and have full signal strength from the start. Min: 0 Max: 4 Default: 0
    WQS_RepeatersModeHowMany_opt = 0,
    -- Multiplier to the chance of finding mod related items in the loot of zombie bodies.(walkie talkie, map fragment of repeater location, etc.) Min: 0.10 Max: 5.00 Default: 1.00
    WQS_ItemInZombieLootMultiplier_opt = 1.0,
    -- Start with the item needed for extraction, you don't need to find it
    WQS_StartWithExtractionItem_opt = false,
    -- If selected you must stay near the extraction point during the entire duration of the extraction event.
    WQS_ConfinedMode_opt = false,
    -- If selected, the quest will NOT be active at the beginning and can only be started after crafting the antenna.
    WQS_GameModeExtended_opt = true,
    -- Select the extraction zone Default = Random
    -- 1 = Random
    -- 2 = Louisville Bridge Road
    -- 3 = Louisville Ohio Mall
    -- 4 = Louisville Central Hospital
    -- 5 = Louisville Fossoil Factory
    -- 6 = Louisville Orio Offices
    -- 7 = Muldraugh Mass-Genfac
    -- 8 = Muldraugh Soccer Field
    -- 9 = March Ridge Cinema
    -- 10 = Rosewood Penitentiary
    -- 11 = Louisville Bruiser
    WQS_ZoneMap_opt = 1,
    -- If a random extraction zone is chosen allows you to select which zones (even those of modded maps) include in the random pick list.   If a fixed extraction zone is selected this parameter is ignored. Default = Random including all zones
    -- 1 = Random including all zones
    -- 2 = Random only Louisville zones
    -- 3 = Random excluding Louisville zones
    WQS_ZoneMap_random_opt = 1,
    -- Parts with a success chance below this value will be skipped during training. <LINE> At '-1' this setting is not enforced, any value over '-1' is enforced server-wide. <LINE>  <LINE> 0% -> All parts will be worked on. Parts will break at lower skill levels. <LINE> 30% -> Default setting for a good balance. <LINE> 100% -> Only parts that are guaranteed to succeed will be worked on. Completely safe at all skill levels. Min: -1 Max: 100 Default: -1
    BAM_Server_MinSuccessChance = -1,
    -- Base XP awarded by Simple practice recipes. Min: 0.00 Max: 500.00 Default: 30.00
    CSP_XPSimpleBase = 30.0,
    -- Base XP awarded by Intermediate practice recipes. Min: 0.00 Max: 500.00 Default: 60.00
    CSP_XPIntermediateBase = 60.0,
    -- Base XP awarded by Advanced practice recipes. Min: 0.00 Max: 500.00 Default: 100.00
    CSP_XPAdvancedBase = 100.0,
    Basement = {
        -- How frequently basements spawn at random locations. Default = Sometimes
        -- 1 = Never
        -- 2 = Extremely Rare
        -- 3 = Rare
        -- 4 = Sometimes
        -- 5 = Often
        -- 6 = Very Often
        -- 7 = Always
        SpawnFrequency = 4,
    },
    Map = {
        -- If enabled, a mini-map window will be available.
        AllowMiniMap = true,
        -- If enabled, the world map can be accessed.
        AllowWorldMap = true,
        -- If enabled, the world map will be completely filled in on starting the game.
        MapAllKnown = false,
        -- If enabled, maps can't be read unless there's a source of light available.
        MapNeedsLight = true,
    },
    ZombieLore = {
        -- How fast zombies move. Default = Random
        -- 1 = Sprinters
        -- 2 = Fast Shamblers
        -- 3 = Shamblers
        -- 4 = Random
        Speed = 4,
        -- If Random Speed is enabled, this controls what percentage of zombies are Sprinters. Check the "Advanced" box below to use a custom percentage. Min: 0 Max: 100 Default: 0
        SprinterPercentage = 2,
        -- The damage zombies inflict per attack. Default = Normal
        -- 1 = Superhuman
        -- 2 = Normal
        -- 3 = Weak
        -- 4 = Random
        Strength = 4,
        -- The difficulty of killing a zombie. Default = Random
        -- 1 = Tough
        -- 2 = Normal
        -- 3 = Fragile
        -- 4 = Random
        Toughness = 4,
        -- How the Knox Virus spreads. Default = Blood and Saliva
        -- 1 = Blood and Saliva
        -- 2 = Saliva Only
        -- 3 = Everyone's Infected
        -- 4 = None
        Transmission = 2,
        -- How quickly the infection takes effect. Default = 2-3 Days
        -- 1 = Instant
        -- 2 = 0-30 Seconds
        -- 3 = 0-1 Minutes
        -- 4 = 0-12 Hours
        -- 5 = 2-3 Days
        -- 6 = 1-2 Weeks
        -- 7 = Never
        Mortality = 4,
        -- How quickly infected corpses rise as zombies. Default = 0-1 Minutes
        -- 1 = Instant
        -- 2 = 0-30 Seconds
        -- 3 = 0-1 Minutes
        -- 4 = 0-12 Hours
        -- 5 = 2-3 Days
        -- 6 = 1-2 Weeks
        Reanimate = 3,
        -- Zombie intelligence. Default = Basic Navigation
        -- 1 = Navigate and Use Doors
        -- 2 = Navigate
        -- 3 = Basic Navigation
        -- 4 = Random
        Cognition = 3,
        -- Min: 0 Max: 100 Default: 0
        DoorOpeningPercentage = 0,
        -- How often zombies can crawl under parked vehicles. Default = Often
        -- 1 = Crawlers Only
        -- 2 = Extremely Rare
        -- 3 = Rare
        -- 4 = Sometimes
        -- 5 = Often
        -- 6 = Very Often
        -- 7 = Always
        CrawlUnderVehicle = 5,
        -- How long zombies remember a player after seeing or hearing them. Default = Normal
        -- 1 = Long
        -- 2 = Normal
        -- 3 = Short
        -- 4 = None
        -- 5 = Random
        -- 6 = Random between Normal and None
        Memory = 2,
        -- Zombie vision radius. Default = Random between Normal and Poor
        -- 1 = Eagle
        -- 2 = Normal
        -- 3 = Poor
        -- 4 = Random
        -- 5 = Random between Normal and Poor
        Sight = 5,
        -- Zombie hearing radius. Default = Random between Normal and Poor
        -- 1 = Pinpoint
        -- 2 = Normal
        -- 3 = Poor
        -- 4 = Random
        -- 5 = Random between Normal and Poor
        Hearing = 5,
        -- Activates the new advanced stealth mechanics, which allows you to hide from zombies behind cars, takes traits and weather into account, and much more.
        SpottedLogic = true,
        -- If zombies that have not seen/heard player can attack doors and constructions while roaming.
        ThumpNoChasing = false,
        -- If zombies can destroy player constructions and defenses.
        ThumpOnConstruction = true,
        -- Whether zombies are more "active" during the day or night.  "Active" zombies will use the speed set in the "Speed" setting.  "Inactive" zombies will be slower, and tend not to give chase. Default = Both
        -- 1 = Both
        -- 2 = Night
        -- 3 = Day
        ActiveOnly = 1,
        -- If zombies trigger house alarms when breaking through windows or doors.
        TriggerHouseAlarm = true,
        -- If multiple attacking zombies can drag you down and kill you.  Dependent on zombie strength.
        ZombiesDragDown = true,
        -- If crawler zombies beside a player contribute to the chance of being dragged down and killed by a group of zombies.
        ZombiesCrawlersDragDown = false,
        -- If zombies have a chance to lunge at you after climbing over a fence or through a window if you're too close.
        ZombiesFenceLunge = true,
        -- Serves as a multiplier when determining the effectiveness of armor worn by zombies. Min: 0.00 Max: 100.00 Default: 2.00
        ZombiesArmorFactor = 2.0,
        -- The maximum defense percentage that any worn protective garments can provide to a zombie. Min: 0 Max: 100 Default: 85
        ZombiesMaxDefense = 85,
        -- Percentage chance of having a random attached weapon. Min: 0 Max: 100 Default: 6
        ChanceOfAttachedWeapon = 6,
        -- How much damage zombies take when falling from height. Min: 0.00 Max: 100.00 Default: 1.00
        ZombiesFallDamage = 1.0,
        -- Whether some dead-looking zombies will reanimate and attack the player. Default = World Zombies
        -- 1 = World Zombies
        -- 2 = World and Combat Zombies
        -- 3 = Never
        DisableFakeDead = 1,
        -- Zombies will not spawn where players spawn. Default = Inside the building and around it
        -- 1 = Inside the building and around it
        -- 2 = Inside the building
        -- 3 = Inside the room
        -- 4 = Zombies can spawn anywhere
        PlayerSpawnZombieRemoval = 2,
        -- How many zombies it takes to damage a tall fence. Min: -1 Max: 100 Default: 25
        FenceThumpersRequired = 25,
        -- How quickly zombies damage tall fences. Min: 0.01 Max: 100.00 Default: 1.00
        FenceDamageMultiplier = 1.0,
    },
    ZombieConfig = {
        -- Set by the "Zombie Count" population option, or by a custom number here. Insane = 2.5, Very High = 1.6, High = 1.2, Normal = 0.65, Low = 0.15, None = 0.0. Min: 0.00 Max: 4.00 Default: 0.65
        PopulationMultiplier = 0.65,
        -- A multiplier for the desired zombie population at the start of the game. Insane = 3.0, Very High = 2.0, High = 1.5, Normal = 1.0, Low = 0.5, None = 0.0. Min: 0.00 Max: 4.00 Default: 1.00
        PopulationStartMultiplier = 1.0,
        -- A multiplier for the desired zombie population on the peak day. Insane = 3.0, Very High = 2.0, High = 1.5, Normal = 1.0, Low = 0.5, None = 0.0. Min: 0.00 Max: 4.00 Default: 1.50
        PopulationPeakMultiplier = 1.5,
        -- The day when the population reaches its peak. Min: 1 Max: 365 Default: 28
        PopulationPeakDay = 28,
        -- The number of hours that must pass before zombies may respawn in a cell. If 0, spawning is disabled. Min: 0.00 Max: 8760.00 Default: 0.00
        RespawnHours = 0.0,
        -- The number of hours that a chunk must be unseen before zombies may respawn in it. Min: 0.00 Max: 8760.00 Default: 0.00
        RespawnUnseenHours = 0.0,
        -- The fraction of a cell's desired population that may respawn every RespawnHours. Min: 0.00 Max: 1.00 Default: 0.00
        RespawnMultiplier = 0.0,
        -- The number of hours that must pass before zombies migrate  to empty parts of the same cell. If 0, migration is disabled. Min: 0.00 Max: 8760.00 Default: 12.00
        RedistributeHours = 12.0,
        -- The distance a zombie will try to walk towards the last sound it heard. Min: 10 Max: 1000 Default: 100
        FollowSoundDistance = 100,
        -- The size of groups real zombies form when idle. 0 means zombies don't form groups. Groups don't form inside buildings or forest zones. Min: 0 Max: 1000 Default: 20
        RallyGroupSize = 20,
        -- The amount, as a percentage, that zombie groups can vary in size from the default (both larger and smaller).   For example, at 50% variance with a default group size of 20, groups will vary in size from 10-30. Min: 0 Max: 100 Default: 50
        RallyGroupSizeVariance = 50,
        -- The distance real zombies travel to form groups when idle. Min: 5 Max: 50 Default: 20
        RallyTravelDistance = 20,
        -- The distance between zombie groups. Min: 5 Max: 25 Default: 15
        RallyGroupSeparation = 15,
        -- How close members of a zombie group stay to the group's "leader". Min: 1 Max: 10 Default: 3
        RallyGroupRadius = 3,
        -- Controls the maximum number of zombies tracked before cleanup occurs. 0 means zombies will not be cleaned up. The default value (300) is strongly recommended. Increasing this value or setting to 0 may cause severe performance problems. For troubleshooting and bug-report purposes, please reproduce any issue with the default setting before submitting a report. Min: 0 Max: 5000 Default: 300
        ZombiesCountBeforeDelete = 300,
    },
    MultiplierConfig = {
        -- The rate at which all skills level up. Min: 0.00 Max: 1000.00 Default: 1.00
        Global = 1.0,
        -- When enabled, all skills will use the Global Multiplier.
        GlobalToggle = true,
        -- Rate at which Fitness skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Fitness = 1.0,
        -- Rate at which Strength skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Strength = 1.0,
        -- Rate at which Sprinting skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Sprinting = 1.0,
        -- Rate at which Lightfooted skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Lightfoot = 1.0,
        -- Rate at which Nimble skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Nimble = 1.0,
        -- Rate at which Sneaking skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Sneak = 1.0,
        -- Rate at which Axe skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Axe = 1.0,
        -- Rate at which Long Blunt skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Blunt = 1.0,
        -- Rate at which Short Blunt skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        SmallBlunt = 1.0,
        -- Rate at which Long Blade skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        LongBlade = 1.0,
        -- Rate at which Short Blade skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        SmallBlade = 1.0,
        -- Rate at which Spear skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Spear = 1.0,
        -- Rate at which Maintenance skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Maintenance = 1.0,
        -- Rate at which Carpentry skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Woodwork = 1.0,
        -- Rate at which Cooking skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Cooking = 1.0,
        -- Rate at which Agriculture skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Farming = 1.0,
        -- Rate at which First Aid skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Doctor = 1.0,
        -- Rate at which Electrical skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Electricity = 1.0,
        -- Rate at which Welding skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        MetalWelding = 1.0,
        -- Rate at which Mechanics skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Mechanics = 1.0,
        -- Rate at which Tailoring skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Tailoring = 1.0,
        -- Rate at which Aiming skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Aiming = 1.0,
        -- Rate at which Reloading skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Reloading = 1.0,
        -- Rate at which Fishing skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Fishing = 1.0,
        -- Rate at which Trapping skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Trapping = 1.0,
        -- Rate at which Foraging skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        PlantScavenging = 1.0,
        -- Rate at which Knapping skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        FlintKnapping = 1.0,
        -- Rate at which Masonry skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Masonry = 1.0,
        -- Rate at which Pottery skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Pottery = 1.0,
        -- Rate at which Carving skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Carving = 1.0,
        -- Rate at which Animal Care skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Husbandry = 1.0,
        -- Rate at which Tracking skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Tracking = 1.0,
        -- Rate at which Blacksmithing skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Blacksmith = 1.0,
        -- Rate at which Butchering skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Butchering = 1.0,
        -- Rate at which Glassmaking skill levels up. Min: 0.00 Max: 1000.00 Default: 1.00
        Glassmaking = 1.0,
        -- Multiplies the XP gained in the Archery skill from landing bow hits. Min: 0.00 Max: 1000.00 Default: 1.00
        Archery = 1.0,
        -- Multiplies the XP gained in the Fletching skill from cutting fletching, carving shafts, binding them and fitting a head. Min: 0.00 Max: 1000.00 Default: 1.00
        Fletching = 1.0,
        -- Min: 0.00 Max: 1000.00 Default: 1.00
        Side_L = 1.0,
        -- Min: 0.00 Max: 1000.00 Default: 1.00
        Side_R = 1.0,
        -- Min: 0.00 Max: 1000.00 Default: 1.00
        ProstFamiliarity = 1.0,
        -- Rate at which the Lockpicking skill levels up. Default 1. Same scale as the other skill multipliers (0 to 1000). Min: 0.00 Max: 1000.00 Default: 1.00
        Lockpicking = 1.0,
    },
    HB = {
        -- Casings will stay in the floor after landing. Turn this off to make casings only visible while active.
        PermanentCasings = true,
        -- Enable custom icons for casings and bullets.
        CustomIcons = true,
        -- Enable sounds for casings hitting the floor.
        CasingSounds = true,
        -- Bandits will drop casings when shooting their guns.
        BanditsCasings = false,
        -- Racking will be required to be done by the player, no longer automatic. Recommended to be used only in Singleplayer only.
        ManualRacking = false,
    },
    SVUC = {
        -- How long it takes to install and uninstall light armor. Min: 10 Max: 50 Default: 15
        timeLight = 15,
        -- How long it takes to install and uninstall heavy armor. Min: 10 Max: 50 Default: 30
        timeHeavy = 30,
        -- How long it takes to install and uninstall reinforced armor. Min: 10 Max: 50 Default: 45
        timeReinforced = 45,
        -- Min: 10 Max: 50 Default: 15
        timeMods = 15,
        -- How long it takes to install and uninstall wheel chains. Min: 10 Max: 50 Default: 15
        timeWheels = 15,
        -- The part HP has to drop below this number to be repaired. Min: 50 Max: 80 Default: 80
        protectionHealthTriger = 80,
        -- How much damage to deal to light armor when it repairs a part. Min: 1 Max: 10 Default: 5
        protectionLightHealthDelta = 5,
        -- How much damage to deal to heavy armor when it repairs a part. Min: 1 Max: 10 Default: 4
        protectionHeavyHealthDelta = 4,
        -- How much damage to deal to reinforced armor when it repairs a part. Min: 1 Max: 10 Default: 3
        protectionReinforcedHealthDelta = 3,
        -- How much damage to deal to small bullbars when they repair a part. Min: 1 Max: 10 Default: 6
        protectionBullbarSmallHealthDelta = 6,
        -- How much damage to deal to medium bullbars when they repair a part. Min: 1 Max: 10 Default: 5
        protectionBullbarMediumHealthDelta = 5,
        -- How much damage to deal to large bullbars when they repair a part. Min: 1 Max: 10 Default: 4
        protectionBullbarLargeHealthDelta = 4,
        -- How much damage to deal to plows when they repair a part. Min: 1 Max: 10 Default: 3
        protectionPlowHealthDelta = 3,
        -- How much damage to deal to wheel chains when they repair a part. Min: 1 Max: 10 Default: 1
        protectionWheelsHealthDelta = 1,
        -- How much horsepower to add when a small air scoop's installed. Min: 0 Max: 50 Default: 10
        protectionEngineSmallPowerIncrease = 10,
        -- How much horsepower to add when a medium air scoop's installed. Min: 0 Max: 50 Default: 20
        protectionEngineMediumPowerIncrease = 20,
        -- How much horsepower to add when a large air scoop's installed. Min: 0 Max: 50 Default: 35
        protectionEngineLargePowerIncrease = 35,
        -- How much horsepower to add when a piped air scoop's installed. Min: 0 Max: 50 Default: 50
        protectionEnginePipedPowerIncrease = 50,
        -- How much horsepower to add when a snorkel's installed. Min: 0 Max: 50 Default: 15
        protectionEngineSnorkelPowerIncrease = 15,
        -- Multiplier for extra gas to use when light armor's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 10
        protectionLightGasUsage = 10,
        -- Multiplier for extra gas to use when heavy armor's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 20
        protectionHeavyGasUsage = 20,
        -- Multiplier for extra gas to use when reinforced armor's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 40
        protectionReinforcedGasUsage = 40,
        -- Multiplier for extra gas to use when modifications are installed. Set to 0 to disable. Min: 0 Max: 100 Default: 0
        protectionModsGasUsage = 0,
        -- Multiplier for extra gas to use when a small bullbar's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 1
        protectionBullbarSmallGasUsage = 1,
        -- Multiplier for extra gas to use when a medium bullbar's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 5
        protectionBullbarMediumGasUsage = 5,
        -- Multiplier for extra gas to use when a large bullbar's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 10
        protectionBullbarLargeGasUsage = 10,
        -- Multiplier for extra gas to use when a plow's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 20
        protectionPlowGasUsage = 20,
        -- Multiplier for extra gas to use when a small air scoop's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 2
        protectionEngineSmallGasUsage = 2,
        -- Multiplier for extra gas to use when a medium air scoop's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 3
        protectionEngineMediumGasUsage = 3,
        -- Multiplier for extra gas to use when a large air scoop's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 4
        protectionEngineLargeGasUsage = 4,
        -- Multiplier for extra gas to use when a piped air scoop's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 5
        protectionEnginePipedGasUsage = 5,
        -- Multiplier for extra gas to use when a snorkel's installed. Set to 0 to disable. Min: 0 Max: 100 Default: 1
        protectionEngineSnorkelGasUsage = 1,
    },
    NewMusic = {
        -- Determines how far each client retains tracking for active devices. Set to 0 for infinite range. Min: 0 Max: 36000 Default: 1500
        MaxTrackingRange = 1500,
        -- Hard cap on actively synced/playback-managed devices per client. Min: 4 Max: 50 Default: 10
        ActiveDeviceLimit = 10,
        -- How fast the battery drains in real life hours. Min: 0.02 Max: 1000.00 Default: 24.00
        BatteryDrainRate = 24.0,
        -- How far, in tiles, world playback devices can be heard at max volume. Min: 9 Max: 500 Default: 35
        AudioMaxRadius = 35,
        -- How far, in tiles, zombies are attracted to devices playing at max volume. Attraction range scales down with volume. Min: 9 Max: 200 Default: 105
        ZombieAttractionRadius = 105,
        -- Enables disassembly and scrap for New Music devices.
        Disassembly = true,
        -- Allows the base mod Zomboid OST items to spawn. Uncheck to disable them.
        ZomboidOST = true,
        -- If enabled, vanilla CDs and CD players are replaced by New Music versions.
        ConvertVanillaCDsAndCDPlayers = true,
        -- If enabled, cassettes, vinyl records, and CDs can spawn inside their case, cover, or jacket items (if one exists).
        MediaSpawnsWithCases = true,
        -- Controls cassette media spawn intensity. 0.00 disables. Min: 0.00 Max: 4.00 Default: 0.60
        CassettesSpawnRate = 0.21,
        -- Controls vinyl media spawn intensity. 0.00 disables. Min: 0.00 Max: 4.00 Default: 0.30
        VinylRecordsSpawnRate = 0.09,
        -- Controls CD media spawn intensity. 0.00 disables. Min: 0.00 Max: 4.00 Default: 0.60
        CDsSpawnRate = 0.05,
        -- Controls walkman spawn intensity. Min: 0.00 Max: 4.00 Default: 0.60
        WalkmanSpawnRate = 0.2,
        -- Controls boombox spawn intensity. Min: 0.00 Max: 4.00 Default: 0.60
        BoomboxSpawnRate = 0.2,
        -- Controls CD player spawn intensity. Min: 0.00 Max: 4.00 Default: 0.60
        CDPlayerSpawnRate = 0.1,
        -- Controls record player spawn intensity. Min: 0.00 Max: 4.00 Default: 0.60
        RecordPlayerSpawnRate = 0.1,
        -- Controls zombie music-device spawn intensity. Min: 0.00 Max: 4.00 Default: 0.60
        MusicalZombiesSpawnRate = 0.1,
    },
    PagerMod = {
        -- Quick bundles of the options below.
        -- Custom: nothing is overridden - every option on this page applies as you set it (the default).
        -- Convenient: the relaxed defaults - map-wide signal, full two-way paging and every feature on.
        -- Almost Realistic: a barely-functional pocket pager - 1 saved page, 16 characters, no location, no read receipts, no SOS, no blocking, no broadcast (still map-wide).
        -- Ultra Realistic: everything in Almost Realistic, plus pagers can only receive (not send), and the network is map-wide only until the power dies, then needs a built, powered pager tower.
        -- A preset overrides the matching options below. Default = Custom (use options below)
        -- 1 = Custom (use options below)
        -- 2 = Convenient
        -- 3 = Almost Realistic
        -- 4 = Ultra Realistic
        Preset = 1,
        -- How far pages travel.
        -- Map-wide: pagers reach anywhere on the map (the default - pagers are your long-range tier, with walkie-talkies for medium range and voice chat up close).
        -- Limited range: a page only arrives if the recipient is within the distance set below.
        -- Powered tower only (after power dies): pages reach map-wide while the electricity grid is still on, but once the power goes out the network only works through a built, powered pager tower's coverage - so the pager network dies with the grid unless someone keeps a tower running on a generator.
        -- Powered tower only: the network ALWAYS needs a built, powered pager tower in range, even while the grid is up. Default = Map-wide (anywhere)
        -- 1 = Map-wide (anywhere)
        -- 2 = Limited range
        -- 3 = Powered tower only (after power dies)
        -- 4 = Powered tower only
        SignalMode = 1,
        -- What pagers can do.
        -- Send and receive: normal two-way paging (the default).
        -- Receive only: pagers can only receive pages - the compose, reply and group features are hidden. Default = Send and receive
        -- 1 = Send and receive
        -- 2 = Receive only
        PagerMode = 1,
        -- The reach distance in tiles (1 tile is about 1 metre), used by two signal modes: in Limited range it's the furthest a page can travel between sender and recipient; in Powered tower mode it's each tower's coverage radius (both ends of a page must be within it). Min: 50 Max: 100000 Default: 7000
        SignalRange = 7000,
        -- Lets a player send one page to every pager on the network with the Broadcast button. Turn this off on busy servers to cut down on spam.
        AllowBroadcast = true,
        -- How many pages a single pager keeps. Once it is full, the oldest page is dropped to make room for a new one. Min: 1 Max: 500 Default: 50
        MaxMessages = 50,
        -- The longest message a player can put in one page, counted in characters. Min: 1 Max: 500 Default: 140
        MessageMaxLength = 140,
        -- Play a beep and show an on-screen alert (with a preview of the message) whenever a new page comes in.
        NotifySound = true,
        -- How loud the pager's notification beep plays. Applies to every beep the pager makes. Default = 50% (default)
        -- 1 = 25% (quiet)
        -- 2 = 50% (default)
        -- 3 = 75%
        -- 4 = 100% (loud)
        BeepVolume = 2,
        -- Whether a page can include where the sender is standing. The recipient then sees the coordinates plus distance and a compass bearing.
        -- Off: location is never shared.
        -- Ask each time: the sender ticks a box per page (the default).
        -- Always on: every page carries the sender's location.
        -- An SOS still shares location unless this is set to Off. Default = Ask each time
        -- 1 = Off
        -- 2 = Ask each time
        -- 3 = Always on
        LocationSharing = 2,
        -- Minimum number of seconds a player must wait between sending pages. Helps stop spam and griefing on PvP servers. Set to 0 for no limit (the default). Min: 0 Max: 600 Default: 0
        SendCooldown = 0,
        -- Notifies the sender once the person they paged has opened and read the message.
        ReadReceipts = true,
        -- Controls who can reach who.
        -- Anyone: any pager can page any other (the default).
        -- Same faction only: members of different factions cannot page each other, so rival groups can't eavesdrop or spam. Players who are not in a faction can always be reached. Default = Anyone can page anyone
        -- 1 = Anyone can page anyone
        -- 2 = Same faction only
        FactionScope = 1,
        -- Enables the emergency SOS button, which pages everyone on the network at once and attaches the sender's location (unless location sharing is Off).
        AllowSOS = true,
        -- Lets players block a pager number so its pages never reach them. Useful against griefers in PvP.
        AllowBlocking = true,
        -- How long a fresh battery powers a pager before it dies and must be replaced. Measured in in-game time. Replace batteries from the pager's right-click menu using a Battery item. Default = 3 months
        -- 1 = 1 month
        -- 2 = 3 months
        -- 3 = 6 months
        -- 4 = 1 year
        -- 5 = Never dies
        BatteryLife = 2,
        -- What the tower base station (000-0001) itself can do.
        -- Send and receive: the tower can send pages and be paged - its console has an inbox.
        -- Send only: the tower can only send pages; it cannot be paged. Default = Send and receive
        -- 1 = Send and receive
        -- 2 = Send only
        TowerComms = 1,
        -- The most pager towers a single player may have set up at once. Each tower is its own node with its own number and coverage circle. Set to 0 for no limit. Admins are exempt. Min: 0 Max: 999 Default: 0
        TowerLimit = 0,
        -- Adds a town-wide GLOBAL tab to every pager: a shared channel anyone with a pager can read and post to, reaching everyone regardless of saved contacts or faction. It still obeys the signal mode, receive-only mode, send cooldown and per-person blocking.
        GlobalChat = false,
        -- What a deployed pager tower needs to run (Powered tower mode).
        -- Grid or generator: mains electricity OR a running generator nearby (the default).
        -- Generator only: only a running, fuelled generator beside it (ignores the power grid).
        -- None: towers always work, no power needed. Default = Grid or generator
        -- 1 = Grid or generator
        -- 2 = Generator only
        -- 3 = None (always on)
        TowerPower = 1,
        -- Pages may contain digits, spaces and dashes only - all letters are stripped out. Turns pagers into a numeric-code device.
        NumericOnly = false,
        -- What the Illiterate trait does to pagers.
        -- No effect: illiterate characters use pagers normally.
        -- Cannot read pages: page text and sender names appear as ??? for an illiterate character, and the pages they send can only contain digits, spaces and dashes - a numeric-code device. Their pager still beeps and shows numbers.
        -- Cannot use a pager: an illiterate character cannot open a pager or a tower console at all. The pager still beeps in their pocket, and they can still set up or pack away a tower. Default = No effect
        -- 1 = No effect
        -- 2 = Cannot read pages (shown as ???)
        -- 3 = Cannot use a pager at all
        Illiteracy = 1,
        -- How much pager loot the world has, as a multiplier on the weights pagers already carry in electronics, police, comms and vehicle containers - so they still turn up where they make sense, there are just more or fewer of them.
        -- Vanilla (unchanged) is the default and touches no loot table at all. In Build 41, where the pager is not a vanilla item, the higher settings are also what puts it into electronics loot in the first place.
        -- Only affects containers the world has not generated yet. Default = Vanilla (unchanged)
        -- 1 = Rare (half as common)
        -- 2 = Vanilla (unchanged)
        -- 3 = More common (x2)
        -- 4 = Common (x4)
        -- 5 = Everywhere (x8)
        SpawnAbundance = 2,
        -- Appends every routed page (sender, recipient, text, delivered/queued/blocked) to PagerMod_PageLog.txt in the server's Zomboid folder. For admins/moderation.
        LogPages = false,
    },
    RainCleansBlood = {
        -- How many random tiles near each player to check and clean per in-game minute. Min: 10 Max: 2000 Default: 300
        TilesPerMinuteNearPlayer = 300,
        -- How heavy the rain or snow must be before blood starts washing away. Higher = needs heavier weather. Min: 0.05 Max: 0.95 Default: 0.25
        WeatherThreshold = 0.25,
        -- Also clean ash left behind by burned corpses.
        AlsoCleanAsh = true,
        -- Also clean animal droppings (dung) left on the ground.
        AlsoCleanDroppings = true,
        -- Also clean blood inside buildings.
        AlsoCleanInside = false,
        -- Also gradually clean blood from vehicles.
        AlsoCleanVehicles = true,
        -- How much blood to remove from vehicles per minute. Min: 0.10 Max: 1.00 Default: 0.10
        VehicleCleanSpeed = 0.1,
        -- Also gradually clean blood and dirt from players' worn clothing.
        AlsoCleanClothes = true,
        -- How much blood and dirt to remove from clothing per minute. Min: 1.00 Max: 10.00 Default: 1.00
        ClothesCleanSpeed = 1.0,
        -- Always clean regardless of weather.
        AlwaysClean = false,
    },
    VisibleDoorDamage = {
        EnableTestMenu = false,
    },
    DAMN = {
        AllowPowerChadSpawns = true,
        AllowBabySpawns = true,
        AllowPro440Spawns = true,
        AllowDemonChildSpawns = false,
        AllowEV6spawns = true,
        AllowTBCspawns = true,
        AllowUBCspawns = true,
        AllowWreckyMcChevySpawns = true,
        AllowShitSpawns = true,
        AllowOinkerSpawns = true,
        AlLAV300Spawns = true,
        AllowMrBusSpawns = true,
        AllowChonkerSpawns = true,
        AllowCashcowSpawns = true,
        AllowMcBoxySpawns = true,
        AllowContainerSpawns = true,
    },
    AMGeneralTankerFunctionality = {
        -- Multiplier for tanker pump transfer speed. 1 is the default speed. Min: 1 Max: 20 Default: 5
        PumpSpeedMultiplier = 5,
        -- Capacity in litres for the M49A2C fuel cargo tank. Applies to newly loaded vehicles. Min: 500 Max: 6000 Default: 850
        M49A2CCargoTankCapacity = 850,
        -- Capacity in litres for the M50A3 water cargo tank. Applies to newly loaded vehicles. Min: 500 Max: 6000 Default: 850
        M50A3CargoTankCapacity = 850,
        -- Capacity in litres for the M967 fuel cargo tank. Applies to newly loaded vehicles. Min: 1000 Max: 10000 Default: 2000
        M967CargoTankCapacity = 2000,
    },
    rSemiTruck = {
        -- Multiplies the spawn chance of all W900 military vehicles in every zone.
        -- 0.5 = default, 0.0 = never spawn, 2.0 = double chance. Min: 0.00 Max: 10.00 Default: 0.50
        MilSpawnMultiplier = 0.5,
        -- If enabled, the fixed-coordinate W900 military vehicle spawns are created. If disabled, only normal zone-based military spawning remains active.
        GuaranteedMilitarySpawns = true,
        -- Controls the amount of dynamically added weapons, ammo, and gun parts in W900 military vehicle loot.
        -- High = full amount (default), Medium = 50%, Low = 25%, None = no extra loot added. Default = High (Default)
        -- 1 = None
        -- 2 = Low (25%)
        -- 3 = Medium (50%)
        -- 4 = High (Default)
        MilitaryLootLevel = 4,
        -- If enabled, Car Trailers can spawn in both normal and fixed vehicle zones. If disabled, Car Trailers will not spawn.
        CarTrailerSpawns = true,
        -- If enabled, Container Trailers can spawn in both normal and fixed vehicle zones. If disabled, Container Trailers will not spawn.
        ContainerTrailerSpawns = true,
        -- If enabled, Containers can spawn in both normal and fixed vehicle zones. If disabled, Containers will not spawn.
        ContainerSpawns = true,
    },
    MSW = {
        -- Sets how many vehicles the MultiWrecker can carry at once.
        -- Lowering this setting only blocks new loads into higher slots; already loaded vehicles can still be unloaded. Default = 5 Vehicles
        -- 1 = 3 Vehicles
        -- 2 = 4 Vehicles
        -- 3 = 5 Vehicles
        Slots = 3,
    },
    VMZ = {
        -- Determines whether military road stories will spawn in the game.
        RoadStories = true,
        -- Allows you to edit the chances of military road stories appearing. Min: 0.00 Max: 5.00 Default: 1.00
        RoadStoriesMultiplier = 1.0,
        -- Minimum amout of days (since start of apocalypse) after which road stories will begin to spawn. Min: 0 Max: 1000 Default: 5
        RoadStoriesMinDay = 5,
        -- Maximum amout of days (since start of apocalypse) after which road stories will stop spawning. Min: 0 Max: 1000 Default: 90
        RoadStoriesMaxDay = 90,
        -- Determines whether a vehicle can spawn in a regular parking stall (near shops, houses) as police and fire department cars occasionally do.
        SpecCar = false,
        -- Set spawn rate for vehicles in military zone. Min: 0 Max: 100 Default: 16
        SpawnRate = 16,
        -- Set condition of vehicle parts (should be 'damaged') that spawn in military zone. Recommend use it in pair with 'Chance of having a damaged part'. So if you want ~100% vehicle set 'Vehicles condition' = 100 and 'Chance of having a damaged part' = 100. Min: 0 Max: 100 Default: 50
        VehiCond = 50,
        -- Set chance of having a 'damaged' part for vehicles in military zone (the part's condition applies specifically to 'damaged' parts, so if the chance is 100 and the durability is 100, the overall condition indicator of the car will also be ~100%). Min: 0 Max: 100 Default: 0
        PartDamage = 0,
        -- Set chance to spawn a key in vehicle and near it (zombies, floor, buildings). Min: 0 Max: 100 Default: 70
        KeySpawn = 70,
    },
    KI5GF = {
        -- Raises the MAN KAT1's suspension travel and rest length so it climbs back out of the ground instead of staying sunk, and stiffens it so the extra travel does not turn into a bounce. Turn off to leave the truck exactly as KI5 ships it.
        FixKat1Suspension = false,
    },
    VVR = {
        -- Disables trailers spawn in traffic jams and basic car crashes. Still can be founded in car crash attached to vehicle and parkings.
        NoTrailers = false,
        -- Replaces burnt cars with KI5's ones in bad condition.
        NoBurnt = true,
        -- Set condition for vehicles that replaced burnt cars. Min: 0 Max: 100 Default: 10
        VehiCond = 10,
        -- Cars that shouldn't spawn in world. Divider - ;
        VehiclesBlacklist = "Base.ModernCar_Martin;",
    },
    RVVFX = {
        -- Temporary marks use the normal RVV lifetime. Persistent marks are saved with the world and remain until weather or RVV cleanup removes them. Safety limits still apply. Default = Temporary
        -- 1 = Temporary
        -- 2 = Persistent
        TireMarkPersistence = 2,
    },
    MaskaradsSummerCar = {
        -- Shifts newly initialized vehicles toward better or worse coherent engine loadouts. Only affects vehicles initialized after the setting is applied. Default = Normal
        -- 1 = Very poor
        -- 2 = Poor
        -- 3 = Normal
        -- 4 = Good
        -- 5 = Very good
        LoadoutQuality = 3,
        -- Controls how many components may be absent from newly initialized vehicles. Optional and service parts are more likely to be missing than critical internals. Default = Common
        -- 1 = None
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Common
        -- 5 = Severe
        MissingParts = 4,
        -- Chance that each newly generated component belongs to a different Standard, Heavy-Duty, or Sport class. The transmission pair always stays internally consistent. Min: 0 Max: 100 Default: 10
        CrossClassChance = 10,
        -- Chance that a newly initialized vehicle receives a manual transmission and clutch instead of an automatic transmission and torque converter. Min: 0 Max: 100 Default: 50
        ManualTransmissionChance = 50,
        -- Legendary chance for newly created MSC components. Lower values make legendary parts more common; 350 means one chance in 350. Min: 1 Max: 5000 Default: 350
        LegendaryOneIn = 350,
        -- Multiplies condition loss from normal running wear and fluid-related engine damage. Zero disables those MSC wear sources. Min: 0.00 Max: 5.00 Default: 1.00
        ComponentWearMultiplier = 1.0,
        -- Multiplies condition- and pressure-related oil, coolant, and transmission-fluid leaks. Zero disables MSC leaks. Min: 0.00 Max: 5.00 Default: 1.00
        FluidLossMultiplier = 1.0,
        -- Default follows each player's account temperature preference. Celsius and Fahrenheit force that unit for every MSC vehicle temperature. Default = Default (player preference)
        -- 1 = Default (player preference)
        -- 2 = Celsius
        -- 3 = Fahrenheit
        TemperatureDisplay = 1,
        -- Allows a shove near either end of a vehicle's side to turn it. Front and rear pushing remains available when disabled.
        AllowSidePushing = true,
        -- Controls how often Standard parts appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Min: 0.00 Max: 5.00 Default: 1.00
        StandardPartsSpawnRate = 1.0,
        -- Controls how often Heavy-Duty parts appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Min: 0.00 Max: 5.00 Default: 1.00
        HeavyDutyPartsSpawnRate = 1.0,
        -- Controls how often Sport parts appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Min: 0.00 Max: 5.00 Default: 1.00
        SportPartsSpawnRate = 1.0,
        -- Controls how often oil, coolant, and transmission-fluid bottles appear as loot. 0 disables them, 1 is the default rate, and 2 doubles it. Min: 0.00 Max: 5.00 Default: 1.00
        FluidSuppliesSpawnRate = 1.0,
    },
    SPNCharCustom = {
        -- Admins or players holding an Appearance Changer ignore this Default = Disabled
        -- 1 = Face and Details
        -- 2 = Face only
        -- 3 = Details only
        -- 4 = Disabled
        AllowCustomisationChange = 4,
        -- Customisation categories that are hidden to normal players. Comma separated, eg: joke,halloween,special
        AdminLockedCustomisation = "",
        -- Set to 0 to disable growth Min: 0 Max: 20 Default: 10
        BodyHairGrowth = 10,
        -- Set to 0 to disable growth Min: 0 Max: 20 Default: 6
        StubbleHeadGrowth = 6,
        -- Set to 0 to disable growth Min: 0 Max: 20 Default: 3
        StubbleBeardGrowth = 3,
        -- Body hair and stubble grows in-game Default = Enabled for everyone
        -- 1 = Enabled for everyone
        -- 2 = Disabled for everyone
        -- 3 = Player Choice
        BodyHairGrowthEnabled = 1,
        -- Display visible muscles on character depending on strength level Default = Enabled for everyone
        -- 1 = Enabled for everyone
        -- 2 = Disabled for everyone
        -- 3 = Player Choice
        MuscleVisuals = 1,
        -- Players with missing eye customisation will have a vision penalty - Set to 1.0 to disable Min: 0.10 Max: 1.00 Default: 0.50
        MissingEyeVisionModifier = 0.5,
        -- In vanilla washing yourself will also wash off makeup
        WashMakeup = true,
    },
    BathTowelsOverhaul = {
        -- Decreases the multiplier for how quickly the player's wetness dries naturally. <LINE> True = 0.002, False = 0.01 (vanilla)
        WetnessDecrease = true,
        -- Whether to give a random wet absorption when generating bath towels. If False, all bath towels will have a absobency of 30.
        RandomBathTowelQuality = true,
        -- The absorbency of bath towels is further randomized. <LINE> (Only work if Bath Towel Quality is True)
        MoreRandomAbsorbency = true,
        -- Whether to overwrite the display name according to the bath towel's absorbency. <LINE> (Only work if Bath Towel Quality is True)
        RandomBathTowelQualityName = true,
        -- Whether the towels likely to deteriorate with use. <LINE> (The rate and chance of deterioration is very low.)
        TowelConditionMayDeteriorate = true,
        -- Whether the towel absorbs blood and dirt on the body during Dry Self.
        WipesBloodAndDirt = true,
        -- If True, the towel can be used with DrySelf even if it grimed. If False, it will become unusable if it is too dirty. <LINE> <RED> Note: Using a grimes towel will make it even grimer and increase your unhappiness.
        AvailableEvenIfTooDirt = false,
        -- Whether hand towel spawn in the world. It spawns in the same place as Bath Towel.
        HandTowelsSpawn = true,
        -- This value is a divisor for the Bathtowel value. 1 is the same probability as a bath towel. 2 is half the probability. Min: 1 Max: 10 Default: 2
        HandTowelsSpawnProbabilty = 2,
        -- Whether dust cloth spawn in the world. It spawns in the same place as Sponge.
        DustClothSpawn = true,
        -- This value is a divisor for the Sponge value. 1 is the same probability as a bath towel. 2 is half the probability. Min: 1 Max: 10 Default: 1
        DustClothSpawnProbabilty = 1,
    },
    TakeABathAndShower = {
        -- This checkbox option does nothing itself.
        GeneralSection = false,
        -- Whether has a water temperature concept to shower and bath. 
        --  If False, you will no longer be able to get the warming to body effects of hot water or the stress relief effects.
        WaterTemperatureConcept = true,
        -- This is the amount of water remaining in the bathtub faucet after a water outage. <LINE> By making this value higher than the amount of taking bath water consumed, you will be able to take a bath in the first house you visit after the water outage. Min: 0 Max: 1000 Default: 100
        RemainTubFaucetWater = 100,
        -- This is the amount of water remaining in the shower faucet after a water outage. <LINE> By making this value higher than the amount of taking shower water consumed, you will be able to take a shower in the first house you visit after the water outage. Min: 0 Max: 1000 Default: 20
        RemainShowerFaucetWater = 20,
        -- Randomizes the amount of water remaining after the water shutoff. <LINE>Higher values can reduce the configured remaining water by a larger amount. Default = None
        -- 1 = None
        -- 2 = Up to 25% reduction
        -- 3 = Up to 50% reduction
        -- 4 = Up to 75% reduction
        -- 5 = Up to 100% reduction
        RemainingWaterRandomizationIntensity = 1,
        -- The chance of body shampoo spawning. Default = Rare
        -- 1 = None
        -- 2 = Extremely Rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Abundant
        BathItemSpawnChance = 3,
        -- The chance of bath salt spawning. Default = Extremely Rare
        -- 1 = None
        -- 2 = Extremely Rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Abundant
        BathSaltSpawnChance = 3,
        -- This checkbox option does nothing itself.
        TubFluidContainerSection = false,
        -- The amount of water that can be stored in a bathtub. 
        --  <PUSHRGB:1,0.5,0.5> Note: This is separate from the amount of water remaining in the faucet when shut out of the water supply. <POPRGB> Min: 100 Max: 1000 Default: 200
        TubWaterCapacity = 200,
        -- If you placed bathtub to outdoors, you can collect rainwater. But you cannot use that water for plumbing.
        TubRainCollect = true,
        -- When you bathing, the water becomes tainted by the dirt washed off your body.
        TubWaterGetDirty = true,
        -- If you have electricity, you can reheat the bath water.
        EnableReheat = true,
        -- Whether to consider all fluid types when check for fluid containers plumbed into baths and showers. If disabled, only fluid containers containing water will be considered.
        AvailableAllFluid = false,
        -- This checkbox option does nothing itself.
        BathAndShowerSection = false,
        -- The amount of water consumed when washing blood, dirt, and grime from your body during a bath. This is a relative value based on the total amount removed. If you want to disable water consumption, set it to 0. Min: 0.00 Max: 1.00 Default: 0.80
        WashInBathConsumeWater = 0.8,
        -- The amount of water needed to take a shower. Min: 0 Max: 200 Default: 80
        ShowerConsumeWater = 80,
        -- Maximum in-game minutes that bath additive benefits can be received. The limit resets 12 in-game hours after the last benefit. Set to 0 for no limit. Min: 0 Max: 240 Default: 30
        BathingBenefitDailyMinutes = 30,
        -- Disable the increase discomfort, boredom, and unhappiness that comes from bathing with wearing clothes or in bad condition bathwater (wrong temperature or dirty).
        DisableNegativeEffectsOfBathing = false,
        -- Disable the increased stress caused by someone (includ zombies) seen at you while bathing.
        DisableFeelingStressByGaze = false,
        -- This checkbox option does nothing itself.
        BodyGrimeSection = false,
        -- Enable Body Grime functions. If this to False, all settings below this will be disabled.
        EnableBodyGrime = true,
        -- Allow the vanilla Wash Yourself action to remove Body Grime.
        WashSelfRemovesGrime = true,
        -- Allow Body Grime to be washed at water sources such as sinks, lakes, and ponds.
        EnableGrimeWash = true,
        -- Require sufficient soap to use the Grime Wash action.
        GrimeWashRequiresSoap = false,
        -- Displays a moodle that increases in severity for every 25 Body Grime accumulated. <LINE> <PUSHRGB:1,0.5,0.5> It will not work if Moodle Framework Mod is not installed!<POPRGB>
        EnableBodyGrimeMoodle = true,
        -- The base amount of Grime that accumulates for your body every hour without you doing anything. Min: 0.00 Max: 100.00 Default: 0.80
        BodyGrimeIncreasedBase = 0.8,
        -- If there is more blood on your body than this value, it will accumulate on the body as Grime. Min: 0 Max: 100 Default: 30
        BloodToGrimeThreshold = 30,
        -- If there is more dirt on your body than this value, it will accumulate on the body as Grime. Min: 0 Max: 100 Default: 30
        DirtToGrimeThreshold = 30,
        -- A multiplier on how amount blood and dirt over the threshold will accumulate as grime. <LINE> This is calculated by total blood or dirt stains on full body, not by part, and the maximum value is 1, not 100. <LINE> If you set this value to 3, you will accumulate 1.5 additional grime every hour if you have 50 blood on your body. Min: 0.00 Max: 100.00 Default: 1.00
        BloodAndDirtMultiplier = 1.0,
        -- If you have too much Grime, you will feel discomfort.
        GrimeDiscomfort = true,
        -- Discomfort modifier when grime is 60 or more but below 75. <LINE> 0 disables discomfort for this stage. Min: 0.00 Max: 1.00 Default: 0.15
        GrimeDiscomfort1 = 0.15,
        -- Discomfort modifier when grime is 75 or more but below 90. <LINE> 0 disables discomfort for this stage. Min: 0.00 Max: 1.00 Default: 0.30
        GrimeDiscomfort2 = 0.3,
        -- Discomfort modifier when grime is 90 or more. <LINE> 0 disables discomfort for this stage. Min: 0.00 Max: 1.00 Default: 0.55
        GrimeDiscomfort3 = 0.55,
        -- If you have too much Grime, you will feel a slight noxious smell.
        GrimeNoxiousSmell = true,
    },
    FcknSpldrV5 = {
        -- This is the loot multiplier for very rare spawns (default chance 0.001-0.010) for Frockin Splendor! Vol.5, such as loose items in residential and functional areas. Set the number to 0 to stop this category from spawning, set the number to 1000 to have them appear in almost all containers. Min: 0.00 Max: 1000.00 Default: 1.00
        LootBetaVRare = 1.0,
        -- This is the loot multiplier for rare spawns (default chance 0.010-0.900) for Frockin Splendor! Vol.5, such as lootboxes. Set the number to 0 to stop this category from spawning, set the number to 100 to have them appear in almost all containers. Min: 0.00 Max: 100.00 Default: 1.00
        LootBetaRare = 1.0,
        -- This is the loot multiplier for common spawns (default chance more than 1.000) for Frockin Splendor! Vol.5, such as items that are spawning in commercial areas. Set the number to 0 to stop this category from spawning, set the number to 10 to have them appear in almost all containers. Min: 0.00 Max: 10.00 Default: 1.00
        LootBetaCommon = 1.0,
    },
    FcknStmpr = {
        -- This is the loot multiplier for very rare spawns (default chance 0.001-0.010) for Frockin Stompers!, such as loose items in residential and functional areas. Set the number to 0 to stop this category from spawning, set the number to 1000 to have them appear in almost all containers. Min: 0.00 Max: 1000.00 Default: 1.00
        LootBetaVRare = 1.0,
        -- This is the loot multiplier for common spawns (default chance more than 1.000) for Frockin Stompers!, such as items that are spawning in commercial areas. Set the number to 0 to stop this category from spawning, set the number to 10 to have them appear in almost all containers. Min: 0.00 Max: 10.00 Default: 1.00
        LootBetaCommon = 1.0,
    },
    LowConditionGuns = {
        -- Min: 1 Max: 100 Default: 20
        NormalMinCondition = 20,
        -- Min: 1 Max: 100 Default: 70
        NormalMaxCondition = 70,
        -- Min: 1 Max: 100 Default: 70
        StoreMinCondition = 70,
        -- Min: 1 Max: 100 Default: 100
        StoreMaxCondition = 100,
        -- Min: 1 Max: 100 Default: 50
        PoliceMinCondition = 60,
        -- Min: 1 Max: 100 Default: 80
        PoliceMaxCondition = 90,
        -- Min: 1 Max: 100 Default: 80
        MilitaryMinCondition = 80,
        -- Min: 1 Max: 100 Default: 100
        MilitaryMaxCondition = 100,
        AffectMelee = false,
        -- Min: 0.00 Max: 100.00 Default: 0.10
        PerfectConditionChance = 0.1,
    },
    TacHold = {
        -- Required aiming level before Long gun animations activate. Min: 0 Max: 10 Default: 0
        AimingRequirement = 2,
        -- Required aiming level before pistol animations activate. Min: 0 Max: 10 Default: 0
        PistolAimingRequirement = 1,
    },
    VFE = {
        -- VFE weapons spawning attached to police zombies.
        PoliceWeapons = true,
        -- Weapons spawning attached to military zombies. (Not just VFE specific ones)
        MilitaryWeapons = true,
        -- Weapons spawning attached to survivor zombies. (Not just VFE specific ones)
        SurvivorWeapons = true,
        -- Weapons spawning attached to other zombies zombies, like bikers. (Not just VFE specific ones)
        OtherWeapons = true,
        -- VFE weapons spawning inside vehicle inventories.
        CarWeapons = true,
        -- VFE weapons spawning inside of normal houses.
        HouseWeapons = true,
        -- Multiplier to weapons spawning in houses (Requires previous option enabled) Min: 0.10 Max: 10.00 Default: 1.00
        HouseWeaponsMulti = 1.0,
        -- Allows spawning of weapons like the M60 Machinegun.
        HeavyWeapons = true,
        -- Global multiplier for how many VFE firearms spawn in containers. Min: 0.10 Max: 10.00 Default: 1.00
        GunLootMulti = 1.0,
        -- VFE firearms spawning in army storage, bunkers and military lockers.
        LootMilitary = true,
        -- VFE firearms spawning in police, SWAT and security storage.
        LootPolice = true,
        -- VFE firearms spawning in gun stores and pawn shops.
        LootStore = true,
        -- VFE firearms spawning in drug labs, dealer shacks and floor-plank stashes.
        LootCriminal = true,
        -- VFE firearms spawning in hunter, trapper and survival containers.
        LootHunting = true,
        -- VFE firearms spawning in survivor safehouse stashes that appear as the world ages.
        LootSafehouse = true,
        -- Vanilla-only firearms (JS14, L92, L94, MSR7T, Trapper Carbine, JS3T) plus the M1911 and both small revolvers stop spawning in the containers VFE fills. They still appear on zombies, in vehicles and in every other vanilla list.
        RemoveVanillaGuns = true,
        -- Range the x2 scope adds to the weapon. Min: -20 Max: 50 Default: 5
        AT_x2ScopeRange = 5,
        -- Aiming time the x2 scope adds. Higher = slower to aim. Min: -50 Max: 50 Default: 5
        AT_x2ScopeAim = 5,
        -- Range the x4 scope adds to the weapon. Min: -20 Max: 50 Default: 10
        AT_x4ScopeRange = 10,
        -- Aiming time the x4 scope adds. Higher = slower to aim. Min: -50 Max: 50 Default: 10
        AT_x4ScopeAim = 10,
        -- Range the x8 scope adds to the weapon. Min: -20 Max: 50 Default: 15
        AT_x8ScopeRange = 15,
        -- Aiming time the x8 scope adds. Higher = slower to aim. Min: -50 Max: 50 Default: 20
        AT_x8ScopeAim = 20,
        -- Aiming time the red dot adds. Negative = faster to aim. Min: -50 Max: 50 Default: -10
        AT_RedDotAim = -10,
        -- Aiming time the improved irons add. Negative = faster to aim. Min: -50 Max: 50 Default: -5
        AT_IronSightAim = -5,
        -- Aiming time the laser adds. Negative = faster to aim. Min: -50 Max: 50 Default: -5
        AT_LaserAim = -5,
        -- Hit chance the laser adds. Min: -50 Max: 50 Default: 10
        AT_LaserHit = 10,
        -- Aiming time the bipod adds. Negative = faster to aim. Min: -50 Max: 50 Default: -5
        AT_BipodAim = -5,
        -- Hit chance the bipod adds. Min: -50 Max: 50 Default: 30
        AT_BipodHit = 30,
        -- Range the bipod adds to the weapon. Min: -20 Max: 50 Default: 5
        AT_BipodRange = 5,
        -- Aiming time the recoil pad adds. Negative = faster to aim. Min: -50 Max: 50 Default: -5
        AT_RecoilPadAim = -5,
        -- Recoil delay the pad adds. Negative = faster follow-up shots. Never lets a weapon reach 0. Min: -20 Max: 20 Default: -2
        AT_RecoilPadDelay = -2,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 20
        Ammo_762 = 20,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 20
        Ammo_223 = 20,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 50
        Ammo_22 = 50,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 20
        Ammo_545 = 20,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 30
        Ammo_76254 = 30,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 50
        Ammo_57 = 50,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 50
        Ammo_46 = 50,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 90
        Ammo_556bp = 90,
        -- Loose rounds one box or pack yields, and how many go back in when packing. Admin panel overrides this. Min: 1 Max: 1000 Default: 30
        Ammo_m13 = 30,
    },
    ISIL = {
        -- Enables configurable suppression strength and optional suppressor durability. Disabled by default to preserve the original mod balance.
        ExtendedMode = false,
        -- Suppressors lose durability whenever the weapon is fired and are destroyed when exhausted. Only applies while Extended Realism Mode is enabled.
        EnableDurability = true,
        -- Adjusts suppressor wear by ammunition caliber. Small calibers consume less durability, while rifle and shotgun ammunition consume more. Unknown ammunition uses the standard 9mm wear rate.
        CaliberBasedWear = true,
        -- Percentage reduction applied to firearm sound radius and volume in Extended Realism Mode. Min: 0 Max: 100 Default: 60
        ProfessionalNoiseReduction = 80,
        -- Percentage reduction applied to firearm sound radius and volume in Extended Realism Mode. Min: 0 Max: 100 Default: 40
        MetalPipeNoiseReduction = 60,
        -- Percentage reduction applied to firearm sound radius and volume in Extended Realism Mode. Min: 0 Max: 100 Default: 30
        HandTorchNoiseReduction = 40,
        -- Percentage reduction applied to firearm sound radius and volume in Extended Realism Mode. Min: 0 Max: 100 Default: 20
        WaterBottleNoiseReduction = 30,
        -- Number of 9mm-equivalent shots before a professional suppressor is destroyed. Min: 1 Max: 10000 Default: 500
        ProfessionalDurability = 500,
        -- Number of 9mm-equivalent shots before a metal pipe suppressor is destroyed. Min: 1 Max: 10000 Default: 100
        MetalPipeDurability = 100,
        -- Number of 9mm-equivalent shots before a hand torch suppressor is destroyed. Min: 1 Max: 10000 Default: 20
        HandTorchDurability = 40,
        -- Number of 9mm-equivalent shots before a water bottle suppressor is destroyed. Min: 1 Max: 10000 Default: 5
        WaterBottleDurability = 10,
    },
    RadArchery = {
        -- Percent chance a Carved Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 25
        CarvedArrowRecovery = 25,
        -- Percent chance a Fine Carved Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 40
        FineCarvedArrowRecovery = 40,
        -- Percent chance a Stone-Tipped Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 50
        StoneTippedArrowRecovery = 50,
        -- Percent chance a Bone-Tipped Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 50
        BoneTippedArrowRecovery = 50,
        -- Percent chance a Tipped Carved Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 55
        TippedCarvedArrowRecovery = 55,
        -- Percent chance a Carbon Hunting Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 90
        HuntingArrowRecovery = 90,
        -- Percent chance a Bodkin Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 75
        BodkinArrowRecovery = 75,
        -- Percent chance a Broadhead Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 65
        BroadheadArrowRecovery = 65,
        -- Percent chance a Bodkin (MFD) Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 90
        BodkinArrowMFDRecovery = 90,
        -- Percent chance a Broadhead (MFD) Arrow survives hitting a zombie and lodges in the body, to be recovered by looting the corpse. Min: 0 Max: 100 Default: 85
        BroadheadArrowMFDRecovery = 85,
        -- Scales how much arm muscle strain drawing and holding a bow causes: a one-off cost when the draw starts, plus a drain for every second the aim is held. Heavier bows tire the arms faster, a compound bow's let-off makes it far easier to hold, and a higher Archery level tires them slower. Set to 0 to remove bow strain entirely. Applied on top of the game's own Muscle Strain Factor setting. Min: 0 Max: 1000 Default: 100
        BowStrainFactor = 100,
        -- Scales the spawn chance of every RadArchery item together -- bows, arrows, the Leather Quiver and Archery skill books -- on top of each category's own slider below. Set to 0 to remove all RadArchery loot. Min: 0 Max: 1000 Default: 100
        LootGeneral = 180,
        -- Scales how often compound bows spawn in containers, vehicles and zombie outfits, on top of the Overall RadArchery Loot slider above. The craft-only carved bows are unaffected -- they never spawn as loot. Min: 0 Max: 1000 Default: 100
        LootBows = 100,
        -- Scales how often loose Carbon Hunting Arrows and their packs and crates spawn, on top of the Overall RadArchery Loot slider above. Min: 0 Max: 1000 Default: 100
        LootArrows = 100,
        -- Scales how often the Leather Quiver spawns, on top of the Overall RadArchery Loot slider above. The quiver is also craftable regardless of this setting. Min: 0 Max: 1000 Default: 100
        LootQuiver = 100,
        -- Scales how often the Archery and Fletching skill books spawn, on top of the Overall RadArchery Loot slider above. Min: 0 Max: 1000 Default: 100
        LootBooks = 100,
        -- Percent chance an arrow shot into an Archery Target survives and stays stuck in it, to be pulled back out. The same for every arrow type. Min: 0 Max: 100 Default: 90
        TargetArrowRecovery = 90,
        -- Archery level at which shooting an Archery Target stops awarding Archery XP. Zombie hits are unaffected. Set to 0 for no cap. Min: 0 Max: 10 Default: 5
        TargetXpCapLevel = 5,
    },
    Explosives = {
        -- Off by default. When enabled, the mod's custom throw arc and ground-target marker also apply to vanilla Pipe Bombs, Aerosol Bombs, Smoke Bombs, Flame Traps, Noise Traps, Firecrackers, and Molotov Cocktails (including their sensor, remote, and timer variants where they exist), instead of only this mod's own grenades.
        VanillaBallisticsEnabled = false,
        -- Multiplies the spawn chance of all grenades and mines in loot containers. 0.5 = half as frequent, 1.0 = default, 2.0 = twice as frequent. Min: 0.01 Max: 5.00 Default: 1.00
        LootMultiplier = 1.0,
        -- When enabled, zombies take additional damage while on fire, regardless of the fire source. Disable to use vanilla fire behavior.
        FireDamageEnabled = true,
        -- Multiplies the additional fire damage dealt to burning zombies. 0.5 = about 30% faster than vanilla, 1.0 = about twice as fast, 5.0 = about five times faster than vanilla. Min: 0.50 Max: 5.00 Default: 1.00
        FireDamageMultiplier = 1.0,
        -- Off by default. When enabled, this mod's own grenades (Mk2, M26, M67, M84 Flashbang, M14 TH3) land and sit armed for a few seconds before exploding, instead of detonating immediately on impact. Does not affect mines/Claymores (which already land as placed traps) or vanilla throwables.
        DelayedFuseEnabled = false,
        -- How many seconds a landed grenade sits armed before exploding, when Delayed Fuse on Landing is enabled. Min: 0.50 Max: 10.00 Default: 4.00
        DelayedFuseSeconds = 4.0,
        -- Off by default. When enabled, Shift + Numpad "+" (rebindable in Mod Options) spawns a single flashbang directly into your inventory for quick trajectory testing.
        DebugSpawnKeyEnabled = false,
    },
    ElectricWeaponMalfunction = {
        -- Adjust the malfunction factor of electrified weapons.
        --  Higher values increase malfunction chances. Min: 0.10 Max: 2.00 Default: 1.00
        MalfunctionFactor = 1.0,
        -- Adjust the battery consumption rate of electrified weapons.
        --  The higher the number, the faster the power drains. Min: 0.10 Max: 2.00 Default: 1.00
        PowerConsumptionFactor = 1.0,
    },
    Nihonto = {
        -- If this is activated, the vanilla Katana will be replaced by Nihontō Katana in all vanilla spawn locations.
        replaceVanillaKatana = true,
        -- This value defines by how much the spawn rate for Nihonto Weapons and the vanilla Katana (if replaced) is changed. 0.5=halved, 1=no change, 2=double, etc. Does not affect associated literature spawns. Min: 0.00 Max: 100.00 Default: 10.00
        WeightMultiplier = 10.0,
        -- If this is activated, the condition protection mechanic will be applied to all bladed weapons, not just Nihonto weapons. The mechanic gives a chance to reduce sharpness instead of condition when hitting with a bladed weapon, simulating the blade getting dull but not breaking immediately.
        SharpnessMechanic = true,
        -- The higher the value, the longer the weapon lasts. Min: 10.00 Max: 100.00 Default: 36.00
        Katana_ConditionLowerChanceOneIn = 36.0,
        -- Sets the maximum durability of the Katana. Min: 10.00 Max: 100.00 Default: 18.00
        Katana_ConditionMax = 18.0,
        -- The higher the value, the longer the weapon lasts. Min: 10.00 Max: 100.00 Default: 32.00
        Wakizashi_ConditionLowerChanceOneIn = 32.0,
        -- Min: 5.00 Max: 30.00 Default: 16.00
        Wakizashi_ConditionMax = 16.0,
        -- The higher the value, the longer the weapon lasts. Min: 10.00 Max: 50.00 Default: 36.00
        Nagamaki_ConditionLowerChanceOneIn = 36.0,
        -- Sets the maximum durability of the Nagamaki. Min: 10.00 Max: 50.00 Default: 18.00
        Nagamaki_ConditionMax = 18.0,
        -- The higher the value, the longer the weapon lasts. Min: 10.00 Max: 100.00 Default: 40.00
        Odachi_ConditionLowerChanceOneIn = 40.0,
        -- Sets the maximum durability of the Ōdachi. Min: 10.00 Max: 100.00 Default: 20.00
        Odachi_ConditionMax = 20.0,
        -- The higher the value, the longer the weapon lasts. Min: 10.00 Max: 50.00 Default: 28.00
        Tanto_ConditionLowerChanceOneIn = 28.0,
        -- Sets the maximum durability of the Tantō. Min: 10.00 Max: 50.00 Default: 14.00
        Tanto_ConditionMax = 14.0,
        -- Chance to prevent condition loss at 100% sharpness. Scaled linearly with current sharpness. Min: 0.00 Max: 100.00 Default: 75.00
        SharpnessProtectionMultiplier = 75.0,
        -- Multiplies how fast the blade dulls when protecting condition. 0.5: Half speed, 2.0: Double speed. Min: 0.50 Max: 2.00 Default: 1.00
        SharpnessDullingMultiplier = 1.0,
        -- Chance for a properly oiled blade (Choji oil ritual) to fully prevent condition loss on a hit, at no cost to sharpness. Checked before the sharpness protection roll. Min: 10.00 Max: 100.00 Default: 50.00
        CareProtectionChance = 50.0,
        -- How many weapon hits the Choji oil protection lasts for before needing to be reapplied. Min: 100.00 Max: 1000.00 Default: 500.00
        ChojiOilProtectionHits = 500.0,
        -- When enabled, Katanas, Wakizashis, crafting books, and weapon parts will spawn in additional, more mundane locations.
        MoreLoot = false,
    },
    B42PackMule = {
        -- Enables attaching lanterns to belt slots.
        Attachment1 = true,
        -- Enables attaching welding torches to back slot.
        Attachment2 = true,
        -- Enables slings to be worn in the satchel slot.
        Satchel1 = true,
        -- Enables cloth gun cases to be worn in the satchel slot.
        Satchel2 = false,
        -- Enables dedicated bracelet slot, can be worn with watches and forearm armor.
        Bracelet = true,
        -- Enabled dedicated watch slot, can be worn with bracelets and forearm armor.
        Watch = true,
        -- If enabled watches and bracelets will be forced to share a slot, but maintain their ability to be worn with forearm armor.
        Exclusion1 = true,
        -- Enables dedicated canteen slot, can be worn with satchels.
        Canteen = true,
        -- Enables dedicated ear protector slot, cannot be worn with full helmets or suit heads.
        Ear = true,
        -- Enables dedicated shoulder slot with the ability to equip alongside backpacks and SCBA gear.
        Shoulder = true,
        -- Enables dedicated slot for duffel and golf bags, can be worn with backpacks.
        Back1 = true,
        -- Enables dedicated cloth gun case slot, can be worn with backpacks and duffels (will overwrite 'Satchel: Sling' if both enabled).
        Back2 = true,
        -- (Singleplayer only) Enables dedicated pouch slot.
        Pouch1 = false,
        -- (Singleplayer only) Enables dedicated wallet slot.
        Wallet1 = false,
        -- If enabled wallets and pouches will be forced to share a slot.
        Exclusion2 = false,
        -- Increases wallet weight reduction from 0 to 30.
        WalletFix = true,
        -- (Does not work with 'Slot: Pouch') Enables keyring auto-equipping behavior to pouches.
        Pouch2 = false,
        -- (Does not work with 'Slot: Wallet') Enables keyring auto-equipping behavior to wallets.
        Wallet2 = false,
        -- Enables carry capacity on all hunting vests and converts them from a clothing item to a container item. If changed mid-game any already existing vests will disappear.
        Vest1 = false,
        -- Enables two new vest attachment slots and allows for firearm magazines/cd players to equip to them.
        Vest2 = true,
        -- (Does not work with 'Vest: Capacity') Enables patching holes on hunting vests.
        Vest3 = false,
        -- Disables the ability to gain holes on all hunting vests (will overwrite 'Vest: Repair' if both enabled).
        Vest4 = false,
        -- Enables webbing slots on all small backpacks.
        Webbing1 = true,
        -- Enables webbing slots on all hiking backpacks.
        Webbing2 = true,
        -- Enables webbing slots on all military and survivor backpacks.
        Webbing3 = true,
        -- Enables webbing slots on all small crafted backpacks.
        Webbing4 = true,
        -- Enables webbing slots on all framepacks.
        Webbing5 = true,
    },
    SBFPlus = {
        DebugLogging = false,
    },
    Cerberus = {
        -- Does Nothing. Just name of category that separates categories
        Category1 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Min: 0.00 Max: 100.00 Default: 0.06
        UnifrormZombiesDefault = 0.06,
        -- Specifies the probability of encountering Zombies in Cerberus Light Armor at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Min: 0.00 Max: 100.00 Default: 0.04
        LightArmoredZombiesDefault = 0.04,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Min: 0.00 Max: 100.00 Default: 0.02
        MediumArmoredZombiesDefault = 0.02,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Default Zones. This setting determines whether Cerberus Zeds can be encountered in cities, forests, or essentially any location where regular zombies can be found. Min: 0.00 Max: 100.00 Default: 0.01
        HeavyArmoredZombiesDefault = 0.01,
        -- Does Nothing. Just separates categories
        EmptyLine2 = false,
        -- Does Nothing. Just name of category that separates categories
        Category2 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Police Stations Min: 0.00 Max: 100.00 Default: 0.08
        UnifrormZombiesPolice = 0.08,
        -- Min: 0.00 Max: 100.00 Default: 0.06
        LightArmoredZombiesPolice = 0.06,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Police Stations Min: 0.00 Max: 100.00 Default: 0.04
        MediumArmoredZombiesPolice = 0.04,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Police Stations Min: 0.00 Max: 100.00 Default: 0.02
        HeavyArmoredZombiesPolice = 0.02,
        -- Does Nothing. Just separates categories
        EmptyLine3 = false,
        -- Does Nothing. Just name of category that separates categories
        Category3 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Military Bases Min: 0.00 Max: 100.00 Default: 0.10
        UnifrormZombiesArmy = 0.1,
        -- Specifies the probability of encountering Zombies in Cerberus Light Armor at Military Bases Min: 0.00 Max: 100.00 Default: 0.80
        LightArmoredZombiesArmy = 0.8,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Military Bases Min: 0.00 Max: 100.00 Default: 0.60
        MediumArmoredZombiesArmy = 0.6,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Military Bases Min: 0.00 Max: 100.00 Default: 0.40
        HeavyArmoredZombiesArmy = 0.4,
        -- Does Nothing. Just separates categories
        EmptyLine4 = false,
        -- Does Nothing. Just name of category that separates categories
        Category4 = false,
        -- Specifies the probability of encountering Zombies in Cerberus Uniform at Secret Base Min: 0.00 Max: 100.00 Default: 2.00
        UnifrormZombiesSecretBase = 2.0,
        -- Specifies the probability of encountering Zombies in Cerberus Light Armor at Secret Base Min: 0.00 Max: 100.00 Default: 1.20
        LightArmoredZombiesSecretBase = 1.2,
        -- Specifies the probability of encountering Zombies in Cerberus Medium Armor at Secret Base Min: 0.00 Max: 100.00 Default: 0.80
        MediumArmoredZombiesSecretBase = 0.8,
        -- Specifies the probability of encountering Zombies in Cerberus Heavy Armor at Secret Base Min: 0.00 Max: 100.00 Default: 0.60
        HeavyArmoredZombiesSecretBase = 0.6,
        -- Does Nothing. Just separates categories
        EmptyLine5 = false,
        -- Does Nothing. Just name of category that separates categories
        Category5 = false,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Bulletproof Vest in containers Min: 0.00 Max: 100.00 Default: 0.05
        BulletproofVest_Cerberus = 0.05,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_HighMobilityKit.png> <LINE> Defines spawn chances for the Cerberus High Mobility Kit in containers Min: 0.00 Max: 100.00 Default: 0.03
        BulletproofVest_Cerberus_HighMobilityKit = 0.03,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_AssaultLightKit.png> <LINE> Defines spawn chances for the Cerberus Light Assault Kit in containers Min: 0.00 Max: 100.00 Default: 0.03
        BulletproofVest_Cerberus_AssaultLightKit = 0.03,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_AssaultKit.png> <LINE> Defines spawn chances for the Cerberus Assault Kit in containers Min: 0.00 Max: 100.00 Default: 0.02
        BulletproofVest_Cerberus_AssaultKit = 0.015,
        -- <IMAGE:media/textures/Item_BulletproofVest_Cerberus_FullProtectionKit.png> <LINE> Defines spawn chances for the Cerberus Full Protection Kit in containers Min: 0.00 Max: 100.00 Default: 0.01
        BulletproofVest_Cerberus_FullProtectionKit = 0.005,
        -- Does Nothing. Just separates categories
        EmptyLine6 = false,
        -- Does Nothing. Just name of category that separates categories
        Category6 = false,
        -- <IMAGE:media/textures/Item_Helmet_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Helmet in containers Min: 0.00 Max: 100.00 Default: 0.02
        Helmet = 0.02,
        -- <IMAGE:media/textures/Item_Helmet_Mandible_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Helmet Mandible in containers Min: 0.00 Max: 100.00 Default: 0.02
        Helmet_Mandible = 0.02,
        -- <IMAGE:media/textures/Item_MaskFull_BallisticMask_Cerberus.png><IMAGE:media/textures/Item_MaskFull_BallisticMask_Cerberus2.png><IMAGE:media/textures/Item_MaskFull_BallisticMask_Cerberus3.png> <LINE> Defines spawn chances for the Cerberus Ballistic Mask in containers Min: 0.00 Max: 100.00 Default: 0.15
        MaskFull_BallisticMask = 0.15,
        -- <IMAGE:media/textures/Item_ElbowPads_Cerberus.png> <LINE> Defines spawn chances for the Cerberus Elbow Pads Kit in containers Min: 0.00 Max: 100.00 Default: 0.40
        ElbowPads = 0.4,
        -- <IMAGE:media/textures/Item_KneePads_Cerberus.png> <LINE> Defines spawn chances for the Knee Pads in containers Min: 0.00 Max: 100.00 Default: 0.40
        KneePads = 0.4,
        -- Does Nothing. Just separates categories
        EmptyLine7 = false,
        -- Does Nothing. Just name of category that separates categories
        Category7 = false,
        -- <IMAGE:media/textures/Item_HipBag_Cerberus.png> <LINE> Defines spawn chances for Cerberus Hip Bag in containers Min: 0.00 Max: 100.00 Default: 0.03
        HipBag = 0.03,
        -- <IMAGE:media/textures/Item_FannyPack_Cerberus.png> <LINE> Defines spawn chances for Cerberus Fanny Pack in containers Min: 0.00 Max: 100.00 Default: 0.03
        FannyPack = 0.03,
        -- <IMAGE:media/textures/Item_ChestRigs_Cerberus.png> <LINE> Defines spawn chances for Cerberus Chest Rig in containers Min: 0.00 Max: 100.00 Default: 0.03
        ChestRigs = 0.03,
        -- <IMAGE:media/textures/Item_Backpack_Cerberus.png> <LINE> Defines spawn chances for Cerberus Backpack in containers. Min: 0.00 Max: 100.00 Default: 0.03
        Backpack = 0.03,
        -- Does Nothing. Just separates categories
        EmptyLine8 = false,
        -- Does Nothing. Just name of category that separates categories
        Category8 = false,
        -- <IMAGE:media/textures/Item_Headsets_Cerberus2.png><IMAGE:media/textures/Item_Headsets_Cerberus.png><IMAGE:media/textures/Item_Mask_Balaclava_Cerberus.png><IMAGE:media/textures/Item_Mask_Balaclava_Cerberus2.png><IMAGE:media/textures/Item_Mask_BandanaMask_Cerberus.png><IMAGE:media/textures/Item_Mask_BandanaMask_Cerberus2.png><IMAGE:media/textures/Item_Mask_BandanaMask_Cerberus3.png><IMAGE:media/textures/Item_Glasses_Goggles_Cerberus.png><IMAGE:media/textures/Item_Glasses_Tactical_Cerberus.png><IMAGE:media/textures/Item_Hat_BaseballCap_Cerberus.png><IMAGE:media/textures/Item_Hat_BaseballCap_Cerberus2.png> <LINE> Defines spawn chances for headsets, balaclavas, bandanas, goggles and caps in containers Min: 0.00 Max: 100.00 Default: 0.30
        HeadApparel = 0.3,
        -- <IMAGE:media/textures/Item_Jacket_Lightweight_Cerberus.png><IMAGE:media/textures/Item_Jacket_Lightweight_Cerberus2.png> <LINE> Defines spawn chances for jackets in containers Min: 0.00 Max: 100.00 Default: 0.03
        Jacket = 0.03,
        -- <IMAGE:media/textures/Item_Gloves_Cerberus.png><IMAGE:media/textures/Item_GlovesFingerless_Cerberus.png> <LINE> Defines spawn chances for gloves in containers Min: 0.00 Max: 100.00 Default: 0.04
        Gloves = 0.04,
        -- <IMAGE:media/textures/Item_Shirt_Cerberus.png><IMAGE:media/textures/Item_Shirt_Cerberus2.png><IMAGE:media/textures/Item_Shirt_ShortSleeve_Cerberus.png><IMAGE:media/textures/Item_Shirt_ShortSleeve_Cerberus2.png><IMAGE:media/textures/Item_Shirt_TankTop_Cerberus.png><IMAGE:media/textures/Item_Shirt_TankTop_Cerberus2.png><IMAGE:media/textures/Item_Shirt_TankTopShort_Cerberus.png><IMAGE:media/textures/Item_Shirt_TankTopShort_Cerberus2.png><IMAGE:media/textures/Item_Shirt_Tshirt_Cerberus.png><IMAGE:media/textures/Item_Shirt_Tshirt_Cerberus2.png><IMAGE:media/textures/Item_Shirt_TshirtShort_Cerberus.png><IMAGE:media/textures/Item_Shirt_TshirtShort_Cerberus2.png> <LINE> Defines spawn chances for classic, short sleeve, tank top, short tank top, T-shirts, short T-shirts in containers Min: 0.00 Max: 100.00 Default: 0.04
        MilitaryTShirts = 0.04,
        -- <IMAGE:media/textures/Item_Pants_Classic_Cerberus.png><IMAGE:media/textures/Item_Pants_Skinny_Cerberus.png> <LINE> Defines spawn chances for cargo and skinny pants in containers Min: 0.00 Max: 100.00 Default: 0.04
        PantsShorts = 0.04,
        -- <IMAGE:media/textures/Item_Shoes_TacticalBoots_Cerberus.png><IMAGE:media/textures/Item_Shoes_TacticalBoots_Cerberus2.png> <LINE>  Defines spawn chances for Cerberus tactical boots in containers Min: 0.00 Max: 100.00 Default: 0.04
        BootsShoes = 0.04,
        -- <IMAGE:media/textures/Item_Shirt_Neckholder_Cerberus.png><IMAGE:media/textures/Item_Shirt_Neckholder_Cerberus2.png><IMAGE:media/textures/Item_Shirt_NeckholderShort_Cerberus.png><IMAGE:media/textures/Item_Shirt_NeckholderShort_Cerberus2.png><IMAGE:media/textures/Item_Tights_Cerberus.png><IMAGE:media/textures/Item_Tights_Cerberus2.png><IMAGE:media/textures/Item_Stockings_Cerberus.png><IMAGE:media/textures/Item_Stockings_Cerberus2.png><IMAGE:media/textures/Item_Stockings_Cerberus3.png><IMAGE:media/textures/Item_Pants_Shorts_Cerberus.png><IMAGE:media/textures/Item_Pants_Shorts_Cerberus2.png><LINE> Defines spawn chances for non-military apparel in store containers. Includes neckholder shirts, short neckholder shirts, tights, stockings and skinny shorts. Does not spawn at military bases Min: 0.00 Max: 100.00 Default: 0.30
        NonMilitary = 0.3,
    },
    KATTAJ1 = {
        -- Specifies the probability of finding NVGs in military storages Min: 0.00 Max: 100.00 Default: 0.10
        ArmyStorage = 0.1,
        -- Specifies the probability of finding NVGs in Police Storages Min: 0.00 Max: 100.00 Default: 0.05
        PoliceStorage = 0.05,
    },
    JordanalSpawns = {
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Min: 0.00 Max: 100.00 Default: 0.04
        Desert_Camo_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Min: 0.00 Max: 100.00 Default: 0.02
        Desert_Camo_UnitChance_General = 0.02,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Min: 0.00 Max: 100.00 Default: 0.04
        MARPAT_Camo_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Min: 0.00 Max: 100.00 Default: 0.04
        Black_Camo_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Min: 0.00 Max: 100.00 Default: 0.02
        Black_Camo_UnitChance_General = 0.02,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Min: 0.00 Max: 100.00 Default: 0.04
        SWAT_UnitChance = 0.04,
        -- Its percentual, but it does share its chance with other outfits, so at 100 you will never get only zombies with this outfits Min: 0.00 Max: 100.00 Default: 0.02
        SWAT_UnitChance_General = 0.02,
    },
    BlackDivisionGear = {
        -- How often the BD1 set spawns in military lockers and storage: jacket, pants, sneakers, gloves, warbelt with holster, LV-119 light plate carrier and its pouches. Default = Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD1 = 4,
        -- How often the BD2 set spawns: combat shirt, pants, boots, gloves, warbelt with holster, drop-leg pouch, wrist GPS, FCPC V5 plate carrier and its pouches, 2 Day Assault Pack. Default = Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD2 = 4,
        -- How often the BD3 set spawns: hooded jacket, pants, boots, fingerless gloves, warbelt with holster, LV-119 plate carrier and its pouches, NICE Frame backpack. Default = Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD3 = 4,
        -- How often the BD4 set spawns: hybrid jacket, pants with knee pads, boots, gloves, battle belt, drop-leg holster and pouches, tactical watch, Siege-R plate carrier and its pouches, Modular Pack 45 backpack. Default = Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnBD4 = 4,
        -- How often the head gear spawns: helmets, headsets, glasses, balaclavas, the M53A1 gas mask and the night vision goggles. Default = Normal
        -- 1 = None
        -- 2 = Very rare
        -- 3 = Rare
        -- 4 = Normal
        -- 5 = Common
        -- 6 = Very common
        SpawnHead = 4,
    },
    BritasArmorPackB42 = {
        -- Turns this pack's night vision, battery actions and battery drain on or off. Clothing and installed batteries are kept. This does not add Brita goggle support to another framework. Restart after changing.
        EnableNightVision = true,
        -- Adds the standard 15 percent bonus for supported Brita carriers missed by the original calculation. Disable if another mod manages reload bonuses. Safety checks and bonuses already granted by the game remain active.
        ReloadCarrierBonus = true,
    },
    NVFramework = {
        -- This integrated repair always requires an installed, charged battery. Old saves that stored this option as disabled are migrated automatically.
        BatterySystemEnabled = true,
        -- Controls how quickly installed night-vision batteries drain. 1.0 gives about 12 in-game hours; 2.0 drains twice as fast; 0.5 drains half as fast. Min: 0.10 Max: 100.00 Default: 1.00
        BatteryDrainMultiplier = 1.0,
        -- Scales procedural spawn weights only for example night-vision items added by the framework. 1.0 is default, 2.0 doubles the weight and 0.0 disables framework-added spawns. Min: 0.00 Max: 100.00 Default: 1.00
        ItemSpawnMultiplier = 1.0,
        -- When enabled, singleplayer uses the attached directional light-cone helper. When disabled, it uses the fallback lamppost-based lighting mode.
        UseLightConeInSingleplayer = true,
    },
    LBO = {
        -- Min: 15.00 Max: 49.00 Default: 49.00
        BagCapacity = 49.0,
        -- Min: 0.90 Max: 0.99 Default: 0.99
        BagRunSpeedModifier = 0.99,
        -- Min: 50.00 Max: 99.00 Default: 99.00
        BagWeightReduction = 99.0,
        -- <RGB:0,1,0>How often legendary backpacks appear in houses and shops. Each color appears in places that fit it.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        BackpackCommon = 2,
        -- <RGB:0,1,0>How often legendary backpacks appear in police stations, military sites, fire stations, antique stores and survivor houses.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        BackpackRare = 3,
        -- <RGB:0,1,0>How often zombies carry a legendary backpack.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        BackpackZombies = 1,
        -- <RGB:0,1,0>How often the magazine that teaches the recipes appears (bookshelves, magazine racks, survivor houses, zombies...).
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        Magazine = 5,
        -- Start with a Legendary Backpack (Grey) in your inventory.
        StartWithLBGrey = false,
    },
    LDO = {
        -- Min: 15.00 Max: 49.00 Default: 49.00
        BagCapacity = 45.0,
        -- Min: 0.90 Max: 0.99 Default: 0.99
        BagRunSpeedModifier = 0.99,
        -- Min: 50.00 Max: 99.00 Default: 99.00
        BagWeightReduction = 99.0,
        -- <RGB:0,1,0>How often legendary duffel bags appear in houses and shops. Each color appears in places that fit it.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        DuffelbagCommon = 2,
        -- <RGB:0,1,0>How often legendary duffel bags appear in police stations, military sites, fire stations, antique stores and survivor houses.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        DuffelbagRare = 3,
        -- <RGB:0,1,0>How often zombies carry a legendary duffel bag.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        DuffelbagZombies = 1,
        -- <RGB:0,1,0>How often the magazine that teaches the recipes appears (bookshelves, magazine racks, survivor houses, zombies...).
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        Magazine = 5,
        -- Start with a Legendary Duffel Bag (Grey) in your inventory.
        StartWithLDGrey = false,
    },
    LFO = {
        -- Min: 1.00 Max: 49.00 Default: 10.00
        FannyCapacity = 15.0,
        -- Min: 0.90 Max: 0.99 Default: 0.99
        FannyRunSpeedModifier = 0.99,
        -- Min: 50.00 Max: 99.00 Default: 99.00
        FannyWeightReduction = 99.0,
        -- <RGB:0,1,0>How often legendary fanny packs appear in houses and shops. Each color appears in places that fit it.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        FannypackCommon = 5,
        -- <RGB:0,1,0>How often legendary fanny packs appear in police stations, military sites, fire stations, antique stores and survivor houses.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        FannypackRare = 5,
        -- <RGB:0,1,0>How often zombies carry a legendary fanny pack.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        FannypackZombies = 1,
        -- <RGB:0,1,0>How often the magazine that teaches the recipes appears (bookshelves, magazine racks, survivor houses, zombies...).
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        Magazine = 5,
        -- Start with a Legendary Fanny Pack (Grey) in your inventory.
        StartWithLFGrey = false,
    },
    LSO = {
        -- Min: 10.00 Max: 49.00 Default: 49.00
        BagCapacity = 40.0,
        -- Min: 0.90 Max: 0.99 Default: 0.99
        BagRunSpeedModifier = 0.99,
        -- Min: 50.00 Max: 99.00 Default: 99.00
        BagWeightReduction = 99.0,
        -- <RGB:0,1,0>How often legendary satchels appear in houses and shops. Each color appears in places that fit it.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        SatchelCommon = 2,
        -- <RGB:0,1,0>How often legendary satchels appear in police stations, military sites, fire stations, antique stores and survivor houses.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        SatchelRare = 3,
        -- <RGB:0,1,0>How often zombies carry a legendary satchel.
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        SatchelZombies = 1,
        -- <RGB:0,1,0>How often the magazine that teaches the recipes appears (bookshelves, magazine racks, survivor houses, zombies...).
        -- 0 = never, 1 = extremely rare, 5 = default, 10 = 3 times the default. Min: 0 Max: 10 Default: 5
        Magazine = 5,
        -- Start with a Legendary Satchel (Grey) in your inventory.
        StartWithLSGrey = false,
    },
    RepairableWindows = {
        -- Sets the formula used to determine the chance for a character to break a window when attempting to pick it up. Placing a window never breaks it. <LINE> Vanilla mimics the values used by vanilla moveable windows - level 2 has a 45% chance to break, level 10 has a 5% chance. <LINE> Generous further reduces the chance to break a window - level 2 has a 45% chance, level 7 has a 0% chance. Default = Vanilla
        -- 1 = Vanilla
        -- 2 = Generous
        -- 3 = Windows never break
        BreakChance = 1,
    },
    BadlandsFence = {
        -- How many connected fence sections one energizer can feed. Sections past the cap stay dead. Min: 5 Max: 200 Default: 40
        LineCap = 40,
        -- Real seconds between shocks on a live line. Min: 0.25 Max: 5.00 Default: 1.00
        PulseSeconds = 1.0,
        -- Generator fuel the energizer burns per in-game hour on its own, in litres. A vanilla generator idles at 0.02; a fridge adds 0.08. Scaled by the Generator Fuel Consumption option. Min: 0.00 Max: 1.00 Default: 0.02
        BaseDraw = 0.02,
        -- Extra fuel per in-game hour for each live section. Min: 0.00 Max: 0.10 Default: 0.00
        SectionDraw = 0.002,
        -- Health a zombie loses to each pulse. Short of the lethal time this never takes a zombie below the health floor. Min: 0.00 Max: 1.00 Default: 0.08
        ZapDamage = 0.08,
        -- Chance a pulse knocks a standing zombie down. Otherwise it staggers back. Min: 0 Max: 100 Default: 20
        KnockdownChance = 20,
        -- Players who push against or climb over a live line get a jolt. Standing next to it is safe.
        PlayerShock = true,
        -- General health a player loses to one jolt (at most one per jolt cooldown). Min: 0.00 Max: 25.00 Default: 3.00
        PlayerShockDamage = 3.0,
        -- Real seconds between jolts while a player keeps touching a live line. Min: 0.50 Max: 10.00 Default: 2.00
        PlayerShockCooldown = 2.0,
        -- Anyone who stays on a live line too long dies: players who keep pushing against or climbing on the wire, zombies and animals that stay on a live square. Off: the fence only stuns and wears.
        Lethal = true,
        -- Real seconds of unbroken contact before a player dies. Letting go for a moment resets it. A warning shows halfway. Min: 1.00 Max: 60.00 Default: 5.00
        PlayerLethalSeconds = 5.0,
        -- Real seconds a zombie can stay on a live square before it dies. One pulse off the wire resets it. Min: 1.00 Max: 120.00 Default: 8.00
        ZombieLethalSeconds = 8.0,
        -- Short of the lethal time, pulses never take a zombie below this much health (1.0 is full). 0 lets pulse damage alone finish them. Min: 0.00 Max: 1.00 Default: 0.05
        ZombieHealthFloor = 0.05,
        -- Livestock and wildlife on a live square get zapped: a little health and a lot of stress each pulse. Mind your own pens.
        AnimalShock = true,
        -- Health an animal loses to each pulse (1.0 is full). Short of the lethal time this never takes one below 0.1. Min: 0.00 Max: 1.00 Default: 0.02
        AnimalShockDamage = 0.02,
        -- Stress added to an animal by each pulse, on the game's 0 to 100 scale. Min: 0.00 Max: 100.00 Default: 15.00
        AnimalStress = 15.0,
        -- Real seconds an animal can stay on a live square before it dies, if sustained contact kills. One pulse off the wire resets it. Min: 1.00 Max: 300.00 Default: 15.00
        AnimalLethalSeconds = 15.0,
    },
    BadlandsPower = {
        -- Percent of generators found on the map and in generator loot (crates, vehicles) that are Badlands Power machines instead of vanilla ones. 0 turns the mixing off; crafting still works. Min: 0 Max: 90 Default: 33
        WorldShare = 33,
    },
    BadlandsPowerControllers = {
        -- Electrical skill needed to build a generator controller. 0 means no requirement. Min: 0 Max: 10 Default: 5
        BuildSkill = 5,
        -- Electrical skill needed to change a controller's program. 0 means no requirement. Min: 0 Max: 10 Default: 3
        ConfigureSkill = 3,
    },
    PlayablePool = {
        -- Boredom reduced after a player takes a valid pool shot or minigame turn. Min: 0 Max: 100 Default: 18
        BoredomReliefPerTurn = 18,
        -- Maximum distance in tiles for using a table or keeping its window open. Walking farther away closes the window and parks the seat. Returning within range reopens a window that closed for distance. Min: 3 Max: 30 Default: 8
        MaxPlayDistance = 8,
        -- Allow administrators to start solo pool practice for testing, even when ordinary solo practice is disabled.
        AllowAdminSoloPractice = true,
        -- Enables solo practice in the Pool window: free shooting with no opponent, no turn order, no fouls, and no win state.
        AllowSoloPractice = true,
        -- Allows a player to watch an occupied minigame without taking a seat. Governs every Playable Pool minigame, not only pool.
        AllowSpectators = true,
        -- Lets players seat computer opponents at any table that offers them. Turn it off to keep every game to solo play and human opponents; pool's solo practice stays available. A bot already seated keeps its chair until someone removes it.
        AllowBots = true,
        -- Drops the call-shot conventions from 8-ball: pocketing one of your own balls keeps the table (the opponent's balls alone do not), a mixed drop still takes a group, and clearing your group plus the 8 on one legal shot wins. Scratches, wrong-group hits, and illegal breaks are still fouls. Off means standard rules.
        CasualCallRules = true,
        -- Enable Balatroid, the poker roguelike in active development. All other games have their own switches. Singleplayer also has a local beta option in Minigame Settings; multiplayer always uses the server setting.
        EnableBetaMinigames = false,
        -- Offer Darts 501 at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableDarts501 = true,
        -- Offer Wordle at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableWordle = true,
        -- Offer Blackjack at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableBlackjack = true,
        -- Offer Texas Hold'em at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableHoldem = true,
        -- Offer Solitaire at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableSolitaire = true,
        -- Offer Chess at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableChess = true,
        -- Offer Checkers at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableCheckers = true,
        -- Offer Connect 4 at its game surface. When disabled, the menu explains which setting blocks it, and the host refuses to start, join, or watch it.
        EnableConnect4 = true,
        -- Clear an abandoned game after this many minutes. A fully parked table has its own shorter hold. A solo game is kept while its living owner remains nearby. Live games are never saved to disk. Min: 1 Max: 120 Default: 20
        AbandonedSessionMinutes = 20,
        -- Turn time limit when at least two humans are seated. A timeout folds in Hold'em, stands in blackjack, skips darts, gives ball in hand in pool, or loses a board game on time. The clock is visible. Solo games and games against bots have no turn clock. Set 0 to disable. Min: 0 Max: 600 Default: 90
        TurnTimeoutSeconds = 90,
        -- Keep a disconnected player's seat and chips for this long. Default: 120 seconds. Rejoining within this time restores the seat. Min: 20 Max: 600 Default: 120
        DisconnectGraceSeconds = 120,
        -- Release the equipment when every human seat has been parked for this long. Default: 2 minutes. A solo game stays available while its living owner remains nearby. Min: 1 Max: 120 Default: 2
        ParkedSessionMinutes = 2,
        -- When a seated player has too few chips to buy in and no chips committed at any table, top up their bankroll to this amount or the table minimum, whichever is higher. Default: 50. Set 0 to disable. Min: 0 Max: 1000 Default: 50
        HouseStake = 50,
        -- Saves a per-character record of games played, won and lost, the shared card-room chip balance used by Hold'em and blackjack, and Balatroid stake unlocks. This is the only thing Playable Pool writes into a save; turn it off and the card room uses table-only chips and nothing is stored. Live games are never saved either way.
        EnableRecords = true,
        -- Optional stress reduction after a valid pool shot or minigame turn. Leave at 0 to disable. Min: 0 Max: 100 Default: 0
        StressReliefPerTurn = 0,
        -- Optional unhappiness reduction after a valid pool shot or minigame turn. Leave at 0 to disable. Min: 0 Max: 100 Default: 0
        UnhappinessReliefPerTurn = 0,
    },
    PropaneExchangeCabinet = {
        -- Turn OFF to make the mod completely dormant: no spawning, no recovery, no cabinet visual updates - while the mod stays loaded so your save (especially multiplayer) remains loadable. Use this instead of uninstalling on game 42.20.4+, which cannot cleanly uninstall mods with craftable furniture. Existing cabinets remain as plain containers. A relog may be needed after changing this mid-save.
        Enabled = true,
        -- Chance that a propane exchange cabinet spawns at each eligible location (Fossoil/Gas2Go gas stations, Zippee's convenience stores). Rolled ONCE per station per save - a station that rolls empty stays empty on that save. 0 = never, 100 = always. Min: 0 Max: 100 Default: 50
        SpawnChance = 50,
        -- Upper limit on how many propane tanks a spawned cabinet is stocked with (actual count is random from 0 to this). Min: 0 Max: 6 Default: 6
        MaxTanks = 6,
        -- Relative weight for a tank being near-full (90%-100%). Weighted against the near-empty weight. Tanks are never in the 20%-90% range. Min: 0 Max: 100 Default: 55
        FillWeightFull = 55,
        -- Relative weight for a tank being near-empty (0%-20%). Min: 0 Max: 100 Default: 15
        FillWeightEmpty = 15,
        -- Chance that a stocked propane cabinet includes the recipe-teaching magazine (Welder Special Edition). 0 = never, 100 = always -- subject to the one-per-save limit below, if enabled. Min: 0 Max: 100 Default: 25
        MagazineChance = 25,
        -- If enabled, the magazine stops dropping after the first copy is found on this save (not per player -- see mod notes for the multiplayer caveat). If disabled, it can drop repeatedly at the chance above.
        MagazineOnePerSave = true,
        -- If selected only weathered cabinets will spawn, existing cabinets are not affected.
        RemoveNewCabinets = false,
    },
    ShelterHoldBeehive = {
        -- Allows Zombees to appear while foraging and when disassembling wild honeycombs. When disabled, existing Zombees are kept for save compatibility but cannot be inserted into a hive again after removal.
        EnableZombees = true,
        -- When enabled, Bait Hive > Add Bait only shows bait that can attract a Wild Honeycomb: Honey, Beeswax, Sugar, Brown Sugar, Sugar Cubes and Sugar Packet. Disabled by default to preserve standard trapping-menu behavior, which may allow other foods to be added even when they cannot catch anything in this trap.
        HideInvalidBaitHiveBaits = false,
        -- Minimum local air temperature at the Beehive square for Honeybee Queens to produce honey. Default: 12 °C. Min: -50.00 Max: 50.00 Default: 12.00
        HoneybeeMinTemperature = 12.0,
        -- Maximum local air temperature at the Beehive square for Honeybee Queens to produce honey. Default: 32 °C. Min: -50.00 Max: 60.00 Default: 32.00
        HoneybeeMaxTemperature = 32.0,
        -- Minimum local air temperature at the Beehive square for Bumblebee Queens to produce honey. Bumblebees tolerate a wider range than Honeybees. Default: 5 °C. Min: -50.00 Max: 50.00 Default: 5.00
        BumblebeeMinTemperature = 5.0,
        -- Maximum local air temperature at the Beehive square for Bumblebee Queens to produce honey. Bumblebees tolerate a wider range than Honeybees. Default: 35 °C. Min: -50.00 Max: 60.00 Default: 35.00
        BumblebeeMaxTemperature = 35.0,
        -- Multiplies Hive Frame honey production speed after queen, frame, season and indoor/outdoor modifiers. Default: 1.0x. Min: 0.00 Max: 5.00 Default: 1.00
        HoneyProductionSpeedMultiplier = 1.0,
        -- Radius in squares around a Beehive affected by its daily plant growth bonus. Default: 2 squares, producing a 5x5 area centered on the hive. Min: 0 Max: 10 Default: 2
        PlantGrowthBoostRadius = 2,
        -- Multiplies biome abundance weights for Honeybee Queens, Bumblebee Queens, Zombee Queens and Wild Honeycombs found through foraging. Does not change Bait Hive capture chances. Default: 1.0x. Min: 0.00 Max: 5.00 Default: 1.00
        BeeForagingAbundanceMultiplier = 1.0,
    },
    Tuna_MultiVHS = {
        -- Place one QuadVision by hand in the television shop of the Louisville mall, on the shop floor beside the display sets. Only ever one, and only in a world created with this option on - it is never added to an existing save.
        CuratedQuadVisionSpawns = true,
        -- Also let the QuadVision turn up as container loot, alongside the DualVision. Off by default: the two-tile flagship is meant to be found where it stands, not pulled out of a crate. The DualVision is unaffected by this option.
        QuadVisionContainerSpawns = false,
        -- How often a QuadVision appears in containers. Has no effect unless QuadVision Container Spawns is on. Default = Exceptionally Rare
        -- 1 = Exceptionally Rare
        -- 2 = Very Rare
        -- 3 = Rare
        QuadVisionContainerRarity = 1,
        -- How often a vanilla widescreen television standing in a shop, living room or bedroom is a Mirage AV DualVision instead. This is chosen when the world is created and cannot be changed afterwards - altering it later has no effect on a world already running. It is never applied to a save that predates this option. Default = Very Rare
        -- 1 = Off
        -- 2 = Exceptionally Rare
        -- 3 = Very Rare
        -- 4 = Rare
        -- 5 = Uncommon
        DualVisionWorldSwaps = 3,
    },
    ForestWildlife = {
        -- Master switch for the hourly scan that places wild animals around you. Off leaves only the route options below.
        Enabled = true,
        -- Nothing appears closer than this to a player. Also the inner edge of the search ring. Min: 20 Max: 150 Default: 40
        ScanMinRadius = 40,
        -- Outer edge of the search ring. Automatically clamped to the loaded area (about 70 tiles in single player), because animals outside loaded chunks cannot be counted. Min: 60 Max: 250 Default: 70
        ScanMaxRadius = 70,
        -- Stop placing animals once this many wild animals are already alive within the scan radius. Min: 1 Max: 60 Default: 12
        MaxAnimals = 12,
        -- Total animals from groups this mod has placed across the whole save. The count corrects itself whenever you pass a group again. Min: 50 Max: 2000 Default: 300
        GlobalCap = 300,
        -- Tiles between any two groups placed by this mod. Min: 20 Max: 200 Default: 60
        MinGroupSpacing = 60,
        -- Skip spots a player can currently see. Single player only: the engine check needs a local player index and does nothing on a dedicated server.
        AvoidPlayerSight = true,
        -- Nothing is placed if any zombie is within this many tiles of the spot. A fresh animal starts calling at once and would drag them to itself. 0 disables the check. Min: 0 Max: 100 Default: 20
        ZombieFreeRadius = 20,
        -- Chance per day of a deer group being placed in suitable forest. Min: 0.00 Max: 100.00 Default: 5.00
        DeerChance = 5.0,
        -- Chance per day of a rabbit group being placed in suitable forest. Min: 0.00 Max: 100.00 Default: 9.00
        RabbitChance = 9.0,
        -- Chance per day of a raccoon group being placed in suitable forest. Min: 0.00 Max: 100.00 Default: 6.00
        RaccoonChance = 6.0,
        -- Chance per day of a mouse group being placed in suitable forest. Min: 0.00 Max: 100.00 Default: 10.00
        MouseChance = 10.0,
        -- Chance per day of a rat group being placed in suitable forest. Min: 0.00 Max: 100.00 Default: 7.00
        RatChance = 7.0,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. 0.0 means no males and the group will never breed. Vanilla herds run about 0.25. Min: 0.00 Max: 1.00 Default: 0.25
        DeerMaleRatio = 0.25,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. 0.0 means no males and the group will never breed. Min: 0.00 Max: 1.00 Default: 0.30
        RabbitMaleRatio = 0.3,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. Min: 0.00 Max: 1.00 Default: 0.40
        RaccoonMaleRatio = 0.4,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. Min: 0.00 Max: 1.00 Default: 0.50
        MouseMaleRatio = 0.5,
        -- Share of males in a placed group. 0.5 is an even split; lower means more females, higher more males. Min: 0.00 Max: 1.00 Default: 0.50
        RatMaleRatio = 0.5,
        -- Around the clock ignores the time of day. By species behaviour applies the multiplier below during each species' active hours: rabbit and raccoon 19:00-05:00 (the game's own trapping data), deer at dawn and dusk, mouse and rat are active all day and get no bonus. Default = By species behaviour
        -- 1 = Around the clock
        -- 2 = By species behaviour
        ActivityMode = 2,
        -- Chance multiplier during a species' active hours. Ignored when Activity Hours is set to around the clock. Min: 1.00 Max: 5.00 Default: 1.20
        NightMultiplier = 1.2,
        -- Chance multiplier in December, January and February. Min: 0.00 Max: 1.00 Default: 0.50
        WinterMultiplier = 0.5,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 1.00
        ZoneDeepForest = 1.0,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 1.00
        ZoneOrganicForest = 1.0,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.80
        ZoneBirchForest = 0.8,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.80
        ZoneBirchMixForest = 0.8,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.70
        ZonePRForest = 0.7,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.70
        ZonePHForest = 0.7,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.60
        ZoneForest = 0.6,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.50
        ZoneFarmForest = 0.5,
        -- Chance multiplier in this zone type. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.50
        ZoneFarmMixForest = 0.5,
        -- Chance multiplier on open farmland, pasture and ranch land. 0 disables wildlife there entirely. Min: 0.00 Max: 2.00 Default: 0.30
        ZoneFarmland = 0.3,
        -- Multiplier on how many animals a placed group contains. Min: 0.50 Max: 3.00 Default: 0.75
        HerdSize = 0.75,
        -- Chance that a female placed by the mod brings a young one along.\ Vanilla herds run 20 for deer and 40 for rabbit. 0 places adults only. Min: 0 Max: 100 Default: 10
        BabyChance = 10,
        -- Livestock and poultry that wandered off the farms, placed loose in and around the woods. Useful on a long save where the game has already cleared the farms and there is nothing left to breed from. They keep their vanilla behaviour: none of them flee from you, and chickens and turkeys cannot graze off the ground, because making them act feral would mean editing shared animal definitions and changing every coop bird on the map. They are not flagged as wild, so you can catch them, lead them home and pen them.
        FarmAnimals = false,
        -- Chance per day of a loose chicken being placed.\ They do not flee and cannot feed off the ground - vanilla farm bird behaviour, kept as is. Min: 0.00 Max: 100.00 Default: 3.00
        FarmChickenChance = 3.0,
        -- Chance per day of a loose turkey being placed.\ Build 42 has no wild turkey, only the farm bird, so this is the way to meet one in the woods. Min: 0.00 Max: 100.00 Default: 2.00
        FarmTurkeyChance = 2.0,
        -- Chance per day of a loose pig being placed.\ Pigs graze off the ground, so they can genuinely live out there. Min: 0.00 Max: 100.00 Default: 1.00
        FarmPigChance = 1.0,
        -- Chance per day of a loose sheep being placed.\ Sheep graze off the ground. A ram fights back when stressed. Min: 0.00 Max: 100.00 Default: 1.00
        FarmSheepChance = 1.0,
        -- Chance per day of a loose cow being placed.\ Lowest by default, because one cow is an enormous amount of meat. A bull fights back when stressed. Min: 0.00 Max: 100.00 Default: 0.50
        FarmCowChance = 0.5,
        -- Chance per day of a loose horse being placed. Needs the Horse Mod; without it this setting does nothing.\ A horse can be tamed, saddled and ridden. A stressed stallion fights back and can knock you down. Min: 0.00 Max: 100.00 Default: 0.20
        FarmHorseChance = 0.2,
        -- How many animals a single farm spawn places.\ 1 keeps them solitary strays, which also means they never breed on their own. Min: 1 Max: 8 Default: 1
        FarmGroupSize = 1,
        -- Share of males among placed farm animals. 0.5 is an even split, lower means more females.\ Shared by all farm species. Min: 0.00 Max: 1.00 Default: 0.50
        FarmMaleRatio = 0.5,
        -- Chance that a placed farm female brings a young one along.\ 0 places adults only. A young animal needs its mother alive nearby. Min: 0 Max: 100 Default: 10
        FarmBabyChance = 10,
        -- Total farm animals from this mod across the whole save.\ Separate from the wildlife cap, because these are not flagged wild and the wildlife counter cannot see them. Min: 0 Max: 500 Default: 60
        FarmCap = 60,
        -- Chance multiplier on farmland, pasture, ranch land and the woods bordering them.\ This and the next multiplier replace the per-forest sliders above for farm animals. Min: 0.00 Max: 2.00 Default: 1.00
        FarmNearMultiplier = 1.0,
        -- Chance multiplier everywhere else in the forest, away from farmland.\ 0 keeps feral farm animals strictly around farms. Min: 0.00 Max: 2.00 Default: 0.25
        FarmWoodMultiplier = 0.25,
        -- Adds a Forest migration routes entry to the right-click menu in the world, where extra deer and rabbit routes can be previewed and then written into this save. Nothing is built until you pick Apply the plan to the save and confirm it. How to use: right-click the ground, Build a plan on the map, open the world map (M) and look at the yellow and red loops, change Extra Routes Multiplier and plan again if the density is wrong, then Apply the plan to the save, and reload the save straight afterwards without travelling anywhere. Applying cannot be undone - the routes become part of the save file, so back up the save folder first. Routes can only be placed where the game own map files describe the forest, so forest that stays empty after planning cannot take them at all - a limit of the game files, not of the mod. How many routes appear also depends on the game own Animal Paths Chance option.
        BuildMapPaths = false,
        -- Route density relative to vanilla: the game's roll count per cell times this, at the chance set by the vanilla option Animal Paths Chance.
        -- 1.0 is vanilla density, 1.2 adds about a fifth. Min: 0.50 Max: 5.00 Default: 1.20
        MapPathMultiplier = 1.2,
        -- Print every scan, spawn and rejection reason to the console and add the FWD Debug right-click menu. Also on automatically when the game runs with -debug.
        Debug = false,
        -- Just a separator. It does nothing.
        HydeCoSeparator = false,
        -- Needs HydeCo. Squirrels! Chance per day that a squirrel comes out of a den tree near you. Replaces that mod's own spawning: nothing comes out except by this roll. Its Most squirrels out at once setting still caps how many can be around you. 0 = none. Min: 0.00 Max: 100.00 Default: 10.00
        HydeCoSquirrelChance = 10.0,
        -- Needs HydeCo. Squirrels! When off, wild squirrel groups no longer spawn alongside rabbits, and only the den squirrels above remain. Applies when a save is loaded.
        HydeCoMigratingSquirrels = false,
        -- Needs HydeCo. Beavers! Chance per day that a beaver comes out of a lodge near you. Replaces that mod's own spawning: nothing comes out except by this roll. Its Most beavers out at once setting still caps how many can be around you. 0 = none. Min: 0.00 Max: 100.00 Default: 5.00
        HydeCoBeaverChance = 5.0,
        -- Needs HydeCo. Frogs! Chance per day that a frog appears by water near you. Replaces that mod's own spawning: nothing appears except by this roll. Its Most frogs out at once setting still caps how many can be around you. 0 = none. Min: 0.00 Max: 100.00 Default: 8.00
        HydeCoFrogChance = 8.0,
        -- Needs HydeCo. Robins! Chance per day that a robin appears near you. Replaces that mod's own spawning: nothing appears except by this roll. Its Most robins out at once setting still caps how many can be around you. 0 = none. Min: 0.00 Max: 100.00 Default: 10.00
        HydeCoRobinChance = 10.0,
    },
    ProjectCook = {
        -- Allows Project Cook to use frozen food in Base Cooking and Cooking by Recipes even when the base-game recipe requires thawed ingredients. Disabled by default. Only affects Project Cook.
        AllowFrozenCooking = false,
    },
    TWF_BF = {
        -- Disabled (default): uses the vanilla fish-size distribution table. Enabled: uses the Better Fishing Small/Medium/Big distribution. Vanilla skill/species weight limits are always preserved.
        -- Note: This choice is applied when the world loads. Reload your save after changing it.
        UseTwF_SizeDistribution = false,
        -- Maximum cast/aim distance in tiles.
        -- 16 (default) uses the original vanilla distance check. Higher values enable the Better Fishing override. Min: 16 Max: 20 Default: 16
        TwF_AimDist = 16,
        -- Shore detection radius in tiles.
        -- 7 (default) keeps the original vanilla shore detection. Values 1-6 enable Better Fishing's lighter directional shore check with the selected radius. Min: 1 Max: 7 Default: 7
        TwF_ShoreRadius = 7,
        -- Controls the near-shore shift toward smaller fish.
        -- 100% (default) keeps vanilla strength. Any other value enables a custom strength; 0% disables the near-shore size shift. Min: 0 Max: 100 Default: 100
        TwF_SizeBlend = 100,
        -- 100% (default) keeps the full vanilla temperature behavior. Any other value enables a flat Better Fishing modifier at all temperatures and replaces the vanilla temperature curve. Min: 10 Max: 200 Default: 100
        TwF_TempCoeff = 100,
        -- Fog coefficient (percent).
        -- 100% = baseline.
        -- Default: 80%. Min: 50 Max: 150 Default: 80
        TwF_FogCoeff = 80,
        -- Wind coefficient (percent).
        -- 100% = baseline.
        -- Default: 80%. Min: 50 Max: 150 Default: 80
        TwF_WindCoeff = 80,
        -- Rain coefficient (percent).
        -- 100% = baseline.
        -- Default: 120%. Min: 50 Max: 200 Default: 120
        TwF_RainCoeff = 120,
        -- Bonus timeframe start hour (morning).
        -- Default: 4. Min: 3 Max: 6 Default: 4
        TwF_MornStart = 4,
        -- Bonus timeframe end hour (morning).
        -- Default: 6. Min: 6 Max: 9 Default: 6
        TwF_MornEnd = 6,
        -- Bonus timeframe start hour (evening).
        -- Default: 18. Min: 15 Max: 18 Default: 18
        TwF_EveStart = 18,
        -- Bonus timeframe end hour (evening).
        -- Default: 20. Min: 19 Max: 21 Default: 20
        TwF_EveEnd = 20,
        -- Catch chance multiplier during the bonus timeframes (percent).
        -- 100% = no bonus.
        -- Default: 120%. Min: 50 Max: 200 Default: 120
        TwF_TimeCoeff = 120,
    },
    VanillaFishingFix = {
        -- Recalculates fish nutrition from real caught weight and preserves the total nutrition when filleting.
        EnableNutritionBalance = true,
        -- Extra calories applied after the weight-based rebalance. 0% uses the balanced values; 100% doubles them and 400% makes them x5. Default = 0% (balanced)
        -- 1 = 0% (balanced)
        -- 2 = 10%
        -- 3 = 20%
        -- 4 = 30%
        -- 5 = 40%
        -- 6 = 50%
        -- 7 = 60%
        -- 8 = 70%
        -- 9 = 80%
        -- 10 = 90%
        -- 11 = 100%
        -- 12 = 150%
        -- 13 = 200%
        -- 14 = 250%
        -- 15 = 300%
        -- 16 = 350%
        -- 17 = 400%
        CalorieBonusPreset = 1,
        -- Enables escapes, exceptional catches and the event system used by line breaks, rod breaks and double catches.
        EnableCatchEvents = true,
        -- Scales the probability of catch events, treasure and rare fish. Default = Normal (x1)
        -- 1 = Low (x0.5)
        -- 2 = Normal (x1)
        -- 3 = High (x2)
        EventFrequency = 2,
        -- Allows high tension and heavy fish to break the fishing line. Line type and condition affect risk.
        EnableLineBreaks = true,
        -- Allows a very rare rod failure. Heavy fish and damaged rods are more dangerous.
        EnableRodBreaks = true,
        -- Adds boots, branches, cans, cordage, hooks and other vanilla junk to fishing catches.
        EnableExpandedTrash = true,
        -- Allows very rare catches such as watches, rings, old coins, tools and premium line.
        EnableTreasure = true,
        -- Makes carp, trout, catfish, pike and compatible mod fish fight with different speed, force and escape risks.
        EnableFishAI = true,
        -- Makes dawn and dusk best, morning good, midday poor and night less productive.
        EnableTimeEffects = true,
        -- Light rain helps, while storms, strong wind, heavy rain and fog reduce fishing success.
        EnableWeatherEffects = true,
        -- Long uninterrupted fishing sessions drain endurance and progressively slow reeling. Resting starts a fresh session.
        EnableFatigue = true,
        -- Hooks alter attraction, line quality alters break risk, and professional rods wear more slowly.
        EnableEquipmentEffects = true,
        -- Insects favour small fish, fresh fish bait attracts predators, meat favours catfish, and stale or rotten bait shifts catches toward scavengers and trash.
        EnableBaitQuality = true,
        -- Shows a blue-and-yellow 1-to-16-tile meter while aiming. Yellow marks the aimed distance and the blue cursor selects the cast.
        EnableCastMiniGame = true,
        -- Allows fishing from the ground and from recognized chairs or furniture. Furniture must face the water.
        EnableSeatedFishing = true,
        -- Caught fish receive an invisible Normal, Good, Excellent or Legendary quality that affects weight, nutrition, mood and value metadata.
        EnableFishQuality = true,
        -- Some thirty-tile water areas are richer. Catches still deplete vanilla abundance and double catches deplete it twice.
        EnableFishSchools = true,
        -- Allows albino, mutated, gigantic, scarred and diseased catches.
        EnableRareFish = true,
        -- Small fish barely wear rods; large and exceptional fish may remove substantially more condition.
        EnableRealisticWear = true,
        -- Tracks fish, total weight, species, records, escapes, breaks, junk, treasure and special catches per character.
        EnableStatistics = true,
        -- Awards +1 XP on a bite, +2 when control starts, +5 on capture and +10 extra for an exceptional catch.
        EnableEnhancedXP = true,
        -- Automatically balances all species registered in the Build 42 Fishing.fishes table and enables dedicated support for Yumi's Fishing Expansion.
        EnableModCompatibility = true,
    },
    B42Horticulture = {
        -- Adds 'Make Glass Pipe' recipe to 'Magazine: Murano Glass Manual'.
        LearnedRecipe = true,
    },
    GydeTraitMags = {
        -- Allows gaining the positive version of a trait if the character started with its negative version (ie. Sunday Driver to Speed Demon)
        -- 
        -- If enabled with consumable magazines off, the positive trait will be given upon reading the magazine.
        NegativeToPositive = false,
        -- Reading a trait magazine will remove the associated trait if the player has it.
        ReadRemove = false,
        -- If enabled, magazines are 1-time use. Reading a magazine will consume the item and remove it from your inventory.
        ReadDelete = false,
        -- Amount of days before trait magazines can be read, maximum value is 1 year. Min: 0 Max: 8766 Default: 0
        DaysBeforeRead = 0,
        -- Change the frequency of magazine spawns. Refer to workshop page for more information. Default = Default
        -- 1 = Very Low
        -- 2 = Low
        -- 3 = Default
        -- 4 = High
        -- 5 = Very High
        SpawnRate = 3,
        -- Disable to stop Speed Demon magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - 200% Gear switching speed
        -- - 115% top speed for all vehicles.
        SpawnSpeedDemon = true,
        -- Disable to stop Nutritionist magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - Allows the player to see the nutritional values of any food, even those that aren't packaged.
        SpawnNutritionist = true,
        -- Disable to stop Organized magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - 130% capacity for all containers, including bags, vehicles, and tiles.
        SpawnOrganized = true,
        -- Disable to stop Outdoorsman magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - 10% chance of catching a cold.
        -- - 1% or 1.25% chance of getting scratched/lacerated while walking or running through trees.
        -- - Start a fire on campfires with a notched wooden plank faster.
        SpawnOutdoorsman = true,
        -- Disable to stop Fast Reader magazine from spawning in game.
        -- 
        -- Trait Description:
        -- 130% reading speed.
        SpawnFastReader = true,
        -- Disable to stop Fast Learner magazine from spawning in game.
        -- 
        -- Trait Description:
        -- 130% XP gain for all skills except Strength and Fitness.
        SpawnFastLearner = true,
        -- Disable to stop Handy magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - +100 HP to some constructions.
        -- - Faster building speed (~11%).
        SpawnHandy = true,
        -- Disable to stop Ax-pert magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - +25% axe swinging and chopping speed.
        -- - +50% bonus chopping damage when using an axe.
        SpawnAxeMan = true,
        -- Disable to stop Burglar magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - Ability to hot-wire vehicles
        -- - 50% less likely to break a window lock.
        -- - Increased sheet rope climbing speed
        SpawnBurglar = true,
        -- Disable to stop Graceful magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - 60% footsteps sound radius.
        -- - -10% chance of tripping when vaulting.
        SpawnGraceful = true,
        -- Disable to stop Dextrous magazine from spawning in game.
        -- 
        -- Trait Description:
        -- 50% inventory transferring time.
        -- - +2% to the chance of successfully unjamming a firearm.
        -- - -20% aiming delay: quicker to start aiming/shouldering a firearm.
        SpawnDextrous = true,
        -- Disable to stop Inconspicuous magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - 50% chance of getting spotted by zombies.
        SpawnInconspicuous = true,
        -- Disable to stop Keen Hearing magazine from spawning in game.
        -- 
        -- Trait Description:
        -- - 200% perception radius.
        -- - Zombies that approach from behind will be visible much earlier.
        SpawnKeenHearing = true,
    },
    WorkingKnowledge = {
        -- How often Working Knowledge documents appear in loot containers. Does not affect already-generated containers; only new ones loaded after this setting is applied. Default = Normal
        -- 1 = Very Rare
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Common
        -- 5 = Abundant
        SpawnRate = 3,
        -- Base XP awarded when a character reads a document for the first time. Scaled by the game's passive skill rate. Set to 0 to disable XP entirely. Default: 50. Min: 0 Max: 500 Default: 50
        XPGrant = 50,
        -- When enabled, a document is destroyed once it has been read, so it cannot be passed to another survivor. Intended for multiplayer servers that do not want a single copy training the whole group. Default: off.
        ConsumeOnRead = false,
    },
    BurdJournals = {
        -- Master toggle for the entire survival journals system.
        EnableJournals = true,
        -- Allow players to use personal journals for recording/recovering skills. Disable to block player-journal interactions entirely.
        EnablePlayerJournals = true,
        -- Allow crafting/restore conversion recipes for personal journals. Disable to prevent journal crafting while still allowing reading/claiming from existing player journals.
        EnablePlayerJournalCrafting = true,
        -- Allow BSJ to add crafting recipes for vanilla Notebook and Journal items. Disable to hide these recipes while keeping existing vanilla items usable.
        EnableVanillaJournalCrafting = true,
        -- Deprecated and no longer active. Existing filled journal restoration is disabled because it can create unsafe duplicate UUID and world-state edge cases. Use Spawn with Blank Player Journal instead.
        RespawnWithExistingPlayerJournal = false,
        -- Give each new character a blank player journal, including replacement characters created after death.
        SpawnWithBlankPlayerJournal = false,
        -- How journal XP recovery is handled. Full Recovery returns 100% of stored XP, while Diminishing Returns reduces repeated reads. Default = Full Recovery (100%)
        -- 1 = Full Recovery (100%)
        -- 2 = Diminishing Returns
        XPRecoveryMode = 1,
        -- Chooses whether wear advances for each skill claim, each reading session, or independently for each recorded skill. Default = Per Skill (Per Journal)
        -- 1 = Per Skill Claim (Journal-wide)
        -- 2 = Per Reading Session (Journal-wide)
        -- 3 = Per Skill (Per Journal)
        DiminishingTrackingMode = 3,
        -- Player journals only. Per Journal keeps each physical volume independent. Per Author Survivor links journals written by the same stable survivor. Per Author Account links every player journal written by that Steam/account identity. Loot journals are never linked. Default = Per Journal
        -- 1 = Per Journal
        -- 2 = Per Author Survivor
        -- 3 = Per Author Account
        DiminishingScope = 1,
        -- XP percentage on first read (50-100%). Only applies with Diminishing Returns. Min: 50 Max: 100 Default: 100
        DiminishingFirstRead = 100,
        -- XP reduction for each subsequent read (0-50%). Min: 0 Max: 50 Default: 10
        DiminishingDecayRate = 10,
        -- Floor percentage that recovery cannot go below (0-50%). Min: 0 Max: 50 Default: 10
        DiminishingMinimum = 10,
        -- Only applies when Journal XP Mode is Diminishing Returns. Gradually restores one percentage point of journal XP readiness after the configured connected in-game time. Only living, connected play counts. Offline server time and paused solo time do not count. Time is not banked while fully ready.
        EnablePassiveDiminishingRecovery = false,
        -- Only applies with Diminishing Returns and passive recovery enabled. Connected in-game hours required to restore one percentage point of journal XP readiness. Sleep and normal time acceleration count. Min: 0.10 Max: 168.00 Default: 24.00
        DiminishingRecoveryHoursPerPercent = 24.0,
        -- Only applies when Journal XP Mode is Diminishing Returns. Adds Maintain Journal for player-journal entries with reduced readiness. Requires a reusable needle, one thread use, and one ripped sheet, denim strip, or leather strip. Maintenance restores the linked diminishing-returns history, not only the selected physical copy.
        EnableManualDiminishingRecovery = false,
        -- Only applies with Diminishing Returns and journal maintenance enabled. Percentage points of journal XP readiness restored by one completed Maintain Journal action. Min: 1 Max: 100 Default: 10
        DiminishingMaintenancePercent = 10,
        -- Require a pen or pencil to log skills in a clean journal.
        RequirePenToWrite = true,
        -- Pen durability consumed when logging skills (1-10). Min: 1 Max: 10 Default: 1
        PenUsesPerLog = 1,
        -- Require an eraser to wipe clean journal contents.
        RequireEraserToErase = true,
        -- When enabled, erasing/restoring and re-writing a journal keeps diminishing-returns read progress instead of resetting it.
        PersistDROnErase = false,
        -- When enabled, journals only record XP earned through gameplay - not profession starting bonuses or trait skill boosts. This prevents exploits where players farm profession skills by creating multiple characters. Recommended ON for multiplayer servers.
        EnableBaselineRestriction = true,
        -- When Only Record Earned Progress is enabled, this controls how player journals are recorded. Strict Earned Only excludes starting data. Legacy Full Current Data records everything. Vested Starting XP lets each eligible skill XP earned after spawning unlock one matching point of that skill's starting XP. Starting traits and recipes stay excluded. Ignored when Only Record Earned Progress is disabled. Default = Strict Earned Only (Recommended)
        -- 1 = Strict Earned Only (Recommended)
        -- 2 = Legacy Full Current Data
        -- 3 = Vested Starting XP (1:1 Earned Match)
        BaselineRecordingMode = 2,
        -- Allows player journals to include TV/VHS skill XP. Claimed journal entries mark their recorded media lines as watched to prevent double-dipping.
        AllowVhsSkillRecording = true,
        -- Controls how the learning time for each skill is calculated. Flat uses one base time per skill. Level Progress charges for the levels and partial levels actually recovered. Total XP charges from the skill's own XP curve, similar to LG Skill Journal. Default = Flat Per Skill (Legacy)
        -- 1 = Flat Per Skill (Legacy)
        -- 2 = Recovered Level Progress
        -- 3 = Recoverable Total XP (LG-style)
        SkillLearningTimeScaling = 1,
        -- Base time in seconds to learn each skill from a journal. Simulates reading/studying. Min: 0.50 Max: 30.00 Default: 4.00
        LearningTimePerSkill = 4.0,
        -- When enabled, Fitness/Strength can be recorded and claimed from player journals. When disabled, passive skill entries are hidden but preserved.
        EnablePassiveSkillsPlayer = true,
        -- Allow players to record traits in their personal journals. When disabled, the traits tab will be hidden in player journals and existing traits will be preserved but inaccessible.
        EnableTraitRecordingPlayer = true,
        -- Base time in seconds to absorb each trait from a journal. Min: 1.00 Max: 60.00 Default: 5.00
        LearningTimePerTrait = 5.0,
        -- Allow players to record magazine-learned recipes in their personal journals. When disabled, the recipes tab will be hidden and existing recipes will be preserved but inaccessible.
        EnableRecipeRecordingPlayer = true,
        -- Base time in seconds to learn each recipe from a journal. Min: 0.50 Max: 30.00 Default: 5.00
        LearningTimePerRecipe = 5.0,
        -- Master toggle for recording player stats (kills, survival time, etc.) in personal journals.
        EnableStatRecording = true,
        -- Allow players to record their zombie kill count in journals.
        RecordZombieKills = true,
        -- Allow players to record their survival time in journals.
        RecordHoursSurvived = true,
        -- Allow players to build customizable note pages in personal journals. Existing notes remain readable when this is disabled.
        EnablePlayerJournalNotes = true,
        -- Maximum number of writable note pages in a personal journal. Higher limits allow longer roleplay notes but increase saved journal payload size. Min: 1 Max: 100 Default: 30
        PlayerJournalNotesMaxPages = 30,
        -- Maximum characters allowed on each personal journal note page. Longer pages increase saved journal payload size. Min: 250 Max: 8000 Default: 2000
        PlayerJournalNotesMaxCharsPerPage = 2000,
        -- Require a carried pen, pencil, marker, or other vanilla writing tool to add or change note blocks. The tool determines the available ink colors.
        RequireWritingToolForPlayerJournalNotes = true,
        -- Require a carried eraser or vanilla eraser-tagged item to remove note blocks, list items, or pages.
        RequireEraserForPlayerJournalNoteDeletion = true,
        -- Global multiplier for all learning times. 0.5 = twice as fast, 2.0 = twice as slow. Min: 0.10 Max: 5.00 Default: 1.00
        LearningTimeMultiplier = 1.0,
        -- Maximum number of skills that can be recorded in a single journal. Set to 0 for unlimited. Vanilla game has ~30 skills. Min: 0 Max: 500 Default: 0
        MaxSkillsPerJournal = 0,
        -- Maximum number of traits that can be recorded in a single journal. Set to 0 for unlimited. Vanilla game has ~50 grantable traits. Min: 0 Max: 500 Default: 0
        MaxTraitsPerJournal = 0,
        -- Maximum number of recipes that can be recorded in a single journal. Set to 0 for unlimited. Heavily modded games can have 400+ magazine recipes. Min: 0 Max: 10000 Default: 0
        MaxRecipesPerJournal = 0,
        -- Multiplier for XP gained from journals (0.25 = 25%, 1.0 = 100%, 2.0 = 200%). Applies to both worn and bloody journals. Min: 0.10 Max: 10.00 Default: 1.00
        JournalXPMultiplier = 1.0,
        -- When enabled, Fitness/Strength can appear and be claimed on worn/bloody journals. When disabled, passive skill entries are hidden but preserved.
        EnablePassiveSkillsLoot = true,
        -- When enabled, discovered worn, bloody, and cursed loot journals dissolve after the selected number of in-game days.
        EnableLootJournalExpiration = true,
        -- In-game days after a survivor first discovers a loot journal before its notes fade and it dissolves. Min: 1 Max: 365 Default: 30
        LootJournalExpirationDays = 30,
        -- Allow worn journals to spawn in world containers (shelves, desks, cabinets). These offer light XP rewards.
        EnableWornJournalSpawns = true,
        -- Chance for worn journals to appear in world containers (0.1-100%). Min: 0.10 Max: 100.00 Default: 1.00
        WornJournalSpawnChance = 1.0,
        -- Minimum skills in world-found worn journals. Min: 1 Max: 5 Default: 1
        WornJournalMinSkills = 1,
        -- Maximum skills in world-found worn journals. Min: 1 Max: 5 Default: 2
        WornJournalMaxSkills = 2,
        -- Minimum XP per skill in worn journals. Min: 10 Max: 200 Default: 25
        WornJournalMinXP = 25,
        -- Maximum XP per skill in worn journals. Min: 25 Max: 500 Default: 75
        WornJournalMaxXP = 75,
        -- When enabled, recipes can be claimed from worn journals. When disabled, recipes tab will be hidden on worn journals but existing recipe data is preserved for when re-enabled.
        EnableWornJournalRecipes = true,
        -- Chance for worn journals to spawn with recipes (0-100%). Set to 0% to prevent recipes from spawning on new journals. Worn journals have a lower chance than bloody. Min: 0 Max: 100 Default: 15
        WornJournalRecipeChance = 15,
        -- Maximum number of magazine recipes that can spawn on a single worn journal (1-5). Min: 1 Max: 5 Default: 1
        WornJournalMaxRecipes = 1,
        -- Chance for a newly generated worn journal to contain a point-of-interest map segment. Min: 0 Max: 100 Default: 8
        WornJournalMapSegmentChance = 8,
        -- Maximum point-of-interest map segments generated in a worn journal. Min: 1 Max: 5 Default: 1
        WornJournalMaxMapSegments = 1,
        -- When enabled, traits can be claimed from worn journals. When disabled, traits tab will be hidden on worn journals but existing trait data is preserved for when re-enabled.
        EnableWornJournalTraits = true,
        -- Chance for worn journals to spawn with traits (0-100%). Set to 0% (default) for classic behavior where only bloody journals have traits. Min: 0 Max: 100 Default: 0
        WornJournalTraitChance = 0,
        -- Minimum number of traits that can spawn on a worn journal when traits roll succeeds (1-5). Min: 1 Max: 5 Default: 1
        WornJournalMinTraits = 1,
        -- Maximum number of traits that can spawn on a worn journal (1-5). Min: 1 Max: 5 Default: 1
        WornJournalMaxTraits = 1,
        -- When enabled, worn journals may spawn with a claimable forget slot.
        EnableWornJournalForgetSlot = true,
        -- Chance for worn journals to include a special forget slot when worn forget slots are enabled. Min: 0 Max: 100 Default: 1
        WornJournalForgetChance = 1,
        -- Allow newly spawned loot journals to sometimes include read-only generated lore notes. Existing discovered journals are not retroactively given notes.
        EnableLootJournalNotes = true,
        -- Chance for newly spawned worn journals to include a generated read-only note page. Min: 0 Max: 100 Default: 35
        WornJournalNoteChance = 35,
        -- Allow zombies to drop bloody journals. These offer better rewards and rare traits.
        EnableBloodyJournalSpawns = true,
        -- Chance for a zombie to drop a bloody journal (0.1-100%). Min: 0.10 Max: 100.00 Default: 0.30
        BloodyJournalSpawnChance = 0.3,
        -- Minimum skills in zombie-dropped bloody journals. Min: 1 Max: 5 Default: 2
        BloodyJournalMinSkills = 2,
        -- Maximum skills in zombie-dropped bloody journals. Min: 2 Max: 10 Default: 4
        BloodyJournalMaxSkills = 4,
        -- Minimum XP per skill in bloody journals. Min: 25 Max: 500 Default: 50
        BloodyJournalMinXP = 50,
        -- Maximum XP per skill in bloody journals. Min: 50 Max: 1000 Default: 150
        BloodyJournalMaxXP = 150,
        -- When enabled, traits can be claimed from bloody journals. When disabled, traits tab will be hidden on bloody journals but existing trait data is preserved for when re-enabled.
        EnableBloodyJournalTraits = true,
        -- Chance for bloody journals to spawn with traits (0-100%). Set to 0% to prevent traits from spawning on new journals. Min: 0 Max: 100 Default: 15
        BloodyJournalTraitChance = 15,
        -- Maximum number of traits that can spawn on a single bloody journal (0-5). Min: 0 Max: 5 Default: 2
        BloodyJournalMaxTraits = 2,
        -- When enabled, bloody journals may spawn with a claimable forget slot.
        EnableBloodyJournalForgetSlot = true,
        -- Chance for bloody journals to include a special forget slot when bloody forget slots are enabled. Min: 0 Max: 100 Default: 3
        BloodyJournalForgetChance = 3,
        -- When enabled, recipes can be claimed from bloody journals. When disabled, recipes tab will be hidden on bloody journals but existing recipe data is preserved for when re-enabled.
        EnableBloodyJournalRecipes = true,
        -- Chance for bloody journals to spawn with recipes (0-100%). Set to 0% to prevent recipes from spawning on new journals. Bloody journals have a higher chance than worn. Min: 0 Max: 100 Default: 60
        BloodyJournalRecipeChance = 60,
        -- Maximum number of magazine recipes that can spawn on a single bloody journal (1-5). Min: 1 Max: 5 Default: 3
        BloodyJournalMaxRecipes = 3,
        -- Chance for a newly generated bloody journal to contain a point-of-interest map segment. Min: 0 Max: 100 Default: 18
        BloodyJournalMapSegmentChance = 18,
        -- Maximum point-of-interest map segments generated in a bloody journal. Min: 1 Max: 5 Default: 2
        BloodyJournalMaxMapSegments = 2,
        -- Chance for newly spawned bloody journals to include a generated read-only note page. Min: 0 Max: 100 Default: 50
        BloodyJournalNoteChance = 50,
        -- Master toggle for fun loot journals. When disabled, cursed and Yuletide journal spawns and seasonal fun-journal hooks are turned off.
        EnableLootJournalsFun = true,
        -- Allow zombies to rarely drop dormant cursed journals. The first opener is cursed, then the journal becomes a richer bloody reward.
        EnableCursedJournalSpawns = true,
        -- When enabled, cursed zombie drops appear as ordinary bloody journals until first open. The curse springs immediately on that first open instead of showing a sealed warning prompt.
        DisguiseCursedJournalsAsBloody = false,
        -- Chance for a zombie to drop a cursed journal (0-100%). If this rolls, normal bloody drop is skipped for that zombie. Min: 0.00 Max: 100.00 Default: 0.08
        CursedJournalSpawnChance = 0.08,
        -- Minimum skills generated on a cursed reward journal. Min: 1 Max: 10 Default: 2
        CursedJournalMinSkills = 2,
        -- Maximum skills generated on a cursed reward journal. Min: 1 Max: 10 Default: 5
        CursedJournalMaxSkills = 5,
        -- Minimum XP per skill on a cursed reward journal. Min: 1 Max: 5000 Default: 75
        CursedJournalMinXP = 75,
        -- Maximum XP per skill on a cursed reward journal. Min: 1 Max: 5000 Default: 300
        CursedJournalMaxXP = 300,
        -- When enabled, cursed reward journals can generate and allow trait claims.
        EnableCursedJournalTraits = true,
        -- Chance for cursed reward journals to include traits (0-100%). Min: 0 Max: 100 Default: 40
        CursedJournalTraitChance = 40,
        -- Minimum traits generated on cursed reward journals when trait roll succeeds. Min: 1 Max: 5 Default: 1
        CursedJournalMinTraits = 1,
        -- Maximum traits generated on cursed reward journals. Min: 1 Max: 5 Default: 3
        CursedJournalMaxTraits = 3,
        -- When enabled, cursed reward journals can generate and allow recipe claims.
        EnableCursedJournalRecipes = true,
        -- Chance for cursed reward journals to include recipes (0-100%). Min: 0 Max: 100 Default: 60
        CursedJournalRecipeChance = 60,
        -- Maximum recipes generated on cursed reward journals. Min: 1 Max: 5 Default: 3
        CursedJournalMaxRecipes = 3,
        -- Chance for a revealed cursed journal to contain a point-of-interest map segment. Min: 0 Max: 100 Default: 30
        CursedJournalMapSegmentChance = 30,
        -- Maximum point-of-interest map segments generated in a cursed journal. Min: 1 Max: 5 Default: 2
        CursedJournalMaxMapSegments = 2,
        -- When enabled, cursed reward journals may generate a claimable forget slot.
        EnableCursedJournalForgetSlot = true,
        -- Chance for cursed reward journals to include a forget slot when cursed forget slots are enabled. Min: 0 Max: 100 Default: 25
        CursedJournalForgetChance = 25,
        -- Relative weight for the softer cursed penalty that adds a negative trait. Higher values make it more likely when a cursed journal opens. Min: 0 Max: 200 Default: 90
        CursedJournalNegativeTraitCurseWeight = 90,
        -- Relative weight for the severe cursed penalty that removes a positive trait. Lower values make this punishment rarer. Min: 0 Max: 200 Default: 12
        CursedJournalLosePositiveTraitCurseWeight = 12,
        -- Relative weight for the severe cursed penalty that removes a skill level. Lower values make this punishment rarer. Min: 0 Max: 200 Default: 10
        CursedJournalLoseSkillCurseWeight = 10,
        -- After a recent severe curse, this is the percent of normal chance retained by severe penalties like losing positive traits or skill levels. Set to 0 to nearly hard-lock repeats, or 100 to disable this cooldown. Min: 0 Max: 100 Default: 4
        CursedJournalSevereRepeatChancePercent = 4,
        -- How long recent severe cursed penalties continue suppressing more severe repeats for the same player. Set to 0 to disable the repeat window. Min: 0 Max: 336 Default: 72
        CursedJournalSevereCooldownHours = 72,
        -- When a cursed journal inflicts a persistent or severe penalty, guarantee a forget slot and (for severe curses) richer skill rewards to keep opening worthwhile.
        CursedJournalSeverityCompensation = true,
        -- Extra percent of skill XP granted by a cursed reward journal when the applied curse was severe. Only applies when Cursed Severity Compensation is enabled. Min: 0 Max: 200 Default: 50
        CursedJournalSevereRewardBonusPercent = 50,
        -- When enabled, cursed journals older than the expiration age open safely without applying a curse.
        EnableCursedJournalExpiration = true,
        -- In-game days before a cursed journal's curse goes dormant. Expired cursed journals still open into bloody reward journals, but no curse fires. Min: 1 Max: 365 Default: 30
        CursedJournalExpirationDays = 30,
        -- Allows perceptive survivors to notice disguised cursed journals and read escalating Hint, Aware, and Exact curse warnings from Cat's Eyes, Foraging, Herbalist, and fieldcraft backgrounds.
        EnableCursedJournalInsight = true,
        -- Foraging level for Hint insight, letting survivors notice hidden-cursed journals. Cat's Eyes and fieldcraft traits can also reveal suspicious journals. Min: 0 Max: 10 Default: 4
        CursedJournalInsightRevealForagingLevel = 4,
        -- Foraging level that, with Cat's Eyes, Herbalist, or Park Ranger fieldcraft, gives Aware insight and reveals the curse's broad omen category. Min: 0 Max: 10 Default: 6
        CursedJournalInsightOmenForagingLevel = 6,
        -- Foraging level used for exact curse insight when exact effect insight is enabled. Min: 0 Max: 10 Default: 8
        CursedJournalInsightExactForagingLevel = 8,
        -- When enabled, survivors meeting the Exact insight threshold can identify the specific curse effect in item hover tooltips and Breaking the Seal confirmation prompts.
        CursedJournalInsightExactEffect = false,
        -- Chance for newly spawned cursed reward journals to include a generated read-only occult note page. Min: 0 Max: 100 Default: 75
        CursedJournalNoteChance = 75,
        -- Allow seasonal Yuletide journals to replace some worn and bloody journals when the Yuletide season is active.
        EnableYuletideJournalSpawns = true,
        -- Controls when Yuletide journal replacements are active. Choose the in-game calendar, the host/server real-world month, either December source, or year-round activation. Default = Only December (In-Game)
        -- 1 = Only December (In-Game)
        -- 2 = Either December (In-Game or IRL Host Month)
        -- 3 = Only December (IRL Host Month)
        -- 4 = Any Time
        YuletideSeasonMode = 1,
        -- Controls when newly spawned cursed journals use Krampus as their author identity. This is separate from Yuletide journal spawn timing. Default = During Yuletide Season (Default)
        -- 1 = During Yuletide Season (Default)
        -- 2 = Only December (In-Game)
        -- 3 = Only December (IRL Host Month)
        -- 4 = Never
        EnableYuletideKrampusCursedAuthors = 1,
        -- Chance for an eligible worn journal world spawn to become a wrapped Yuletide journal during the active season. Min: 0.00 Max: 100.00 Default: 8.00
        YuletideWornReplacementChance = 8.0,
        -- Chance for an eligible bloody zombie drop to become a wrapped Yuletide journal during the active season after cursed roll precedence is checked. Min: 0.00 Max: 100.00 Default: 4.00
        YuletideBloodyReplacementChance = 4.0,
        -- Minimum skills generated on unwrapped Yuletide journals. Min: 1 Max: 10 Default: 2
        YuletideJournalMinSkills = 2,
        -- Maximum skills generated on unwrapped Yuletide journals. Min: 1 Max: 10 Default: 5
        YuletideJournalMaxSkills = 5,
        -- Minimum XP per skill generated on Yuletide journals. Min: 1 Max: 5000 Default: 75
        YuletideJournalMinXP = 75,
        -- Maximum XP per skill generated on Yuletide journals. Min: 1 Max: 5000 Default: 300
        YuletideJournalMaxXP = 300,
        -- When enabled, Yuletide journals can include claimable traits.
        EnableYuletideJournalTraits = true,
        -- Chance for a Yuletide journal to include traits. Min: 0 Max: 100 Default: 40
        YuletideJournalTraitChance = 40,
        -- Minimum traits generated on Yuletide journals when trait roll succeeds. Min: 1 Max: 5 Default: 1
        YuletideJournalMinTraits = 1,
        -- Maximum traits generated on Yuletide journals. Min: 1 Max: 5 Default: 3
        YuletideJournalMaxTraits = 3,
        -- When enabled, Yuletide journals can include claimable recipes.
        EnableYuletideJournalRecipes = true,
        -- Chance for a Yuletide journal to include recipes. Min: 0 Max: 100 Default: 60
        YuletideJournalRecipeChance = 60,
        -- Maximum recipes generated on Yuletide journals. Min: 1 Max: 5 Default: 3
        YuletideJournalMaxRecipes = 3,
        -- Chance for a Yuletide journal to contain a point-of-interest map segment. Min: 0 Max: 100 Default: 25
        YuletideJournalMapSegmentChance = 25,
        -- Maximum point-of-interest map segments generated in a Yuletide journal. Min: 1 Max: 5 Default: 2
        YuletideJournalMaxMapSegments = 2,
        -- Chance for newly spawned Yuletide journals to include a generated read-only holiday note page. Min: 0 Max: 100 Default: 75
        YuletideJournalNoteChance = 75,
        -- Allow Yuletide journals to roll the forget-slot reward.
        EnableYuletideJournalForgetSlot = true,
        -- Chance for Yuletide journals to include a forget slot when Yuletide forget slots are enabled. Min: 0 Max: 100 Default: 25
        YuletideJournalForgetChance = 25,
        -- Relative weight for practical bundled gift rolls. Min: 0 Max: 100 Default: 70
        YuletideGiftPracticalWeight = 70,
        -- Relative weight for rare bundled gift rolls. Min: 0 Max: 100 Default: 25
        YuletideGiftRareWeight = 25,
        -- Relative weight for jackpot bundled gift rolls. Min: 0 Max: 100 Default: 5
        YuletideGiftJackpotWeight = 5,
        -- Minimum immediate physical gift items granted when a Yuletide journal is unwrapped. Min: 1 Max: 10 Default: 1
        YuletideGiftMinItems = 1,
        -- Maximum immediate physical gift items granted when a Yuletide journal is unwrapped. Min: 1 Max: 10 Default: 2
        YuletideGiftMaxItems = 2,
        -- When enabled, worn, bloody, cursed, and Yuletide journals allow only a limited number of successful rewards. Already-known or blocked claims do not consume the limit. With per-player loot claims, the limit applies separately to each survivor and the journal does not dissolve.
        EnableLimitedClaimLootJournals = false,
        -- When enabled, each survivor gets a separate claim history for worn, bloody, cursed, and Yuletide journals. If limited claims are also enabled, the limit applies separately to each survivor and locks only that survivor's remaining rewards. The journal never dissolves from claims while this setting is active. Default: Off
        EnablePerPlayerLootJournalClaims = false,
        -- Maximum successful rewards one survivor can claim from one eligible loot journal. The journal normally dissolves at the limit. With per-player loot claims, only that survivor's remaining rewards lock and the journal stays. Only applies when limited-claim loot journals are enabled. Default: 1 Min: 1 Max: 25 Default: 1
        LootJournalMaxClaimsBeforeDissolve = 1,
        -- When enabled, skill book XP multipliers (from reading skill books) will apply to XP absorbed from Worn and Bloody journals ONLY. Player Journals are not affected. The multiplier is capped by the setting below.
        SkillBookMultiplierForJournals = true,
        -- Maximum XP multiplier from skill books when absorbing skills from Worn and Bloody journals. Default 2x prevents overpowered early-game progression. Set to 16 to allow full skill book multipliers. Does not affect Player Journals. Min: 1.00 Max: 16.00 Default: 2.00
        SkillBookMultiplierCap = 2.0,
        -- When enabled, opening journals and reading/writing journal actions require enough light, following vanilla reading darkness rules.
        RequireLightForJournalUse = true,
        -- Higher reading skill levels reduce learning time when absorbing from journals.
        ReadingSkillAffectsSpeed = true,
        -- Speed bonus per reading skill level (0.1 = 10% faster per level, max 100% at level 10). Min: 0.00 Max: 0.50 Default: 0.10
        ReadingSpeedBonus = 0.1,
        -- Time in seconds to erase a journal's contents. Min: 1.00 Max: 60.00 Default: 10.00
        EraseTime = 10.0,
        -- Time in seconds to convert a worn journal to a clean journal. Min: 5.00 Max: 120.00 Default: 15.00
        ConvertTime = 15.0,
        -- Allows animated journal backgrounds and future animated journal effects in the UI. Disable this to keep journal visuals static.
        EnableAnimatedJournalVisuals = true,
        -- How many entries a journal tab can show on one page before pagination appears. Lower values reduce UI load but split long lists into more pages. Min: 10 Max: 200 Default: 50
        JournalUIPaginationThreshold = 50,
        -- If enabled, other players can open and view personal journals they didn't create. If disabled, only the journal's author can open it.
        AllowOthersToOpenJournals = true,
        -- If enabled, other players can claim skills/traits from personal journals they didn't create. Requires 'Allow Others to Open' to be enabled. If disabled, only the author can claim from their own journals.
        AllowOthersToClaimFromJournals = true,
        -- If enabled, journal owners can let other players record progress and edit Notes. This does not allow renaming, erasing recorded progress, or changing access.
        AllowOthersToWriteInJournals = false,
        -- Let journal owners make an individual journal more private than the server-wide sharing rules. Individual journals can never grant access the server has disabled.
        AllowPerJournalSharingControls = true,
        -- Let journal owners approve specific readers, writers, and claimers. Player lists cannot grant a permission disabled by the server.
        AllowJournalAccessWhitelists = true,
        -- If enabled, negative traits (like Clumsy, Slow Learner, etc.) can appear in journals and be recorded. Useful for modded traits or challenge runs. Default: OFF (only positive traits).
        AllowNegativeTraits = false,
        -- If enabled, journals will not record or grant traits automatically managed by Fitness, Strength, or body weight changes: Unfit, Out of Shape, Fit, Athletic, Puny, Weak, Feeble, Stout, Strong, Overweight, Obese, Underweight, Very Underweight, and Emaciated. Default: ON.
        ExcludePassiveSkillRelatedTraits = true,
        -- Controls whether 'Restored' journals (player journals created from worn/bloody blanks) dissolve after all contents are claimed. Restored journals always display their origin status. Default: OFF (restored journals persist forever like clean journals).
        AllowPlayerJournalDissolution = false,
        -- When claiming a trait that conflicts with one you already have, the conflicting trait is automatically removed.
        AllowMutualExclusionCancellation = true,
        -- When enabled, BSJ stores SteamID-anchored baseline snapshots for admin recovery and rollback safety.
        EnableBaselineSnapshots = true,
        -- Maximum baseline snapshots kept per SteamID before old entries are pruned. Active snapshots are preserved. Min: 1 Max: 500 Default: 5
        BaselineSnapshotsPerSteamLimit = 5,
        -- Automatically captures snapshots when baseline data is registered, recovered, or debug-edited.
        BaselineSnapshotsAutoCapture = true,
        -- When enabled, baseline snapshot lineage is finalized with death metadata during death cleanup.
        BaselineSnapshotsCaptureOnDeath = true,
        -- Legacy safety mode. When enabled, applying a snapshot sets debugModified=true (requires manual unlock). Default is OFF for canon restore flow.
        BaselineSnapshotsProtectOnRestore = false,
        -- How many skills/traits/recipes to record in a single action when using 'Record All' or 'Record Tab'. Higher values complete faster but can cause heavy multiplayer/server desync on busy servers. Set to 1 for classic one-at-a-time behavior. Default: 15 Min: 1 Max: 50 Default: 15
        RecordBatchSize = 15,
        -- How many skills/traits/recipes to absorb in a single action when using 'Absorb All'. Higher values complete faster but can cause heavy multiplayer/server desync on busy servers. Set to 1 for classic one-at-a-time behavior. Default: 15 Min: 1 Max: 50 Default: 15
        AbsorbBatchSize = 15,
        -- Multiplier for batch action duration. Lower = faster batches. Example: 15 recipes at 0.8s each = 12s normally. With 0.25 multiplier = 3s. Only affects 'Record All' and 'Absorb All', not individual clicks. Default: 0.25 (4x faster) Min: 0.10 Max: 1.00 Default: 0.25
        BatchTimeMultiplier = 0.25,
        -- Compatibility toggle for Traits Purchase System (Mod ID: TraitsPurchaseSystem). When disabled (default), its trait-currency skills (Traits/Traits1/Traits2/Traits3) are hidden from journal recording and claiming, while existing data remains preserved.
        AllowTraitPurchaseSkillRecording = false,
        -- Compatibility toggle for Adaptive Traits (Mod ID: AdaptiveTraits). When disabled (default), AdaptiveTraits-managed traits are hidden from player journal recording and claiming while existing journal data is preserved.
        AllowAdaptiveTraitsManagedTraitRecording = false,
        -- Compatibility toggle for Evolving Traits World (Mod ID: EvolvingTraitsWorld). When disabled (default), ETW-managed traits are hidden from player journal recording and claiming while existing journal data is preserved.
        AllowEvolvingTraitsWorldManagedTraitRecording = false,
        -- Compatibility toggle for Evolving Traits World (Mod ID: EvolvingTraitsWorld). When disabled (default), ETW-managed traits are excluded from newly generated worn, bloody, cursed, and yuletide journals while existing journal data is preserved.
        AllowEvolvingTraitsWorldManagedTraitLootGeneration = false,
        -- Allow clean blank and filled player journals to be painted with vanilla paint buckets and washed clean with water or a completed washing-machine cycle.
        EnableJournalCoverPainting = true,
        -- Compatibility toggle for Lifestyle: Hobbies (Mod ID: LifestyleHobbies). When disabled (default), music like/dislike traits are excluded from recording, claiming, and loot journals to prevent stacked or conflicting preferences. Enabling this also consolidates restored preferences to one like and one dislike.
        AllowLifestyleMusicPreferenceTraitRecording = false,
        -- Compatibility toggle for Lifestyle: Hobbies. When disabled (default), traits that Lifestyle awards or removes from skill progression are excluded from recording, claiming, and loot journals. Restore the Lifestyle skill XP and let Lifestyle recalculate these traits. Enable only if you want journals to control the traits directly.
        AllowLifestyleManagedTraitRecording = false,
        -- Master switch for BSJ debug commands and menus. The game's -debug launch flag does not enable them. Multiplayer access is controlled separately below.
        AllowDebugCommands = false,
        -- Controls which multiplayer roles may use BSJ debug commands when enabled. Single-player remains available to the local player. Default = Admins Only
        -- 1 = Admins Only
        -- 2 = Admins and Staff
        -- 3 = All Players
        DebugCommandAccessLevel = 1,
        -- Allow player journals to record traits managed by Dynamic Traits and Expanded Moodles. Claims use the mod server hooks. Dynamic progression counters are not restored. Build 42.15+ only.
        AllowDynamicTraitsManagedTraitRecording = false,
        -- Allow player journals to record traits managed by the legacy More Traits Dynamic submod. Progression counters are not restored. Prepared starting-item rewards remain excluded.
        AllowMoreTraitsDynamicManagedTraitRecording = false,
    },
    NeuroRadio = {
        -- Turns Aftermath Radio broadcasts on or off.
        Enabled = true,
        -- Radio frequency as MHz x 1000. Default 101800 means 101.8 MHz. Min: 200 Max: 1000000 Default: 101800
        Frequency = 101800,
        -- In-game minutes after world start before the first possible broadcast. Min: 0 Max: 1440 Default: 5
        StartDelayMinutes = 5,
        -- Minimum in-game minutes between Louisville Relay broadcasts. Min: 1 Max: 10080 Default: 20
        MinIntervalMinutes = 20,
        -- Maximum in-game minutes between Louisville Relay broadcasts. Min: 1 Max: 10080 Default: 60
        MaxIntervalMinutes = 60,
        -- How many text-pack entries can be sent in one broadcast. Serial arcs still play as coherent episodes. Min: 1 Max: 5 Default: 1
        MaxLinesPerBroadcast = 1,
        -- In-game minutes before the same listener can receive another XP or mood effect. Does not change how often broadcasts air. Min: 0 Max: 1440 Default: 10
        ListenCooldownMinutes = 10,
        -- Scales only positive unhappiness effects from broadcasts. 50 means half depression. Relief messages, panic, boredom, and XP are not reduced. Min: 0 Max: 100 Default: 50
        UnhappinessMultiplierPercent = 50,
        -- How many recent broadcasts the station tries not to repeat. 0 disables this protection. Min: 0 Max: 50 Default: 3
        AvoidRepeatWindow = 3,
        -- Tile range where a tuned radio placed in the world can trigger XP and mood effects. Set 0 to ignore placed radios for effects. Min: 0 Max: 50 Default: 12
        WorldRadioRadius = 12,
        -- Off by default. When off, a radio inside the backpack does not give XP or mood effects; use hands, vehicle radio, or a placed radio.
        InventoryRadioEffects = false,
        -- 0 Auto, 1 English, 2 Russian, 3 Simplified Chinese. Force a language on servers when auto-detection picks the wrong pack. Min: 0 Max: 3 Default: 0
        LanguageMode = 0,
        -- Chooses where broadcast text is loaded from: 0 built-in only, 1 built-in plus custom overlays, 2 custom only with built-in fallback. Does not change language. Min: 0 Max: 2 Default: 1
        TextMode = 1,
        -- Allows ordered multi-part voices such as Dispatch, Bookman, Mapmaker, Hollow Choir, and Field Logs.
        ArcEnabled = true,
        -- Percent chance per broadcast to play the next available serial arc episode. 0 disables arc picks but keeps standalone broadcasts. Min: 0 Max: 100 Default: 30
        ArcChancePercent = 30,
        -- Writes extra Aftermath Radio details to the game logs. Use mainly for testing.
        Debug = false,
        -- Colors lines by tone or speaker: horror, warnings, Bookman, Dispatch, Pastor, and system fragments.
        LineColors = true,
    },
    ComputerMod = {
        -- Min: 0 Max: 100 Default: 14
        DiscSpawnChance = 14,
        -- Min: 0 Max: 300 Default: 100
        GameDiscWeightPercent = 100,
        -- Min: 0 Max: 300 Default: 100
        SystemDiscWeightPercent = 100,
        -- Min: 0 Max: 300 Default: 100
        BlankDiscWeightPercent = 100,
        -- Min: 0 Max: 300 Default: 100
        HackDiscWeightPercent = 100,
        -- Min: 0 Max: 100 Default: 60
        PreinstalledGameChance = 60,
        -- Min: 0 Max: 100 Default: 34
        PasswordChance = 34,
        -- Min: 0 Max: 100 Default: 12
        FramePasswordNoteChance = 12,
        -- Min: 0 Max: 100 Default: 18
        NearbyPasswordNoteChance = 18,
        -- Min: 0 Max: 10 Default: 1
        HackRequiredElectricalLevel = 1,
        -- Min: 0 Max: 100 Default: 28
        EmptyFolderChance = 28,
        -- Min: 0 Max: 100 Default: 12
        FolderMagazineChance = 12,
        -- Min: 0 Max: 100 Default: 18
        FolderNewspaperChance = 18,
        -- Min: 0 Max: 100 Default: 9
        FolderVideoChance = 9,
        -- Min: 0 Max: 100 Default: 10
        PaintFileChance = 10,
        -- Min: 0 Max: 100 Default: 6
        ComponentSpawnChance = 6,
        -- Min: 0 Max: 100 Default: 18
        FoundComputerBadPartChance = 18,
        -- Min: 0 Max: 100 Default: 1
        FoundComputerBrokenPartChance = 1,
        -- Min: 0 Max: 300 Default: 100
        ComponentWearRate = 100,
        EnableGameInstallVirus = true,
        -- Min: 0 Max: 100 Default: 8
        GameInstallVirusChance = 8,
        EnableBoardApp = true,
        EnableChatApp = true,
        EnableCommerceApp = true,
        NetworkOutageOnPowerLoss = true,
        NetworkTerminalNeedsPower = true,
        -- Min: 1 Max: 168 Default: 24
        MarketShopRefreshHours = 24,
        -- Min: 1 Max: 168 Default: 24
        MarketJobRefreshHours = 24,
        -- Min: 0 Max: 100 Default: 42
        MailAccountChance = 42,
        -- Min: 0 Max: 100 Default: 55
        MailLoggedInChance = 55,
        -- Min: 0 Max: 100 Default: 28
        SecretSiteHintChance = 28,
    },
    ComputerModLaptop = {
        -- Min: 0 Max: 100 Default: 1
        LaptopSpawnChance = 1,
        -- Min: 0 Max: 100 Default: 3
        SpareBatterySpawnChance = 3,
        -- Min: 25 Max: 300 Default: 100
        BatteryDrainRate = 100,
        -- Min: 25 Max: 300 Default: 100
        BatteryChargeRate = 100,
    },
    ComputerModNewMusic = {
        -- Min: 0 Max: 100 Default: 1
        CassetteDeckSpawnChance = 1,
    },
    ElectrifyRadios = {
        -- Minimum Electrical skill level (0-10) needed to convert radios to or from mains power. Set to 0 to disable the requirement. Min: 0 Max: 10 Default: 3
        RequiredElectricalLevel = 2,
    },
    ImmersiveBlackouts = {
        -- Enabling this option will reset the mod's saved data.
        -- Only enable this if you have changed the day when the shutdowns will occur.
        -- It will automatically disable afterwards.
        ModReset = false,
        -- Enables automatic emergency radio broadcasts from the Knox Emergency Regional Infrastructure Service.
        -- The radio will provide information about upcoming outages, current infrastructure status, and other emergency events.
        Radio = true,
        -- Sets the frequency of the emergency radio broadcasts in MHz.
        RadioFrequency = "89.2",
        -- Sets the day range for a random permanent shutoff.
        -- Format: minimum day - maximum day
        -- 0-30 = random day
        -- 30-30 = fixed day.
        -- Overrides the vanilla 'Water Shutoff' day setting.
        -- If the value becomes blank, the entered format was invalid and was rejected.
        WaterShutoffDayRange = "1-30",
        -- Number of days before the scheduled permanent shutoff to start random outages.
        -- Vanilla shutoff: 30, Random Outage Offset: 5 = random outages start on day 25.
        -- Vanilla shutoff: Disabled, Random Outage Offset: 2147483647 = random outages start on day 0. Min: 1 Max: 2147483647 Default: 7
        WaterOffset = 7,
        -- Determines how often the chance of a shutoff or restoration is checked.
        -- The value is specified in in-game minutes. Min: 1 Max: 1440 Default: 10
        WaterCheckInterval = 10,
        -- Cooldown time (in in-game hours) before another state change can occur.
        -- Format: after restoration|after shutoff
        -- 2-2 = 2 hour cooldown after both restoration and shutoff
        -- 1-3|12-24 = random cooldown of 1-3 hours after a restoration and 12-24 hours after a shutoff
        -- 0-0|2-2 = no cooldown after a restoration and a fixed 2 hour cooldown after a shutoff.
        WaterCooldown = "0-0|0-0",
        -- Chance (in percent) that the supply will be shut off.
        -- Checked according to the configured check interval. Min: 0.00 Max: 100.00 Default: 1.00
        WaterPercentOFF = 1.0,
        -- Chance (in percent) that the supply will be restored.
        -- Checked according to the configured check interval. Min: 0.00 Max: 100.00 Default: 5.00
        WaterPercentON = 5.0,
        -- Weather conditions affect the chance of outages.
        -- Bad weather increases the chance of outages and decreases the chance of restoration.
        -- Determines the maximum percentage of weather influence on the chance. Min: 0.00 Max: 100.00 Default: 0.00
        WeatherInfluenceWater = 0.0,
        -- Dynamically adjusts the chance of shutoffs and restorations based on how close the scheduled shutoff day is.
        -- Uses the maximum chance set in the Shutoff Chance and Restore Chance settings.
        -- The restore chance always remains at a minimum of 5%.
        -- It is recommended to use a cooldown when this option is enabled.
        DynamicWaterChance = false,
        -- Sets the day range for a random permanent shutoff.
        -- Format: minimum day - maximum day
        -- 0-30 = random day
        -- 30-30 = fixed day.
        -- Overrides the vanilla 'Electricity Shutoff' day setting.
        -- If the value becomes blank, the entered format was invalid and was rejected.
        ElectricityShutoffDayRange = "14-30",
        -- Number of days before the scheduled permanent shutoff to start random outages.
        -- Vanilla shutoff: 30, Random Outage Offset: 5 = random outages start on day 25.
        -- Vanilla shutoff: Disabled, Random Outage Offset: 2147483647 = random outages start on day 0. Min: 1 Max: 2147483647 Default: 7
        ElectricityOffset = 7,
        -- Determines how often the chance of a shutoff or restoration is checked.
        -- The value is specified in in-game minutes. Min: 1 Max: 1440 Default: 10
        ElectricityCheckInterval = 10,
        -- Cooldown time (in in-game hours) before another state change can occur.
        -- Format: after restoration|after shutoff
        -- 2-2 = 2 hour cooldown after both restoration and shutoff
        -- 1-3|12-24 = random cooldown of 1-3 hours after a restoration and 12-24 hours after a shutoff
        -- 0-0|2-2 = no cooldown after a restoration and a fixed 2 hour cooldown after a shutoff.
        ElectricityCooldown = "0-0|0-0",
        -- Chance (in percent) that the supply will be shut off.
        -- Checked according to the configured check interval. Min: 0.00 Max: 100.00 Default: 1.00
        ElectricityPercentOFF = 1.0,
        -- Chance (in percent) that the supply will be restored.
        -- Checked according to the configured check interval. Min: 0.00 Max: 100.00 Default: 5.00
        ElectricityPercentON = 5.0,
        -- Weather conditions affect the chance of outages.
        -- Bad weather increases the chance of outages and decreases the chance of restoration.
        -- Determines the maximum percentage of weather influence on the chance. Min: 0.00 Max: 100.00 Default: 0.00
        WeatherInfluenceElectricity = 0.0,
        -- Dynamically adjusts the chance of shutoffs and restorations based on how close the scheduled shutoff day is.
        -- Uses the maximum chance set in the Shutoff Chance and Restore Chance settings.
        -- The restore chance always remains at a minimum of 5%.
        -- It is recommended to use a cooldown when this option is enabled.
        DynamicElectricityChance = false,
    },
    ImmersiveWaterShutoff = {
        -- Determines how water will be handled once the main supply is shut off.
        -- 
        -- Off — water will not be removed or reduced.
        -- Randomized Reduction — water will be reduced by a random amount within the range defined by 'Minimum Reduction' and 'Maximum Reduction'.
        -- Full Shutoff — completely removes all water sources, except when the 'Keep Water in Toilets' or/and 'Keep Water in Baths' option is enabled.
        --  Default = Full Shutoff
        -- 1 = OFF
        -- 2 = Randomized Reduction
        -- 3 = Full Shutoff
        WaterRemovalMode = 3,
        -- If enabled, toilets will retain a randomized amount of water in their tanks.
        -- Toilet water will be reduced based on the Minimum Reduction and Maximum Reduction values.
        -- This option has no effect if 'Randomized Reduction' is active.
        -- 
        ToiletsKeepWater = true,
        -- If enabled, baths may retain water prior to the shutoff to emulate people filling their tubs as emergency water.
        -- Bath water is randomized from 0 to 100, and the chance a bath has been filled is determined by the 'Filled Bath Chance' option.
        -- This option has no effect if 'Randomized Reduction' is active.
        -- 
        BathsKeepWater = false,
        -- If enabled, baths can be filled in advance to prepare for the main water supply being shut off.
        -- This allows players to have emergency water stored in their tubs.
        -- 
        FillableBaths = false,
        -- The percentage chance that a bath has been filled prior to the water shutoff to emulate people filling their tubs for emergency use.
        -- This option only has effect if 'Keep Water in Baths' is enabled. Min: 0 Max: 100 Default: 10
        BathPercent = 10,
        -- The minimum percentage of water to be removed when 'Randomized Reduction' or 'Keep Water in Toilets' is enabled. Min: 0 Max: 100 Default: 90
        MinPercent = 90,
        -- The maximum percentage of water to be removed when 'Randomized Reduction' or 'Keep Water in Toilets' is enabled. Min: 0 Max: 100 Default: 100
        MaxPercent = 100,
        -- Determines when water becomes tainted after the main supply is shut off:
        -- 
        -- -1 = disabled
        -- 0 = immediately
        -- 1+ = water becomes tainted after the specified number of in-game days.
        --  Min: -1 Max: 2147483647 Default: -1
        TaintedWater = -1,
        -- Determines the strength of poisoning when consuming tainted water.
        -- 
        -- 1 = vanilla value.
        -- 2 = twice as strong.
        -- 3+ = extremely dangerous values.
        -- 
        -- The Iron Gut trait reduces the poison received, but does not make the character completely immune to tainted water.
        -- The Weak Stomach trait increases the poison received from tainted water.
        -- At x2, drinking around 2 liters of tainted water at maximum thirst can result in fatal food poisoning. Min: 1.00 Max: 10.00 Default: 1.00
        TaintedWaterPoisonMultiplier = 1.0,
        -- If enabled, water quality in connected plumbing will depend on the water source.
        -- If the connected barrel contains tainted water or another tainted liquid, sinks, baths, and other plumbing objects will also provide tainted liquid.
        PlumbingSourceQuality = false,
        -- If enabled, the settings below will be used.
        -- By default, they contain the game's default values.
        UseCustomRainCollectors = false,
        -- Determines the maximum amount of water that can be stored in a square rain collector. Min: 0.00 Max: 10000.00 Default: 400.00
        RainCollectorCapacity = 400.0,
        -- Determines how efficiently the square rain collector collects rainwater. Min: 0.00 Max: 100.00 Default: 0.40
        RainCollectorRainFactor = 0.4,
        -- Determines the maximum amount of water that can be stored in a round rain collector. Min: 0.00 Max: 10000.00 Default: 600.00
        RainCollectorRoundCapacity = 600.0,
        -- Determines how efficiently the round rain collector collects rainwater. Min: 0.00 Max: 100.00 Default: 0.25
        RainCollectorRoundRainFactor = 0.25,
        -- Determines the maximum amount of water that can be stored in a square tarp rain collector. Min: 0.00 Max: 10000.00 Default: 400.00
        RainCollectorTarpCapacity = 400.0,
        -- Determines how efficiently the square tarp rain collector collects rainwater. Min: 0.00 Max: 100.00 Default: 0.40
        RainCollectorTarpRainFactor = 0.4,
        -- Determines the maximum amount of water that can be stored in a round tarp rain collector. Min: 0.00 Max: 10000.00 Default: 600.00
        RainCollectorRoundTarpCapacity = 600.0,
        -- Determines how efficiently the round tarp rain collector collects rainwater. Min: 0.00 Max: 100.00 Default: 0.25
        RainCollectorRoundTarpRainFactor = 0.25,
        -- Determines the maximum amount of water that can be stored in an amphora. Min: 0.00 Max: 10000.00 Default: 300.00
        AmphoraCapacity = 300.0,
        -- Determines how efficiently the amphora collects rainwater. Min: 0.00 Max: 100.00 Default: 0.40
        AmphoraRainFactor = 0.4,
    },
    LGExtendedElectricity = {
        -- A generator powers the whole building it reaches, not just the tiles around it. Every floor, the roof and the basement. Turn this off and restart before removing the mod.
        Enabled = true,
        -- On: plug a generator in and it powers the building straight away. Off: you right-click it and pick Wire up the building first. Either way you can change your mind on any generator.
        ExtendByDefault = false,
        -- On: the extra rooms cost fuel, so a big building burns more. Off: they are free. To change the fuel rate itself, use the game's own Generator Fuel Consumption.
        ChargeFuel = true,
        -- On: two generators on one building split the fuel bill instead of both paying it in full. Off: each one pays in full.
        ShareLoad = true,
        TakeoverMark = "v1:f20:F1:fv3:FV1",
        -- Put too much on a generator and its breaker trips, taking every generator on the same buildings with it. Start them all again, then right-click one and reset. To stop it tripping, add a generator or turn something off. Needs Generator Fuel Consumption above zero.
        Breaker = true,
        -- How much a generator can run at once. A better generator gets more: at 225 they range from 5400 to 8100 watts. Lower this for a harder game, raise it for an easier one. Min: 10 Max: 10000 Default: 225
        BreakerWattsPerPoint = 225,
        -- Lets you pipe petrol to a generator with a pipe wrench. A barrel next to it feeds it directly. With LG Extended Plumbing, a generator can also draw from the whole base's petrol barrels. Off: nothing can be connected.
        FuelLine = true,
        -- Lets you pipe a fuel station pump into a generator parked next to it, so it runs off the tanks below. Off: barrels only.
        FuelFromPumps = true,
        -- How far power reaches past the walls, so a porch light or an outdoor freezer works. Set 0 for indoors only. Some tiles reach a little further than this, so treat it as a minimum. Min: 0 Max: 8 Default: 1
        ExteriorReach = 1,
        -- On: generators and wire relays use the two ranges below, and the game's Generator tile range is set to 1. Off: the game's range is used. Needs a restart.
        TakeOverGeneratorRange = true,
        -- How many tiles a running generator powers around itself, and how far away a building can be to wire it up. Used when the mod sets generator range. Min: 1 Max: 100 Default: 20
        GeneratorRange = 20,
        -- How many tiles a wire relay powers around itself, and how many electrical wires it costs. Used when the mod sets generator range. Min: 1 Max: 100 Default: 2
        WireRelayRange = 2,
        -- On: generators and wire relays use the two level settings below, and the game's Generator vertical range is set to 1. Only works while Mod sets generator range is on. Off: the game's vertical range is used. Needs a restart.
        TakeOverGeneratorVerticalRange = true,
        -- How many levels above and below a running generator it powers. Wired buildings always get every level. Used when the mod sets generator vertical range. Min: 1 Max: 15 Default: 1
        GeneratorVerticalRange = 1,
        -- How many levels above and below a wire relay it powers. Used when the mod sets generator vertical range. Min: 1 Max: 15 Default: 1
        WireRelayVerticalRange = 1,
        -- What one street light costs your generator once you wire it up. The game charges nothing for street lights, so this figure is the mod's. Set 0 to make them free. Min: 0 Max: 1000 Default: 100
        StreetLightWatts = 100,
        -- Writes every power change to the log file. Only useful for tracking down a problem.
        Debug = false,
    },
    LGExtendedPlumbing = {
        -- A rain collector plumbed into a building feeds every plumbed fixture in it, not just the one right below. Turn this off for normal plumbing.
        Enabled = true,
        -- How far a fixture looks for barrels when it is not in a real building, like a base you built yourself. Inside a real building the whole building is used and this does nothing. 12 covers a good sized base. Min: 1 Max: 64 Default: 12
        Reach = 12,
        -- Things that can be plumbed in to be FILLED by the supply instead of feeding it. Water dispensers by default. You still have to right-click one and plumb it with a pipe wrench. Use the object's script name, separated by semicolons. Clear the box to turn this off.
        FedFixtures = "WaterDispenser",
        -- Fixes two base game bugs on servers: a washing machine you cannot plumb, and one that keeps running on your screen after it runs dry. Singleplayer does not need it.
        WasherPatch = true,
        -- Fixes a base game bug that empties your barrels without filling anything. It only hits drinks like cola, juice and vodka. Water, beer and whiskey were never affected.
        FluidPatch = true,
        -- Writes every plumbing change to the log file. Only useful for tracking down a problem.
        Debug = false,
    },
    UsefulBarrels = {
        -- Enables additional information for debugging purposes.
        DebugMode = false,
        -- Maximum barrel capacity.
        -- Applied only for new barrels, previously used is unaffected. Min: 1 Max: 9999 Default: 400
        BarrelCapacity = 400,
        -- A Pipe Wrench is required for barrel uncapping.
        RequirePipeWrench = true,
        -- A Rubber Hose is required to take Gas from barrel.
        RequireHoseForTake = true,
        -- A Funnel is required to add Gas to barrel.
        RequireFunnelForFill = true,
        -- Speed up canisters filling by modifier if there is a Funnel nearby.
        -- Example: value 1.25 means 25% bonus or 1.25 times faster operation.
        -- Set to 1 to disable speed bonus. 
        --  Does not work if 'Require Funnel' disabled. Min: 1.00 Max: 2.00 Default: 1.25
        FunnelSpeedUpFillModifier = 1.25,
        -- Acid, Alcohol, Blood, Gasoline, Dye...
        AllowIndustrial = true,
        -- Gasoline
        AllowFuel = true,
        -- Acid, Bleach, Cleaning Liquid...
        AllowHazardous = true,
        -- Seltzer Water, Water, Tainted Water
        AllowWater = true,
        -- Alcohol, Beer, Wine...
        AllowAlcoholic = false,
        -- Blood, Beer, Coffee, Milk, Honey, Soda...
        AllowBeverage = false,
        -- Alcohol
        AllowMedical = false,
        -- Dye, Hair Dye, Wine
        AllowColors = false,
        -- Dye
        AllowDyes = false,
        -- Hair Dye
        AllowHairDyes = false,
        -- No any fluids as for B42.4
        AllowPaint = false,
        -- Potent Poison
        AllowPoisons = false,
        EnableGeneratorRefuel = true,
        GeneratorRefuelRequiresHose = true,
        EnableCarRefuel = true,
        CarRefuelRequiresHose = true,
        EnableFillBarrelFromVehicles = true,
        FillBarrelFromVehiclesRequiresHose = true,
        InitialFluid = true,
        -- Whitespace separated list of fluids that can spawn in barrels.
        InitialFluidPool = "Acid Water TaintedWater Petrol Petrol Bleach PotentPoison",
        -- Max amount of initial fluid.
        -- Won't be greater than the barrel capacity. Min: 0 Max: 9999 Default: 54
        InitialFluidMaxAmount = 54,
        -- Spawn chance of initial fluid. Min: 0.00 Max: 100.00 Default: 25.00
        InitialFluidSpawnChance = 25.0,
        RequireWeldingMask = true,
        RequireBlowTorch = true,
    },
    PIP = {
        -- When on, pipes automatically water nearby crops from connected rain barrels.
        EnableAutoWatering = true,
        -- In-game minutes between each watering cycle. Min: 1 Max: 1440 Default: 10
        WateringInterval = 10,
        -- 0 = the pipe's own tile only. Higher values water crops in a square area around each pipe. Min: 0 Max: 10 Default: 0
        WateringRadius = 0,
        -- When on, pipes fill crops up to their optimal water level. When off, they add a fixed small amount each cycle.
        SmartPipes = true,
        -- Maximum water level added to a crop per cycle in Smart Pipes mode. Min: 3 Max: 100 Default: 20
        SmartPipesFillMax = 20,
        -- When on, barrels connected in the same network share and balance their water (a full and an empty barrel even out).
        SharedWaterPool = true,
        -- When on, pour Fertilizer or Compost into a connected rain barrel and the pipe network auto-fertilizes nearby crops (one safe dose per crop, never over-fertilizes). On by default.
        EnableFertigation = true,
        -- Simulated Farming skill used when auto-fertilizing. Higher = better chance of a yield bonus. Does not affect safety. Min: 0 Max: 10 Default: 5
        FertigationSkill = 5,
        -- How many crops one poured bag can fertilize. Independent of barrel water volume. Min: 1 Max: 100 Default: 10
        ChargesPerBag = 10,
        -- Prints internal logs to the console. For troubleshooting only.
        DebugLogs = false,
    },
    PSR = {
        -- How often Battery Bank will charge Default = Every Ten Minutes
        -- 1 = Every Ten Minutes
        -- 2 = Every Hour
        ChargeFreq = 1,
        -- Solar panel power efficiency
        -- 12% is realistic for 1993
        -- 25% is modern solar
        -- default is unrealistic Min: 1 Max: 100 Default: 25
        solarPanelEfficiency = 25,
        -- How fast batteries wear while the bank is running, in percent of 1 condition point per day.
        -- 100 = 1 point per day (default) - 50 = half as fast on average - 200 = twice as fast - 0 = no wear.
        -- A DIY Battery always wears 64 times slower. Min: 0 Max: 1000 Default: 100
        batteryDegradeChance = 100,
        -- Multiplier for device power consumption, in percent.
        -- 100 = normal consumption (default)
        -- 50 = half consumption
        -- Lower this if powering your base requires too many solar panels. Min: 1 Max: 1000 Default: 100
        consumptionMultiplier = 100,
        -- Multiplies the capacity of the source battery. Default is 100%: the DIY holds exactly what its source held, and the real gain is wear - it degrades about sixty times slower. Higher values add capacity: at 800%, a wired CarBattery1 (50Ah) gives 400Ah, an Improvised Battery (100Ah) gives 800Ah. Min: 1 Max: 10000 Default: 100
        DIYBatteryMultiplier = 100,
        -- Rarity of Battery Bank spawning on the map. Default = Rare
        -- 1 = None
        -- 2 = Very Rare
        -- 3 = Rare
        -- 4 = Uncommon
        BatteryBankSpawn = 3,
        -- Solar panel spawns in random containers and pre-placed crates multiplier Min: 0.00 Max: 100.00 Default: 1.00
        LRMSolarPanels = 1.0,
        -- Batteries spawns in random containers and pre-placed crates multiplier Min: 0.00 Max: 100.00 Default: 1.00
        LRMBatteries = 1.0,
        -- Spawn rate multiplier for the magazine, the Inverter and the Solar Failsafe, in random containers and pre-placed crates Min: 0.00 Max: 100.00 Default: 1.00
        LRMMisc = 1.0,
        -- Base number of in-game minutes it takes to connect one panel. Min: 1 Max: 1440 Default: 30
        ConnectPanelMin = 30,
        -- Max distance to link a backup generator to a battery bank.
        -- 0 = use Electrician skill (default, ~10 tiles max)
        -- 1-50 = fixed range in tiles, any skill. Min: 0 Max: 50 Default: 0
        BackupConnectRange = 0,
        -- Max horizontal distance between a solar panel and the battery bank it connects to.
        -- 20 is the default and the original behaviour. Raise it for large bases and bunkers.
        -- Vertical reach is set separately, see Solar Panel Vertical Reach.
        -- Larger values make the mod scan a wider area, which costs performance on very big buildings. Min: 20 Max: 40 Default: 20
        PanelConnectRange = 20,
        -- How many floors up or down a solar panel can reach to find its battery bank.
        -- 3 is the default and the original behaviour. Raise it if your bank sits deep in a basement or bunker, or high up a tower.
        -- Each extra floor widens the scan above and below, which costs performance on very big buildings. Min: 3 Max: 8 Default: 3
        PanelConnectFloors = 3,
        -- How many floors up or down a battery bank can reach to find its backup generator.
        -- 1 is the default and the original behaviour. Raise it if your generator sits on a roof, or several floors away from the bank.
        -- This also widens the distance budget, so a rooftop generator is no longer penalised for being high up. Min: 1 Max: 8 Default: 1
        BackupConnectFloors = 1,
        -- Rarity of pre-placed solar crates spawning on the map, in sheds, garages, storage units, electronics storage and farm storage.
        -- Crates are the best find in the mod - a whole batch of parts at once - so they stay rarer than battery banks.
        -- Set to None to remove them entirely. Default = Rare
        -- 1 = None
        -- 2 = Very Rare
        -- 3 = Rare
        -- 4 = Uncommon
        SolarCrateSpawn = 3,
        -- When ON, crafting solar panels needs a harder, more realistic recipe (tempered glass + aluminium, more components, higher Electricity skill).
        -- OFF = the standard recipe (default).
        -- This sets which recipe the magazine teaches. Changing it on an existing save works: flip it and reload, and the other recipe is added to the one you already knew.
        HardenedPanelRecipe = false,
        -- Lets you connect a building that is part of the map - not one you built - to a Battery Bank, with Connect this area to the Power Bank.
        -- Off by default everywhere, singleplayer and co-op included - turn it on to use it.
        -- The reason it defaults to off: on a server, anyone could otherwise connect a neighbour's house and switch their appliances off from the Solar Computer.
        AllowVanillaConnect = false,
    },
    PFR = {
        -- Default target temperature applied when a new Cold Unit is placed. Range -30 to 0 Celsius. Can be overridden per-unit via the Control Panel. Freezing needs a target below 0: set it to 0 and the room still gets cold, but nothing will ever freeze. Min: -30 Max: 0 Default: -10
        TargetTemp = -10,
        -- Multiplier applied to the cooling rate. 1.0 = default, 0.25 = slow, 4.0 = very fast. Min: 0.25 Max: 4.00 Default: 1.00
        CoolingSpeed = 1.0,
        -- Display temperatures in Celsius or Fahrenheit on the Control Panel. Default = Celsius
        -- 1 = Celsius
        -- 2 = Fahrenheit
        TempUnit = 1,
        -- Multiplier applied to the impact of open doors / smashed windows / gaps on the cold room insulation. 0.0 = disabled (openings have no effect, like v1.1), 1.0 = default (v1.2 behavior), 3.0 = tripled effect. Min: 0.00 Max: 3.00 Default: 1.00
        InsulationStrength = 1.0,
        -- When enabled, your character feels the cold while standing inside a PFR cold room with an active Cold Unit. Triggers vanilla moodles (Hypothermia, catch a cold) depending on the room temperature. Automatically disabled when Realistic Temperature mod is active to avoid conflicts.
        ColdFeelingEnabled = true,
    },
    PWS = {
        -- How many days ahead the computer shows exact highs and lows.
        -- 3 days is what a real station can honestly predict. 7 is the most this mod will give you.
        -- Set to 0 to remove precise forecasting entirely. Min: 0 Max: 7 Default: 3
        PreciseForecastDays = 3,
        -- How many days ahead the computer shows a rough trend - warm or cold front only, no numbers - past the precise range.
        -- Beyond about a week, real forecasting is guesswork, so 7 is the limit here. Min: 0 Max: 7 Default: 7
        TrendForecastDays = 7,
        -- How many past days the computer shows, up to 10.
        -- Days when the station had no power leave gaps in the record. Min: 1 Max: 10 Default: 10
        HistoryDays = 10,
        -- How often the meteorology magazine spawns in containers.
        -- The magazine is the only way to learn the recipes, so setting this to 0 disables the mod's crafting. Min: 0 Max: 1000 Default: 100
        MagazineLootMultiplier = 100,
        -- How far the desktop computer can sit from the weather station and still read it.
        -- 1 means right next to it, which is the default and the way the mod is balanced.
        -- The station has to stand outside, so raise this if you would rather keep the computer indoors. Min: 1 Max: 10 Default: 1
        ComputerRange = 1,
        -- How many floors up or down the computer can sit from the weather station and still read it.
        -- 0 means the same floor only, which is the default and changes nothing.
        -- Raise it if you want the station on the roof while the computer stays indoors. Min: 0 Max: 2 Default: 0
        ComputerVerticalRange = 0,
    },
    LGRealisticPowerUsage = {
        -- Off: nothing ever uses more power than it did before, only less. On: a few things that really use a lot now cost a lot. A clothes dryer goes to 3000 watts and an oven to 1500.
        Increases = true,
    },
    ImmersiveSnow = {
        -- Who leaves footprints in ground snow: everyone (players and the zombies near a player), players only, or nobody (no footprints and no snow carried off on the soles). Each player can also show fewer for themselves in Options > Mods. Default = Everyone (players and zombies)
        -- 1 = Everyone (players and zombies)
        -- 2 = Players only
        -- 3 = Nobody (off)
        FootprintsFrom = 1,
        -- Vehicles leave tire tracks in ground snow. Off: no tire tracks and no snow carried off on the tires. Each player can also turn them off for themselves in Options > Mods.
        TireTracks = true,
        -- For weak integrated graphics with little video memory. Turns off snow on zombies, on items in hand and on vehicle doors, hoods and wheels, and the icing on vehicles; fewer footprints and tire tracks (at most 600 / 1200), zombie footprints only within 15 tiles, fewer snow particles blown off cars, half the footprint textures. The same switch is in Options > Mods for each player.
        LowEndMode = false,
        -- In-game hours a player's footprint lasts when no snow is falling. Min: 0.50 Max: 168.00 Default: 6.00
        FootprintHours = 6.0,
        -- In-game hours a zombie's footprint lasts when no snow is falling. Lower it so hordes do not trample the snow for long. Min: 0.50 Max: 168.00 Default: 6.00
        ZombieFootprintHours = 6.0,
        -- How much faster footprints disappear during heavy snowfall. Min: 0.00 Max: 50.00 Default: 8.00
        SnowfallCoverRate = 8.0,
        -- Above this limit the oldest footprints fade out. Players and zombies share it (each keeps at least half); lower it if the game slows down in snow. Min: 10 Max: 10000 Default: 2000
        MaxFootprints = 2000,
        -- Only zombies within this many tiles of the player leave footprints. Min: 5 Max: 60 Default: 25
        ZombieRadius = 25,
        -- B42 animals (deer, rabbits, chickens, cows, pigs, sheep...) and the horses, dogs and cats of the Horse Mod and Companion Dogs leave hoof and paw prints in ground snow, also out of sight, so game can be tracked. Each player can also turn them off for themselves in Options > Mods.
        AnimalTracks = true,
        -- In-game hours an animal's print lasts when no snow is falling. Min: 0.50 Max: 168.00 Default: 12.00
        AnimalTrackHours = 12.0,
        -- Above this limit the oldest animal prints fade out (a limit of their own, apart from the footprints). Lower it if the game slows down by a farm in snow. Min: 10 Max: 10000 Default: 1000
        MaxAnimalTracks = 1000,
        -- Only animals within this many tiles of the player leave prints (the nearest 48 at most). Min: 5 Max: 60 Default: 25
        AnimalTrackRadius = 25,
        -- A player or zombie without shoes leaves the print of a bare foot (heel, ball and toes) instead of a boot sole, in the snow and with the snow carried onto clear ground.
        BarefootPrints = true,
        -- A player or zombie who steps on a corpse leaves red prints for the next steps, each fainter, in the snow and on clear ground (asphalt, floors). Blood on the floor alone does not count. Off with the game's blood decals set to none.
        BloodyFootprints = true,
        -- How many steps after the blood still leave red prints. Min: 1 Max: 40 Default: 8
        BloodyFootprintSteps = 8,
        -- Bloody footprints are also left when no snow lies: red prints on clear ground after stepping on a corpse, in any season, like the bloody tire tracks. Only with Bloody footprints on, and for whoever leaves footprints (players, zombies).
        BloodyFootprintsNoSnow = true,
        -- Drops of blood behind a bleeding player or a wounded zombie, covered by snowfall like the footprints. In multiplayer only for players on this computer and zombies: the game does not tell other clients that a player bleeds. Off with the game's blood decals set to none.
        BloodOnSnow = true,
        -- In-game hours a tire track lasts when no snow is falling. Min: 0.50 Max: 168.00 Default: 12.00
        TireTrackHours = 12.0,
        -- A segment is 0.4 tile of one wheel's track. Hard limit: above it the oldest segments vanish within seconds; lower it if the game slows down in snow. Min: 20 Max: 20000 Default: 4000
        MaxTireTracks = 4000,
        -- Above this many segments the oldest fade out over about 20 seconds, so a spot driven over again and again keeps only its latest laps. Has no effect at or above the max segments. Min: 20 Max: 20000 Default: 1500
        TireTrackSoftLimit = 1500,
        -- A wheel that runs over a corpse leaves a red track that pales out: a red rut in snow, red tread marks on clear ground. Only the wheels that went over it; blood on the ground alone does not count. Follows the vanilla blood settings (none with Blood Level none or blood decals off). Each player can also turn it off for themselves in Options > Mods.
        BloodyTireTracks = true,
        -- Tiles a wheel keeps leaving a red track after the blood, paler and paler. Min: 0.40 Max: 40.00 Default: 2.00
        BloodyTireTrackTiles = 2.0,
        -- Snow builds up on vehicles parked outdoors, melts in warmth and from a running engine, and blows off when driving. Works with modded vehicles.
        VehicleSnow = true,
        -- In-game hours of heavy snowfall until a parked vehicle is fully covered. Min: 0.25 Max: 24.00 Default: 2.00
        VehicleSnowHours = 2.0,
        -- Glazed ice around the snow on the body, the wheels and the glass edges. Off: plain snow only. Frost on the glass is a separate option.
        VehicleSnowIce = true,
        -- Snow settles on the clothes and on what you hold while you are outdoors in snowfall, and melts in warmth: indoors, by a fire, in the rain above freezing. Melting snow wets the clothes. Off: no snow on characters at all, so none melts into the clothes (falling snow and walking through snow still wet them).
        CharSnow = true,
        -- In-game hours of heavy snowfall outdoors a full layer of snow on the clothes would take (players stop at the most snow below). Light snowfall builds up slower. Min: 0.10 Max: 24.00 Default: 3.00
        CharSnowHours = 3.0,
        -- How much snow snowfall leaves on a player's clothes, moving about shakes off as much as falls; the lighter the snowfall, the less. 1: a full layer only in the heaviest snowfall. 1.5: a full layer in heavy snowfall, three quarters in light. Never more than a full layer. Zombies always get a full layer. Min: 0.10 Max: 2.00 Default: 1.50
        CharSnowMax = 1.5,
        -- Game hours a full layer of snow on a character takes to melt at 20 C (indoors, by a fire, in a heated car). At 10 C it takes twice as long; below 0 C it does not melt. Min: 0.10 Max: 24.00 Default: 1.25
        CharSnowMeltHours = 1.25,
        -- Under a roof or in a vehicle just above 0 C a full layer of snow on a character melts in this many game hours, however cold the room; warmer rooms melt it faster still (the option above). Min: 0.10 Max: 24.00 Default: 0.50
        CharSnowIndoorMeltHours = 0.5,
        -- Game hours body heat takes to melt a full layer of snow in the cold while it does not snow. Zombies have no body heat. Min: 1.00 Max: 500.00 Default: 50.00
        CharSnowBodyMeltHours = 50.0,
        -- Game hours of heavy rain above 0 C that wash a full layer of snow off a character or zombie (on top of melting in the warmth). Min: 0.10 Max: 48.00 Default: 3.00
        CharSnowRainMeltHours = 3.0,
        -- Snow on what characters hold and carry on the body: weapons, tools, backpacks on the back. Off: snow on the clothes only. Turn it off if a weapon mod shows the wrong weapon models in the snow.
        CharItemSnow = true,
        -- Darker snow on vehicles, characters and items, and darker snow particles, to match darker ground snow. On by itself with Snow Lands - Darker Snow. Takes effect after loading the save again.
        DarkSnow = false,
        -- Zombies get snow on their clothes too. They have no body heat: the snow melts in warmth above freezing or in the rain, and goes within an hour once the ground outdoors is bare.
        ZombieSnow = true,
        -- Game hours of heavy snowfall until a zombie outdoors is fully covered. Melting works as for players, without body heat; outdoors on bare ground the snow goes within an hour. Min: 0.10 Max: 24.00 Default: 0.50
        ZombieSnowHours = 0.5,
        -- A zombie or player that dies with snow on keeps it on the corpse, and it melts there as on zombies: in warmth above freezing, in the rain, and within an hour once the ground outdoors is bare. No new snow settles on corpses. Off: the snow comes off when a character dies. In multiplayer only on the corpses of deaths this client saw.
        CorpseKeepSnow = false,
        -- While it is 0 C or colder outdoors, no flies buzz over corpses and their stench makes nobody sick: the mod holds the game's "Decaying Corpse Health Impact" at None and sets it back above +1 C. If you set that option yourself while it is held, the mod leaves it as you set it and turns this option off. Before taking the mod out of a save, run ISnow.cleanSave() in the console (see the mod page), or that option may stay at None.
        ColdCorpses = true,
        -- Snow falling on a player and the snow melting on the clothes make them wet, like rain does in vanilla; walking through snow wets the shoes. Water-resistant clothes and boots protect. Wet clothes keep less warm.
        SnowWetness = true,
        -- Multiplier of how fast snow wets the clothes. 1 = wet snow at 0 C soaks an outer layer in about 3 game hours; the colder, the drier the snow. Min: 0.00 Max: 5.00 Default: 1.00
        SnowWetnessRate = 1.0,
        -- Stepping or driving from snow onto a clear square leaves a few fading snowy prints.
        CarriedSnow = true,
        -- How many steps on clear ground after the snow still leave snowy prints. Min: 1 Max: 10 Default: 3
        CarriedSnowSteps = 3,
        -- How far a wheel leaves snowy tread marks on clear ground after the snow. Min: 0.40 Max: 20.00 Default: 3.20
        CarriedSnowTireTiles = 3.2,
        -- Game hours snowy prints and tire marks on clear ground last at 0 C and below. Min: 0.10 Max: 48.00 Default: 2.00
        CarriedSnowHours = 2.0,
        -- Game hours snowy prints and tire marks take to melt at 20 C (a heated house); at 10 C twice as long. Uses the temperature of their square. Min: 0.02 Max: 24.00 Default: 0.25
        CarriedSnowMeltHours = 0.25,
        -- Living players breathe out vapour in the cold: faster and thicker after running, none through a gas mask or respirator, half through cloth over the face. Uses the air temperature at the character (indoors, heaters and the vehicle heater count). Zombies do not breathe.
        Breath = true,
        -- Air temperature at and below which the vapour shows, faint at first. Min: -20.00 Max: 15.00 Default: 7.00
        BreathMaxTemp = 7.0,
        -- Air temperature at and below which the vapour is at full strength. Min: -40.00 Max: 0.00 Default: -20.00
        BreathFullTemp = -20.0,
        -- How thick the vapour is, 0.1 (barely visible) to 1. Min: 0.10 Max: 1.00 Default: 0.85
        BreathOpacity = 0.85,
        -- While the engine is warm, the snow on the hood melts faster than on the roof: the hotter the engine, the faster (vanilla engine temperature: it warms up over the first hour or so of running and stays warm for a while after it stops). Only on vehicles whose hood is a separate model (KI5, Vanilla Vehicles Animated...); on the vanilla cars the hood is part of the body. In multiplayer the server decides; each player can hide it for themselves in Options > Mods.
        VehicleHoodMelt = true,
        -- Game hours a hot engine takes to melt a full layer of snow off the hood. A cold engine melts nothing; half warm, twice as long. In multiplayer always as on the server. Min: 0.10 Max: 24.00 Default: 1.00
        VehicleHoodMeltHours = 1.0,
        -- Running and sprinting through snow throws a little powder back off the feet; a player or zombie that goes down in the snow (knocked down, tripped, killed) raises a puff. Only with footprints on.
        SnowKick = true,
        -- Powder puffs a running step into snow throws (a fraction is the chance of one): 0 none, 0.4 about every other step, 3 a lot. Min: 0.00 Max: 3.00 Default: 0.40
        SnowKickRun = 0.4,
        -- Powder puffs a sprinting step into snow throws, with a chance of a clump. Min: 0.00 Max: 5.00 Default: 1.30
        SnowKickSprint = 1.3,
        -- A player or zombie that goes down in the snow (knocked down, tripped, killed) raises a puff along the body.
        SnowKickFalls = true,
        -- How much snow a fall raises: 1 is 7 puffs and 3 clumps, 2 twice as many. Min: 0.10 Max: 3.00 Default: 1.00
        SnowKickFallAmount = 1.0,
        -- Vehicle wheels in snow throw powder and now and then a clump behind them: more the faster the vehicle goes, more again when it slides sideways. Works with tire tracks off too.
        SnowKickWheels = true,
        -- How much snow the wheels throw: 1 is about 40 puffs a second off a car at 40 km/h and over, 2 twice as many. Min: 0.10 Max: 3.00 Default: 0.80
        SnowKickWheelAmount = 0.8,
        -- Frost creeps in from the edges of the screen with the Hypothermia moodle: further in at each level, in full at level 4. Goes away as the character warms up. In multiplayer each player can hide it for themselves in Options > Mods.
        FrostScreen = true,
        -- How thick the frost at the edges of the screen is at its fullest, 0.1 (barely visible) to 1. In multiplayer always as on the server. Min: 0.10 Max: 1.00 Default: 0.80
        FrostScreenOpacity = 0.8,
        -- Level of the Hypothermia moodle (1-4) at which the first frost shows at the edges of the screen. It reaches further in at each level above, in full at level 4. In multiplayer always as on the server. Min: 1 Max: 4 Default: 1
        FrostScreenFromLevel = 1,
        -- Real seconds the frost takes to creep in to the next stage when the Hypothermia moodle rises. In multiplayer always as on the server. Min: 1.00 Max: 120.00 Default: 12.00
        FrostScreenComeSeconds = 12.0,
        -- Real seconds the frost takes to thaw back when the Hypothermia moodle drops or goes. In multiplayer always as on the server. Min: 1.00 Max: 300.00 Default: 30.00
        FrostScreenGoSeconds = 30.0,
        -- The frost at the edges of the screen trembles while the character shivers with cold, harder at each Hypothermia level. Turn off if screen motion bothers you.
        FrostScreenShiver = true,
        -- Level of the Hypothermia moodle (1-4) at which the frost starts to tremble. Min: 1 Max: 4 Default: 2
        FrostScreenShiverLevel = 2,
        -- A vehicle parked outdoors in the frost gets frost on its windows, on the glass itself. Scrape it off (right-click the vehicle; faster with a scraper, spatula or trowel) or run the engine with the heater on. In multiplayer each player can hide it for themselves in Options > Mods.
        VehicleFrost = true,
        -- Game hours a vehicle parked outdoors at -8 C or colder takes to frost over fully. Slower in a milder frost, none above 0 C. In multiplayer always as on the server. Min: 0.25 Max: 24.00 Default: 3.00
        VehicleFrostHours = 3.0,
        -- Game minutes the heater (with the engine running) takes to clear fully frosted windows. The engine alone takes four times as long. In multiplayer always as on the server. Min: 1.00 Max: 120.00 Default: 10.00
        VehicleFrostHeaterMinutes = 10.0,
        -- Game hours full frost takes to thaw on its own at +5 C; at +10 C half as long. Below 0 C it does not thaw on its own. In multiplayer always as on the server. Min: 0.25 Max: 24.00 Default: 2.50
        VehicleFrostMeltHours = 2.5,
        -- In a strong wind in the frost, low snow dust sweeps along the ground snow with the wind, in gusts. In multiplayer each player can hide it for themselves in Options > Mods.
        DriftingSnow = true,
        -- Wind speed from which snow drifts along the ground; it grows to full 30 km/h above it. Min: 5.00 Max: 100.00 Default: 25.00
        DriftingSnowWind = 25.0,
        -- How much snow dust drifts: 1 is about 30 wisps a second on the screen at full wind, 2 twice as many. Min: 0.10 Max: 3.00 Default: 1.00
        DriftingSnowAmount = 1.0,
        -- A campfire, a fire on the ground or a burning building melts the snow around it into a dark wet patch, with a little steam, while it burns. The patch freezes over and is snowed over after the fire goes out. In multiplayer each player can hide it for themselves in Options > Mods.
        FireThaw = true,
        -- Game hours a fully thawed patch takes to go after the fire is out, if no snow falls (falling snow covers it faster). Min: 0.25 Max: 24.00 Default: 2.00
        FireThawHours = 2.0,
        -- Snow walked over again and again (players and zombies) becomes a trodden path that lasts much longer than footprints: you can see where a horde keeps walking. Counted from the footprints, so only with footprints on. In multiplayer each player can hide them for themselves in Options > Mods.
        TrampledPaths = true,
        -- Footprints on one square that make a path there (older ones count less, half after 3 game hours); the path gets darker with more. About 2 footprints a square each time someone walks through. Min: 3 Max: 100 Default: 12
        TrampledPathSteps = 12,
        -- Game hours a path lasts after the last walker, if no snow falls (falling snow covers it faster). Min: 1.00 Max: 336.00 Default: 48.00
        TrampledPathHours = 48.0,
        -- Only with the Immersive Snow - Viewpoint add-on: depth of the snow on the ground in Viewpoint's 3D view at the highest snow level, less while it is building up or melting. The snow also drifts deeper against buildings, steps run together into a trench and shovelled squares stand as cuttings; from 10 cm it slows you down (3D snow slows you down). Min: 5 Max: 100 Default: 35
        SnowDepth = 35,
        -- Only with the Immersive Snow - Viewpoint add-on (its 3D snow on the ground): from 10 cm of snow (Snow depth) wading through it tires you; no speed limits. Not on squares cleared with a shovel; on trampled paths it is easier. In MP the server decides.
        SnowSlowdown = true,
        -- Game hours of rain that wash a full cover of snow off the ground, in stages: the snow thins out, the prints and the depth go with it; heavy rain is twice as fast. 0: all at once at the next hour, as in vanilla. In MP the server decides. Min: 0.00 Max: 48.00 Default: 3.00
        RainWashHours = 3.0,
        -- Only in the 3D view of Viewpoint with the Immersive Snow - Viewpoint add-on: the snow on vehicles stands out as a layer where it settles on top (the roof, the bonnet: up to about 12 cm at the last stage at 100%); clothes, the vehicles' sides, ice and frost on the glass stay flat. 0: flat, as before. Min: 0 Max: 200 Default: 100
        SnowThickness3D = 100,
        -- Only in the 3D view of Viewpoint with the Immersive Snow - Viewpoint add-on: the snow on the ground has a depth (prints, ruts and furrows pressed into it). Off: the ground snow is flat, as Viewpoint lays it.
        Snow3DGround = true,
        -- Only in the 3D view of Viewpoint with the Immersive Snow - Viewpoint add-on: the snow on vehicles lies on top as a layer with a thickness (roof, bonnet, boot). Off: the snow on vehicles is flat, as in the isometric view.
        Snow3DVehicles = true,
    },
    UnseasonalWeather = {
        -- If false, this mod's unseasonal weather events are disabled.
        Enabled = true,
        -- Approximate chance per day for an unseasonal weather event to occur. Min: 0 Max: 100 Default: 25
        DailyEventChance = 25,
        -- Shortest possible duration of a single unseasonal weather event. Min: 1 Max: 48 Default: 3
        MinDuration = 3,
        -- Longest possible duration of a single unseasonal weather event. Min: 1 Max: 72 Default: 8
        MaxDuration = 8,
        -- Scales the strength of unseasonal weather events. 1.0 = default. Min: 0.20 Max: 3.00 Default: 1.00
        IntensityMultiplier = 1.0,
        -- If enabled, each winter day rolls against Daily event chance to decide whether hardcore winter temperatures apply that day. Default: off.
        HardcoreWinterTemps = false,
        -- If enabled, each summer day rolls against Daily event chance to decide whether hardcore summer temperatures apply that day. Default: off.
        HardcoreSummerTemps = false,
        -- If true, unseasonal weather events keep their temperature, wind, fog and cloud changes but do not generate rain or snow.
        DryEvents = false,
        -- Rain now increases wetness progressively. Prolonged high wetness amplifies cold damage indirectly; rain does not cause direct illness.
        EnhancedRainExposure = true,
        -- If enabled, a lit campfire, fireplace, antique oven or barbecue warms players anywhere in the same enclosed room as strongly as standing beside it. Heat does not spread to other rooms. Default: off.
        RoomWideIndoorHeat = false,
        PauseWhileDriving = true,
        -- If true, lightning strikes emit a strong world sound that attracts zombies like a global meta event. Default: off.
        LightningAttractsZombiesGlobal = false,
        -- If true, Unseasonal Weather uses its custom minute-precision clock UI. If false, it is disabled and the normal clock is used.
        ClockUIEnabled = true,
    },
    UW_RadioForecasting = {
        -- If false, all SPEC radio forecasts are disabled.
        Enabled = true,
        -- If true, schedules broadcasts between 20:00 and 23:00; otherwise between 08:00 and 11:00.
        UseNightWindow = false,
        -- If true, active walkies show subtle WX scanner readings (default: on).
        WalkieHints = true,
        -- If true, print broadcast text to console for verification.
        DebugLogging = false,
    },
    HereGoesTheSun = {
        EnableGodRays = true,
        EnableStormMood = true,
        -- Default = Recommended
        -- 1 = Soft
        -- 2 = Recommended
        -- 3 = Night of the Living Dead
        StormMoodPreset = 2,
    },
    NaturesCall = {
        -- Multiplier applied to bladder filling over time. Min: 0.10 Max: 5.00 Default: 1.00
        BladderRateMult = 1.0,
        -- Multiplier applied to bowel filling over time. Min: 0.10 Max: 5.00 Default: 1.00
        BowelRateMult = 1.0,
        -- Multiplier applied to chance-based accidents from fill pressure, overflow, and incontinence. Min: 0.10 Max: 5.00 Default: 1.00
        AccidentChanceMult = 1.0,
        -- Multiplier applied to how much is released and how harsh the consequences are for non-forced accidents. Min: 0.10 Max: 5.00 Default: 1.00
        AccidentSeverityMult = 1.0,
        -- Multiplier applied to wipe supply consumption when cleaning after relief and accidents. Min: 0.10 Max: 5.00 Default: 1.00
        WipeNeedMult = 1.0,
        -- Multiplier applied to relief and wiping action duration. Min: 0.10 Max: 5.00 Default: 1.00
        WipeDurationMult = 1.0,
        -- When checked, gut health stays at a constant neutral and your diet no longer causes cramps, diarrhea, constipation, heartburn or any other good/bad gut effects. Eating and drinking still track and fill your bladder and bowels, and you can still get sick from rotten or tainted food and normal vanilla food effects. Can be changed mid-game (single-player and multiplayer).
        DisableGutSystem = false,
        -- Multiplier applied to how quickly gut health improves or worsens from diet. Min: 0.10 Max: 5.00 Default: 1.00
        GutTrendMult = 1.0,
        -- Multiplier applied to the duration of stomach effects (cramps, heartburn, diarrhea, constipation, laxative, sugar/water/caffeine highs, binge fatigue) when they are triggered or extended. Lower values let effects wear off faster. Min: 0.10 Max: 5.00 Default: 1.00
        EffectDurationMult = 1.0,
        -- Multiplier applied to discomfort and unhappiness from wearing soiled clothing. Set to 0 to disable these penalties. Min: 0.00 Max: 5.00 Default: 1.00
        SmellPenaltyMult = 1.0,
        -- Multiplier applied to zombie attraction radius from player soilage, dropped soiled items, exposed waste, and foul toilets. Set to 0 to disable smell-based attraction. Min: 0.00 Max: 5.00 Default: 1.00
        ZombieSmellRangeMult = 1.0,
        -- Multiplier applied to unhappiness from using unflushed toilets and to nearby foul-toilet smell severity. Set to 0 to disable these penalties. Min: 0.00 Max: 5.00 Default: 1.00
        ToiletPenaltyMult = 1.0,
        -- Multiplier applied to trait modifiers such as fill rates, control, soilage penalties, and accident scaling. Min: 0.00 Max: 5.00 Default: 1.00
        TraitIntensityMult = 1.0,
        -- Minimum accumulated scale (servings) before a food category's per-hour effects (bowel rate, control, mood, sleepiness) start applying. Higher values mean you must eat more of a category in a short window before its effects engage. Default 1.0 means roughly 2-3 servings. Min: 0.50 Max: 3.00 Default: 1.00
        CategoryActivationThreshold = 1.0,
        -- How fast a food category's effect fades per game hour once you stop eating it. Higher means effects wear off quicker. Default 0.50: a heavy meal's effect lasts about 1-3 hours and a single snack fades in well under an hour. Min: 0.05 Max: 1.00 Default: 0.50
        CategoryScaleDecayPerHour = 0.5,
        -- Multiplier applied to the per-hour magnitude of active food category effects and binge penalties. Higher values make the effects hit harder while active. Default 1.5. Min: 0.50 Max: 3.00 Default: 1.50
        CategoryIntensityScale = 1.5,
    },
    WoundsOverhaul = {
        -- An untreated wound infection reaches the bloodstream and kills.
        -- Antibiotics work as a course over days, not as a single pill.
        -- Turned off, wound infection behaves as it does in vanilla.
        SepsisEnabled = true,
        -- How fast an infection takes hold and climbs. 1.0 is the balance the mod was built around: untreated, the first symptoms arrive after about twelve hours and it kills in roughly three days.
        -- Lower is milder. It never makes the body recover faster, only the illness slower. Min: 0.10 Max: 5.00 Default: 1.00
        SepsisSpeed = 1.0,
        -- How much cover it takes to beat an infection. 1.0 is 48 hours - three antibiotics back to back, the balance the mod was built around.
        -- Lower it on a world where medicine is scarce: 0.66 makes it a two-pill course, 0.33 a single one. Higher makes a cure a project.
        -- It does not change how fast the illness climbs - that is the sepsis speed setting. Min: 0.25 Max: 3.00 Default: 1.00
        AntibioticCourse = 1.0,
        -- A broken bone under an open wound worsens while unsplinted and feeds the infection.
        -- Arms and legs only.
        -- Also needs the Bone Fracture option enabled, or nothing can break in the first place.
        FractureEnabled = true,
        -- Ribs, a skull, a pelvis - the fractures a splint cannot reach. On: sitting down mends them measurably faster, running on them hurts, sets the bone back and drains you; painkillers dull it. Off: they heal on vanilla's flat timer, untouched by anything you do.
        AxialFractureEnabled = true,
        -- Taking more medicine than the body can clear makes you ill for far longer than the overdose itself lasts, and leaves a mark on the liver and kidneys.
        -- Alcohol on top of a course of medicine is much harder on the liver than alcohol alone.
        -- Water helps: a hydrated survivor clears an overdose about twice as fast, and healthy kidneys are what makes that work.
        -- Turned off, medicine behaves as it did before this was added - an overdose still makes you sick while it lasts, but nothing accumulates.
        PoisoningEnabled = true,
        -- Heavy bleeding leaves the survivor weak for days after the cut is dressed.
        BloodLossEnabled = true,
        -- A heavier survivor has more blood to lose: about 4.2 litres at 70 kg and under, 5 at 80, 5.8 at 90 and over. The same wound empties a light body faster, and the same bag of blood does less for a heavy one. Off: everybody has 5 litres, as before.
        BloodVolumeByWeight = false,
        -- Multiplies how fast lost blood comes back. 1.0 is the mod's own rate - about a day to rebuild a third of the body's blood when well fed. 2.0 is twice as fast, 0.5 half.
        -- Food and the healing traits still count on top. Min: 0.10 Max: 10.00 Default: 1.00
        BloodRegenRate = 1.0,
        -- Multiplies how fast a bleeding body loses blood. 1.0 is the mod's own rate - one untreated deep wound brings on the drain on health in about three and a half hours. 2.0 is twice as fast, 0.5 half.
        -- The stages stay where they are: going under, the drain on health and the end come at the same share of blood gone. Min: 0.10 Max: 10.00 Default: 1.00
        BloodLossRate = 1.0,
        -- Turns on the blood part of the mod: drawing blood, transfusion, blood groups, typing and crossmatching - and puts the supplies for it in hospital and clinic loot: blood collection bags (single-use, the only vessel blood goes into), a transfusion set and a blood typing kit.
        -- OFF by default. While off, none of it is offered and none of the items ever spawn - the mod stays pure Lua and can be removed at any time.
        -- Turning it on lets mod items into your save.
        MedicalItemsEnabled = false,
        -- Multiplies how often blood bags, transfusion sets and typing kits turn up in clinic and medical storage loot. 1.0 is the mod's own rate, 0.5 half as often, 2.0 twice - 0 removes them from loot entirely.
        -- Only matters while the switch above is on. Min: 0.00 Max: 5.00 Default: 1.00
        MedicalItemsRate = 1.0,
        -- How many in-game hours drawn blood stays usable while warm. Real blood banks allow 4; the default is 8 so a trip home is possible.
        -- A powered fridge stops the clock, a cooler slows it six times, winter air at 6 C or below keeps blood that is not being carried on a body.
        -- A freezer ruins whole blood. Min: 1.00 Max: 72.00 Default: 8.00
        BloodWarmHours = 8.0,
        -- On: with a needle and an empty bag you can draw blood from another player standing next to you, not only from yourself - the donor pays the blood loss. On a server that includes a player who is unconscious and cannot refuse, so turn it on only if you trust your players.
        -- Not yet tested in a multiplayer game.
        -- Off: everybody draws only from their own arm.
        DrawFromOthers = false,
        -- On: two things to do for a bleeding wound before the bandage. Press on it with your hand - a quarter of the blood loss while you hold it, hands busy. Tie a tourniquet high on an arm or leg with a belt, rope or strip of cloth - everything below stops bleeding, but past two hours the limb goes numb and past four the tissue starts dying.
        -- Off: neither option.
        BleedingFirstAidEnabled = true,
        -- On: a burn is 1st to 4th degree. 1st heals in a day and cannot get infected, 2nd blisters and needs a dressing, 3rd and 4th have dead tissue that barely heals and feeds infection until it is cut away. Burning longer burns deeper; an uncooled fresh burn may deepen within half an hour - cool it with water. Deep burns make you thirsty.
        -- Off: vanilla's single kind of burn.
        BurnDegreesEnabled = true,
        -- On: a bullet stops either in a joint - it has to come out before anything else - or deep in the tissue, where it stays: pack the wound and run antibiotics until the flesh closes over it. Gunshot wounds are packed, not stitched.
        -- Not yet tested in a multiplayer game.
        -- Off: bullets work exactly as in vanilla.
        GunshotWoundsEnabled = false,
        -- On: stitching opens a close-up of the wound and you place each stitch yourself - the needle goes in one side and out the other, and how well it is done is up to you. First Aid decides how steady your hand is; a surgical needle forgives more than a sewing one. A poor closure can tear open when you run.
        -- Off: stitching works exactly as it does in vanilla, decided by a dice roll behind the scenes.
        SutureGameEnabled = true,
        -- On: trimming a ragged wound opens a close-up where you cut the dead edge away yourself, with a scalpel or scissors. How clean the cut is decides how well the wound stitches afterwards and how much it hurts.
        -- Off: trimming is a plain timed action, as it was before the minigame.
        TrimGameEnabled = true,
        -- On: taking out a lodged bullet opens a close-up where you guide the tweezers in yourself. A shaky hand hurts and can slip.
        -- Off: the bullet comes out the vanilla way.
        ExtractGameEnabled = true,
        -- On: putting ointment on a burn opens a close-up where you take it out a dab at a time and rub it in yourself. Cover the whole burn, and go gently over blisters.
        -- Off: a plain timed action that covers most of the burn.
        OintmentGameEnabled = true,
        -- On: cutting the dead tissue off a third- or fourth-degree burn opens a close-up where you run the blade round each piece yourself. Off the edge it cuts live skin.
        -- Off: a plain timed action takes all of it off.
        DebrideGameEnabled = true,
        -- On: a third- or fourth-degree burn round an arm or a leg can tighten and kill the limb below unless the eschar is cut open; a debrided deep burn can be closed with skin from the thigh; a healed deep burn leaves a tight, aching scar for days. With The Only Cure a dead limb is amputated.
        -- Off: deep burns stop at cutting the dead tissue away.
        DeepBurnsEnabled = true,
        -- On: cutting a tight eschar open shows the burn, and you draw the blade down it yourself.
        -- Off: a plain timed action does it.
        EscharGameEnabled = true,
        -- On: a skin graft is three moves of your own - shaving a strip off the thigh in one even pass, laying it over the burn, then fixing it down at each mark with staples (or needle and thread).
        -- Off: a plain timed action does it.
        GraftGameEnabled = true,
        -- On: right-click a fresh body (three days at most) to practise on it - stitching, trimming wound edges, and taking out a bullet if one stayed in it when it was shot. Uses the same minigames, spends what the job spends, pays three quarters of the First Aid XP of the real thing. Three sessions of sewing and trimming per body.
        -- Each kind needs its own minigame on.
        CorpsePracticeEnabled = true,
        -- The body always shows where it hurts and how badly. This decides how much of the naming an examination has to do first - and First Aid decides how fast and how detailed that examination is.
        -- Everything: nothing is named until you look, treatment included.
        -- Only what you cannot feel: an injury you watched happen is named at once, and looking is for infection, dirt and how far it has got.
        -- Nothing: everything is named straight away, the way vanilla does it. Default = Everything
        -- 1 = Everything
        -- 2 = Only what you cannot feel
        -- 3 = Nothing
        RequireExamination = 1,
        -- How quickly an examination is carried out. Higher is faster.
        -- First Aid still shortens it on top of this. Min: 0.10 Max: 5.00 Default: 1.00
        ExamineSpeed = 1.0,
        -- On the strictest examination setting, a limb cannot be treated until it has been examined - you cannot bandage what you have not looked at.
        -- Turn this off to keep the naming behind an examination while letting first aid go ahead: you can dress a wound in a hurry and find out what it is later, somewhere safer.
        -- Has no effect on the other two examination settings, where nothing was held back to begin with.
        TreatmentNeedsExam = true,
        -- On: what the finding IS decides the time - a scratch is read at a glance, a laceration or a bite is real work. Two deep wounds' worth is a full examination.
        -- Off (the default): every examination takes the flat time set by skill and the speed slider, however much or little there is to find.
        ExamineScalesWithFindings = false,
        -- Below this First Aid level an examination roots the character in place. 0 allows walking from the start, 10 never.
        -- Legs, feet and groin always require standing still - that is anatomy, not skill. Min: 0 Max: 10 Default: 4
        WalkingExamSkill = 4,
        -- A bandaged limb shows only the bandage, a broken bone, and whether it hurts. The kind of wound, stitches and infection stay hidden until the dressing comes off.
        -- What was examined before is remembered: removing the bandage shows it without a new examination.
        -- Off: wounds read through the bandage as before.
        CoveredWoundsHidden = true,
        -- A cut throat empties a survivor in well under a minute, and an untrained character spends twelve seconds looking before they are allowed to touch it.
        -- On: the neck can be treated on sight, like vanilla.
        -- Off: it waits for an examination like every other limb.
        NeckSkipsExamination = true,
        -- Only matters with Mini Health Panel or Mini Health Plus installed. Their floating window offers treatment without an examination, which walks around this mod's central rule.
        -- On: their menu is held on an unexamined limb, same as this mod's own panel.
        -- Off: their panel stays a fast lane - on some servers a neck wound is a matter of seconds, and one screen too many before a bandage can be a death.
        GateMiniHealthPanel = true,
        -- BETA - turn on at your own risk. Not yet tested in a multiplayer game. Reloading does not get you up - a character who was out is out again. It cannot trap anybody: after six hours down they come round whatever happened, and turning this off stands them up.
        -- 
        -- On: after losing about a third of their blood the character goes down and the screen goes dark - they cannot move or act, and they are helpless where they fell. Once the bleeding is stopped another survivor can bring them round, which buys an hour on their feet but does not put blood back; only a transfusion or time does that.
        -- Bleed on past that and the heart can stop: then only chest compressions (which buy time) and a defibrillator (which starts it) help, and without them they die within half an hour.
        -- Alone, they come round on their own once the bleeding has been stopped long enough. Still bleeding, they come to for a few minutes - time to put a bandage on; left open, the wound puts them under again.
        -- Off: blood loss behaves exactly as it did before.
        UnconsciousEnabled = true,
        -- Multiplies the experience the mod's OWN work pays: examining a limb, trimming a laceration, drawing blood, crossmatching, running a transfusion. 1.0 is the mod's own rate, 0 pays nothing for them.
        -- Stitching and bandaging are the game's own awards and are left alone - move those with the world's XP multiplier. Min: 0.00 Max: 5.00 Default: 1.00
        XpRate = 1.0,
        -- Draws the wound close-ups - the examination panel and the stitching minigame - in a pixelated style that sits with the game's own look, instead of the drawn originals.
        -- The wounds, the aim marks and everything they do stay exactly the same; only the rendering changes.
        -- Off by default.
        PixelArt = false,
        -- Writes what the mod is doing to Zomboid/Lua/Wounds_debug.log, and on a server to Wounds_debug_server.log: every condition's numbers once an in-game minute, and what each of them asked for.
        -- For working out where health is going when nothing is visible on the panel. It does NOT enable any cheat.
        -- Off by default: the file grows and is never cleaned up.
        DebugLog = false,
    },
    PIW = {
        -- If disabled, the following features won't be active: 'Chance of wound infection', 'Wound infection strength', 'Dirty bandage safe wear time' and 'Wound infection damage modifier'.
        enableinfection = true,
        -- Changes chance of getting wound infection, default chance is 10/1000, updated every in-game minute after safe wear time. Min: 1 Max: 1000 Default: 11
        chanceofinfection = 11,
        -- Changes how potent do you want the wound infection to be. Min: 0.01 Max: 8.00 Default: 0.75
        infectionstrength = 0.75,
        -- Changes how long you can wear dirty bandage before you have chance to get wound infection (Measured with in-game minutes, on default settings 24 in-game minutes = 1 real minute). Min: 1 Max: 10000 Default: 240
        safetime = 240,
        -- Changes modifier of wound infection damage. Min: 0.00 Max: 1000.00 Default: 0.00
        infectiondamage = 0.0,
        -- Changes if wearing dirty bandages on wounds does damage.
        unsafedirtybandages = true,
        -- Changes modifier of dirty bandage damage. (Does nothing if 'Dirty bandages do damage' is disabled). Min: 0.00 Max: 1000.00 Default: 2.25
        dirtybandagesdamage = 2.25,
        -- Changes if you have reduced healing when you have infected wound (Beware: Indirectly increases damage).
        reducedhealingwhilewounded = true,
        -- Changes the percentage (ex. 0.3 = 30%) of default healing while you have wound infection (Does nothing if 'Infected wound reduces healing' is disabled). Min: 0.00 Max: 1.00 Default: 0.50
        reducedhealingwhilewoundedammount = 0.5,
        -- Enables getting sick from having wound infection.
        sicknessenabled = true,
        -- Changes the potency and speed of getting sick. Default = Low
        -- 1 = Very low
        -- 2 = Low
        -- 3 = Medium
        -- 4 = High
        -- 5 = Very high
        sicknessdificulty = 2,
        -- Changes how long you can have wound infection before starting to get sick (Measured with in-game minutes, on default settings 24 in-game minutes = 1 real minute). Min: 1 Max: 10000 Default: 270
        sicknesssafetime = 270,
    },
    PainkillersRemoveMuscleStrain = {
        -- Amount of stiffness/muscle strain removed from enabled body parts when taking painkillers (1-120). Min: 1 Max: 100 Default: 20
        strainRemoval = 20,
        -- Remove muscle strain from Right Hand when taking painkillers
        Hand_R = true,
        -- Remove muscle strain from Right Forearm when taking painkillers
        ForeArm_R = true,
        -- Remove muscle strain from Right Upper Arm when taking painkillers
        UpperArm_R = true,
        -- Remove muscle strain from Left Hand when taking painkillers
        Hand_L = true,
        -- Remove muscle strain from Left Forearm when taking painkillers
        ForeArm_L = true,
        -- Remove muscle strain from Left Upper Arm when taking painkillers
        UpperArm_L = true,
        -- Remove muscle strain from Head when taking painkillers
        Head = false,
        -- Remove muscle strain from Neck when taking painkillers
        Neck = false,
        -- Remove muscle strain from Upper Torso when taking painkillers
        Torso_Upper = false,
        -- Remove muscle strain from Lower Torso when taking painkillers
        Torso_Lower = false,
        -- Remove muscle strain from Groin when taking painkillers
        Groin = false,
        -- Remove muscle strain from Left Upper Leg when taking painkillers
        UpperLeg_L = false,
        -- Remove muscle strain from Left Lower Leg when taking painkillers
        LowerLeg_L = false,
        -- Remove muscle strain from Left Foot when taking painkillers
        Foot_L = false,
        -- Remove muscle strain from Right Upper Leg when taking painkillers
        UpperLeg_R = false,
        -- Remove muscle strain from Right Lower Leg when taking painkillers
        LowerLeg_R = false,
        -- Remove muscle strain from Right Foot when taking painkillers
        Foot_R = false,
    },
    TOC = {
        -- Min: 1 Max: 10 Default: 1
        CicatrizationSpeed = 1,
        -- Min: 0 Max: 5 Default: 1
        WoundDirtynessMultiplier = 1,
        -- Min: 1 Max: 3 Default: 2
        SurgeonAbilityImportance = 2,
        EnableZombieAmputations = false,
        -- Min: 0 Max: 10 Default: 1
        ZombieAmputationDamageThreshold = 1,
        -- Min: 0 Max: 100 Default: 25
        ZombieAmputationDamageChance = 25,
        -- Amputating while the Knox infection is below this percentage always cures it. Default 20. Min: 1 Max: 90 Default: 20
        CureWindow = 20,
        -- Between the cure window and this value the cure becomes a gamble that gets worse every hour. 0 disables the gamble. Min: 0 Max: 99 Default: 40
        LateGambleWindow = 40,
        -- Chills, sweat and fever messages as the infection advances. They are the only hint you get.
        ShowSymptoms = true,
        -- Right-click a bite or scratch in the health panel to get a (fallible) opinion. The Field Amputation Guide also allows it. Min: 0 Max: 10 Default: 2
        DiagnosisMinDoctor = 2,
        -- Off: you find out whether you were in time the hard way.
        RevealOutcome = false,
        -- Scales the chance of a rough or botched amputation. 0 makes every surgery clean. Min: 0.00 Max: 5.00 Default: 1.00
        SurgeryRiskMultiplier = 1.0,
        -- How far a patient without anaesthesia is heard. Zombies will come. Min: 0 Max: 80 Default: 25
        ScreamRadius = 25,
        -- How much sleeping pills can count towards anaesthesia during surgery, in percent (0 = they do not count). Painkillers count up to 60 and alcohol up to 50. Min: 0 Max: 50 Default: 30
        SleepingPillAnesthesia = 30,
        -- Extra stamina used while walking on a crutch, in percent of the default (100 = tired after about a minute of walking without rest, 0 = no extra cost). Min: 0 Max: 300 Default: 100
        CrutchStaminaDrain = 100,
        -- Extra stamina used while crawling, in percent of the default (100 = tired after about 40 seconds, 0 = no extra cost). Min: 0 Max: 300 Default: 100
        CrawlStaminaDrain = 100,
        -- Characters who start with a leg amputee trait already know how to use crutches: their crutch and crawling stamina cost is this percent of the values above (50 = half). Min: 0 Max: 100 Default: 50
        AmputeeTraitStaminaDrain = 50,
        -- Amputee traits do not appear in character creation. Characters that already have them keep them.
        HideAmputeeTraits = false,
        -- Lets a survivor cut off their own upper arm or thigh. Much more likely to fail or to faint halfway.
        SelfAmputationHigh = false,
        DropSeveredLimbs = true,
        -- Feet, lower legs and thighs can be amputated. Walking then needs a crutch or a prosthetic leg.
        EnableLegAmputations = true,
        -- A dirty stump gets infected (vanilla wound infection), causes fever and can kill. Clean it with alcohol and take antibiotics.
        SepsisEnabled = true,
        -- Min: 1 Max: 5 Default: 2
        SepsisSpeed = 2,
        -- Days of weakness, hunger and tiredness after an amputation. Min: 0 Max: 14 Default: 5
        ConvalescenceDays = 5,
        PhantomPain = true,
        CarryPenalty = true,
        -- Every action wears the prosthesis; repair it with glue, tape, welding rods or screws before it breaks.
        ProsthesisWear = true,
        -- Multiplies how fast prostheses wear out (1 = normal, 0.5 = half as fast, 2 = twice as fast). Also the chainsaw and bayonet. Min: 0.10 Max: 5.00 Default: 1.00
        ProsthesisWearMultiplier = 1.0,
        ZombieCrawlerOnLegHit = true,
    },
    ZombieVirusVaccineBETA = {
        -- <BHC>Do NOT change this. DEV ONLY. <RGB:1,1,1><LINE> Prints a hella lot of debug info in console.
        DebugMode = false,
        -- Completely enables or disables the spawning of Zombie Virus Vaccine items in the world.
        EnableWorldLoot = true,
        -- Defines how many chemical items from the mod appear in the world. Default = Default
        -- 1 = Disabled
        -- 2 = Low
        -- 3 = Default
        -- 4 = High
        LootChemicals = 3,
        -- Expands the loot table to include additional chemical products.
        ExpandChemicalsLoot = false,
        -- Enables or disables item spawning in vehicles.
        EnableVehicleLoot = true,
        -- Enables or disables item spawning in survivor backpacks.
        EnableBagsLoot = true,
        -- Defines how many syringes from the mod appear in the world. Default = Default
        -- 1 = Disabled
        -- 2 = Low
        -- 3 = Default
        -- 4 = High
        LootSyringes = 3,
        -- Defines how many laboratory equipment books appear in the world. Default = Default
        -- 1 = Disabled
        -- 2 = Low
        -- 3 = Default
        -- 4 = High
        LootEquipmentBooks = 3,
        -- Defines how many virology and chemistry books appear in the world. Default = Default
        -- 1 = Disabled
        -- 2 = Low
        -- 3 = Default
        -- 4 = High
        LootVirologyBooks = 3,
        -- Defines whether virology books spawn only in specific locations or are spread throughout the world. Default = Specific locations only
        -- 1 = Expand spawn locations
        -- 2 = Specific locations only
        -- 3 = Make them common
        VirologyBooksSpawnMode = 2,
        -- Enables or disables blood aging.  <LINE><BHC>It might cause heavy CPU usage for multiplayer servers. If so, consider disabling this feature.
        BloodAgingMode = true,
        -- 14 is the default value from the original mod. If issues occur, reduce this value or disable blood aging. Min: 5 Max: 21 Default: 14
        BloodAgingRadius = 14,
        -- Enable water purification through heat (stoves, microwaves, etc). If disabled, water purification will only be possible by using chlorine tablets. <LINE><BHC>It might cause heavy CPU usage for multiplayer servers. If so, consider disabling this feature.
        EnableWaterPurification = true,
        -- The radius within which flasks with water in containers will be searched for purification. Ticks onEveryTenMinutes. Min: 5 Max: 21 Default: 5
        WaterPurificationRadius = 5,
        -- Enables or disables the spawning of the light painting magazine. If disabled, players will not be able to learn how to paint lights.
        EnableLightPaints = true,
        -- If enabled, each time a player remove glasses from a broken window, it will give a shattered glass material<LINE><LINE>Even if it's off, players still can pick up the shattered glass from the ground.
        AllowWindowGlass = true,
        -- Allows players to perform autopsies directly on the ground, without the need for a table.
        AllowAutopsyOnGround = true,
        -- <BHC>Changing this option will affect game balance. <RGB:1,1,1><LINE> Defines how many ticks are required to complete an autopsy. Lower values = faster. Min: 800 Max: 1800 Default: 1200
        AutopsySpeed = 1200,
        -- The maximum number of hours before a corpse is considered too decomposed for an autopsy. Min: 2 Max: 72 Default: 12
        AutopsyMaxHours = 12,
        -- <BHC>Changing this option will affect game balance. <RGB:1,1,1><LINE> How many ticks are reduced from the autopsy time for each First Aid skill level. Min: 0 Max: 30 Default: 30
        TicksDecreasedByPerkLv = 30,
        -- <BHC>Changing this option will affect game balance. <RGB:1,1,1><LINE> Defines the speed bonus when performing an autopsy on an autopsy table. Default = 50%
        -- 1 = None
        -- 2 = 10%
        -- 3 = 20%
        -- 4 = 30%
        -- 5 = 40%
        -- 6 = 50%
        -- 7 = 60%
        TableSpeedBonus = 6,
        -- <BHC>Changing this option will affect game balance. <RGB:1,1,1><LINE> Amount of experience gained when performing an autopsy on the ground. Min: 0 Max: 15 Default: 15
        AutopsyGroundXP = 15,
        -- <BHC>Changing this option will affect game balance. <RGB:1,1,1><LINE> Amount of experience gained when performing an autopsy on a table. Min: 0 Max: 30 Default: 30
        AutopsyTableXP = 30,
        -- <BHC>Changing this option will affect game balance. <RGB:1,1,1><LINE> Defines the base XP gained in Butchering and First Aid skills. Min: 0 Max: 30 Default: 15
        CollectPartXP = 15,
        -- <BHC>Changing this option will affect game balance. <RGB:1,1,1><LINE> Defines the base chance of collecting a brain in perfect condition. Min: 0 Max: 15 Default: 10
        BrainHighOffset = 10,
        -- Defines the hemophobia penalty applied when a character with the Hemophobic trait performs an autopsy.<LINE> Affects the chance of obtaining a brain in perfect condition. Min: 0 Max: 30 Default: 10
        HemophobicDebuff = 10,
        -- If enabled, scalpels will degrade and break with use.
        AllowScalpelDegrade = false,
        -- If enabled, saws will degrade and break with use.
        AllowSawDegrade = true,
        -- Allows players to place corpses in a composter to produce fertilizer
        AllowBodyCompostage = true,
        -- Enables/Disables Lab Inter Profession Starting Kit <LINE><LINE> While unchecked Lab Intern Profession won't start with research files
        StartingKit = true,
    },
    TrueSmoking = {
        -- Global burn speed for ALL smokables
        -- 25 = lasts forever · 100 = balanced · 200 = burns very fast Min: 0.10 Max: 3.00 Default: 1.00
        SmokingSpeed = 1.0,
        -- How strong each puff feels (nicotine hit + stress/boredom relief)
        -- 50 = weak puffs · 100 = normal · 200 = very strong Min: 0.00 Max: 3.00 Default: 1.00
        PuffStrength = 1.0,
        -- How much faster the smoke burns when walking, running or sprinting
        -- 25 = barely burns while moving · 100 = normal · 200 = burns fast when active Min: 0.00 Max: 3.00 Default: 1.00
        MovementBurn = 1.0,
        -- How quickly the cigarette goes out when standing still
        -- 0 = never goes out (always stays lit)
        -- 100 = goes out normally (needs relighting) Min: 0.00 Max: 3.00 Default: 1.00
        IdleBurnOut = 1.0,
        -- Multiplies all effects from smoking (nicotine, stress relief, boredom relief, etc.)
        -- 50 = half effects · 100 = normal · 200 = double effects Min: 0.10 Max: 3.00 Default: 1.00
        EffectMultiplier = 1.0,
        -- How much smoking reduces hunger
        -- 0 = no hunger reduction · 0.25 = subtle (default) · 1.0 = vanilla strength · 2.0 = double Min: 0.00 Max: 2.00 Default: 0.25
        HungerReduction = 0.25,
        -- How much smoking reduces fatigue
        -- 0 = no fatigue reduction · 0.25 = subtle (default) · 1.0 = vanilla strength · 2.0 = double Min: 0.00 Max: 2.00 Default: 0.25
        FatigueReduction = 0.25,
        -- Automatically lowers shemaghs, gas masks, etc. when smoking and re-equips them after
        ManageHeadGear = true,
        -- If the ember gets too weak, you can relight it instead of it dying completely
        SmokeRelighting = true,
        -- Enables the new smoking moodle which better reflects nicotine levels and withdrawal
        UseNewMoodle = true,
        -- Enable chance to cough when taking a puff
        Coughing = true,
        -- Chance (%) to cough per puff if player has the Smoker trait Min: 0 Max: 100 Default: 4
        CoughingChanceSmoker = 4,
        -- Chance (%) to cough per puff if player does NOT have the Smoker trait Min: 0 Max: 100 Default: 15
        CoughingChanceNonSmoker = 15,
        -- Chance to drop your lit cigarette when falling, climbing, or hit by zombies
        Dropping = true,
        -- Drop chance (%) if player has the Smoker trait Min: 0 Max: 100 Default: 6
        DropChanceSmoker = 6,
        -- Drop chance (%) if player does NOT have the Smoker trait (much clumsier!) Min: 0 Max: 100 Default: 35
        DropChanceNonSmoker = 35,
        -- Turns on nicotine tracking, withdrawal effects, and dynamic addiction
        UseNicotineSystem = true,
        -- Players can gain or lose the Smoker trait based on smoking habits
        DynamicSmokerTrait = true,
        -- How many in-game days of heavy smoking until player gains the Smoker trait Min: 1 Max: 60 Default: 10
        DaysToAddiction = 10,
        -- How many in-game days without smoking until player loses the Smoker trait Min: 3 Max: 90 Default: 30
        DaysToDetox = 30,
        -- How many in-game days it takes to reach peak withdrawal symptoms after quitting Min: 1 Max: 7 Default: 2
        DaysToPeakWithdrawal = 2,
        -- How quickly addiction and withdrawal decrease when player has the Smoker trait
        -- Higher = faster decay Min: 0.10 Max: 1.00 Default: 0.80
        SmokerTraitDecayMultiplier = 0.8,
        -- Enable debug logging and debug UI panel (for mod developers and troubleshooting)
        DebugMode = false,
    },
    NnC = {
        -- How often narcotics appear in world containers.
        -- REBOOT NEEDED AFTER CHANGE Default = Uncommon
        -- 1 = Rare
        -- 2 = Uncommon
        -- 3 = Common
        -- 4 = Abundant
        Narcotics = 2,
        -- How often narcotics appear in vehicle containers.
        -- REBOOT NEEDED AFTER CHANGE Default = Uncommon
        -- 1 = Rare
        -- 2 = Uncommon
        -- 3 = Common
        -- 4 = Abundant
        NarcoticsCar = 2,
        -- How often narcotics are carried by zombies.
        -- REBOOT NEEDED AFTER CHANGE Default = Uncommon
        -- 1 = Rare
        -- 2 = Uncommon
        -- 3 = Common
        -- 4 = Abundant
        NarcoticsZombie = 2,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnBenzos = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnOpioids = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnPsychedelics = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnWeed = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnStimulants = true,
        -- If disabled, this category of drugs will not spawn in the world, on zombies, or in vehicles.
        -- REBOOT NEEDED AFTER CHANGE
        SpawnSteroids = true,
        -- Indicates if you want the player to spawn in with drugs, if they have a drug trait. Example: Coke Head trait has you spawn in with Cocaine.
        -- REBOOT NEEDED AFTER CHANGE
        PlayerDrugSpawn = true,
        -- REBOOT NEEDED AFTER CHANGE
        ScreenEffects = true,
        -- Prints one group of the mod's internal counters to the console every ten in-game minutes. For troubleshooting; leave Off for normal play.
        -- REBOOT NEEDED AFTER CHANGE Default = Off
        -- 1 = Off
        -- 2 = Addiction counters
        -- 3 = Active effect counters
        -- 4 = Overdose counters
        DevPrint = 1,
    },
    NepWrecks = {
        -- Vanilla default is 10, which is an entire welding torch. Min: 0 Max: 100 Default: 10
        FuelUsed = 10,
        -- If disabled you can use Safety Squints instead of a welding mask
        NeedMask = true,
        -- Mutliplies the amount of items created by salvaging Min: 0.00 Max: 100.00 Default: 1.00
        LootMult = 1.0,
        -- Prints additional debugging data to console
        DebugMode = false,
    },
    PushVehicle = {
        AllowSidePushing = true,
        -- Min: 0.00 Max: 10.00 Default: 1.00
        StaminaCostMultiplier = 1.0,
        -- Min: 0.00 Max: 10.00 Default: 1.00
        PushCooldownSeconds = 1.0,
        -- Min: 0 Max: 100000 Default: 0
        MaximumPushableWeight = 0,
    },
    AutomaticRefueling = {
        -- How much liters of fuel the pump will provide per ingame minute Min: 1 Max: 100 Default: 10
        LitersPerMinute = 10,
        -- The maximum distance a vehicle can move away from the pump, before it cuts off Min: 1 Max: 50 Default: 5
        MaxDistance = 5,
        -- Whether to remove the original pump-refuel and tsarslib option where you have to wait by the car
        RemoveOriginalOptions = true,
        -- Whether a pump can be damaged by driving off without having stopped the refuel process
        CanPumpBeDamaged = true,
        -- Whether a damaged pump can be repaired. Only relevant if "Pumps can be damaged" is enabled
        CanPumpBeRepaired = true,
        -- How many seconds in real-time it takes to repair a damaged pump. Only relevant if "Pumps can be damaged" is enabled Min: 1 Max: 60 Default: 5
        PumpRepairDuration = 5,
        -- The tile-radius in which the fuel pump sound will attract zombies (0 disables the sound) Min: 0 Max: 200 Default: 20
        PumpSoundRadius = 20,
    },
    GasPumpIndicator = {
        -- Adds the pump's remaining fuel to its right-click menu.
        -- Vanilla shows this number in debug mode only.
        ShowFuelAmount = false,
    },
    FCW = {
        RequireElectricity = true,
    },
    workingSeatbelt = {
        -- Min: 0 Max: 100 Default: 50
        seatbeltDamageReduction = 50,
        -- Min: 0 Max: 100 Default: 50
        seatbeltFractureReduction = 50,
        seatbeltCausesChestFracture = true,
        -- Min: 0 Max: 100 Default: 50
        chanceChestFracture = 50,
        -- Min: 0 Max: 100 Default: 60
        chestFractureMinimumCrashStrength = 60,
        -- Min: 0 Max: 100 Default: 3
        chestFractureTime = 3,
        exitVehicleAutoUnfasten = true,
        switchSeatAutoUnfasten = true,
        seatbeltWarningIndicator = true,
        seatbeltWarningChime = true,
        playersToggleChime = true,
        -- Min: 0 Max: 100 Default: 15
        chimeMinimumSpeed = 15,
        airbagModule = true,
        loreFriendlyAirbags = true,
        -- Min: 0 Max: 100 Default: 50
        airbagMinimumCrashStrength = 50,
        -- Min: 0 Max: 100 Default: 50
        airbagDamageReduction = 50,
        -- Min: 0 Max: 100 Default: 50
        airbagFractureReduction = 50,
        airbagsAffectedByCondition = true,
        airbagDeploymentAlert = false,
        canPlayerBeEjected = false,
        -- Min: 0 Max: 100 Default: 65
        ejectMinimumCrashStrength = 65,
        -- Min: 0 Max: 100 Default: 85
        ejectDamage = 85,
    },
    MHP = {
        -- Adds the 'Replace Bandage' context-menu entry for dirty bandages.
        EnableReplaceBandage = true,
        -- Shows the blue indicator when a bandage or splint can be removed safely.
        ShowSafeRemoveIndicator = true,
        -- Shows the purple indicator when stitched wounds should be checked.
        ShowStitchInspectIndicator = true,
    },
    NeatLockpicking = {
        -- When off, vehicles use the vanilla hotwire action instead of the wire minigame.
        EnableHotwire = true,
        -- When on, locked windows can be opened with a lockpick, same as with a crowbar.
        EnableWindowLockpick = false,
        -- Min: 3 Max: 10 Default: 6
        PinCount = 6,
        -- Min: 0 Max: 100 Default: 50
        BreakChanceAtZeroSkill = 50,
        -- Min: 0 Max: 100 Default: 5
        BreakChanceMinimum = 5,
        NoiseOnFail = true,
        ResetPinsOnBreak = true,
        -- Min: 0.10 Max: 5.00 Default: 1.00
        BrokenLockpickDuration = 1.0,
        -- Min: 1 Max: 10 Default: 4
        RandomPinCountMin = 4,
        -- Min: 1 Max: 10 Default: 7
        RandomPinCountMax = 7,
        -- Min: 3 Max: 10 Default: 8
        ReinforcedDoorPinCount = 8,
        -- Degrees per second for the crowbar minigame on normal doors and windows. Default 180. Min: 90 Max: 900 Default: 180
        NormalDoorArrowSpeed = 180,
        -- Degrees per second for the crowbar minigame on security doors. Default 360. Min: 180 Max: 1800 Default: 360
        ReinforcedDoorArrowSpeed = 360,
        -- When on, a hit on a security door reverses the arrow direction.
        ReinforcedReverseArrowOnHit = true,
        -- Progress added per yellow-zone hit on security doors. Default 10%. Min: 1 Max: 100 Default: 10
        ReinforcedYellowHitValue = 10,
        -- Progress added per green-zone hit on security doors. Default 20%. Min: 1 Max: 100 Default: 20
        ReinforcedGreenHitValue = 20,
        -- When on, crowbar minigame progress slowly drops if you wait.
        CrowbarProgressDecayEnabled = true,
        -- Seconds between each decay tick. Default 2. Min: 0.50 Max: 10.00 Default: 2.00
        CrowbarProgressDecayInterval = 2.0,
        -- Progress removed each decay tick. Default 1%. Min: 1 Max: 10 Default: 1
        CrowbarProgressDecayAmount = 1,
        -- Multiplier on endurance lost per crowbar swing. Default 0.5 (half of the old drain). 1.0 is the previous rate. Min: 0.10 Max: 3.00 Default: 0.50
        CrowbarExhaustionMultiplier = 0.5,
        -- When on, pins bind after about 50% lift. The first pin in the sequence is stiffest. Off by default.
        PinResistanceEnabled = false,
    },
    NeatCrafting = {
        -- When enabled, Neat Crafting uses ingredients and tools directly from accessible containers instead of transferring them to the character's main inventory first. This differs from vanilla Crafting behavior and can make some crafting actions faster. Default: Off.
        CraftDirectFromAccessibleContainers = false,
    },
    CHStatusHUD = {
        -- Off by default: every player decides for themselves which stats their HUD shows, and the options below do nothing. Turn this on to enforce the list below for everyone on the server - stats you disallow cannot be switched back on by the player.
        RestrictStats = false,
        -- The right-click Verify menu reads every stat directly, including ones locked or hidden by the server, which some hardcore admins would rather players not see. Uncheck to remove it from every player's right-click menu entirely.
        AllowVerifyTool = false,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Health from every player's HUD.
        AllowHealth = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Food from every player's HUD.
        AllowFood = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Water from every player's HUD.
        AllowWater = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Rest from every player's HUD.
        AllowRest = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Endurance from every player's HUD.
        AllowEndurance = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Fitness from every player's HUD.
        AllowFitness = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Stress from every player's HUD.
        AllowStress = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Panic from every player's HUD.
        AllowPanic = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Pain from every player's HUD.
        AllowPain = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Unhappy from every player's HUD.
        AllowUnhappy = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Boredom from every player's HUD.
        AllowBoredom = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Body Temperature from every player's HUD.
        AllowBodyTemp = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Anger from every player's HUD.
        AllowAnger = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Morale from every player's HUD.
        AllowMorale = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Nicotine Withdrawal from every player's HUD.
        AllowNicotine = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Idleness from every player's HUD.
        AllowIdleness = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Sanity from every player's HUD.
        AllowSanity = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Body Heat Generation from every player's HUD.
        AllowHeatGen = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Wetness from every player's HUD.
        AllowWetness = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Discomfort from every player's HUD.
        AllowDiscomfort = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Food Sickness from every player's HUD.
        AllowFoodSickness = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Poison from every player's HUD.
        AllowPoison = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Sickness from every player's HUD.
        AllowSickness = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Infection from every player's HUD.
        AllowInfection = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Fever from every player's HUD.
        AllowFever = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Drunk from every player's HUD.
        AllowDrunk = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Carry Weight from every player's HUD.
        AllowCarry = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Body Weight from every player's HUD.
        AllowBodyWeight = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Calories from every player's HUD.
        AllowCalories = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Proteins from every player's HUD.
        AllowProteins = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Carbs from every player's HUD.
        AllowCarbs = true,
        -- Only has any effect while 'Restrict which stats players can see' is on. Uncheck to hide Fat from every player's HUD.
        AllowLipids = true,
        -- Players can opt in to tick marks on the gauge showing where a stat's next moodle level kicks in (e.g. Peckish/Hungry/Starving on Food). Uncheck to hide this option from every player, e.g. on a hardcore server where exact thresholds should stay hidden.
        AllowThresholdTicks = true,
    },
    BetterContainers = {
        -- Enables the Proximity Inventory system for this server.
        ProximityEnabled = true,
        -- Forces Proximity Inventory to operate in corpse-only mode. Players cannot switch modes.
        ForceCorpseOnly = false,
        -- Allows players to enable or disable Proximity Inventory via keybind or mod options.
        AllowToggleProximity = true,
        -- Allows players to switch between all-containers mode and corpse-only mode.
        AllowSwitchMode = true,
        -- Enables the Auto-Lock feature. When active, Proximity Inventory will snap back to the selected container unless intentionally changed.
        AutoLockEnabled = true,
        -- Allows players to enable or disable Auto-Lock via mod options.
        AllowToggleAutoLock = true,
    },
    EnteBaseAutosorter = {
        -- Cheat. Players can turn on Teleport in the mod options. The character then skips the walk and appears next to a tagged container or a vehicle on the same floor.
        AllowTeleport = false,
    },
    WhoseKeyIsThis = {
        -- On by default. Shows the name of a key lying on the ground nearby, above the key itself. When off, it is not shown even if a player has it enabled in their own mod options.
        AllowGroundKeys = true,
        -- On by default. When a key ring marked to be followed leaves a player's inventory - most often on the body they left behind - the last place it was seen is marked until it is picked up again. It is also what puts the key ring tab in the map's key list. When off, no player follows rings and no tab appears, however they have their own mod options set.
        TrackLostKeyRings = true,
        -- On by default. Multiplayer only. Following stops the moment another survivor takes the key ring out of your body and into their own pockets. Off, and the mark follows them instead. Dragging your body about or loading it into a car is not taking your ring, so the mark stays either way.
        StopWhenTaken = true,
        -- On by default. Multiplayer only, and only when "Stop following once another survivor takes it" above is on. Following stops once somebody moves the body well away from where it fell - dragged, loaded into a vehicle or stored in a container - even though the ring was never taken out of it. Off, and the mark follows the body wherever it goes. Shifting it out of a doorway is not enough to stop anything.
        MovedBodyCountsAsTaken = true,
        -- On by default. Multiplayer only. Someone who picks up a ring carrying another survivor's mark gets a right-click option to switch that mark off, which stops the follow on the other end too. Off, and the mark is not theirs to touch.
        TakerCanStop = true,
        -- Off by default, since it is a lot to ask in singleplayer. When on, distances, the map jump and the direction pointer only work while you carry a compass. Independent of the other rules. Renaming keys always works.
        RequireCompass = false,
        -- Off by default. When on, a key's location is only readable if you carry a paper map covering that spot - but once you have read a key's location it stays readable, map or not. Independent of the other rules.
        RequireMapItem = false,
        -- On by default. A key only shows its location if that part of the world map has already been uncovered - by walking there, or by a map you have read. Keys pointing into the blank stay hidden until you find the place. Independent of the other rules.
        RequireExplored = false,
        -- Off by default. When on, the key list still says what a key opens and the arrow still leads you there, but the place name and the coordinates are held back until you have opened that lock with it once. Follow the key, use it, and the address is written on it from then on.
        HidePlaceUntilUsed = false,
    },
    CyesPushDoors = {
        -- Scales damage dealt to zombies.
        -- 0 disables damage but keeps other effects. Default: 1.0. Min: 0.00 Max: 2.00 Default: 1.00
        ZombieDamageMultiplier = 1.0,
        -- Scales targets per regular impact for all supported doors.
        -- Forced opening always affects its entire eligible crowd; sliding glass doors remain capped at 3. Min: 0.25 Max: 2.00 Default: 1.00
        ZombiesAffectedMultiplier = 1.0,
        -- Scales how many eligible zombies a character can push through before an entrance blocks.
        -- It also changes the pressure used to calculate regular and forced door wear. Garages are excluded. Default: 1.0. Min: 0.50 Max: 2.00 Default: 1.00
        DoorBlockCapacityMultiplier = 1.0,
        -- Chance for a selected eligible zombie to fall during regular, closing, or forced impacts; otherwise it staggers.
        -- Arm strain can reduce it. Sliding glass doors never knock zombies down. Default: 35%. Min: 0 Max: 100 Default: 35
        ZombieKnockdownChance = 35,
        -- Scales every durability loss caused by Push Doors!.
        -- 0 disables regular, forced, and garage wear, including random garage failure. Default: 1.0. Min: 0.00 Max: 3.00 Default: 1.00
        DoorWearMultiplier = 1.0,
        -- Extra wear multiplier for successful forced openings.
        -- Stacks with Door Wear; 0 disables only forced-opening wear. Default: 1.0. Min: 0.00 Max: 3.00 Default: 1.00
        ForcedOpeningDoorWearMultiplier = 1.0,
        -- Extra wear multiplier for garage doors.
        -- Stacks with Door Wear. Default: 1.0. Min: 0.25 Max: 3.00 Default: 1.00
        GarageDoorWearMultiplier = 1.0,
        -- Scales garage failure from Strength and existing damage while Door Wear is above 0.
        -- 0 disables random failure, not normal wear. Default: 1.0. Min: 0.00 Max: 3.00 Default: 1.00
        GarageFailureChanceMultiplier = 1.0,
        -- Scales vanilla Endurance consumed by successful CPD impacts.
        -- 0 disables CPD drain; current Endurance still affects CPD. Default: 1.0. Min: 0.00 Max: 3.00 Default: 1.00
        EnduranceCostMultiplier = 1.0,
        -- Scales the normal chance of fracturing one healthy part of the selected arm: hand, forearm, or upper arm.
        -- At critical endurance, with both arms already at the strain limit, or when the selected arm reaches the limit after the action, fracture risk is always 100%. Default: 1.0. Min: 0.00 Max: 2.00 Default: 1.00
        ForcedOpeningFractureRiskMultiplier = 1.0,
        -- Scales strain added to both arms by regular successful impacts and to the selected arm during forced opening.
        -- It also applies before garage-specific strain. Min: 0.00 Max: 3.00 Default: 1.00
        ArmStrainGainMultiplier = 1.0,
        -- Scales the 20.00 limit and every penalty threshold.
        -- Both arms at the limit block CPD effects. Default: 1.0. Min: 0.25 Max: 5.00 Default: 1.00
        ArmStrainUsageLimitMultiplier = 1.0,
        -- Extra strain multiplier for garage impacts.
        -- Stacks with Arm Strain Gain. Default: 1.0. Min: 0.25 Max: 3.00 Default: 1.00
        GarageArmStrainMultiplier = 1.0,
        -- Scales how arm strain reduces damage and knockdown chance.
        -- Default: 1.0. Min: 0.00 Max: 2.00 Default: 1.00
        ArmStrainPenaltyMultiplier = 1.0,
        -- Scales the anti-spam recovery between CPD impacts: 1.60s at 0-4.99 arm strain, 2.00s light, and 2.50s medium/high.
        -- Low Endurance can add extra recovery time. Default: 1.0. Min: 0.25 Max: 3.00 Default: 1.00
        ArmStrainRecoveryMultiplier = 1.0,
        -- Allows impacts to damage other valid PvP players. On normal doors, fence gates, and double entrances, a stronger target blocks the regular interaction but can be hit through forced opening. Sliding and garage doors do not use the player Strength block.
        DamagePlayers = true,
        -- Allows eligible door impacts to knock down other valid PvP players. Regular impacts use Player Knockdown Chance; forced opening has a 100% knockdown chance across its two-square impact band.
        KnockDownPlayers = true,
        -- Maximum chance for regular impacts after comparing Strength and Fitness.
        -- Winning one stat halves it; winning neither sets it to 0. Forced opening uses 100% while Knock Down Players is enabled. Default: 25%. Min: 0 Max: 100 Default: 25
        PlayerKnockdownChance = 25,
        -- Allows door impacts to damage and stun crawling zombies.
        AffectCrawlers = true,
        -- Allows doors, fences, and double doors to apply mod effects from either side.
        -- Disabled by default. Garages and sliding doors are unaffected.
        AllowImpactsFromBothSides = false,
        -- In MP, locks each player's personal feedback controls and enforces Global Impact Feedback.
        -- The forced-opening shortcut remains available.
        HideIndividualOptions = false,
        -- When personal feedback controls are locked, controls messages, custom animations, and sound effects for everyone.
        GlobalImpactFeedback = true,
    },
    ExerciseWithCorpses = {
        -- Check to enable, uncheck to disable
        scaleBool = false,
        -- Check to enable, uncheck to disable
        haloTextBool = true,
        -- Integer Value Only Min: 1 Max: 10 Default: 4
        exerciseStrXP = 4,
        -- Integer Value Only Min: 1 Max: 10 Default: 4
        exerciseFitXP = 4,
    },
    LGWalkieTalkies = {
        -- How fast a radio you carry uses its battery. 100 is the normal rate, 50 makes a battery last twice as long, 0 means it never runs down. Min: 0 Max: 100 Default: 100
        BatteryUsagePercent = 100,
    },
    SprintDiveWindows = {
        -- Chance to botch the dive and hit the floor instead of landing on your feet. 0 means you never wipe out, 100 means you always do. Min: 0 Max: 100 Default: 30
        FailChance = 30,
        -- Chance to get cut by the glass when diving through a window. The chance of botching the dive itself is handled by the game's own vault over fence rules. Min: 0 Max: 100 Default: 60
        InjuryChance = 60,
        -- How long you must sprint before a dive is allowed. Higher means you need a longer run up. Min: 0 Max: 120 Default: 30
        MinSprintTime = 30,
        -- When you hit a window without enough of a run up, break the glass and risk getting cut. Turn this off to just bounce off the intact window, taking no injury.
        ShortSprintBreaksGlass = true,
        -- Play the game's normal sprint vault animation instead of the custom window smashing dive.
        VanillaAnimation = false,
        -- Prints debug messages to the console.
        Debug = false,
    },
    ImmersiveSuicide = {
        -- When checked, player will always become a zombie after suicide, even if not infected.
        ForceZombification = false,
        -- Do you want a suicide confirmation popup to appear before performing a suicide?
        ShowConfirmationModal = true,
    },
    TrueSleep = {
        -- How much faster a solo napper rests compared to world time. 7 means a full night of rest fits into roughly one in-game hour. Min: 1.00 Max: 60.00 Default: 14.00
        SleepSpeed = 14.0,
        -- Solo naps cannot reduce fatigue below this remainder. Full rest is reserved for a proper night when everyone sleeps. Min: 0 Max: 90 Default: 15
        NapFloorPercent = 15,
        -- The server keeps restoring sleepers at normal speed on its own. With this on, Solo nap speed means the total rest speed instead of stacking on top of vanilla.
        CompensateVanilla = true,
        -- Min: 0.00 Max: 10.00 Default: 1.00
        EnduranceMult = 1.0,
        -- Automatically wake a solo napper once they hit the nap limit.
        WakeWhenRested = true,
        -- Small 'Sleeping 2/4' indicator with go-to-bed notifications.
        ShowHud = true,
        -- Min: 0.10 Max: 2.00 Default: 0.60
        FloorMult = 0.6,
        -- Min: 0.10 Max: 2.00 Default: 0.90
        BadBedMult = 0.9,
        -- Min: 0.10 Max: 2.00 Default: 1.00
        AverageBedMult = 1.0,
        -- Min: 0.10 Max: 2.00 Default: 1.10
        GoodBedMult = 1.1,
        -- Min: 0.00 Max: 0.50 Default: 0.05
        PillowBonus = 0.05,
    },
    TWF_QoL = {
        -- When enabled, wild crops found through foraging still give the food item, but the automatically generated extra seed items are ignored.
        -- Multiplayer: controlled by the server and applied authoritatively.
        -- Singleplayer: Mod Options override this Sandbox setting.
        ForagingIgnoreCollateralSeeds = false,
    },
    TWF_Resting = {
        -- Allows players to enable the Resting status HUD through Mod Options.
        -- Default: disabled.
        -- Enable this only in worlds or servers where the HUD is allowed.
        AllowStatusHUD = false,
    },
    DGMC_Cleaning_Wipes = {
        -- Whether you can clean your body with cleaning wipes.
        Clean_Body = true,
        -- Whether you can clean clothing with cleaning wipes.
        Clean_Clothing = true,
        -- Whether you can clean melee weapons with cleaning wipes.
        Clean_Weapons = true,
        -- Whether to remove makeup when cleaning your body.
        Remove_Makeup = true,
        -- How long it takes to clean with wipes, relative to washing with water only.  Lower for faster, higher for slower. Min: 0.00 Max: 10.00 Default: 1.00
        Speed_Mult = 1.0,
        -- When cleaning clothes, their wetness level will be set to a maximum of this value or its current level.  For example with the default value, clothes at 0 wetness would be set to 25, while clothes already at 50 wetness would stay at 50. Min: 0 Max: 100 Default: 25
        Wetness = 25,
        Debug_Logging = false,
    },
    DGMC_Bolt_Cutters = {
        -- whether the lock on garage doors can be cut open
        Allow_Garage_Doors = true,
        -- whether the lock on fence gates can be cut open
        Allow_Fence_Gates = true,
        -- whether bolt cutters can be used to destroy fence sections
        Allow_Fences = true,
        -- the percentage chance to drop a resource when destroying a fence section, 0 to disable Min: 0 Max: 100 Default: 0
        Fence_Wire_Chance = 0,
        -- whether the lock on security shutters over doors and windows can be cut open, the shutters will be destroyed
        Allow_Shutters = true,
        -- a character must have at least this level of strength to perform easy actions, like cutting thin wire fences Min: 0 Max: 10 Default: 3
        Easy_Strength_Req = 3,
        -- a character must have at least this level of strength to perform moderate actions, like cutting locks Min: 0 Max: 10 Default: 5
        Medium_Strength_Req = 5,
        -- a character must have at least this level of strength to perform challenging actions, like cutting thick fences Min: 0 Max: 10 Default: 7
        Hard_Strength_Req = 7,
        -- how many seconds it will take, before strength is factored in Min: 0 Max: 60 Default: 22
        Base_Duration = 22,
        -- how much muscle strain will be applied, before strength is factored in Min: 0.00 Max: 40.00 Default: 4.00
        Base_Muscle_Strain = 4.0,
        Debug_Logging = false,
    },
    TrueWeight = {
        -- If enabled, applies the mod creator's custom weight values. <LINE>Player custom sandbox settings above will ALWAYS override the preset if modified.
        UseModPreset = true,
        -- Multiplies the weight of ALL items in the game. <LINE>This calculation is applied AFTER any custom lists, sandbox categories, or mod presets. Min: 0.00 Max: 256.00 Default: 1.00
        GeneralMultiplier = 1.0,
        -- Format: ItemID:Weight;ItemID:Weight <LINE>(e.g., Nails:0.001;DuctTape:0.1)
        CustomWeights = "Key1:0;Key_Blank:0;KeyPadlock:0;CarKey:0;WalkieTalkie1:0.1;WalkieTalkie2:0.1;WalkieTalkie3:0.1;WalkieTalkie4:0.1;WalkieTalkie5:0.1;WalkieTalkieMakeShift:0.1;Padlock:0;CombinationPadlock:0;WalkieTalkie1_Electric:0.1;WalkieTalkie2_Electric:0.1;WalkieTalkie3_Electric:0.1;WalkieTalkie4_Electric:0.1;WalkieTalkie5_Electric:0.1;WalkieTalkieMakeShift_Electric:0.1",
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Accessory = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Ammo = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Animal = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        AnimalPart = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        AnimalPartWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Animals = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Appearance = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Armor = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Assembly = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Badger = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Bag = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Bandage = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Barricades = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Bear = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Beaver = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Blacksmithing = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Blade = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        BrokenWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Bug = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Bunny = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        CDs = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Camping = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Carpentry = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Cartography = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Carving = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Clothing = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Communications = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Container = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Cooking = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        CookingWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Cookware = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Corpse = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Debug = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Dog = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Duck = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Ears = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Electrical = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Electronics = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Entertainment = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Explosives = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Eye = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Farming = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        FireSource = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Firearm = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        FirstAid = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        FirstAidWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Fishing = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        FishingWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Food = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Fox = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Frog = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Furniture = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Gardening = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        GardeningWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Generic = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Glassmaking = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Goblin = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Hedgehog = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Hidden = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Home_VHS = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Household = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        HouseholdWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Instrument = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        InstrumentWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Item = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Junk = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        JunkWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Knapping = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        LightSource = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Literature = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        MaleBody = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Masonry = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Material = 0.05,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        MaterialWeapon = 0.05,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Medical = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Memento = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Meta = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Metalworking = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Miscellaneous = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Mole = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Music = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Object = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Outdoors = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Packing = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Paint = 0.05,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Player = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Pottery = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        ProtectiveGear = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Raccoon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        RecipeResource = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Repair = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Retail_VHS = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Security = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        SkillBook = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Slash = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Spear = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Spider = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Sports = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        SportsWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Squirrel = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Stab = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Swinging = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Tail = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Tailoring = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Teddy_Bear = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Tool = 0.05,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        ToolWeapon = 0.05,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Tools = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Trapping = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        UI = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Vehicle = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        VehicleMaintenance = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        VehicleMaintenanceWeapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Wall_Coverings = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Water = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        WaterContainer = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Weapon = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        WeaponCrafted = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        WeaponImprovised = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        WeaponPart = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Weaponry = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Welding = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        World = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Wound = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        ZedDmg = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        Zombie = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        bodywork = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        brakes = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        door = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        engine = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        gastank = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        lights = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        nodisplay = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        seat = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        suspension = 1.0,
        -- Min: 0.00 Max: 256.00 Default: 1.00
        tire = 1.0,
    },
    DynamicGearRattling = {
        -- When enabled, zombies will hear the sounds of your gear. Off by default.
        ZombiesCanHearNoise = false,
        -- Multiplier for how loud zombies hear sounds (DOESN'T AFFECT PLAYERS). 1 by default, which is what the mod is balanced on. Min: 0.10 Max: 5.00 Default: 1.00
        ZombiesCanHearNoiseMultiplier = 1.0,
    },
    OverTheShoulder = {
        -- How often the character stumbles while running and looking back. A glance of about a second is safe, after that the risk grows over three seconds up to this rate and stays there. Looking ahead again lets it fade. <LINE> 15 is roughly one fall per minute of looking back, 100 is one every ten seconds, 1000 is one a second. Zero never falls. Min: 0.00 Max: 1000.00 Default: 100.00
        RunTripChance = 100.0,
        -- The same for a sprint. Min: 0.00 Max: 1000.00 Default: 180.00
        SprintTripChance = 180.0,
        -- The rates above are for a character with no skill. Each level of Sprinting cuts them by 6%, each level of Fitness by 4%, so level ten in both removes falls entirely. Graceful halves the rate, Clumsy raises it by half. <LINE> Off, the rates work exactly as set, skills and traits are ignored.
        TripSkillScaling = true,
        -- Helmets, goggles, gas masks and other worn items that narrow the field of view also shorten how far you can see behind you when looking over the shoulder. <LINE> Off, looking back reaches behind you whatever you wear. The normal field of view is narrowed by them as usual.
        WornItemsLimitLook = true,
        -- Holding the look over the shoulder for long makes the neck stiff and sore. A quick glance and the first three seconds are free. <LINE> 1 is the normal rate, 2 twice as fast, 0.5 half as fast. Zero turns neck pain off. Min: 0.00 Max: 10.00 Default: 1.00
        NeckStrainFactor = 1.0,
        -- Degrees the edge of the field of view goes past the line straight behind you when looking back. <LINE> 0 stops right at your back, 10 shows a little more of the other side. At night a small margin helps the area straight behind stay visible. Min: 0 Max: 10 Default: 5
        BackMargin = 5,
    },
    SNT = {
        -- Sets damage, accuracy and instant kills of all turrets (normal zombie: 1.0 health). Weak: damage x0.6, -15 percent hit chance, no instant kills - rifle needs 2-3 hits. Realistic (default): base values, 5 percent instant kills - rifle 1-2 hits. Strong: damage x2, +3 percent, 15 percent instant kills - rifle almost always 1 hit. Very strong: damage x3.5, +5 percent, 30 percent instant kills - almost always 1 hit. Extreme: damage x6, +10 percent, 75 percent instant kills. Lethal: every hit kills, +15 percent. Default = Realistic
        -- 1 = Weak
        -- 2 = Realistic
        -- 3 = Strong
        -- 4 = Very strong
        -- 5 = Extreme
        -- 6 = Lethal
        TurretStrength = 2,
        -- If on, turrets need no ammo at all. Single shots or bursts are set on each rifle turret (right-click > Settings).
        UnlimitedAmmo = false,
        -- How much material the Junkyard Sentinel build menu asks for (turrets, sensor post, alarm lamp, barricade, fences, gates, watchtower). Hard: twice the material of Normal, Very hard: three times, Extreme: four times. Tools stay the same. Above Normal, turrets, sensor post and alarm lamp can only be made in the build menu, not in the crafting menu. Default = Normal
        -- 1 = Normal
        -- 2 = Hard (x2 material)
        -- 3 = Very hard (x3 material)
        -- 4 = Extreme (x4 material)
        BuildDifficulty = 1,
        -- Raises every skill the Junkyard Sentinel build menu asks for by 1, 2 or 3 levels (at most 10). Example: the gun turrets need Electrical 4 on Normal, 6 on Very hard. Above Normal, turrets, sensor post and alarm lamp can only be made in the build menu, not in the crafting menu. Default = Normal
        -- 1 = Normal
        -- 2 = Hard (+1 skill level)
        -- 3 = Very hard (+2 skill levels)
        -- 4 = Extreme (+3 skill levels)
        BuildSkill = 1,
        -- Size of a base square (Base tab: New base / Move base). Bases set earlier keep their size until they are moved. Default = 60 x 60 tiles
        -- 1 = 40 x 40 tiles
        -- 2 = 60 x 60 tiles
        -- 3 = 80 x 80 tiles
        -- 4 = 100 x 100 tiles
        -- 5 = 150 x 150 tiles
        BaseSize = 2,
        -- How many base squares one player may set. Admins have no limit. Min: 1 Max: 10 Default: 3
        BasesPerPlayer = 3,
        -- On: turrets, fences, gates, towers, barricades, sensor posts and alarm lamps of this mod can only be built inside an own base square (or one of an owner the player builds for). Admins can build anywhere.
        BuildOnlyInBases = false,
        -- Who can switch and configure a turret and take things out of it. Invited players (Moderator / Member / User) may what the server admin allows in Admin > Roles; members of the owner's safehouse count as Member when that switch is on there. Renaming and picking up always follow the groups. Admins may always do everything. Default = Owner and invited players (Admin > Roles)
        -- 1 = Owner and invited players (Admin > Roles)
        -- 2 = Same, and always the owner's safehouse
        -- 3 = Everyone
        ControlAccess = 1,
        -- Active turrets one player can own. Extra turrets stay switched off. 0 = no limit. Min: 0 Max: 500 Default: 12
        MaxTurretsPerPlayer = 12,
        -- Only matters with an NPC mod (Project A-Life, Bandits, Roaming Survivors and others). What turrets do with NPCs unless the owner picks something else in the turret menu. Non-hostile means friendly or neutral towards the turret owner (companions, recruits, friendly survivors); hostile NPCs (raiders, hostile bandits) are shot. NPCs of mods the turret does not know count as non-hostile. Default = Spare non-hostile NPCs
        -- 1 = Shoot all NPCs
        -- 2 = Spare non-hostile NPCs
        -- 3 = Spare all NPCs
        NpcDefault = 2,
        -- Rifle turret: maximum distance to a target in tiles. Min: 3 Max: 30 Default: 12
        Range = 12,
        -- Shotgun turret: maximum distance to a target in tiles. Min: 2 Max: 20 Default: 6
        SG_Range = 6,
        -- Sniper turret: maximum range in tiles. Hard cap is 30. Min: 4 Max: 30 Default: 22
        SN_Range = 22,
        -- Harpoon turret: maximum range in tiles. Min: 3 Max: 30 Default: 10
        HP_Range = 10,
        -- If on, every fired spear lands next to the target and can be picked up again. If off, fired spears are used up.
        HP_DropSpears = true,
        -- Only a separator - this box does nothing.
        UG_Separator = true,
        -- On (default): vanilla rifles, shotguns and the like work in the Universal Gun Turret too (useful on servers without a gun mod). Off: it only takes weapons from gun mods; vanilla firearms belong to the Sentinel Turrets. Pistols and revolvers never work.
        UG_AllowVanilla = true,
        -- The turret fires with the values of the weapon in it, measured against a vanilla weapon of the same class and the turret strength above. This multiplies the damage on top (1.0 = as calculated). Min: 0.10 Max: 5.00 Default: 1.00
        UG_DamageMult = 1.0,
        -- A weapon can deal at most this many times the damage of the matching Sentinel Turret (1.5 = 50 percent more). Keeps very strong mod weapons in check. Min: 0.50 Max: 5.00 Default: 1.50
        UG_MaxFactor = 1.5,
        -- Machine guns (M60, BAR and the like) deal this much more damage per round. They already fire at their real rate of fire in long bursts. Min: 0 Max: 200 Default: 25
        UG_MGBonus = 25,
        -- Only a separator - this box does nothing.
        SB_Separator = true,
        -- How much each barricade tile takes before zombies break it. A stick fence has 200. Applies to barricades built from now on. Min: 50 Max: 5000 Default: 400
        SB_Health = 400,
        -- Damage a zombie takes from the spikes each second while it touches the barricade - striking it or walking past (0 = none). A zombie has about 1 health: 0.02 = dead after about 50 seconds of contact, 0.04 = about 25 seconds. Min: 0.00 Max: 1.00 Default: 0.02
        SB_Damage = 0.02,
        -- Only a separator - this box does nothing.
        FN_Separator = true,
        -- How much each fence piece and gate tile takes before zombies break it. A stick fence has 200, the spike barricade 400. Applies to pieces built or repaired from now on. Min: 50 Max: 10000 Default: 600
        FN_Health = 600,
        -- Only a separator - this box does nothing. The settings below are for special cases and rarely need changing.
        ADV_Separator = true,
        -- Turrets and sensors already recognise NPCs of Project A-Life, Bandits, Roaming Survivors, Stay With Me and other mods using the common markers. For another NPC mod, add the marker its bodies carry, separated by ; - an animation variable by name (e.g. MyNpcMod) or a mod data key as md:Key.
        NPC_Markers = "",
        -- Weapons the turret refuses, separated by ; - e.g. MarzGuns.AA12;MarzGuns.M60 or a whole mod with MarzGuns.*
        UG_BlockList = "",
    },
    SNS = {
        -- Only a separator - this box does nothing.
        Separator = true,
        -- Max. distance in tiles between two linked sensor posts (default 30). Min: 5 Max: 60 Default: 30
        LinkRange = 30,
        -- Max. number of sensor posts in one network (default 15). Min: 2 Max: 30 Default: 15
        MaxPosts = 15,
        -- Max. distance in tiles from an alarm lamp to the nearest post of the network it is linked to (default 150). Far away posts only detect zombies while their area is loaded (a player nearby). Min: 10 Max: 1000 Default: 150
        LampRange = 150,
        -- How many sensor networks one player may own (default 5, 0 = no limit). Admins have no limit. Min: 0 Max: 50 Default: 5
        MaxNetworksPerPlayer = 5,
        -- How many other networks one sensor network can be bridged with (default 3, 0 = no bridges). An alarm also sounds on the lamps of bridged networks. Min: 0 Max: 10 Default: 3
        MaxBridges = 3,
        -- How many bridges in a row an alarm travels (default 5). Network A - B - C: depth 2 reaches C. Min: 1 Max: 10 Default: 5
        BridgeDepth = 5,
    },
    UndeadSurvivor = {
        -- The chance is a percentage, but it is shared with the other outfits - even at 100 not every zombie will wear this outfit. Min: 0.00 Max: 100.00 Default: 0.04
        StalkerChance = 0.04,
        -- Zombies will not spawn wearing this outfit until this many days have been survived in the current world. Zero means it can appear from the start. Min: 0 Max: 3650 Default: 180
        StalkerMinDays = 180,
        -- The chance is a percentage, but it is shared with the other outfits - even at 100 not every zombie will wear this outfit. Min: 0.00 Max: 100.00 Default: 0.04
        NomadChance = 0.04,
        -- Zombies will not spawn wearing this outfit until this many days have been survived in the current world. Zero means it can appear from the start. Min: 0 Max: 3650 Default: 0
        NomadMinDays = 0,
        -- The chance is a percentage, but it is shared with the other outfits - even at 100 not every zombie will wear this outfit. Min: 0.00 Max: 100.00 Default: 0.04
        PrepperChance = 0.04,
        -- Zombies will not spawn wearing this outfit until this many days have been survived in the current world. Zero means it can appear from the start. Min: 0 Max: 3650 Default: 0
        PrepperMinDays = 0,
        -- The chance is a percentage, but it is shared with the other outfits - even at 100 not every zombie will wear this outfit. Min: 0.00 Max: 100.00 Default: 0.04
        HeadhunterChance = 0.04,
        -- Zombies will not spawn wearing this outfit until this many days have been survived in the current world. Zero means it can appear from the start. Min: 0 Max: 3650 Default: 90
        HeadhunterMinDays = 90,
        -- The chance is a percentage, but it is shared with the other outfits - even at 100 not every zombie will wear this outfit. The Amazona outfit only spawns on female zombies, so for an equal spawn rate set this to twice the value of the other outfits. Min: 0.00 Max: 100.00 Default: 0.08
        AmazonaChance = 0.08,
        -- Zombies will not spawn wearing this outfit until this many days have been survived in the current world. Zero means it can appear from the start. Min: 0 Max: 3650 Default: 180
        AmazonaMinDays = 180,
    },
    AmmoLootDropVFE93B42 = {
        -- <RGB:1,1,1>The chance for each round type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 3 does not mean 3% of zombies.
        -- Many small chances add up. At 3 you
        -- get ammo from about 60% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get ammo from about
        -- 11% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop ammo. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 3.00
        DropRate = 3.0,
        -- <RGB:1,1,1>How many rounds you get each time
        -- ammo drops. You get between 1 and
        -- this many.
        -- 
        -- <RGB:0.100,0.800,1.000>This does not change how often you
        -- find ammo. Only the drop rate above
        -- does that. It changes how much you
        -- find each time.
        -- 
        -- Every round type gets its own
        -- number, so a body with two calibers
        -- gives a separate amount for each.
        -- 
        -- <RGB:0.800,1.000,0.000>At the default of 10, a body with
        -- ammo holds about 8 rounds. That is
        -- enough to be useful.
        -- 
        -- Set it to 1 if you want only one
        -- round at a time, like the old
        -- version of this mod.
        -- 
        -- <RGB:1.000,0.700,0.200>A body has limited space. If you set
        -- a big number, the body may fill up
        -- and you will get less than you asked
        -- for. Min: 1 Max: 99 Default: 10
        LooseRoundsMax = 10,
        -- <RGB:1,1,1>OFF: any zombie can drop ammo. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop ammo, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets9mm = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets45 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets44 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets38 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets357 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoShotgunShells = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo3030Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo223Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo762Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308BulletsLinked = true,
        Ammo57Bullets = true,
        Ammo46Bullets = true,
    },
    AmmoLootDropVFE93B42Box = {
        -- <RGB:1,1,1>The chance for each box type to drop
        -- from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.3 does not mean 0.3% of
        -- zombies. Many small chances add up.
        -- At 0.3 you get boxes from about 9%
        -- of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get boxes from about
        -- 1% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop boxes. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.30
        DropRate = 0.3,
        -- <RGB:1,1,1>OFF: any zombie can drop boxes. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop boxes, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets9mmBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets45Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets44Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets38Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets357Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoShotgunShellsBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo3030Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo308Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo223Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo762Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo22Box = true,
        Ammo57Box = true,
        Ammo46Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556BattlePack = true,
    },
    AmmoLootDropVFE93B42Carton = {
        -- <RGB:1,1,1>The chance for each carton type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 14 types on,
        -- that is 28 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.03 does not mean 0.03% of
        -- zombies. Many small chances add up.
        -- At 0.03 you get cartons from about
        -- 1% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>12 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get cartons from about
        -- 0% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 13 if you want almost every
        -- zombie to drop cartons. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.03
        DropRate = 0.03,
        -- <RGB:1,1,1>OFF: any zombie can drop cartons.
        -- This is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop cartons, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets9mmCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets45Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets44Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets38Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets357Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoShotgunShellsCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo3030Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo308Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo556Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo223Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo762Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo22Carton = true,
        Ammo57Carton = true,
        Ammo46Carton = true,
    },
    AmmoLootDropVFE93B42Magazine = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a magazine.
        -- 
        -- This is the total chance, not the
        -- chance for each magazine. All the
        -- magazines you turn on share it.
        -- Turning a caliber off changes which
        -- magazine you get, not how often you
        -- get one.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice. At
        -- 0.5 you get a magazine from about 1
        -- body in 100. The 32 magazines share
        -- that chance.
        -- 
        -- <RGB:1.000,0.700,0.200>The 5 base game magazines are in
        -- that count. This pack drops them so
        -- it can work on its own. If Ammo Loot
        -- Drop Magazine is also on, that mod
        -- drops them instead, and only the 27
        -- this pack adds share the chance
        -- here.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition you
        -- can fire straight away. It is worth
        -- more than the same rounds found
        -- loose. Raise this slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.50
        DropRate = 0.5,
        -- <RGB:1,1,1>OFF: any zombie can drop a magazine,
        -- even office workers and nurses.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop one, and only the
        -- kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- Pistols, shotguns, rifles - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- Pistols, shotguns - police, guards,
        -- bandits, bikers (10)
        -- Shotguns, rifles - farmers,
        -- fishermen (2)
        -- Pistols only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Magazines for belt fed and launcher
        -- guns drop from soldiers only. Nobody
        -- else in Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>How much ammunition is waiting in a
        -- magazine that drops.
        -- 
        -- It is a percent of what the magazine
        -- holds, and the amount is rolled each
        -- time, so you get between one round
        -- and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine saves you a
        -- reload. Set it low if you want the
        -- magazine to be the prize and the
        -- rounds to stay hard to find.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines. Min: 0.00 Max: 100.00 Default: 50.00
        MagazineLoaded = 50.0,
        -- M16 Magazine
        -- JS-14 Magazine
        Mags556Bullets = true,
        -- M15-22 Magazine
        -- K-33 Magazine
        -- R1022 Magazine
        -- Mk2 Magazine
        Mags22Bullets = true,
        -- FN-57 Magazine
        -- P90 Magazine
        Mags57Bullets = true,
        -- V-45 Magazine
        -- M1911 Magazine
        -- M10 Magazine
        -- MK23 Magazine
        MagsBullets45 = true,
        -- AA12 Drum
        MagsShotgunShells = true,
        -- MP7 Magazine
        Mags46Bullets = true,
        -- MK-17 Magazine
        -- FAL Magazine
        -- M14 Magazine
        -- R788 Magazine
        Mags308Bullets = true,
        -- V-9 Magazine
        -- CZ 75 Magazine
        -- G17 Magazine
        -- MP5 Magazine
        -- P229 Magazine
        -- TEC9 Magazine
        -- Uzi Magazine
        -- M9 Magazine
        MagsBullets9mm = true,
        -- AK-47 Magazine
        Mags762Bullets = true,
        -- Mini-14 Magazine
        Mags223Bullets = true,
        -- Cugir Md. 91 Magazine
        MagsBullets38 = true,
        -- AutoMag IV Magazine
        -- DE Magazine
        MagsBullets44 = true,
        -- M60 Belt Pouch
        Mags308BulletsLinked = true,
    },
    AmmoLootDropVFE93B42Weapon = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a gun at all.
        -- 
        -- It is not the chance of each gun.
        -- The chance is split across every
        -- caliber you leave on, so turning one
        -- off changes which gun drops and not
        -- how often one does.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice, so
        -- 0.1 leaves a gun on about one body
        -- in 500.
        -- 
        -- <RGB:1.000,0.700,0.200>71 of the 86 guns come from the base
        -- game or from a pack this one
        -- requires. This mod drops them so it
        -- can work on its own. If the mod that
        -- owns them is on too, only this
        -- pack's own 15 are left here sharing
        -- the chance.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.10
        DropRate = 0.1,
        -- <RGB:1,1,1>OFF: any zombie can drop guns. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop guns, and only
        -- the kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher guns drop from
        -- soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>ON: a gun that feeds from a magazine
        -- arrives with one. This is the normal
        -- setting.
        -- 
        -- 57 of the 86 guns take a magazine,
        -- and they share 30 between them.
        -- 
        -- <RGB:0.100,0.800,1.000>Magazines roll on their own as well,
        -- so you can find one without the gun.
        -- 
        -- <RGB:1.000,0.700,0.200>OFF: guns only. A rifle off a body
        -- is then no use until you find a
        -- magazine for it.
        -- 
        -- <RGB:1,1,1>Revolvers, shotguns and break
        -- actions take loose rounds and never
        -- needed one either way.
        DropMagazine = true,
        -- <RGB:1,1,1>How much ammunition is waiting in
        -- a magazine that drops.
        -- 
        -- It is a percent of what the
        -- magazine holds, and the amount is
        -- rolled each time, so you get
        -- between one round and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition
        -- you can fire straight away. It is
        -- worth more than the same rounds
        -- loose.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines,
        -- which is how they dropped before. Min: 0.00 Max: 100.00 Default: 50.00
        MagazineLoaded = 50.0,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets9mm = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets45 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets44 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets38 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets357 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsShotgunShells = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns3030Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns223Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns762Bullets = true,
        Guns22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308BulletsLinked = true,
        Guns57Bullets = true,
        Guns46Bullets = true,
    },
    AmmoLootDropVFEB42 = {
        -- <RGB:1,1,1>The chance for each round type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 13 types on,
        -- that is 26 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 3 does not mean 3% of zombies.
        -- Many small chances add up. At 3 you
        -- get ammo from about 55% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>9 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 4 types are left
        -- here, so you get ammo from about
        -- 22% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 14 if you want almost every
        -- zombie to drop ammo. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 3.00
        DropRate = 3.0,
        -- <RGB:1,1,1>How many rounds you get each time
        -- ammo drops. You get between 1 and
        -- this many.
        -- 
        -- <RGB:0.100,0.800,1.000>This does not change how often you
        -- find ammo. Only the drop rate above
        -- does that. It changes how much you
        -- find each time.
        -- 
        -- Every round type gets its own
        -- number, so a body with two calibers
        -- gives a separate amount for each.
        -- 
        -- <RGB:0.800,1.000,0.000>At the default of 10, a body with
        -- ammo holds about 8 rounds. That is
        -- enough to be useful.
        -- 
        -- Set it to 1 if you want only one
        -- round at a time, like the old
        -- version of this mod.
        -- 
        -- <RGB:1.000,0.700,0.200>A body has limited space. If you set
        -- a big number, the body may fill up
        -- and you will get less than you asked
        -- for. Min: 1 Max: 99 Default: 10
        LooseRoundsMax = 10,
        -- <RGB:1,1,1>OFF: any zombie can drop ammo. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop ammo, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets9mm = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets45 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets44 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets38 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets357 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoShotgunShells = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo3030Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo556Bullets = true,
        Ammo223Bullets = true,
        Ammo762Bullets = true,
        Ammo22Bullets = true,
        Ammo308BulletsLinked = true,
    },
    AmmoLootDropVFEB42Box = {
        -- <RGB:1,1,1>The chance for each box type to drop
        -- from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 13 types on,
        -- that is 26 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.3 does not mean 0.3% of
        -- zombies. Many small chances add up.
        -- At 0.3 you get boxes from about 8%
        -- of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>9 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 4 types are left
        -- here, so you get boxes from about
        -- 2% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 14 if you want almost every
        -- zombie to drop boxes. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.30
        DropRate = 0.3,
        -- <RGB:1,1,1>OFF: any zombie can drop boxes. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop boxes, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets9mmBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets45Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets44Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets38Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets357Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoShotgunShellsBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo3030Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo308Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556Box = true,
        Ammo223Box = true,
        Ammo762Box = true,
        Ammo22Box = true,
        Ammo556BattlePack = true,
    },
    AmmoLootDropVFEB42Carton = {
        -- <RGB:1,1,1>The chance for each carton type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 12 types on,
        -- that is 24 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.03 does not mean 0.03% of
        -- zombies. Many small chances add up.
        -- At 0.03 you get cartons from about
        -- 1% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>9 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 3 types are left
        -- here, so you get cartons from about
        -- 0% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 15 if you want almost every
        -- zombie to drop cartons. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.03
        DropRate = 0.03,
        -- <RGB:1,1,1>OFF: any zombie can drop cartons.
        -- This is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop cartons, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets9mmCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets45Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets44Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets38Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets357Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoShotgunShellsCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo3030Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo308Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo556Carton = true,
        Ammo223Carton = true,
        Ammo762Carton = true,
        Ammo22Carton = true,
    },
    AmmoLootDropVFEB42Magazine = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a magazine.
        -- 
        -- This is the total chance, not the
        -- chance for each magazine. All the
        -- magazines you turn on share it.
        -- Turning a caliber off changes which
        -- magazine you get, not how often you
        -- get one.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice. At
        -- 0.5 you get a magazine from about 1
        -- body in 100. The 23 magazines share
        -- that chance.
        -- 
        -- <RGB:1.000,0.700,0.200>The 5 base game magazines are in
        -- that count. This pack drops them so
        -- it can work on its own. If Ammo Loot
        -- Drop Magazine is also on, that mod
        -- drops them instead, and only the 18
        -- this pack adds share the chance
        -- here.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition you
        -- can fire straight away. It is worth
        -- more than the same rounds found
        -- loose. Raise this slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.50
        DropRate = 0.5,
        -- <RGB:1,1,1>OFF: any zombie can drop a magazine,
        -- even office workers and nurses.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop one, and only the
        -- kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- Pistols, shotguns, rifles - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- Pistols, shotguns - police, guards,
        -- bandits, bikers (10)
        -- Shotguns, rifles - farmers,
        -- fishermen (2)
        -- Pistols only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Magazines for belt fed and launcher
        -- guns drop from soldiers only. Nobody
        -- else in Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>How much ammunition is waiting in a
        -- magazine that drops.
        -- 
        -- It is a percent of what the magazine
        -- holds, and the amount is rolled each
        -- time, so you get between one round
        -- and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine saves you a
        -- reload. Set it low if you want the
        -- magazine to be the prize and the
        -- rounds to stay hard to find.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines. Min: 0.00 Max: 100.00 Default: 50.00
        MagazineLoaded = 50.0,
        -- CZ 75 Magazine
        -- G17 Magazine
        -- MP5 Magazine
        -- P229 Magazine
        -- TEC9 Magazine
        -- Uzi Magazine
        -- M9 Magazine
        MagsBullets9mm = true,
        -- AK-47 Magazine
        Mags762Bullets = true,
        -- M16 Magazine
        -- JS-14 Magazine
        Mags556Bullets = true,
        -- FAL Magazine
        -- M14 Magazine
        -- R788 Magazine
        Mags308Bullets = true,
        -- M1911 Magazine
        -- M10 Magazine
        -- MK23 Magazine
        MagsBullets45 = true,
        -- R1022 Magazine
        -- Mk2 Magazine
        Mags22Bullets = true,
        -- Mini-14 Magazine
        Mags223Bullets = true,
        -- Cugir Md. 91 Magazine
        MagsBullets38 = true,
        -- AutoMag IV Magazine
        -- DE Magazine
        MagsBullets44 = true,
        -- M60 Belt Pouch
        Mags308BulletsLinked = true,
    },
    AmmoLootDropVFEB42Weapon = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a gun at all.
        -- 
        -- It is not the chance of each gun.
        -- The chance is split across every
        -- caliber you leave on, so turning one
        -- off changes which gun drops and not
        -- how often one does.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice, so
        -- 0.1 leaves a gun on about one body
        -- in 500.
        -- 
        -- <RGB:1.000,0.700,0.200>20 of the 71 guns come from the base
        -- game or from a pack this one
        -- requires. This mod drops them so it
        -- can work on its own. If the mod that
        -- owns them is on too, only this
        -- pack's own 51 are left here sharing
        -- the chance.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.10
        DropRate = 0.1,
        -- <RGB:1,1,1>OFF: any zombie can drop guns. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop guns, and only
        -- the kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher guns drop from
        -- soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>ON: a gun that feeds from a magazine
        -- arrives with one. This is the normal
        -- setting.
        -- 
        -- 42 of the 71 guns take a magazine,
        -- and they share 21 between them.
        -- 
        -- <RGB:0.100,0.800,1.000>Magazines roll on their own as well,
        -- so you can find one without the gun.
        -- 
        -- <RGB:1.000,0.700,0.200>OFF: guns only. A rifle off a body
        -- is then no use until you find a
        -- magazine for it.
        -- 
        -- <RGB:1,1,1>Revolvers, shotguns and break
        -- actions take loose rounds and never
        -- needed one either way.
        DropMagazine = true,
        -- <RGB:1,1,1>How much ammunition is waiting in
        -- a magazine that drops.
        -- 
        -- It is a percent of what the
        -- magazine holds, and the amount is
        -- rolled each time, so you get
        -- between one round and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition
        -- you can fire straight away. It is
        -- worth more than the same rounds
        -- loose.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines,
        -- which is how they dropped before. Min: 0.00 Max: 100.00 Default: 50.00
        MagazineLoaded = 50.0,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets9mm = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets45 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets44 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets38 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets357 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsShotgunShells = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns3030Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns556Bullets = true,
        Guns223Bullets = true,
        Guns762Bullets = true,
        Guns22Bullets = true,
        Guns308BulletsLinked = true,
    },
    AmmoLootDropVFESB42 = {
        -- <RGB:1,1,1>The chance for each round type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 3 does not mean 3% of zombies.
        -- Many small chances add up. At 3 you
        -- get ammo from about 60% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get ammo from about
        -- 11% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop ammo. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 3.00
        DropRate = 3.0,
        -- <RGB:1,1,1>How many rounds you get each time
        -- ammo drops. You get between 1 and
        -- this many.
        -- 
        -- <RGB:0.100,0.800,1.000>This does not change how often you
        -- find ammo. Only the drop rate above
        -- does that. It changes how much you
        -- find each time.
        -- 
        -- Every round type gets its own
        -- number, so a body with two calibers
        -- gives a separate amount for each.
        -- 
        -- <RGB:0.800,1.000,0.000>At the default of 10, a body with
        -- ammo holds about 8 rounds. That is
        -- enough to be useful.
        -- 
        -- Set it to 1 if you want only one
        -- round at a time, like the old
        -- version of this mod.
        -- 
        -- <RGB:1.000,0.700,0.200>A body has limited space. If you set
        -- a big number, the body may fill up
        -- and you will get less than you asked
        -- for. Min: 1 Max: 99 Default: 10
        LooseRoundsMax = 10,
        -- <RGB:1,1,1>OFF: any zombie can drop ammo. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop ammo, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets9mm = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets45 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets44 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets38 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoBullets357 = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        AmmoShotgunShells = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo3030Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308Bullets = true,
        -- <RGB:1,1,1>A vanilla round. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo223Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo762Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same round is never dropped
        -- twice.
        Ammo308BulletsLinked = true,
        Ammo545Bullets = true,
        Ammo76254Bullets = true,
    },
    AmmoLootDropVFESB42Box = {
        -- <RGB:1,1,1>The chance for each box type to drop
        -- from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 15 types on,
        -- that is 30 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.3 does not mean 0.3% of
        -- zombies. Many small chances add up.
        -- At 0.3 you get boxes from about 9%
        -- of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>13 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get boxes from about
        -- 1% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 12 if you want almost every
        -- zombie to drop boxes. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.30
        DropRate = 0.3,
        -- <RGB:1,1,1>OFF: any zombie can drop boxes. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop boxes, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets9mmBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets45Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets44Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets38Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoBullets357Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        AmmoShotgunShellsBox = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo3030Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo308Box = true,
        -- <RGB:1,1,1>A vanilla box. This pack drops it so
        -- it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Box drops the vanilla
        -- ones when it is on. This switch only
        -- works when this mod is the one
        -- dropping them.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo223Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo762Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo22Box = true,
        Ammo545Box = true,
        Ammo76254Box = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same box is never dropped twice.
        Ammo556BattlePack = true,
    },
    AmmoLootDropVFESB42Carton = {
        -- <RGB:1,1,1>The chance for each carton type to
        -- drop from a zombie you kill.
        -- 
        -- Every type you turn on is checked on
        -- its own, and most zombies are
        -- checked twice. With all 14 types on,
        -- that is 28 checks per body.
        -- 
        -- <RGB:0.100,0.800,1.000>So 0.03 does not mean 0.03% of
        -- zombies. Many small chances add up.
        -- At 0.03 you get cartons from about
        -- 1% of bodies.
        -- 
        -- <RGB:1.000,0.700,0.200>12 of these come from the base game
        -- or from a pack this one requires.
        -- This mod drops them so it can work
        -- on its own. If the mod that owns
        -- them is on too, that mod drops them
        -- instead. Then only 2 types are left
        -- here, so you get cartons from about
        -- 0% of bodies.
        -- 
        -- <RGB:0.800,1.000,0.000>Try 13 if you want almost every
        -- zombie to drop cartons. Raise it
        -- slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.03
        DropRate = 0.03,
        -- <RGB:1,1,1>OFF: any zombie can drop cartons.
        -- This is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop cartons, and only
        -- the kind that fits their gun:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher rounds drop
        -- from soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets9mmCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets45Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets44Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets38Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoBullets357Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        AmmoShotgunShellsCarton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo3030Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo308Carton = true,
        -- <RGB:1,1,1>A vanilla carton. This pack drops it
        -- so it can work on its own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Carton drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo556Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo223Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo762Carton = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same carton is never dropped
        -- twice.
        Ammo22Carton = true,
        Ammo545Carton = true,
        Ammo76254Carton = true,
    },
    AmmoLootDropVFESB42Magazine = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a magazine.
        -- 
        -- This is the total chance, not the
        -- chance for each magazine. All the
        -- magazines you turn on share it.
        -- Turning a caliber off changes which
        -- magazine you get, not how often you
        -- get one.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice. At
        -- 0.5 you get a magazine from about 1
        -- body in 100. The 36 magazines share
        -- that chance.
        -- 
        -- <RGB:1.000,0.700,0.200>The 5 base game magazines are in
        -- that count. This pack drops them so
        -- it can work on its own. If Ammo Loot
        -- Drop Magazine is also on, that mod
        -- drops them instead, and only the 31
        -- this pack adds share the chance
        -- here.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition you
        -- can fire straight away. It is worth
        -- more than the same rounds found
        -- loose. Raise this slowly.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.50
        DropRate = 0.5,
        -- <RGB:1,1,1>OFF: any zombie can drop a magazine,
        -- even office workers and nurses.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop one, and only the
        -- kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- Pistols, shotguns, rifles - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- Pistols, shotguns - police, guards,
        -- bandits, bikers (10)
        -- Shotguns, rifles - farmers,
        -- fishermen (2)
        -- Pistols only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Magazines for belt fed and launcher
        -- guns drop from soldiers only. Nobody
        -- else in Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>How much ammunition is waiting in a
        -- magazine that drops.
        -- 
        -- It is a percent of what the magazine
        -- holds, and the amount is rolled each
        -- time, so you get between one round
        -- and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine saves you a
        -- reload. Set it low if you want the
        -- magazine to be the prize and the
        -- rounds to stay hard to find.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines. Min: 0.00 Max: 100.00 Default: 50.00
        MagazineLoaded = 50.0,
        -- PKM Box
        -- SV98 Magazine
        -- Dragunov Magazine
        -- SVT-40 Magazine
        Mags76254Bullets = true,
        -- Bizon Magazine
        -- Makarov Magazine
        -- PPSH-41 Drum
        -- VSS Magazine
        -- Vityaz Magazine
        -- CZ 75 Magazine
        -- G17 Magazine
        -- MP5 Magazine
        -- P229 Magazine
        -- TEC9 Magazine
        -- Uzi Magazine
        -- M9 Magazine
        MagsBullets9mm = true,
        -- Saiga-12 Magazine
        MagsShotgunShells = true,
        -- 5.45 Magazine
        Mags545Bullets = true,
        -- M16 Magazine
        -- M249 Box
        -- JS-14 Magazine
        Mags556Bullets = true,
        -- UMP-45 Magazine
        -- MK23 Magazine
        -- M1911 Magazine
        -- M10 Magazine
        MagsBullets45 = true,
        -- AK-47 Magazine
        Mags762Bullets = true,
        -- FAL Magazine
        -- M14 Magazine
        -- R788 Magazine
        Mags308Bullets = true,
        -- R1022 Magazine
        -- Mk2 Magazine
        Mags22Bullets = true,
        -- Mini-14 Magazine
        Mags223Bullets = true,
        -- Cugir Md. 91 Magazine
        MagsBullets38 = true,
        -- AutoMag IV Magazine
        -- DE Magazine
        MagsBullets44 = true,
        -- M60 Belt Pouch
        Mags308BulletsLinked = true,
    },
    AmmoLootDropVFESB42Weapon = {
        -- <RGB:1,1,1>The chance that a zombie you kill is
        -- carrying a gun at all.
        -- 
        -- It is not the chance of each gun.
        -- The chance is split across every
        -- caliber you leave on, so turning one
        -- off changes which gun drops and not
        -- how often one does.
        -- 
        -- <RGB:0.100,0.800,1.000>Most zombies are checked twice, so
        -- 0.1 leaves a gun on about one body
        -- in 500.
        -- 
        -- <RGB:1.000,0.700,0.200>71 of the 93 guns come from the base
        -- game or from a pack this one
        -- requires. This mod drops them so it
        -- can work on its own. If the mod that
        -- owns them is on too, only this
        -- pack's own 22 are left here sharing
        -- the chance.
        -- 
        -- <RGB:1,1,1>Set it to 0 to stop the drop. Min: 0.00 Max: 100.00 Default: 0.10
        DropRate = 0.1,
        -- <RGB:1,1,1>OFF: any zombie can drop guns. This
        -- is the normal setting.
        -- 
        -- ON: only zombies who look like they
        -- carried a gun drop guns, and only
        -- the kind that suits them:
        -- 
        -- <RGB:0.100,0.800,1.000>All types - soldiers, militia (4)
        -- 
        -- Pistol, shotgun, rifle - hunters,
        -- rangers, campers, rednecks,
        -- survivalists, raiders (20)
        -- 
        -- Pistol, shotgun - police, guards,
        -- bandits, bikers (10)
        -- 
        -- Shotgun, rifle - farmers, fishermen
        -- (2)
        -- 
        -- Pistol only - detectives, agents,
        -- truckers, mobsters (5)
        -- 
        -- <RGB:1,1,1>That is 41 of the 125 zombie outfits
        -- in the game. Every other zombie
        -- drops nothing. In a normal town,
        -- only about 1 zombie in 100 wears one
        -- of these outfits.
        -- 
        -- <RGB:1.000,0.700,0.200>Belt fed and launcher guns drop from
        -- soldiers only. Nobody else in
        -- Kentucky carried them.
        -- 
        -- <RGB:0.800,1.000,0.000>So search where these people worked:
        -- police stations, army bases,
        -- prisons, farms and bars.
        -- 
        -- <RGB:1,1,1>A higher drop rate helps a little,
        -- but you will still find very little
        -- in the suburbs.
        ArmedZombiesOnly = true,
        -- <RGB:1,1,1>ON: a gun that feeds from a magazine
        -- arrives with one. This is the normal
        -- setting.
        -- 
        -- 61 of the 93 guns take a magazine,
        -- and they share 34 between them.
        -- 
        -- <RGB:0.100,0.800,1.000>Magazines roll on their own as well,
        -- so you can find one without the gun.
        -- 
        -- <RGB:1.000,0.700,0.200>OFF: guns only. A rifle off a body
        -- is then no use until you find a
        -- magazine for it.
        -- 
        -- <RGB:1,1,1>Revolvers, shotguns and break
        -- actions take loose rounds and never
        -- needed one either way.
        DropMagazine = true,
        -- <RGB:1,1,1>How much ammunition is waiting in
        -- a magazine that drops.
        -- 
        -- It is a percent of what the
        -- magazine holds, and the amount is
        -- rolled each time, so you get
        -- between one round and this much.
        -- 
        -- <RGB:0.100,0.800,1.000>At 50 a 30 round magazine arrives
        -- holding 1 to 15 rounds.
        -- 
        -- <RGB:1.000,0.700,0.200>The game leaves a looted magazine
        -- empty. This setting is the only
        -- thing that puts rounds in one.
        -- 
        -- <RGB:0.800,1.000,0.000>A loaded magazine is ammunition
        -- you can fire straight away. It is
        -- worth more than the same rounds
        -- loose.
        -- 
        -- <RGB:1,1,1>Set it to 0 for empty magazines,
        -- which is how they dropped before. Min: 0.00 Max: 100.00 Default: 50.00
        MagazineLoaded = 50.0,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets9mm = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets45 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets44 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets38 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsBullets357 = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        GunsShotgunShells = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns3030Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308Bullets = true,
        -- <RGB:1,1,1>Guns from the base game. This pack
        -- drops them so it can work on its
        -- own.
        -- 
        -- <RGB:1.000,0.700,0.200>Ammo Loot Drop Weapon drops the
        -- vanilla ones when it is on. This
        -- switch only works when this mod is
        -- the one dropping them.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns556Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns223Bullets = true,
        Guns762Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns22Bullets = true,
        -- <RGB:1,1,1>This comes from Vanilla Firearms
        -- Expansion, which this pack requires.
        -- This mod drops it so it can work on
        -- its own.
        -- 
        -- <RGB:1.000,0.700,0.200>The mod for that pack drops it when
        -- that mod is on. This switch only
        -- works when this mod is the one
        -- dropping it.
        -- 
        -- <RGB:1,1,1>The same gun is never dropped twice.
        Guns308BulletsLinked = true,
        Guns545Bullets = true,
        Guns76254Bullets = true,
    },
    ReactiveSE = {
        -- Minimum IN-GAME HOURS before events can occur Min: 1 Max: 720 Default: 48
        MinEventCooldown = 48,
        -- Maximum IN-GAME HOURS before an event is guaranteed Min: 2 Max: 720 Default: 240
        MaxEventCooldown = 240,
        -- Probability of an event per 10-MINUTE CHECK after minimum cooldown Min: 1 Max: 20 Default: 4
        EventChance = 4,
        -- If enabled, probability stays flat. If disabled, probability increases until max cooldown (legacy)
        FlatProbability = true,
        -- Minimum distance (in tiles) from the player where sound events can spawn Min: 120 Max: 1000 Default: 200
        MinSoundRange = 200,
        -- Maximum distance (in tiles) from the player where sound events can spawn Min: 120 Max: 1000 Default: 600
        MaxSoundRange = 600,
        -- If a sound occurs within this distance, the player may panic or wake up. Sounds beyond this range will only be heard. Must be between the minimum and maximum sound range; otherwise it is adjusted automatically Min: 120 Max: 1000 Default: 300
        ReactionThresholdRange = 300,
        -- Probability an event spawns at close range Min: 0 Max: 100 Default: 20
        CloseDistanceChance = 20,
        -- Probability an event spawns at medium range Min: 0 Max: 100 Default: 40
        MediumDistanceChance = 40,
        -- Probability an event spawns at far range Min: 0 Max: 100 Default: 40
        FarDistanceChance = 40,
        -- Allow zombies to react to sound events
        EnableZombieHearing = true,
        -- [DEV] Enables debug logging and visual helpers
        EnableDebugMode = false,
    },
    ReactiveSEEvents = {
        -- Animal sounds occurring in the distance
        EnableAnimalEvents = true,
        -- Gunfights between survivors
        EnableGunfightEvents = true,
        -- Single shots heard in the distance
        EnableGunshotEvents = true,
        -- Distant screams of survivors
        EnableScreamEvents = true,
        -- Vehicles crashing or colliding
        EnableVehicleCrashEvents = true,
        -- Weather-related sounds such as lightning
        EnableWeatherEvents = true,
        -- Zombie noises occurring in the distance
        EnableZombieEvents = true,
    },
    ReactiveSEBehavior = {
        -- Adjust event chances based on the player's aggressive or passive behavior
        EnablePlayerStyle = true,
        -- Kills per day required to consider the player aggressive Min: 10 Max: 200 Default: 40
        AggressiveStyleKills = 40,
        -- Days without killing zombies required to consider the player passive Min: 1 Max: 7 Default: 2
        PassiveStyleDays = 2,
        -- Player may panic when a sound event happens within reaction range
        EnablePlayerReactionPanic = true,
        -- Sleeping player may wake up if a sound event happens nearby
        EnablePlayerReactionWakeUp = true,
    },
    ReactiveSEScenes = {
        -- Enable physical scenes generated from sound events
        EnableEventScenes = true,
        -- Chance for a sound event to generate a scene Min: 0 Max: 100 Default: 100
        EventSceneChance = 100,
        -- Hours before generated scenes are automatically cleaned up (0 = disabled) Min: 0 Max: 168 Default: 72
        SceneCleanupHours = 72,
        -- Events with scenes look for a place in towns, trailer parks and roads first. They only happen in forests or fields when there is no other place in range
        PreferTownsAndRoads = false,
        -- Generate corpse scenes when gunfight sounds occur
        EnableGunfightScene = true,
        -- Generate single corpse when gunshot sounds occur
        EnableGunshotScene = true,
        -- Generate corpse when scream sounds occur
        EnableScreamScene = true,
        -- Maximum zombies that may spawn with scream scenes (0 = disabled) Min: 0 Max: 10 Default: 3
        ScreamZombieCount = 3,
        -- Spawn crashed vehicles when crash sounds occur
        EnableVehicleCrashScene = true,
        -- Maximum condition of vehicles spawned in scenes Default = Low
        -- 1 = Very Low
        -- 2 = Low
        -- 3 = Normal
        -- 4 = High
        -- 5 = Very High
        VehicleMaxCondition = 2,
        -- Chance that a spawned vehicle contains its key Min: 0 Max: 100 Default: 25
        VehicleKeyChance = 25,
        -- Spawn zombie groups when zombie sounds occur
        EnableZombieScene = true,
        -- Minimum number of zombies spawned in a Zombie event Min: 1 Max: 20 Default: 8
        ZombieSceneMin = 8,
        -- Maximum number of zombies spawned in a Zombie event Min: 1 Max: 20 Default: 16
        ZombieSceneMax = 16,
        -- Notify the player when a scene spawns nearby
        EnableSceneSpawnNotify = true,
        -- Player says something when a scene spawns nearby
        SceneSpawnNotifyText = true,
        -- Show the directional marker when a scene spawns nearby
        SceneSpawnNotifyMarker = true,
    },
    ReactiveSELoot = {
        -- Overall quality of loot found in scenes Default = Dynamic
        -- 1 = Dynamic
        -- 2 = Poor
        -- 3 = Normal
        -- 4 = Rich
        LootQuality = 1,
        -- Maximum condition of weapons found in scenes Min: 10 Max: 100 Default: 100
        WeaponMaxCondition = 100,
        -- Chance that a ranged weapon appears in a scene Min: 0 Max: 100 Default: 10
        RangedWeaponChance = 10,
        -- Minimum probability that a backpack is stolen from a corpse. Applied during End Game. Min: 0 Max: 100 Default: 0
        MinBackpackStealChance = 0,
        -- Maximum probability that a backpack is stolen from a corpse (scales with World Tier). Applied during Early Game. Min: 0 Max: 100 Default: 70
        MaxBackpackStealChance = 70,
        -- Controls how scarce ammunition is in scenes Default = Scarce
        -- 1 = None
        -- 2 = Scarce
        -- 3 = Normal
        -- 4 = Abundant
        AmmoScarcity = 2,
        -- Minimum number of items generated per SubKit (Dynamic Loot: Early Game) Min: 1 Max: 10 Default: 1
        SubKitCountMin = 1,
        -- Maximum number of items generated per SubKit (Dynamic Loot: End Game) Min: 1 Max: 10 Default: 3
        SubKitCountMax = 3,
    },
    ReactiveSEWorld = {
        -- Maximum number of corpses spawned in a scene Min: 2 Max: 8 Default: 3
        CorpseCount = 3,
        -- Defines the last day considered Early Game. Mid Game starts Min: 1 Max: 365 Default: 7
        WorldTierEarlyEnd = 7,
        -- Defines the last day considered Mid Game. Late Game starts Min: 2 Max: 365 Default: 30
        WorldTierMidEnd = 30,
        -- Defines the last day considered Late Game. End Game starts Min: 3 Max: 365 Default: 90
        WorldTierLateEnd = 90,
        -- On the vanilla map nothing across the Ohio river is reachable (north of Riverside and West Point, west and north of Louisville), so events never happen there. Enable only if a map mod adds content on that side
        AllowEventsBeyondOhio = false,
    },
    ReactiveSERadio = {
        -- Enable the Knox Relay radio station that broadcasts scene locations and survival stories
        EnableRadioFeature = true,
        -- Allow players to mark intel coordinates on their map via the radio context menu. Disable to prevent players from using this feature
        EnableMapMarker = true,
        -- Allow players to gain XP from listening to the morning show
        EnableMorningShowXP = true,
    },
    ALife = {
        Preset_ExplicitValues = false,
        Preset_World = 4,
        -- How hard NPCs fight and how often raids come. Only default-valued options change. Reload for full effect. Details are on the EXPERT preset page.
        -- Default Normal (2). The single player start cards still open on Easy. Default = Normal
        -- 1 = Easy
        -- 2 = Normal
        -- 3 = Hard
        -- 4 = Hardcore
        Preset_Difficulty = 1,
        -- How many NPCs, groups and outposts the world holds: spawn rates, caps, encounters and outposts. Only default-valued options change. Reload for full effect.
        -- Default High (3). Default = High
        -- 1 = Low
        -- 2 = Medium
        -- 3 = High
        -- 4 = Very high (heavy, may lag)
        Preset_Population = 3,
        -- Off prevents hostile factions, automatic raids and new outposts. Friendly, neutral and cautious survivors can still appear.
        -- Default on.
        World_HostileEnabled = true,
        -- Enables automatic raids: a radio warning, scouts arriving unseen, then a buildup before the attack. The earliest raid day still applies. Admins can force raids.
        -- Default on.
        Raid_Enabled = true,
        -- Groups in contact may request backup, with limited calls, a cooldown and a chance of no answer.
        -- Default on.
        Support_Enabled = true,
        -- Outlaws may rob a lone player instead of shooting: hands up, weapon down, three or four valuables taken, then they leave. Refusal can lead to shooting.
        -- Default on.
        Robbery_Enabled = true,
        -- Allows groups who hate you to attack your base after warnings. Off prevents these base-event attacks.
        -- Default on.
        Safehouse_Attacks = true,
        -- Adds extra activity for the first 3 game days and a National Guard checkpoint north of West Point. After 72 hours, road police, army and the checkpoint disappear.
        -- Default on.
        Realistic_Outbreak = true,
        -- NPC squads send a member round the side of a target they cannot reach head on. Off: they keep fighting from the front.
        -- Default on.
        Combat_Flanking = true,
        -- Squads advance together on a target that is pinned down or reloading. Off: they hold their positions.
        -- Default on.
        Combat_SquadPush = true,
        -- NPCs pin a target down with bursts and near misses before closing in. Off: they only shoot to hit.
        -- Default on.
        Combat_Suppression = true,
        -- How often A-Life helicopters show up: flybys and backup calls. Helicopters get rarer as the days pass. Low is half as often, High is twice as often, Off stops all flybys, patrols and first passes (backup helicopters follow their own switch). A-Life helicopters must be on.
        -- Default Normal (2). Default = Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Off
        Heli_Frequency = 2,
        -- Lets helicopters turn hostile and circle to attack, and lets full-scale raids bring a helicopter (raid gunship, helicopter drop). Off: no helicopter ever attacks and raids arrive on foot or by car.
        -- Default on.
        Heli_HostileRaid = true,
        -- How many NPC cars are on the roads: ambient traffic, drive-bys and pull-ups. Low is about 40 percent, High is 1.5 times, Off stops all ambient NPC car traffic (raid, police response and scripted cars follow their own switches). Enable NPC vehicles must be on.
        -- Default Normal (2). Default = Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Off
        Cars_TrafficFrequency = 2,
        -- NPCs that would carry the JS-5 submachine gun carry an M9 pistol instead when this is off.
        -- Default on.
        Weapons_Js5Enabled = true,
        -- How many groups keep travelling and working at night. No risks makes everyone shelter; Risk takers keeps most groups active.
        -- Default Moderate chance (3). Default = Moderate chance
        -- 1 = No risks
        -- 2 = Low chance
        -- 3 = Moderate chance
        -- 4 = High chance
        -- 5 = Risk takers
        Night_Activity = 3,
        -- Changes distant gunfire, helicopters and other background events. Low halves event limits and doubles the wait between them.
        -- Default Normal (2). Default = Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_MetaEvents = 2,
        -- Off stops the law factions (police, sheriff, and any Creator faction set to the law bloc) from spawning on their own. NPCs already in the world stay.
        -- Default on.
        Factions_Law = true,
        -- Off stops the military factions (army, guard, special forces) from spawning on their own. NPCs already in the world stay.
        -- Default on.
        Factions_Military = true,
        -- Off stops the fire and rescue factions from spawning on their own. NPCs already in the world stay.
        -- Default on.
        Factions_Rescue = true,
        -- Off stops the civilian, family, worker and federation factions from spawning on their own. NPCs already in the world stay.
        -- Default on.
        Factions_Towns = true,
        -- Off stops the crime, gang, club, raider and prison factions from spawning on their own. NPCs already in the world stay. Raids from them stop too.
        -- Default on.
        Factions_Outlaws = true,
        -- Allows hostile NPC factions to fight each other.
        -- Default on.
        World_FactionWarfare = true,
        -- Lets fortified stations, occupied houses and forest camps appear over time, with garrisons that remain at their site.
        -- Default on.
        Outposts_Enabled = true,
        -- Lets you ask a friendly NPC group to take you in. The group keeps its own plans, offers jobs and warnings, and can leave you behind if you stay away.
        -- Default on.
        Party_Enabled = true,
        -- Some NPCs can join a player as companions: they follow, take orders and fight next to you. Off: they stay ordinary NPCs.
        -- Default on.
        Companions_Enabled = true,
        -- Door visits bring named individuals and small groups with their own history, needs and conversation. Off: visits work exactly as before.
        -- Default on.
        Visitors_Persons = true,
        -- Nearby NPCs answer typed questions, requests, threats and yes-or-no replies. They also speak when you hit them or help them fight.
        -- Default on.
        Talk_Enabled = true,
        -- Calm groups pause to talk, and passing NPCs greet each other or you. Danger interrupts them. Off disables both group chatter and these greetings.
        -- Default on.
        Chatter_Enabled = true,
        -- Enables recorded speech where available. Off keeps conversations as text; pain and death sounds are separate.
        -- Default off.
        Voice_Enabled = false,
        -- Tracks kills, help and mistreatment, with change notices and character-window scores. Off stops both tracking and display.
        -- Default on.
        Reputation_Tracking = true,
        -- Shows the number beside your reputation level in the character window, notes and radio panel, such as Cutthroat (-62). Off shows only the level name.
        -- Default on.
        Reputation_ShowScore = true,
        -- Shows your reputation level and a progress bar at the top of the screen for a few seconds after it changes, and replaces the small green text with a change popup. Off keeps the small text.
        -- Default on.
        Rep_BarHud = true,
        -- Where the reputation bar and its change popup appear on the screen.
        -- Default Top right (1). Default = Top right
        -- 1 = Top right
        -- 2 = Top centre
        -- 3 = Left
        Rep_HudPosition = 1,
        -- The popup names what changed your reputation, such as killed a hostile survivor. Off shows only the amount.
        -- Default on.
        Rep_ShowReasons = true,
        -- How many seconds the reputation bar stays on screen after a change.
        -- Default 5. Min: 2 Max: 15 Default: 5
        Rep_PopupSeconds = 5,
        -- Controls opening sirens, jets and raid aircraft sounds. Helicopter raid arrivals also need the helicopter option switched on.
        -- Default on.
        Raid_SirenAircraftSounds = true,
        -- Chance for each carried item to stay on an NPC's body. 100 drops all items; lower values drop fewer. Fixed NPC weapon drop chances take priority. Use wear below for poorer gear.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Loot_NpcDropPercent = 100,
        -- Wear added to gear and ammo on death. 0 adds no wear; 100 is full. Fixed NPC weapon conditions take priority. Guns can still drop broken: set Dropped weapon condition for working guns.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Loot_NpcWearPercent = 100,
        -- Per NPC profile uses each NPC's own chance times the NPC loot percent. Another choice sets one chance for all weapons and ignores that percent; needs NPC weapon drops.
        -- Default Per NPC profile (1). Default = Per NPC profile
        -- 1 = Per NPC profile
        -- 2 = Off (0%)
        -- 3 = Very low (0-10%)
        -- 4 = Low (10-20%)
        -- 5 = Moderate (20-30%)
        -- 6 = High (30-50%)
        -- 7 = Very high (50-70%)
        -- 8 = Almost always (70-99%)
        -- 9 = Always (100%)
        Drops_WeaponChance = 3,
        -- NPCs that would bleed out can lie injured, be rescued, bandaged or questioned. Off keeps ordinary injury behavior; in multiplayer, only the client controlling the NPC runs its movement.
        -- Default on.
        Injury_Enabled = true,
        -- Infected NPC corpses wait before rising, giving you time to right-click and put them down. Off: they rise immediately. The wait advances only while the body is loaded.
        -- Default on.
        Turning_Enabled = true,
        -- Returns fast-forward to normal speed when a visitor knocks, a raid or a crash starts, support arrives or an NPC asks you something. Single player only.
        -- Default on.
        FastForward_Interrupt = true,
        -- Job-uniform crews, stranded commuters and lone nurses belong to the first days. From this day they spawn less and less. NPCs already in the world stay.
        -- Default 10. Min: 0 Max: 365 Default: 10
        Funnel_StarterFadeDay = 10,
        -- From this day starter survivors no longer spawn and part of their share goes to experienced survivors. Keep it after the thinning-out day.
        -- Default 30. Min: 1 Max: 730 Default: 30
        Funnel_StarterGoneDay = 30,
        -- Hardened survivors, preppers and old hands do not spawn before this day and phase in after it.
        -- Default 10. Min: 0 Max: 365 Default: 10
        Funnel_VeteranStartDay = 10,
        -- The day experienced survivors reach their full spawn weight. Keep it after the start day.
        -- Default 30. Min: 1 Max: 730 Default: 30
        Funnel_VeteranFullDay = 30,
        -- Early local gangs begin to lose ground to larger raiders from this day. They thin out but never vanish completely.
        -- Default 150. Min: 0 Max: 3650 Default: 150
        Funnel_DeclineStartDay = 150,
        -- The day declining gangs reach their lowest spawn weight. Keep it after the start day.
        -- Default 450. Min: 1 Max: 3650 Default: 450
        Funnel_DeclineEndDay = 450,
        -- How much of the spawn weight a fading faction loses is passed to its named successor. 0 means the weight is simply lost, 100 passes all of it. Needs the faction timeline option on.
        -- Default 70. Min: 0 Max: 100 Default: 70
        Funnel_HandoffPercent = 70,
        -- During day 0, adds selection weight for police and military. 50 means half again; 0 disables it. Other spawn limits still apply. Requires the faction timeline option.
        -- Default 50. Min: 0 Max: 200 Default: 50
        Funnel_Day0LawBoost = 50,
        -- Restores the earlier factions, attitudes and spawn weights instead of the merged roster. Takes effect when the game or server starts.
        -- Default off.
        Factions_LegacyRoster = false,
        -- Changes factions, gear and aim as the world ages. Emergency services disappear by day 120; survivor and raider groups take over. Off uses fixed faction schedules.
        -- Default on.
        Funnel_Enabled = true,
        -- Moves faction progression ahead or back. At +30, a new world uses day-30 factions and gear; -10 delays progression by 10 days.
        -- Default 0. Min: -3650 Max: 3650 Default: 0
        Funnel_DayOffset = 0,
        -- Limits lone survivors and survivor pairs to this many NPCs, even if group-size settings would make their party larger.
        -- Default 2. Min: 1 Max: 2 Default: 2
        Funnel_LoneSurvivorMax = 2,
        -- Marks 10, 20 or 35 percent of suitable buildings once per world, up to the building limit. Residents appear when approached and are saved. Realistic outbreak does not turn it off.
        -- Default Uncommon (3). Default = Uncommon
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Uncommon
        -- 4 = Common
        Population_PopulateOnStart = 3,
        -- Adds small local groups, such as a family or rescue crew, when a new character starts in town. Reloading or rejoining does not add more.
        -- Default on.
        TownWelcome_Enabled = true,
        -- On allows a character's town welcome group only during their first game day. Off extends the window to their first game week.
        -- Default on.
        TownWelcome_FirstDayOnly = true,
        -- Sets how many newcomers can replace dead survivors each game week early in the outbreak. If nobody has died, nobody arrives.
        -- Default 7.0. Min: 0.00 Max: 100.00 Default: 7.00
        Census_ArrivalsEarly = 7.0,
        -- Sets the replacement arrival rate after the early period. Arrivals gradually fall from the early rate to this one; they only replace losses.
        -- Default 1.0. Min: 0.00 Max: 100.00 Default: 1.00
        Census_ArrivalsLate = 1.0,
        -- Sets how long the weekly arrival rate takes to fall from the early value to the later value.
        -- Default 28. Min: 1 Max: 365 Default: 28
        Census_ArrivalsFadeDays = 28,
        -- Keeps a camp, outpost or inhabited building empty after all its residents die. Once this period ends, rare newcomers may settle there if resettlement is enabled.
        -- Default 30. Min: 1 Max: 365 Default: 30
        Census_ClearedDays = 30,
        -- Allows newcomers to settle cleared sites after their vacancy period, at most one site per four arrivals. Off keeps cleared sites empty for the rest of the game.
        -- Default on.
        Census_Resettle = true,
        -- Allows groups such as patrols, scavengers and hostile crews to appear near players in suitable map areas.
        -- Default on.
        Encounters_Enabled = true,
        -- Scales Roadside Pickers, small looting crews that may warn or rob you. They are common in the first two weeks and gone by week four. At 0, they do not appear.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Encounters_EarlyLooters = 100,
        -- Visitors, travellers and traders you met stay in the world when you quit. Raiders and other hostile groups do not. Counts toward the saved crew limit.
        -- Default on.
        Population_KeepEncounterNpcs = true,
        -- Adds winter layers, removes heavy layers in summer and adds rainwear in wet weather. Uniforms and profiles with their own seasonal outfits are preserved.
        -- Default on.
        Loadouts_SeasonalDress = true,
        -- Each new person gets their own hair, hair colour, beard and clothing colours, so crews stop looking cloned. Off keeps the authored look. People already in a save keep theirs.
        -- Default on.
        Appearance_Variation = true,
        -- Share of new people who keep their authored face, so named characters stay recognisable. 0 varies everyone, 100 varies nobody. Needs Varied NPC looks on.
        -- Default 35. Min: 0 Max: 100 Default: 35
        Appearance_KeepAuthoredPercent = 35,
        -- New arrivals from built-in factions mix uniforms with civilian clothes from this day; makeshift armour appears later. At 0, uniforms stay intact. Creator profiles are unchanged.
        -- Default 10. Min: 0 Max: 365 Default: 10
        Loadouts_UniformDecayDay = 10,
        -- Sets how quickly built-in civilian groups gain guns over time. At 200, guns spread twice as fast; at 50, half as fast. Police, army and elite units are unaffected.
        -- Default 100. Min: 25 Max: 400 Default: 100
        Loadouts_ArmingPace = 100,
        -- Scales gun ownership among built-in non-military NPCs. At 0, affected NPCs use melee tools only. Police, army, elite units and Creator profiles are unchanged.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Loadouts_ArmingShare = 100,
        -- Full keeps groups travelling beyond players' view. Local only stops new distant groups; existing ones retire on reload. Outposts can still develop in either mode.
        -- Default Full A-Life (offline squads roam the map) (1). Default = Full A-Life (offline squads roam the map)
        -- 1 = Full A-Life (offline squads roam the map)
        -- 2 = Local only (groups near players; outposts stay)
        World_Mode = 1,
        -- Scales the chance of a random group near players without changing check intervals. Low halves the chance; Abundant triples it.
        -- Default Normal (2). Default = Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_Encounters = 2,
        -- Scales natural group arrivals and the distant travelling group limit together. Low halves both; Abundant triples them, within their limits.
        -- Default Normal (2). Default = Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_Groups = 2,
        -- Scales how often friendly, neutral and wary factions are picked compared with hostile ones. Low halves their selection weight; Abundant triples it.
        -- Default Normal (2). Default = Normal
        -- 1 = Low
        -- 2 = Normal
        -- 3 = High
        -- 4 = Very High
        -- 5 = Abundant
        Rate_Survivors = 2,
        -- Allows cautious survivor communities to hold outposts alongside hostile crews. They warn strangers away but never send hunting parties. Off leaves only hostile holders.
        -- Default on.
        Outposts_SurvivorHolds = true,
        -- A group at this size refuses new members. NPCs and players both count toward the limit.
        -- Default 6. Min: 2 Max: 12 Default: 6
        Party_MaxSize = 6,
        -- Sets the leader's minimum opinion of you before you can join. Soldiers and raiders require more; gentler groups, such as families, require less.
        -- Default 20. Min: -50 Max: 80 Default: 20
        Party_MinOpinion = 20,
        -- Sets the minimum time between jobs offered by your group leader at calm stops. At 0, automatic offers stop; you can still ask for a job.
        -- Default 45. Min: 0 Max: 240 Default: 45
        Party_TaskFrequency = 45,
        -- Sets how long you can stay far from your NPC group before it leaves you behind and your membership ends.
        -- Default 10. Min: 2 Max: 60 Default: 10
        Party_AwayMinutes = 10,
        -- Allows settled groups near you to tell stories about their old lives. You can also ask for a story.
        -- Default on.
        Party_Stories = true,
        -- Sets how many travelling groups each town receives when the world starts. The distant travelling group limit may allow extra groups in larger worlds.
        -- Default 3. Min: 1 Max: 4 Default: 3
        Population_SeedPerTown = 3,
        -- Blocks new travelling groups in an area of about 120 tiles after NPC deaths. Heavy losses extend the delay. At 0, this delay is disabled.
        -- Default 3. Min: 0 Max: 60 Default: 3
        Population_RespawnCooldownDays = 3,
        -- After the death cooldown, limits a recovering area to one new group per interval. At 0, this additional recovery limit is disabled.
        -- Default 2. Min: 0 Max: 30 Default: 2
        Population_RegrowthDays = 2,
        -- Sets open-countryside encounters relative to towns. At 50, the rate is half the town rate. Only suitable visitors, such as travellers and hunters, appear.
        -- Default 50. Min: 0 Max: 100 Default: 50
        Spawn_RuralDensityPercent = 50,
        -- Sets forest and wilderness encounters relative to towns. At 30, the rate is 30 percent of the town rate.
        -- Default 30. Min: 0 Max: 100 Default: 30
        Spawn_WildernessDensityPercent = 30,
        -- Sets farm and ranch encounters relative to towns. At 60, the rate is 60 percent of the town rate.
        -- Default 60. Min: 0 Max: 100 Default: 60
        Spawn_FarmDensityPercent = 60,
        -- Keeps spawning, waking and removal away from nearby or watching players. Also reduces rural encounters and prevents checkpoints near players or on dead-end roads.
        -- Default on.
        Spawn_FairnessEnabled = true,
        -- Minimum distance from players for random groups to appear, then walk in. Sight and loaded-map limits also apply; too large a distance can prevent spawns.
        -- Default 45. Min: 20 Max: 150 Default: 45
        Spawn_PlayerKeepOutTiles = 45,
        -- Lets welcome and starting-town groups appear nearby during a new character's first minutes. Other groups still obey the normal player clearance.
        -- Default 10. Min: 0 Max: 240 Default: 10
        Spawn_StartGraceMinutes = 10,
        -- Prevents starting travelling groups from being placed this close to a player. Groups may still arrive later. At 0, this starting clearance is disabled.
        -- Default 150. Min: 0 Max: 400 Default: 150
        Population_SeedClearTiles = 150,
        -- Allows wounded hostile NPCs to retreat from a fight.
        -- Default on.
        Behavior_Retreat = true,
        -- NPCs infected by zombie bites or attacks can rise in their own clothes. The game's Transmission, Mortality and Reanimate settings still apply.
        -- Default on.
        Behavior_NPCsReanimate = true,
        -- Sets the shortest wait before an infected NPC corpse rises. For example, 30 means at least half a minute while the body is loaded.
        -- Default 20. Min: 0 Max: 600 Default: 20
        Turning_DelaySecondsMin = 20,
        -- Sets the longest wait before an infected NPC corpse rises. For example, 120 allows up to two minutes while the body is loaded.
        -- Default 90. Min: 0 Max: 600 Default: 90
        Turning_DelaySecondsMax = 90,
        -- Scales the ammo an NPC starts with; 100 keeps its profile amount. Each gun retains at least one full load. Infinite-ammo profiles are unchanged.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Ammo_SpawnPercent = 100,
        -- Caps starting and collected spare ammo in gun loads of at least 6 rounds. Smaller kits stay smaller; 2 permits two spare loads. 0 removes the cap; infinite-ammo profiles are unchanged.
        -- Default 2. Min: 0 Max: 20 Default: 2
        Ammo_ReserveLoads = 2,
        -- Chooses which NPC profiles may use infinite ammo. Creator profiles only limits it to profiles you made or edited; stock NPCs can run dry.
        -- Default Creator profiles only (1). Default = Creator profiles only
        -- 1 = Creator profiles only
        -- 2 = Every profile that asks
        -- 3 = Never
        Ammo_Bottomless = 1,
        -- On: dropped magazines use only ammo the NPC had left, up to its profile limit. Off: each issued magazine gets a drop roll and can be full even after its rounds were fired.
        -- Default on.
        Ammo_HonestDrops = true,
        -- Allows NPC firearms other than revolvers to jam: the gun clicks instead of firing, then the NPC racks it clear.
        -- Default on.
        Combat_EnableJamming = true,
        -- Moving vehicles hurt NPCs they hit, with damage based on speed. Off: collisions do no NPC damage. Intact car windows still protect you from NPC attacks either way.
        -- Default on.
        Combat_VehicleDamage = true,
        -- On: NPCs do not start fights in non-PvP zones, but still retaliate against an attacker. Off: NPCs may attack there. Safehouses protect you either way.
        -- Default off.
        Combat_NonPvpZoneShield = false,
        -- Hits cause bruises, fractures, cuts, bullet wounds or bites. Leg wounds slow NPCs, arm wounds spoil aim, and open wounds bleed until bandaged; below 10 percent health, bleed-out is rapid.
        -- Default on.
        Combat_Wounds = true,
        -- Your shoves briefly stagger NPCs, and melee hits interrupt their next swing. A staggered NPC cannot finish its attack.
        -- Default on.
        Outplay_Stagger = true,
        -- Zombies use the game's bite and scratch attack animations when attacking NPCs.
        -- Default on.
        Zombies_AttackAnims = true,
        -- Enough zombies grabbing one NPC at once drag it down and kill it, with the game's being-eaten voice.
        -- Default on.
        Zombies_DragDown = true,
        -- Sets how many zombies must grab an NPC at the same time to drag it down. For example, 4 requires four simultaneous attackers.
        -- Default 4. Min: 2 Max: 8 Default: 4
        Zombies_DragDownCount = 4,
        -- A teammate or friendly ally from the same bloc who can see a downed NPC walks over and bandages it. The rescued NPC stands up limping.
        -- Default on.
        Injury_Rescue = true,
        -- Rescuers drag downed NPCs away before bandaging when zombies or hostiles are within 12 tiles. Off: rescue cannot start with danger that close.
        -- Default on.
        Injury_RescueDrag = true,
        -- Allows rescues while players are near or watching. Off: rescuers wait until all players are beyond the nearby-player distance set under expert combat.
        -- Default on.
        Injury_RescueInView = true,
        -- Downed NPCs crawl away from zombies and hostiles toward their group, and occasionally shuffle instead of lying still.
        -- Default on.
        Injury_Crawl = true,
        -- Sets the time from getting up with low health to full health and a normal walk. For example, 12 means half a game day of recovery.
        -- Default 8. Min: 1 Max: 72 Default: 8
        Injury_RecoverHours = 8,
        -- Sets how long a downed NPC waits without help before getting up on its own, still limping. For example, 6 means a quarter of a game day.
        -- Default 4. Min: 1 Max: 48 Default: 4
        Injury_DownHours = 4,
        -- Civilians, families and workers flee zombies, flinch at loud events and spread fear early in the outbreak. Soldiers, police and criminals stay steadier. Requires Civilian fear of zombies.
        -- Default on.
        Panic_FirstDays = true,
        -- Stretches or shortens the early-outbreak panic curve. Fright is strongest at the start and nearly gone by this many days after the outbreak.
        -- Default 12. Min: 2 Max: 60 Default: 12
        Panic_LengthDays = 12,
        -- Civilians, families and workers avoid distant zombies and flee crowds for at least 30 seconds, fighting if cornered. Soldiers, police, criminals and hardened members stay steadier.
        -- Default on.
        Modules_Fear = true,
        -- Poorly armed NPCs back away from a player or hostile aiming or raising a firearm. The Creator determines which factions and members have this fear.
        -- Default on.
        GunFear_Enabled = true,
        -- Sets the warning-to-scout delay; the raid follows its buildup. 0 sends scouts immediately. Scouts and raiders walk in from 40-50 tiles away, unseen and away from player bases.
        -- Default 3. Min: 0.00 Max: 24.00 Default: 3.00
        Raid_WarningHours = 3.0,
        -- Allows all A-Life helicopters: raid and backup arrivals, night searchlights and flyovers. Off: none of these helicopters fly.
        -- Default on.
        Raid_Helicopter = true,
        -- Off: hostile crews attack on sight. On: reputation sets how many attack on sight (Expert page); the rest demand surrender or warn first. Careful factions keep their own rules.
        -- Default on.
        Warning_Enabled = true,
        -- Sets the share of raids, assassins, highway ambushers and admin-spawned attackers that warn first. A bad reputation lowers it, a good one raises it. 0 makes all of them attack on sight.
        -- Default 10. Min: 0 Max: 100 Default: 10
        Warning_RaidChancePercent = 10,
        -- Limits unanswered warnings, standoffs and hold-ups. A crew waits four fifths of this per warning or demand before the next step. Replies restart the clock, up to four times this limit.
        -- Default 8. Min: 2 Max: 60 Default: 8
        Warning_HoldSeconds = 8,
        -- Crews that warn may question you, demand a toll or call you outside before fighting. Silence, leaving, a raised gun or betrayal can start a fight. Off: only their attack warning remains.
        -- Default on.
        Encounter_Standoffs = true,
        -- Scales how often crews call hidden players outside instead of searching; police do this more than raiders. Player bases are always called out first. 0 disables ordinary callouts.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Encounter_CalloutPercent = 100,
        -- Limits revenge groups sent after a player for one grudge. Each is drawn from the original crew's survivors plus at most two reinforcements.
        -- Default 2. Min: 1 Max: 10 Default: 2
        Revenge_MaxWaves = 2,
        -- Game hours between hunts sent by each hostile outpost. From day 7, after dark, one crew per player. Uses faction sightings refreshed every 24 game hours. At 0, off.
        -- Default 72. Min: 0 Max: 168 Default: 72
        Assassins_GapHours = 72,
        -- Crews weigh guns, ammo, distance and nearby zombies before attacking a player, and avoid poor odds. Crews sent to attack and NPCs you have hurt still fight.
        -- Default on.
        Discretion_Enabled = true,
        -- Careful factions can calm down after provocation once their waiting time passes. Naturally hostile factions and grudges from real attacks do not fade this way.
        -- Default on.
        CalmDown_Enabled = true,
        -- Adds floor splatter, bleeding drips and death pools, respecting the game's blood settings. Off: only the game's ordinary splatter and body stains remain.
        -- Default on.
        Blood_Enabled = true,
        -- Scales floor splatter, body stains, drips and pools from non-melee deaths. At 100, only the earlier body-stain behavior remains.
        -- Default 200. Min: 100 Max: 500 Default: 200
        Blood_Percent = 200,
        -- NPCs leave distant zombies alone unless they approach, threaten a friend or are near the NPC's post, helping the group stay on task.
        -- Default on.
        ZombieFocus_Enabled = true,
        -- Travelling NPCs avoid zombie groups by skipping buildings, detouring, waiting or backing off. They still fight zombies that are close or coming at them.
        -- Default on.
        Caution_Enabled = true,
        -- Unvisited scavenged buildings may have fewer valuables and signs of looting. Never changes buildings players entered, player bases, safehouses or outposts.
        -- Default on.
        PickedOver_Enabled = true,
        -- Scales the chance that a building is already scavenged. 100 keeps the usual chance, 300 triples it and 0 disables it.
        -- Default 100. Min: 0 Max: 300 Default: 100
        PickedOver_Strength = 100,
        -- Sets the base chance before building type and rate scaling. Nearby scavenging adds up to 60 percentage points before those adjustments.
        -- Default 5. Min: 0 Max: 100 Default: 5
        PickedOver_Baseline = 5,
        -- Already scavenged buildings may show open doors, broken windows and blood. These signs are placed only while every player is at least 40 tiles away.
        -- Default on.
        PickedOver_Visuals = true,
        -- Already scavenged buildings may contain one or two dead zombies.
        -- Default on.
        PickedOver_ZombieCorpses = true,
        -- A building may rarely contain a dead member of the group that scavenged the area, wearing that group's clothes and carrying its gear.
        -- Default on.
        PickedOver_FactionCorpses = true,
        -- NPCs killed in battles away from players leave dressed bodies at the battle site. Bodies are placed while players are 40-110 tiles away and forgotten after 14 game days.
        -- Default on.
        WarDead_Enabled = true,
        -- A melee NPC turns to face its target and swings only when the target is inside the swing angle. After 0.6 seconds it swings anyway, so it never freezes.
        -- Default on.
        Combat_FaceBeforeSwing = true,
        -- How far off its target a melee NPC may be facing and still swing. Lower is stricter. Needs the turn-before-swing option on.
        -- Default 35. Min: 10 Max: 90 Default: 35
        Combat_SwingAngleDegrees = 35,
        -- An NPC prefers the zombie that is biting or clawing it over a nearer or lower one, so it does not keep swinging at a crawler while another zombie chews on it.
        -- Default on.
        Combat_GrabberFirst = true,
        -- An NPC ordered to surrender lowers its hands this long after the player walked off or stopped paying attention. A hands-up pose with no owner at all is cleared after the same time.
        -- Default 60. Min: 10 Max: 600 Default: 60
        Orders_CaptiveReleaseSeconds = 60,
        -- NPC gunfire makes one noise per burst. Shots closer together than this make no new noise, so zombies keep walking. Nearby shooters share one noise.
        -- Default 1500. Min: 200 Max: 10000 Default: 1500
        Combat_ShotNoiseGapMs = 1500,
        -- A zombie lunges at an NPC only when the NPC is inside this angle in front of it. Outside it the zombie turns and walks closer first. 180 turns the check off.
        -- Default 75. Min: 20 Max: 180 Default: 75
        Zombies_LungeConeDegrees = 75,
        -- A zombie starts hunting an NPC it merely sees only inside this distance. Gunfire and a target it already has still reach further. Lower means NPCs are left alone from farther away.
        -- Default 12. Min: 4 Max: 30 Default: 12
        Zombies_NpcTargetTiles = 12,
        -- A zombie hunting an NPC by sight drops the chase once the NPC is farther than this. A chase drawn by gunfire follows the gunfire range instead.
        -- Default 20. Min: 8 Max: 40 Default: 20
        Zombies_NpcClearTiles = 20,
        -- Lets your profession affect how NPCs treat you, including Creator rules. Off: profession has no attitude effect; faction and folder relations still apply.
        -- Default off.
        ProfessionAffectsAttitude = true,
        -- The Toggle chat key opens a small chat line for talking to NPCs in single player. Start a message with ! to shout.
        -- Default on.
        Talk_SinglePlayerChat = true,
        -- Friendly and neutral NPCs notice you nearby, stop and look when you speak. Passing friends greet you; outlaw groups call out strangers.
        -- Default on.
        Talk_Presence = true,
        -- An NPC you talk to stops walking, turns to face you and picks its old task back up when the talk ends. Hostile NPCs, fighters and drivers are never held.
        -- Default on.
        Talk_HoldNpc = true,
        -- NPCs add small hand and body gestures while they speak to you, matched to the mood of the line. They never gesture while fighting or aiming.
        -- Default on.
        Talk_Gestures = true,
        -- Fresh survivors avoid unprovoked fights, but hostile relations, grudges and self-defence still allow attacks. Veterans and predators ignore this caution.
        -- Default on.
        Talk_RiskAssessment = true,
        -- Non-enemy groups within eight tiles may stop and talk, then part or walk together briefly. Off disables meetings; fights, fleeing and player orders always interrupt.
        -- Default Normal (3). Default = Normal
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Often
        Talk_GroupMeetings = 3,
        -- How often calm groups start talking. At 200, conversations happen twice as often; at 50, half as often.
        -- Default 100. Min: 10 Max: 400 Default: 100
        Chatter_Frequency = 100,
        -- Chance that an NPC greets you or another NPC while passing. Friendly people greet more, wary people less, enemies never. At 0, passing greetings stop.
        -- Default 70. Min: 0 Max: 100 Default: 70
        Chatter_PassingGreetPercent = 70,
        -- Maximum group conversations happening at once. Lower values keep speech easier to follow in crowded places.
        -- Default 3. Min: 1 Max: 8 Default: 3
        Chatter_MaxConcurrent = 3,
        -- Lets you order NPCs to raise their hands, drop weapons, leave or follow. Obedience depends on fear, faction, weapons and group size.
        -- Default on.
        Orders_Enabled = true,
        -- Scales the chance an NPC obeys a spoken order. At 0, nobody obeys; at 200, obedience is twice as likely. Civilians are easier to command than armed factions.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Orders_Chance = 100,
        -- Chance the target and their group attack after refusing hands-up, drop-weapon or hold-up orders. At 100, they always attack; at 0, they only refuse.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Orders_FailFight = 100,
        -- A surrendering NPC lowers their hands and reacts when a zombie comes within this distance.
        -- Default 4. Min: 1 Max: 8 Default: 4
        Orders_ZombieTiles = 4,
        -- Longest time an NPC keeps their hands up before lowering them and carrying on.
        -- Default 90. Min: 10 Max: 600 Default: 90
        Orders_SurrenderSeconds = 90,
        -- How much weapons, loaded ammo, armour, numbers, distance and clear sight affect obedience. At 0, these advantages do not matter; at 300, they dominate the decision.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Orders_Advantage = 100,
        -- When one member surrenders, each groupmate chooses whether to obey, fight or flee after a warning. Off: the whole group always follows the surrendering member.
        -- Default on.
        Orders_GroupSurrender = true,
        -- Robbed NPCs flee, then remember you as dangerous and keep their distance for this long. At 0, this caution is not remembered.
        -- Default 15. Min: 0 Max: 240 Default: 15
        Orders_CarefulMinutes = 15,
        -- Opening a calm NPC's talk menu makes them stop, face you and greet you before choices appear. Fighting or frightened NPCs are not interrupted.
        -- Default on.
        Talk_GreetOnOpen = true,
        -- NPCs remember repeated questions, lose patience and react to your tone. Off: no question memory or opinion changes from words; deeds still count.
        -- Default on.
        Talk_AntiSpam = true,
        -- Prioritises useful replies, marks asked questions and hides unsuitable choices, such as personal questions for strangers. Requires conversation memory and patience.
        -- Default on.
        Talk_MenuFocus = true,
        -- Within this time, a repeated question gets an already-answered reply and no opinion gain. Personal-life answers stay remembered for a full game day.
        -- Default 30. Min: 1 Max: 600 Default: 30
        Talk_RepeatCooldownMinutes = 30,
        -- Base number of questions an NPC will answer. NPCs who like you allow more; those who dislike you allow fewer. After warning that patience is spent, they end the talk.
        -- Default 10. Min: 2 Max: 30 Default: 10
        Talk_QuestionsPerTalk = 10,
        -- After ending an overlong or irritating conversation, the NPC refuses to answer and closes the talk window until this time passes.
        -- Default 60. Min: 5 Max: 1440 Default: 60
        Talk_RefuseMinutes = 60,
        -- Talks needed before family and past-life questions open up, unless the NPC already likes you. Asking too early lowers their opinion.
        -- Default 2. Min: 1 Max: 10 Default: 2
        Talk_PersonalAfterTalks = 2,
        -- Scales how much polite, nosy, rude or kind words change an NPC's opinion. At 0, words do not change opinion; repetition, patience and refusals still work.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Talk_OpinionFromTalk = 100,
        -- Limits opinion gained from words in one talk; losses stop at one and a half times this amount. Twenty quiet game minutes begin a new conversation.
        -- Default 6. Min: 1 Max: 40 Default: 6
        Talk_OpinionCapPerConversation = 6,
        -- Limits opinion gained from words with each NPC per game day. Losses stop at one and a half times this amount.
        -- Default 12. Min: 1 Max: 100 Default: 12
        Talk_OpinionCapPerDay = 12,
        -- Conversation cannot raise an NPC's opinion above this score. Beyond it, gifts, healing or fighting beside them must earn further trust.
        -- Default 40. Min: 0 Max: 100 Default: 40
        Talk_OpinionWordCeiling = 40,
        -- Each NPC remembers a separate opinion of each player, shaped by temperament, reputation and deeds toward their group. Shown in conversations. Off disables individual opinions.
        -- Default on.
        Reputation_NpcOpinion = true,
        -- Scales how deeds change an NPC's opinion. At normal strength, a gift gives about 8 points, a hit loses 20 and killing a groupmate loses 45; others may hear about it.
        -- Default 100. Min: 25 Max: 300 Default: 100
        Reputation_NpcOpinionScale = 100,
        -- Scales opinion's effect on prices, replies, invitations, company, deals, greetings, betrayal and orders. At 0, opinion is displayed but has no gameplay effect.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Reputation_NpcOpinionEffects = 100,
        -- How far each NPC's opinion moves back toward its starting value each day. At 0, the NPC never forgets.
        -- Default 3. Min: 0 Max: 20 Default: 3
        Reputation_NpcOpinionDecay = 3,
        -- Radio stories may name players after lasting reputation changes, fighting sprees or surviving raids. Requires personal reputation; never reveals the player's location.
        -- Default on.
        Reputation_RadioNames = true,
        -- Allows radio stories about a player's bad reputation. Off: only neutral or positive mentions are broadcast.
        -- Default on.
        Reputation_RadioBadNews = true,
        -- Food gifts and fair trades improve standing with the visitor's faction. Off: these choices do not change faction standing; existing grudges remain.
        -- Default Off (1). Default = Off
        -- 1 = Off
        -- 2 = On
        Reputation_Mode = 1,
        -- How quickly earned faction standing returns toward zero. At 200, it fades twice as fast; at 0, earned standing stays unchanged.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Reputation_DecayPercent = 100,
        -- New characters reset personal reputation, faction standing and NPC memories, not faction or Creator relations. Off keeps the old values. Reconnecting never resets the same character.
        -- Default on.
        Reputation_ResetOnNewCharacter = true,
        -- The T-menu reputation answer also lists other players' reputation levels on the server. Off shows only your own.
        -- Default off.
        Reputation_ShowOthers = false,
        -- Killing an NPC already in a fight counts as a hostile kill and is not held against you. Off judges each kill by the NPC's attitude toward you.
        -- Default on.
        Reputation_NpcFightIsHostile = true,
        -- Points of personal reputation that drift toward neutral each day. At 0, your earned reputation stays unchanged.
        -- Default 5. Min: 0 Max: 50 Default: 5
        Reputation_DriftPerDay = 5,
        -- Scales personal reputation changes from kills and from deeds (visitors, hosting, gifts, treating, trading). At 0 none count; at 200 they count twice as much.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Reputation_KillScale = 100,
        -- Limits reputation gained from kills each day at full rate; extra hostile kills count at the reduced share below. Deeds get their own limit of 150 percent of this.
        -- Default 60. Min: 0 Max: 1000 Default: 60
        Reputation_GainCapPerDay = 60,
        -- Share of normal gain earned for hostile or criminal kills after the daily limit, with at least 1 point per kill. At 0, no further gain is possible that day.
        -- Default 25. Min: 0 Max: 100 Default: 25
        Reputation_OverCapPercent = 25,
        -- Extra points beyond a level boundary needed before your reputation label changes. Higher values reduce frequent label changes.
        -- Default 15. Min: 0 Max: 100 Default: 15
        Reputation_Hysteresis = 15,
        -- Personal reputation gained for killing an NPC who was hostile toward you.
        -- Default 10. Min: 0 Max: 200 Default: 10
        Reputation_KillHostile = 10,
        -- Personal reputation gained for killing an NPC from a criminal faction.
        -- Default 15. Min: 0 Max: 200 Default: 15
        Reputation_KillCrime = 15,
        -- Personal reputation lost for killing a neutral or cautious NPC who meant you no harm.
        -- Default 40. Min: 0 Max: 500 Default: 40
        Reputation_KillNeutral = 40,
        -- Personal reputation lost for killing an NPC who regarded you as a friend.
        -- Default 80. Min: 0 Max: 500 Default: 80
        Reputation_KillFriendly = 80,
        -- Personal reputation lost for killing an NPC who had surrendered.
        -- Default 100. Min: 0 Max: 500 Default: 100
        Reputation_KillSurrendered = 100,
        -- Hides faction, rank, mood and standing in the talk window. Shows only a name you have learned and held items. Off restores the full heading.
        -- Default on.
        Talk_MysteryMode = true,
        -- Survivors may ask about your travels or how you cope: up to two questions per talk, then a ten-real-minute cooldown. Not during combat, injury or surrender.
        -- Default on.
        Talk_NpcQuestions = true,
        -- Shows requests for an NPC to follow you or walk alongside you. These conversation choices are still being reworked.
        -- Default off.
        Talk_FollowOptions = false,
        -- Visitor and ambient NPC lines show over their heads only within this many tiles, and only if you can see them or stand by the door. 0 shows them at any distance.
        -- Default 14. Min: 0 Max: 60 Default: 14
        Text_VisitorRangeTiles = 14,
        -- NPC speech appears as a bubble with the speaker's name and a pointer. A speaker off screen gets an edge arrow and the distance. Off: the game's plain floating text.
        -- Default on.
        Text_Bubbles = true,
        -- Shows a clickable Talk or Answer button while a visitor waits at your door or someone has just asked you something. Right-click still works.
        -- Default on.
        Talk_StartButton = true,
        -- Uses each faction's view of your profession when choosing nearby encounters. Off: every profession uses that faction's general attitude.
        -- Default on.
        Reputation_ProfessionEncounters = true,
        -- During the first week, NPCs from a similar background may recognise your former profession, such as police recognising police. Requires personal reputation.
        -- Default on.
        Reputation_ProfessionRecognition = true,
        -- With multiple players, outpost theft blames those inside the outpost rather than everyone. A manhunt keeps its named target instead of switching to the nearest player.
        -- Default on.
        Blame_Fair = true,
        -- Extra no-spawn distance around claimed multiplayer safehouses. At 8, new NPCs cannot spawn within eight extra tiles of the claim.
        -- Default 8. Min: 0 Max: 50 Default: 8
        World_SafehouseClearance = 8,
        -- Adds a right-click peephole view on closed doors. Each player can also turn it off in their own mod options.
        -- Default on.
        Peek_Enabled = true,
        -- Every few seconds, an NPC within two tiles of the door may hear you peeking and speak. They cannot see you through the peephole. At 0, peeking is never heard.
        -- Default 5. Min: 0 Max: 100 Default: 5
        Peek_NoticeChancePercent = 5,
        -- Crews of two or more may settle in an empty building away from players, store their loot and return after trips.
        -- Default on.
        Activities_Bases = true,
        -- Caps settled NPC bases across the world. If the limit is exceeded, the oldest base is abandoned. At 0, crews cannot found new bases.
        -- Default 6. Min: 0 Max: 24 Default: 6
        Activities_MaxBases = 6,
        -- Chance that each eligible crew founds a base, checked once per game day.
        -- Default 25. Min: 0 Max: 100 Default: 25
        Activities_BaseChance = 25,
        -- Time a crew with a base spends away before planning a return home.
        -- Default 8. Min: 2 Max: 48 Default: 8
        Activities_BaseReturnHours = 8,
        -- Minimum distance from any player when an NPC crew founds a base.
        -- Default 45. Min: 20 Max: 120 Default: 45
        Activities_BaseClearTiles = 45,
        -- Normal outposts start within this distance, at least 40 tiles from players. Fixed checkpoints may start up to 200 tiles away; all need loaded ground.
        -- Default 120. Min: 60 Max: 200 Default: 120
        Outposts_BuildRadius = 120,
        -- Share of destroyed or burned walls, doors, windows and fences that causes an outpost to be removed. At 0, this damage-based removal is disabled.
        -- Default 40. Min: 0 Max: 100 Default: 40
        Outposts_StructureLossPercent = 40,
        -- A built outpost receives its garrison when a player comes within this distance.
        -- Default 90. Min: 40 Max: 150 Default: 90
        Outposts_SpawnRadius = 90,
        -- Residents slowly carry zombie corpses out of loaded buildings to reduce corpse sickness. Never removes player or NPC corpses, or corpses in claimed player safehouses.
        -- Default on.
        Residents_ClearCorpses = true,
        -- Controls notes, gifts, visitors and attacks at claimed safehouses or buildings you live in. Off disables these base events.
        -- Default Normal (3). Default = Normal
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Often
        Safehouse_Events = 3,
        -- Some visitors may lie about why they came. They give a warning sign before you open the door.
        -- Default on.
        Safehouse_Betrayal = true,
        -- Only when invited: visitors enter after you let them in at the door. Never: all visitors remain outside.
        -- Default Only when invited (1). Default = Only when invited
        -- 1 = Only when invited
        -- 2 = Never
        Safehouse_Entry = 1,
        -- Time after a place becomes your base before its first base event can happen.
        -- Default 3. Min: 0 Max: 14 Default: 3
        Safehouse_QuietDays = 3,
        -- Allows base events on dedicated servers while at least one resident is online. Off disables them there. Single player and co-op do not need this switch.
        -- Default on.
        Safehouse_Dedicated = true,
        -- Radio messages, door marks, knocks, distant gunfire and dog barks can happen in the world. Off leaves text notices only.
        -- Default on.
        Events_ScriptedEffects = true,
        -- Tunes and switches on a nearby radio for base-event messages, then turns it off. No radio: text only. Requires physical and audible base-event effects.
        -- Default on.
        Events_RadioActivate = true,
        -- Travellers may visit your door with goods to trade. Their trading conversation is still being reworked.
        -- Default off.
        Safehouse_TraderVisits = false,
        -- Places washable wall marks by the door: up to four, fading after ten game days. Off gives text only. Requires physical and audible base-event effects.
        -- Default on.
        Events_WallMarks = true,
        -- Time an invited visitor waits for the door to open before giving up.
        -- Default 10. Min: 2 Max: 60 Default: 10
        Safehouse_InviteMinutes = 10,
        -- Visitors face the door and wait for roughly two thirds to four thirds of this duration. Opening the door, talking or attacking ends it immediately. At 0, no initial wait.
        -- Default 30. Min: 0 Max: 120 Default: 30
        Safehouse_VisitorHoldSeconds = 30,
        -- Hear visitors knock at doors or windows from about 50 tiles away. Break-ins sound when the first inside door opens. Off: text notices only.
        -- Default on.
        Safehouse_KnockSounds = true,
        -- Chance that an overnight guest refuses to leave in the morning until you talk them out.
        -- Default 15. Min: 0 Max: 100 Default: 15
        Safehouse_SquatPercent = 15,
        -- Chance that a wounded visitor is secretly bitten. Bitten visitors refuse to be searched.
        -- Default 15. Min: 0 Max: 100 Default: 15
        Safehouse_BittenPercent = 15,
        -- Minimum time between a hostile group's threat letter, door mark, sabotage and eventual attack.
        -- Default 48. Min: 12 Max: 240 Default: 48
        Safehouse_LadderGapHours = 48,
        -- In SP/co-op, recognised bases block NPC spawning, shelter, loot and uninvited non-hostiles. Off: any slept-in or built-at place blocks spawns, as on dedicated servers.
        -- Default on.
        Safehouse_BaseFlag = true,
        -- Points needed to recognise a base, with at least two kinds of evidence. A night adds 20, a day there 10, a running generator 20 and a claim 30.
        -- Default 100. Min: 20 Max: 400 Default: 100
        Safehouse_BaseScore = 100,
        -- Chance of an event at an eligible house. Rare halves this chance; Often increases it by half.
        -- Default 12. Min: 1 Max: 100 Default: 12
        Safehouse_ChancePercent = 12,
        -- Time between event checks at the same house.
        -- Default 2. Min: 1.00 Max: 24.00 Default: 2.00
        Safehouse_CheckHours = 2.0,
        -- Minimum gap between events at one house. Rare doubles the gap; Often halves it, but never below one game day.
        -- Default 2. Min: 0.50 Max: 14.00 Default: 2.00
        Safehouse_GapDays = 2.0,
        -- Minimum gap between two visits to the same house.
        -- Default 1. Min: 1 Max: 30 Default: 1
        Safehouse_VisitGapDays = 1,
        -- Minimum gap between attacks on the same house.
        -- Default 1. Min: 1 Max: 60 Default: 1
        Safehouse_AttackGapDays = 1,
        -- World age before the first attack on a house is allowed.
        -- Default 14. Min: 0 Max: 365 Default: 14
        Safehouse_AttackMinDay = 14,
        -- Above this many zombies within 40 tiles of the front door, only armed groups visit.
        -- Default 10. Min: 0 Max: 200 Default: 10
        Safehouse_DensityMid = 10,
        -- Above this many zombies within 40 tiles of the front door, nobody visits and notes arrive half as often.
        -- Default 30. Min: 0 Max: 400 Default: 30
        Safehouse_DensityHigh = 30,
        -- Above this many zombies within 40 tiles of the front door, nothing is left at the house.
        -- Default 60. Min: 0 Max: 800 Default: 60
        Safehouse_DensityExtreme = 60,
        -- Notes and gifts can be left when every resident is at least this far from the delivery point and is not looking toward it.
        -- Default 40. Min: 10 Max: 60 Default: 40
        Safehouse_AwayTiles = 40,
        -- Notes and gifts can also be left when every resident is at least this far away, is not looking toward the delivery point and cannot see it.
        -- Default 20. Min: 5 Max: 60 Default: 20
        Safehouse_HiddenTiles = 20,
        -- How long a note waits for a safe delivery opportunity before it expires without being delivered.
        -- Default 3. Min: 1 Max: 14 Default: 3
        Safehouse_DropDeadlineDays = 3,
        -- Notes go into a mailbox within this distance of the front door. Without one, they are left on the porch.
        -- Default 10. Min: 2 Max: 20 Default: 10
        Safehouse_MailboxTiles = 10,
        -- Outposts start with one or two ground-floor planks, adding more every four game days while players stay over 40 tiles away. Upstairs gets sheets; metal bars stay unchanged.
        -- Default on.
        Boarding_Staged = true,
        -- Limits new walled compounds. At 0, none are proposed. Existing sites, small camps, checkpoints and admin-built sites stay.
        -- Default 1. Min: 0 Max: 40 Default: 1
        Outposts_MaxCompounds = 1,
        -- Minimum distance between new walled compounds. Recently expired sites count until cleared. Small camps and fixed checkpoints are unchanged.
        -- Default 500. Min: 0 Max: 5000 Default: 500
        Outposts_CompoundSpacing = 500,
        -- Keeps campfires, lamps and generators in outposts, compounds, checkpoints and camps burning and switched on, refuelled while a player is near. Off leaves them as built.
        -- Default on.
        Outposts_LightsOn = true,
        -- New outposts and installation-type encounters stay at least this far from claimed safehouses and player-built bases. Raise it if one appears too close to your base.
        -- Default 45. Min: 10 Max: 200 Default: 45
        Outposts_PlayerKeepOutTiles = 45,
        -- How often a guest inside your home starts talking by themselves, for example asking about the TV. Rare waits longer, Often waits less. Off: guests only answer when you talk.
        -- Default Normal (3). Default = Normal
        -- 1 = Off
        -- 2 = Rare
        -- 3 = Normal
        -- 4 = Often
        Visitors_ProactiveEvents = 3,
        -- Real seconds that must pass after a guest speaks up before the same player is prompted again. Higher is calmer.
        -- Default 240. Min: 60 Max: 1800 Default: 240
        Visitors_EventMinGapSeconds = 240,
        -- A guest never stays inside longer than this. Most guests leave sooner. Raise it to let people ask to stay for a few nights; more time inside means more risk and more help.
        -- Default 1. Min: 1 Max: 48 Default: 1
        Visitors_StayHours = 1,
        -- Pairs and trios of related people can knock together instead of one stranger at a time. Off: one visitor per visit.
        -- Default on.
        Visitors_Parties = true,
        -- Once you have really helped someone, this chance decides whether a later visit is that person coming back. 0 means never.
        -- Default 15. Min: 0 Max: 50 Default: 15
        Visitors_ReturningChance = 15,
        -- Guests inside your home walk around, sit on furniture, read and look out of windows instead of standing where they were let in. Off: they stand still.
        -- Default on.
        Visitors_Life = true,
        -- Adult guests can ask for clean clothes and change in a closed room, down to the default body and never beyond. Off: no clothes changes.
        -- Default on.
        Visitors_ChangeClothes = true,
        -- Strict: a guest only changes in a room with the door shut, and not while you stand near the door. Normal: the door may be open.
        -- Default Strict (1). Default = Strict
        -- 1 = Strict
        -- 2 = Normal
        Visitors_Privacy = 1,
        -- Adult guests can show gentle, optional, non-explicit warmth after real trust and always accept a no. Off: no flirting at all.
        -- Default On (2). Default = On
        -- 1 = Off
        -- 2 = On
        Visitors_Flirt = 2,
        -- Guests can carry and read books and newspapers and discuss them with you. Off: no book conversations.
        -- Default on.
        Visitors_Books = true,
        -- Words spoken by guests also appear in the chat window, not only as speech bubbles. Needs the chat mirror of the talk interface.
        -- Default on.
        Visitors_ChatMirror = true,
        -- A companion lights a torch at night or in a dark building only when she carries a charged hand torch. Off: she lights one without owning it.
        -- Default on.
        Companions_TorchNeedsItem = true,
        -- Game hours a full battery lasts while a companion's torch is lit. 0: the battery never drains.
        -- Default 12. Min: 0 Max: 240 Default: 12
        Companions_TorchHours = 12,
        -- Following companions walk to the car you sit in and take a free seat, and get out when you do. Companions on hold or wait never board. Off: only the Get in the car order seats them.
        -- Default on.
        Companions_AutoBoard = true,
        -- Lets players open the companion sheet (stats, tasks, journal and gear) from the order wheel, the right-click menu, the journal and the admin console. Turn off to hide every entry point.
        -- Default on.
        Companion_SheetEnabled = true,
        -- The owner of a companion can look at what they carry, take or hand over items, drop items and change their weapon from the Gear tab. Other players can only look.
        -- Default on.
        Companion_SheetInventory = true,
        -- Allows hostile looters to take nearby supplies.
        -- Default on.
        Behavior_Scavenge = true,
        -- Hostile NPCs may walk toward gunfire, shouts and other signs of activity they notice.
        -- Default on.
        Behavior_Investigate = true,
        -- Outside combat, the last group member closes doors the group opened. Player-opened doors and occupied doorways stay untouched; no locks are changed.
        -- Default on.
        Behavior_CloseDoors = true,
        -- Allows eligible NPC guns and melee weapons to remain on their bodies for looting. The weapon drop chance still applies.
        -- Default on.
        Drops_WeaponsEnabled = true,
        -- Sets dropped weapon condition, not NPC combat strength. Per NPC profile keeps its rating and early-game wear curve; Broken needs repairs before use.
        -- Default Per NPC profile (1). Default = Per NPC profile
        -- 1 = Per NPC profile
        -- 2 = Broken (0/10)
        -- 3 = Scrap, a shot or two (1/10)
        -- 4 = Very poor, a few shots (2/10)
        -- 5 = Poor (3/10)
        -- 6 = Worn (4/10)
        -- 7 = Used, half gone (5/10)
        -- 8 = Serviceable (6/10)
        -- 9 = Good (7/10)
        -- 10 = Very good (8/10)
        -- 11 = Near new (9/10)
        -- 12 = Issue fresh (10/10)
        Drops_WeaponCondition = 1,
        -- Only military and special-response crews can drop rare armor, dirty and at 10-40 percent condition. 0 stops these drops. Sledgehammers and crafting components never drop.
        -- Default 5. Min: 0 Max: 100 Default: 5
        Loot_RareDropPercent = 5,
        -- On: Creator profiles keep their chosen rare gear. Off: custom sledgehammers, crafting heads and heavy armor are replaced with common gear at spawn.
        -- Default off.
        Loot_AllowRareFromProfiles = false,
        -- When not fighting, NPCs search areas with signs that survivors are nearby, such as barricades or a running generator.
        -- Default on.
        Clues_Enabled = true,
        -- Running or hotwired vehicles attract NPC searches in the surrounding area.
        -- Default on.
        Clues_Vehicles = true,
        -- Planks on doors and windows make NPCs treat a building as occupied and worth investigating.
        -- Default on.
        Clues_Barricades = true,
        -- Player-built walls, gates and fences make NPCs treat a place as occupied and worth investigating.
        -- Default on.
        Clues_PlayerBuilt = true,
        -- A running generator gives NPCs a strong sign that someone lives nearby, attracting investigation.
        -- Default on.
        Clues_Power = true,
        -- Scales how readily NPCs investigate survivor traces. Higher values let weaker evidence draw a search; lower values require stronger evidence.
        -- Default 1.0. Min: 0.25 Max: 5.00 Default: 1.00
        Clues_WeightMultiplier = 1.0,
        -- How many survivors may search the same trace at once. The rest pick another trace or carry on. Lower stops crowds gathering at one spot.
        -- Default 2. Min: 1 Max: 8 Default: 2
        Clues_MaxSearchersPerZone = 2,
        -- Most survivors within about 25 tiles of a player that may answer sounds or search traces at once. 0 turns the limit off.
        -- Default 4. Min: 0 Max: 24 Default: 4
        Clues_MaxInvestigatorsNearPlayer = 4,
        -- After one search of a trace finishes, nobody else is sent to it for this long.
        -- Default 90. Min: 0 Max: 1800 Default: 90
        Clues_ZoneCooldownSeconds = 90,
        -- A car left running draws survivors for this long, then stops counting as a fresh trace until its engine is restarted.
        -- Default 5. Min: 1 Max: 120 Default: 5
        Clues_VehicleFreshMinutes = 5,
        -- After fights, NPCs near players loot bodies when no danger is within 15 tiles, taking supplies and useful gear. Player bodies and former player companions' bodies are left alone.
        -- Default on.
        BodyLoot_Enabled = true,
        -- Caps how many bodies one group searches each real minute. For example, 2 prevents it searching more than two corpses in a minute.
        -- Default 3. Min: 1 Max: 20 Default: 3
        BodyLoot_PerMinute = 3,
        -- Adds a survivor-run station with scanner traffic, military chatter, calls, stories, jokes and rumors about events in your world.
        -- Default on.
        Radio_KnoxCounty = true,
        -- Choose an unused frequency; 100000 means 100 MHz. Other channels are never replaced. Restart the server after changes, then open a radio to add the matching preset.
        -- Default 99600. Min: 88000 Max: 108000 Default: 99600
        Radio_KnoxFrequency = 99600,
        -- Free groups choose goals such as supplies or shelter, discuss them and follow through until done, blocked, hurt or threatened. Off: groups return to travelling and idling.
        -- Default on.
        Plans_Enabled = true,
        -- Sets how far a group looks for a building to visit for its plan. Nearby buildings are preferred; 80 limits the search to 80 tiles.
        -- Default 100. Min: 40 Max: 200 Default: 100
        Plans_Radius = 100,
        -- Sets how long a group keeps a plan before giving up and choosing again. Shelter plans last until morning.
        -- Default 6. Min: 1 Max: 48 Default: 6
        Plans_LifespanHours = 6,
        -- Groups discuss plans before leaving and speak when they arrive or give up. Off: they still follow plans, but silently.
        -- Default on.
        Plans_Talk = true,
        -- Crews can move on after an encounter, such as fixing a car then scavenging from it. Distant groups plan around supplies. Off: crews keep their earlier behavior.
        -- Default on.
        Activities_Enabled = true,
        -- Sets the share of finished encounters whose crews take up another activity. The rest keep their post and later leave as before; higher values put more crews on roads.
        -- Default 70. Min: 0 Max: 100 Default: 70
        Activities_SwitchChance = 70,
        -- Allows armed NPC crews to hunt. Offline only allows hunting away from players and leaves nearby wildlife to you.
        -- Default Offline and nearby wildlife (3). Default = Offline and nearby wildlife
        -- 1 = Off
        -- 2 = Offline only
        -- 3 = Offline and nearby wildlife
        Activities_Hunting = 3,
        -- A crew stuck at a broken or crashed car this long may leave it and go scavenging, but only when no player is nearby.
        -- Default 10. Min: 1 Max: 72 Default: 10
        Activities_SwitchHours = 10,
        -- A crew cannot abandon its car while any player is closer than this distance. For example, 80 keeps it at the car while you are within 80 tiles.
        -- Default 60. Min: 20 Max: 150 Default: 60
        Activities_SwitchClearTiles = 60,
        -- Scales encounters with fishers, hunters, foragers, woodcutters, camp builders, scavengers and water carriers. 100 keeps the usual rate; 0 disables these encounters.
        -- Default 100. Min: 0 Max: 500 Default: 100
        Activities_PartyWeight = 100,
        -- Scales food gained from NPC hunts. 100 keeps the usual amount; 0 gives no food and 200 gives twice the usual amount.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Activities_HuntYieldPercent = 100,
        -- Allows NPC crews to fish near water without reducing the fish available to players.
        -- Default on.
        Activities_Fishing = true,
        -- Sessions last 60-140 percent of this time. Fishers stop if noticed by a player, hostile or zombie, or after gunfire or a hit.
        -- Default 65. Min: 10 Max: 240 Default: 65
        Activities_FishingMinutes = 65,
        -- Scales fish caught by NPC crews. 100 keeps the usual catch; 0 gives no fish and 200 gives twice the usual catch.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Activities_FishYieldPercent = 100,
        -- Foraging crews bring seasonal berries, herbs, nuts and mushrooms to their camp stash. This does not reduce what players can forage.
        -- Default on.
        Activities_Foraging = true,
        -- Scales food foraged per crew per game day. 100 gives six items, 200 gives twelve and 0 gives none.
        -- Default 100. Min: 0 Max: 300 Default: 100
        Activities_ForageYieldPercent = 100,
        -- Scales how quickly groups become hungry and thirsty. Higher values cause more supply runs and more chances to encounter you.
        -- Default 100. Min: 25 Max: 400 Default: 100
        Activities_NeedsDrainPercent = 100,
        -- Caps encounter crews kept travelling while you are away; they share the distant-group limit. Extra crews may continue while you are near, then leave the world as before.
        -- Default 6. Min: 0 Max: 24 Default: 6
        Activities_AdoptCap = 6,
        -- On: repaired cars have working engines, batteries, bonnets and some fuel, and remain with their trunk loot. Off: the car stays a wreck but remains the crew's stash.
        -- Default on.
        Activities_FixedCarDrivable = true,
        -- Sets how full a repaired car's fuel tank is. For example, 25 gives it a quarter tank.
        -- Default 15. Min: 0 Max: 100 Default: 15
        Activities_FixedCarFuelPercent = 15,
        -- Flashlights: NPCs see 12 tiles in darkness, or 20 when their light reaches you. Night vision: they can see at night, but you must supply goggles yourself.
        -- Default Flashlights (1). Default = Flashlights
        -- 1 = Flashlights
        -- 2 = Night vision
        Night_Sight = 1,
        -- Groups that lose members to you and escape can return for revenge two to three game days later, bringing backup.
        -- Default on.
        Offline_RevengeEnabled = true,
        -- Sets the daylight game hours between distant travelling groups (up to 1500 tiles away) heading for you and arriving out of sight. Hostile ones wait until day 3. At 0, off.
        -- Default 6. Min: 0.00 Max: 48.00 Default: 6.00
        Offline_ApproachGapHours = 6.0,
        -- Groups scavenging away from players keep this share of each house's loot value. They stash it at a base or carry it if homeless. 0 disables this loot gain.
        -- Default 25. Min: 0 Max: 100 Default: 25
        Offline_LootPercent = 25,
        -- Sets how far scavengers look for a nearby building. Higher values widen the search but increase the work needed to find one.
        -- Default 27. Min: 10 Max: 60 Default: 27
        Scavenge_BuildingRadius = 27,
        -- Scavengers return to their camp or base depot after collecting this many items. For example, 4 sends them home with four collected items.
        -- Default 8. Min: 1 Max: 24 Default: 8
        Scavenge_CarryLimit = 8,
        -- Scavengers bring supplies home after searching this many buildings. For example, 3 allows three building searches before returning.
        -- Default 2. Min: 1 Max: 8 Default: 2
        Scavenge_ReturnAfterBuildings = 2,
        -- Weather and clothing affect NPC warmth. Prolonged chill can cause coughing, worse aim, slower walking and faster fatigue. Indoors or near a fire, NPCs warm up.
        -- Default on.
        Cold_Enabled = true,
        -- Chilled NPCs without orders or danger seek a fire or heated building and wear warmer clothes from their packs. Groups follow their leader to a fire.
        -- Default on.
        Cold_SeekWarmth = true,
        -- In cold weather, NPCs sitting beside a lit campfire periodically hold their hands toward it. In warm weather or without a fire, they just sit.
        -- Default on.
        Idle_CampWarmHands = true,
        -- Shore fishers cast, wait and pull their rods every 20-60 seconds. Off: they continue fishing without the rod animation.
        -- Default on.
        Idle_FishingAnim = true,
        -- Camp sitters beside a free outdoor bench sit on it instead of the ground. Off: they always sit on the ground.
        -- Default on.
        Idle_BenchSeat = true,
        -- Patrols and scouts pause off the road every few hours and after fights to sit, smoke, drink or talk, then resume their route.
        -- Default on.
        PatrolRest_Enabled = true,
        -- Sets the minimum length of a patrol rest. For example, 30 means each rest lasts at least half a game hour.
        -- Default 20. Min: 5 Max: 180 Default: 20
        PatrolRest_MinMinutes = 20,
        -- Sets the maximum length of a patrol rest. For example, 60 limits each rest to one game hour.
        -- Default 45. Min: 10 Max: 240 Default: 45
        PatrolRest_MaxMinutes = 45,
        -- Sets the usual time between a group's planned rests, with some variation. Rest after a fight is separate from this schedule.
        -- Default 3.0. Min: 0.50 Max: 48.00 Default: 3.00
        PatrolRest_EveryHours = 3.0,
        -- Rare harmless meme encounters that appear once in a while near a player: a dancer on the road, a cone collector, a lost tourist. They never appear in a base or during a fight.
        -- Default on.
        Eggs_Enabled = true,
        -- How often the game rolls for an egg: 1 about every 3 hours, 2 every 90 minutes, 3 every 45 minutes (game time), and a roll can find nothing. 0 turns eggs off.
        -- Default 2. Min: 0 Max: 3 Default: 2
        Eggs_Frequency = 2,
        -- Mythic eggs are the very rare ones and some of them can only be seen once per world. Turn this off to keep only the common and rare eggs.
        -- Default on.
        Eggs_AllowMythic = true,
        -- Shows a small note above the player when an egg spawns, so an admin can go and look. Everyone else is not told.
        -- Default off.
        Eggs_DebugHints = false,
        -- Sets how close saved NPCs must be to a player before they appear as physical characters. Larger distances keep more nearby NPCs active.
        -- Default 90. Min: 40 Max: 250 Default: 90
        World_SimRadius = 90,
        -- Sets the volume of zombie bites, being-eaten voices and NPC pain cries. Sounds fade with distance and are heard only within 25 tiles. At 0, they are muted.
        -- Default 40. Min: 0 Max: 100 Default: 40
        Audio_BiteLoudness = 40,
        -- Shows a visible streak along NPC gunshots. Turning this off does not change muzzle flashes, gunfire sounds or casings.
        -- Default on.
        Combat_VisibleTracers = true,
        -- Shows weapon-sized flashes and nearby ground light when NPCs fire. Suppressed weapons do not flash. Gunfire sounds and casings are unchanged.
        -- Default on.
        Combat_MuzzleFlash = true,
        -- Sets how far other players can see an NPC shot's flash and streak and hear its gunshot and casing in multiplayer.
        -- Default 90. Min: 20 Max: 150 Default: 90
        Combat_ShotFxRange = 90,
        -- Removes inactive NPCs after nobody has approached them for this long. Persistent crews, such as anchored NPCs and garrisons, never expire. At 0, cleanup is disabled.
        -- Default 8. Min: 0 Max: 168 Default: 8
        Population_DormantTtlHours = 8,
        -- Beyond this distance (60-400 tiles), groups stop travelling, planning and using supplies. Members and loot stay; groups wake on approach without catching up missed time.
        -- Default 150. Min: 60 Max: 400 Default: 150
        Population_HibernateTiles = 150,
        -- Sets how often distant travelling groups move and make decisions. Longer intervals mean fewer updates.
        -- Default 20. Min: 10 Max: 60 Default: 20
        Offline_TickSeconds = 20,
        -- Pauses multiplayer wall and structure work until players stop crossing map sections. At least 5 seconds protects loading clients; new joins keep a separate 30-second pause.
        -- Default 5. Min: 5 Max: 30 Default: 5
        Outposts_StreamHoldSeconds = 5,
        -- Restores NPCs after map reloads, removes leftover zombie copies out of sight and clears zombies around returning groups. Blocked groups return farther away. Off removes this protection.
        -- Default on.
        Lifecycle_ReloadGuard = true,
        -- NPCs can become inactive or be removed only when they are at least this far from every player and out of sight.
        -- Default 60. Min: 0 Max: 200 Default: 60
        Spawn_DespawnMinTiles = 60,
        -- Sets how long a requested searchlight flight lasts before the helicopter leaves.
        -- Default 180. Min: 5 Max: 180 Default: 180
        Support_SpotlightSeconds = 180,
        -- Sets how long the support helicopter's flyover effects last. This does not set how long ground reinforcements stay.
        -- Default 35. Min: 5 Max: 180 Default: 35
        Support_HelicopterSeconds = 35,
        -- A backup call answered by helicopter sends a real one that hovers near the contact and rappels the squad down. Off: the squad appears on the ground after a delay.
        -- Default on.
        Support_HeliRappel = true,
        -- A badly hit helicopter leaves a trail of smoke on the ground beneath it as it sinks and falls.
        -- Default on.
        Helicopter_DamageSmoke = true,
        -- A crash ends in an explosion and a fireball at the wreck. Nothing explodes when a player stands within 6 tiles of the impact. Off: only the fires.
        -- Default on.
        Helicopter_CrashExplosion = true,
        -- Firing at a helicopter and shooting it down is held against the shooter by the faction it belongs to, as if the crew had been shot. Off: no standing changes.
        -- Default on.
        Helicopter_ShotReputation = true,
        -- On: bullets from players and from hostile NPCs wound a low-flying helicopter; a badly hit one loses height and falls, crashes, burns and leaves a wreck. Off: helicopters cannot be hurt.
        -- Default on.
        Helicopter_ShootDown = true,
        -- How much damage a helicopter takes before it is shot down. A rifle round does about 16 to 24 points; a pistol round about 8. Hits only count when they find the helicopter.
        -- Default 120. Min: 20 Max: 1000 Default: 120
        Helicopter_Health = 120,
        -- A crashed helicopter sets a few fires around the wreck. Off: no fire.
        -- Default on.
        Helicopter_CrashFire = true,
        -- How long a crashed helicopter stays in the world before it is cleared, once no player is within 120 tiles.
        -- Default 48. Min: 1 Max: 720 Default: 48
        Helicopter_WreckHours = 48,
        -- Chance that each person aboard a crashing helicopter survives, hurt and hostile. The pilot is capped at 20.
        -- Default 35. Min: 0 Max: 100 Default: 35
        Helicopter_CrashSurvivorPercent = 35,
        -- Allows moving searchlights at night or in low light. They can reveal people outdoors; cover and buildings hide them. Off disables only the searchlight.
        -- Default on.
        Helicopter_Spotlight = true,
        -- Sets the radius of the lit area. A larger beam covers more ground and makes it easier to be caught in the light.
        -- Default 11. Min: 4 Max: 20 Default: 11
        Helicopter_SpotlightSize = 11,
        -- Sets how strongly the helicopter searchlight illuminates the ground.
        -- Default 100. Min: 20 Max: 100 Default: 100
        Helicopter_SpotlightBrightness = 100,
        -- Sets the minimum time between searchlight flights anywhere in the world. Shorter intervals allow more flights; the call chance still applies.
        -- Default 20. Min: 2 Max: 240 Default: 20
        Helicopter_SpotlightGapMinutes = 20,
        -- Each helicopter picks a height between the lowest and the highest value and drifts to a new one every few seconds while circling. Close flights use about half.
        -- Default 36. Min: 8 Max: 60 Default: 36
        Helicopter_HeightMinM = 36,
        -- Upper end of the height range. Set it equal to the lowest height for a helicopter that always flies at one height. A value below the lowest height is raised to it.
        -- Default 60. Min: 8 Max: 120 Default: 60
        Helicopter_HeightMaxM = 60,
        -- Helicopters never fly above this height, so they stay on screen: in the isometric view each floor of height moves one 96 pixels up. 0 uses the height range alone.
        -- Default 18. Min: 0 Max: 60 Default: 18
        Helicopter_ScreenHeightM = 18,
        -- Allows the Black Hawk helicopter to appear as a second helicopter encounter. Off: it never appears.
        -- Default on.
        Helicopter2_Enabled = true,
        -- Chance that a helicopter drop on a backup call is the Black Hawk, not the standard helicopter. Squads over three riders use the standard one.
        -- Default 30. Min: 0 Max: 100 Default: 30
        Helicopter2_Share = 30,
        -- The Black Hawk's door gunners fire at you and at zombies near you, but only when the crew is hostile to you (same rule as a drive-by). Off: the Black Hawk never shoots.
        -- Default on.
        Helicopter2_Gunner = true,
        -- Chance that one gunner round hits you at point blank. It falls off with distance, down to 15 percent of this value at the gunner's range.
        -- Default 8. Min: 1 Max: 50 Default: 8
        Helicopter2_GunnerHitPercent = 8,
        -- How much of a normal rifle wound a gunner hit does to you.
        -- Default 25. Min: 5 Max: 100 Default: 25
        Helicopter2_GunnerDamagePercent = 25,
        -- Gunners only fire at targets this close to the helicopter.
        -- Default 40. Min: 10 Max: 80 Default: 40
        Helicopter2_GunnerRangeTiles = 40,
        -- Some bursts go at zombies near the player instead of at the player. Some of those rounds kill or hurt a zombie.
        -- Default on.
        Helicopter2_GunnerZombies = true,
        -- Allows NPCs to react to world sounds and notice nearby players who run or shoot.
        -- Default on.
        Hearing_Enabled = true,
        -- Scales how far NPCs hear sounds. At 50, hearing distance is halved. Indoor player sounds and NPC gunshots use half the resulting range.
        -- Default 100. Min: 25 Max: 200 Default: 100
        Hearing_RadiusPercent = 100,
        -- Sets how much hearing distance remains when a wall blocks the sound's path. At 50, a blocked sound can be heard from half as far away.
        -- Default 50. Min: 0 Max: 100 Default: 50
        Hearing_WallPercent = 50,
        -- Reduces hearing distance for each floor between the NPC and sound. At 50, one floor leaves half the range; two floors leave one quarter.
        -- Default 50. Min: 0 Max: 100 Default: 50
        Hearing_FloorPercent = 50,
        -- Lets NPCs notice a running or recently shooting player behind them on the same floor. At 0, this rear detection is disabled.
        -- Default 8. Min: 0 Max: 12 Default: 8
        Hearing_PeripheralTiles = 8,
        -- Sets how long extra awareness from sounds and warnings lasts before the NPC returns to its normal awareness.
        -- Default 20. Min: 1 Max: 60 Default: 20
        Hearing_AlertSeconds = 20,
        -- Sets the minimum awareness after an NPC hears a sound. Confirmed contacts and final warnings still give full awareness.
        -- Default 70. Min: 0 Max: 100 Default: 70
        Hearing_AlertPercent = 70,
        -- Limits extra sight checks for danger detours across all NPCs. Groups wait when the limit is reached. At 0, these extra checks stop; normal perception is unaffected.
        -- Default 32. Min: 0 Max: 120 Default: 32
        Caution_DangerRaysPerSecond = 32,
        -- How solid the talk window and the speech bubble boxes are. Text stays fully opaque. Lower is more see-through, 100 is the classic look.
        -- Default 100. Min: 40 Max: 100 Default: 100
        Talk_UIOpacity = 100,
        -- Copies NPC speech into the chat box in multiplayer, or a small log panel in single player. Only on your own screen, rate limited, names follow the stranger rule.
        -- Default Off (1). Default = Off
        -- 1 = Off
        -- 2 = Spoken to you
        -- 3 = Everything you hear
        Text_NpcChatLog = 1,
        -- Volume of human footsteps for nearby A-Life survivors on this computer. Set 0 to turn them off. Does not change noise heard by zombies.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Audio_NpcFootsteps = 100,
        -- Auto lowers background work when A-Life costs more than its budget and raises it again when there is room. Pick a level to pin it. Combat and anything you can see is never reduced.
        -- Default Auto (recommended) (1). Default = Auto (recommended)
        -- 1 = Auto (recommended)
        -- 2 = Ultra
        -- 3 = High
        -- 4 = Medium
        -- 5 = Low
        -- 6 = Minimal
        Perf_Tier = 1,
        -- How much game-frame time A-Life may use per frame before Auto steps the level down. Higher keeps more background work running on a fast PC.
        -- Default 2. Min: 1 Max: 16 Default: 2
        Perf_FrameBudgetMs = 2,
        -- How long one A-Life world tick may take before Auto steps the level down. Matters most on a dedicated server.
        -- Default 8. Min: 2 Max: 50 Default: 8
        Perf_TickBudgetMs = 8,
        -- Auto waits this long over budget before it lowers the level one step. A burst of heavy frames lowers it at once.
        -- Default 10. Min: 1 Max: 600 Default: 10
        Perf_DownSeconds = 10,
        -- Auto waits this long well under budget before it raises the level one step. Longer avoids flip-flopping.
        -- Default 30. Min: 5 Max: 3600 Default: 30
        Perf_UpSeconds = 30,
        -- Auto leaves the level alone for this long after loading, so loading hitches do not lower it. 0 turns the wait off.
        -- Default 60. Min: 0 Max: 300 Default: 60
        Perf_WarmupSeconds = 60,
        -- Auto raises the level one step after this long inside the budget with no long freezes, even when it is not well under it.
        -- Default 180. Min: 30 Max: 3600 Default: 180
        Perf_RecoverSeconds = 180,
        -- How far away an NPC can be when it puts a question to you (a standoff, a robbery, a call-out). Farther than this the question is not shown and cannot be answered.
        -- Default 25. Min: 5 Max: 60 Default: 25
        Talk_AskRangeTiles = 25,
        -- An NPC only puts a question to you when you can see it. Off lets questions open from behind walls.
        -- Default on.
        Talk_AskNeedsSight = true,
        -- Cap on new chase path requests the horde logic sends to the engine each second. Lower it if hordes make the game stall.
        -- Default 16. Min: 4 Max: 60 Default: 16
        Zombies_PathPerSecond = 16,
        -- Most far-away chasing zombies allowed to wait on an unanswered path request at once. Chases close to their target are never held.
        -- Default 24. Min: 4 Max: 120 Default: 24
        Zombies_PathInflightMax = 24,
        -- A zombie this close to its target always gets a fresh path at once when the target changes.
        -- Default 6. Min: 2 Max: 20 Default: 6
        Zombies_PathNearTiles = 6,
        -- Members that fall behind close back up on their group instead of drifting.
        Behavior_Regroup = true,
        -- Groups travel together in formation rather than as separate walkers.
        Behavior_MarchTogether = true,
        -- How hard NPCs work a door, a window or a barricade when they break in. 100 is the tested default: a window takes three swings, a plank four, a plain door about half a minute, and only one man swings while the rest cover him. Lower it and they take longer; raise it and they come through faster. Min: 25.00 Max: 200.00 Default: 100.00
        Breach_Strength = 100.0,
        -- NPCs break into a building only when raiding or looting, use an unlocked door first, try a window before smashing a door, and tell before entering a player's base. On by default.
        Breach_Policy = true,
        -- NPCs walk to where a target was last seen and sweep the area before giving up.
        Search_Enabled = true,
        -- Shouting draws every NPC within earshot toward you.
        Search_ShoutResponse = true,
        -- An NPC that spots something tells its group where, once. Not a live feed.
        Search_GroupCallout = true,
        -- Armed NPCs get out of the line of fire to reload, break contact when hurt, and fight from behind walls and corners.
        Modules_Cover = true,
        -- A shooter that is losing breaks contact, runs about a block back, holes up out of sight -- inside a building when there is one -- then comes back in from another side. Ranged only; melee always closes.
        Modules_Withdraw = true,
        -- After a fight, a wounded NPC stops, bandages, and loses the limp and the bleeding.
        Modules_Healing = true,
        -- Allows sprint windows for melee closing, cover moves, and retreats. Off keeps those moves at a run or walk.
        Modules_Sprint = true,
        -- A shooter that loses sight of its target dumps the magazine into the last known position, full auto, spraying left and right. Pistols magdump too.
        Modules_Gunner = true,
        -- The conduct layer: squad leaders that deploy and rally their group, snipers that keep distance, medics that dress their wounded, ambushers that wait in the dark, stealth killers. Off disables every conduct at once.
        Modules_Behaviors = true,
        -- Armed NPCs keep the gun on their target, or on where it was last seen, while they walk, back off or sidestep.
        Modules_Strafe = true,
        -- Master switch. On: the Sawmill Hands crew can spawn and the five melee modules work. Off: the faction is hidden from spawning, the Creator and the debug spawner, and every melee module is inert.
        Melee_FactionEnabled = true,
        -- Sidestep between swings, back off when zombies press in, step back in afterwards. Tuned for pairs and groups.
        Melee_Footwork = true,
        -- In a melee group one member engages and the others circle round to the far side of the target.
        Melee_Flank = true,
        -- A fighter holding an axe cuts through doors and windows faster and does it when checking a noise. The normal courtesy rules still apply.
        Melee_Breach = true,
        -- Walks up on a player, shouts the warning from range, then closes in. The normal warn-before-strike rules still decide when the first blow may land.
        Melee_Intimidate = true,
        -- Breaks contact early when a few zombies close in, using the existing withdraw behaviour with a lower crowd threshold.
        Melee_Caution = true,
        -- How many zombies near a crew member make it retreat. Normal fighters need five. Min: 2 Max: 8 Default: 3
        Melee_CautionCrowd = 3,
        -- How far an offline squad walks in one in-game hour. Default 150, a walking pace at the default day length; towns are 1700-3400 tiles apart. Min: 20 Max: 400 Default: 150
        Offline_TravelTilesPerHour = 150,
        -- A hostile NPC never lands its first blow or shot on a player who has not attacked it unless the player had a fair chance to notice: a shouted warning, a door or window heard opening, or the NPC in plain view for the first-contact grace. Fighting back is never delayed.
        Fair_TellBeforeStrike = true,
        -- How long a hostile NPC must have been in your view before it may attack without shouting first. Min: 0.00 Max: 10.00 Default: 2.50
        Fair_FirstContactGrace = 2.5,
        -- Time between a hostile NPC's warning shout and its first blow or shot. Min: 0.50 Max: 6.00 Default: 1.50
        Fair_WarningLead = 1.5,
        -- Time between the sound of a hostile NPC opening a door or climbing through a window and its first attack on a player nearby. Min: 0.00 Max: 6.00 Default: 1.50
        Fair_EntryLead = 1.5,
        -- How long an NPC needs to open a closed window before it climbs through. The window can be heard opening. Min: 0.30 Max: 4.00 Default: 1.20
        Fair_WindowOpenTime = 1.2,
        -- How long NPCs remember who started a fight with a player. Fighting back inside this time is self-defence, and the NPC that started it does not speak like a victim. Min: 10 Max: 240 Default: 60
        Fair_FightMemory = 60,
        -- How long a hostile crew holds its fire after it discovers a player: time to answer, drop the weapon, raise the hands or act first. Aiming at the crew or attacking it ends the beat at once. Min: 1.00 Max: 10.00 Default: 3.00
        Encounter_SurpriseSeconds = 3.0,
        -- How long a confronting crew waits for an answer before it asks again ('Will you answer me?'). After the third silence the crew acts: leave, warn or attack, by faction. Min: 4 Max: 30 Default: 10
        Encounter_AnswerSeconds = 10,
        -- How long a crew outside a building waits for the player to answer or come out, with repeated calls and a warning shot, before it searches the building or leaves. The time left is shown to the player. Min: 15 Max: 180 Default: 45
        Encounter_CalloutSeconds = 45,
        -- How long a crew searches a building where it believes a player is hiding: one man at the door, the rest room by room. Then it gives up and moves on. Min: 20 Max: 600 Default: 90
        Encounter_SearchSeconds = 90,
        -- How long an NPC keeps chasing a player it can no longer see or hear. After that it only knows where he was last seen and searches from there. Min: 2.00 Max: 30.00 Default: 6.00
        Encounter_LostSightSeconds = 6.0,
        -- A hunting, raiding or revenge crew gets ONE tip about where its target is when it sets out, off by up to this many tiles. It never follows the player's live position; it searches and gives up. Min: 0 Max: 60 Default: 12
        Encounter_FixBlurTiles = 12,
        -- Stand-offs and hold-ups lean on gestures and distance instead of text over heads: one spoken line per phase (notice, demand, turn, parting), the rest goes to the talk panel, hand signals and nods carry the in-between. Every line is picked so it does not repeat. Off: every line is shouted over the head as before.
        -- Default on.
        Encounter_ScriptedCues = true,
        -- In a hold-up one crew member, never the speaker if someone else is free, walks up to arm's length and pats you down with an animation and one of three pat-down sounds. The search lasts exactly as long as the sound. If you step away or fight, it stops and the crew reacts. Off: the old instant search.
        -- Default on.
        Robbery_FriskScripted = true,
        -- A crew fights when its score reaches this value. Lower means bolder crews, higher means more cautious ones. Default 50. Min: 0 Max: 100 Default: 50
        Discretion_FightPercent = 50,
        -- A gun with fewer rounds than this (loaded plus reserve) counts as a melee weapon when a crew weighs a fight. Default 6. Min: 0 Max: 30 Default: 6
        Discretion_LowAmmoRounds = 6,
        -- A crew that keeps holding back because of the odds alone commits to the fight after this many seconds if you stay near. Crews short on ammunition or surrounded by zombies never commit this way. Default 45. Min: 10 Max: 600 Default: 45
        Discretion_PatienceSeconds = 45,
        -- Game hours until a provoked careful faction forgives. Default 2. Min: 0 Max: 24 Default: 2
        CalmDown_Hours = 2,
        -- Zombies inside this distance are always fought. Default 8. Min: 2 Max: 30 Default: 8
        ZombieFocus_Radius = 8,
        -- How far ahead on their route NPCs watch for zombies. Default 12. Min: 4 Max: 30 Default: 12
        Caution_AvoidTiles = 12,
        -- Groups walk in a loose formation instead of one clump, never share a square when calm, and when they stop for a rest they move into a nearby house or shelter and idle there with different jobs: one sits in a corner, one keeps watch, two talk face to face, one comments, one stays quiet, others eat or smoke. Danger breaks it up at once. Off restores the old behaviour. On by default.
        GroupLife_Enabled = true,
        -- How wide a travelling group spreads out. 100 is the normal formation, 50 keeps them closer, 150 spreads them wider, 0 turns the formation off. Default 100. Min: 0 Max: 150 Default: 100
        GroupLife_Spread = 100,
        -- Typical length of a group rest, in game minutes. Each rest lasts between half and double of this value. Default 20, so 10 to 40. Min: 5 Max: 90 Default: 20
        GroupLife_ShelterIdleMinutes = 20,
        -- While a group rests, every member gets a role (lookout, sitter, talker, commenter, quiet, eater, smoker) with its own spot and pose. Off: they only spread out and stand. On by default.
        GroupLife_Roles = true,
        -- NPCs sometimes sneak (slow, crouched) while moving around town or scavenging. They stop sneaking when they see a player or a hostile NPC. Sneaking NPCs are harder for zombies to notice; the effect follows the zombie sight and hearing settings of the world. On by default.
        Stealth_Enabled = true,
        -- Share of the time a calm NPC or group moves sneaking. Higher near zombies. 0 never, 100 always. Default 30. Min: 0 Max: 100 Default: 30
        Stealth_Frequency = 30,
        -- How far zombies notice a sneaking NPC, as a share of the normal distance. Poor zombie sight or hearing makes sneaking stronger, eagle sight and pinpoint hearing weaker. Default 50. Min: 10 Max: 100 Default: 50
        Stealth_NoticePercent = 50,
        -- Blockades and checkpoints are never built within this distance of a player, a player base or a place a player drove through in the last five minutes, and never on dead-end roads. Default 150. Min: 0 Max: 400 Default: 150
        Spawn_CheckpointMinTiles = 150,
        -- Walking NPCs take short detours around nearby zombie crowds and fresh combat or loud noises. They wait or abandon an unsafe destination when no safe detour is found. Running and combat movement keep their existing rules.
        Caution_DangerRouting = true,
        -- Checks proposed movement legs for burning tiles, lit campfires and water. NPCs reject legs with known hazards. Applies to all movement paces.
        Caution_HazardCheck = true,
        -- How hard the cold hits NPCs and how big the penalties of a cold are. 0 = NPCs never get chilled. 100 = default and gentle. 300 = harsh winters. Default 100. Min: 0 Max: 300 Default: 100
        Cold_Severity = 100,
        -- Per game hour spent badly chilled, the base chance that an NPC comes down with a cold (it grows with how chilled and wet the NPC is). 0 = chills never turn into a cold. Default 6. Min: 0.00 Max: 100.00 Default: 6.00
        Cold_ChancePercent = 6.0,
        -- A sneeze or cough from a sick NPC is a small sound (a few tiles) that nearby zombies can hear. Turn off to keep them silent.
        Cold_SneezeNoise = true,
        -- Maximum work units per round. Higher values finish sooner but may increase server stalls. Multiplayer streaming pauses still apply.
        -- Default 100. Min: 1 Max: 2000 Default: 100
        Outposts_BuildBudget = 100,
        -- People whose profile lists several weapons for one slot pick one of them per person. Off always uses the first listed weapon. Profiles with a single weapon are unaffected. Default on.
        Appearance_LoadoutVariation = true,
        -- Time to raise, aim and start firing, and to look for a new combat target. Default 75% shortens these delays by one quarter. 100% restores the previous timing. Lower is faster. Weapon fire rate, reload time and warnings keep their own timings. Min: 25 Max: 200 Default: 75
        Combat_ReactionDelayPercent = 75,
        -- How much NPC aim improves as the stages pass, in % of the built-in ramp (up to +3 aim rating in the last stage). 0% turns the ramp off, 100% is the default. Min: 0 Max: 200 Default: 100
        Funnel_SkillRampPercent = 100,
        -- Base chance per trigger pull for a non-revolver NPC firearm to jam. Zero disables jams even if the feature is enabled. Min: 0.00 Max: 25.00 Default: 1.00
        Combat_JamChance = 1.0,
        -- A two-handed swing by an NPC carries into a second zombie standing in the arc, at three quarters of the blow. Zombies only, never people. Off by default.
        Combat_MultiHit = false,
        -- A round an NPC puts into a zombie goes on into the zombie standing right behind it (up to three squares). Zombies only, never people; better against a horde. Off by default.
        Combat_BulletPenetration = false,
        -- Scales how often NPC gunfire hits a ZOMBIE. 100 is unchanged; raise it if crews look helpless against a horde. Does not affect their aim against you. Min: 10 Max: 200 Default: 100
        Combat_AimZombiePercent = 100,
        -- Global multiplier on how often NPC gunfire hits players, applied on top of the NPC aim setting and each character's own accuracy. 100 is unchanged. NPCs also aim worse in the first seconds of a fight, at long range and against a moving target. Default 85. Min: 10 Max: 200 Default: 85
        Combat_AimPlayerPercent = 70,
        -- Optional extra overall-health loss added on top of a hit, on top of the damage option above. 0 means no extra damage, so the 60% option is exactly 60% of the original hit. Default 0. Min: 0 Max: 200 Default: 0
        Combat_ExtraWoundPercent = 0,
        -- How hard bullets, melee hits, shoves and zombie bites land on NPCs, on top of the NPC maximum health setting. At 100 guns, shoves and bites cost what they used to, 130 is 30% more. Melee hits are priced so that the defaults keep the old number of swings. This is the damage NPCs receive, not what they deal to players (see NPC damage output). Default 130. Min: 25 Max: 400 Default: 130
        NpcHealth_DamageTakenPercent = 130,
        -- How fast a resting NPC recovers health. 100 is the original 1.5% of maximum health per game hour, 50 is half of that. Only an NPC that has been out of the fight for two minutes and has no open wound recovers. 0 turns recovery off. Default 50. Min: 0 Max: 400 Default: 50
        NpcHealth_RegenPercent = 50,
        -- Switches the NPC health rebalance off: original maximum health, original hits needed to put an NPC down, original bleeding and regeneration. Default off.
        NpcHealth_Legacy = false,
        -- NPCs carrying a weapon walk into buildings slowly with the weapon raised, pause at doorways and corners and look over the room before moving on.
        Combat_RoomSweep = true,
        -- A frightened survivor makes the people around them more frightened for 30 to 60 seconds: their own group first, strangers within about 12 tiles less. Soldiers and police nearby calm them down. Off keeps every survivor's fright separate.
        Panic_Contagion = true,
        -- Civilians start out at full fear and steady over this many days, down to the lingering fear below. 0 starts them at the lingering fear. Min: 0 Max: 30 Default: 7
        Fear_Days = 7,
        -- How many zombies it takes before civilians break and run. Default = Normal
        -- 1 = Hard to scare
        -- 2 = Normal
        -- 3 = Easily scared
        Fear_Level = 2,
        -- How much of their fear civilians keep once they have steadied. At 50 it takes a crowd about 1.6 times the size to make them run. 0 means they stop running from zombies altogether after the days above. Min: 0 Max: 100 Default: 50
        Fear_Lingering = 50,
        -- How far, in tiles, a frightened NPC runs from the gun on each leg. It heads for cover that breaks line of sight and keeps going until the gun has been out of sight for a few seconds. Default 35. Min: 8 Max: 80 Default: 35
        GunFear_RunDistance = 35,
        -- How fast a frightened NPC runs away. A flight may use all of its stamina and slows down only when it is empty. Default = Sprint
        -- 1 = Run
        -- 2 = Sprint
        GunFear_RunSpeed = 2,
        -- How long an NPC freezes and stares at the gun before it starts to run. 0 runs at once. Default 400. Min: 0 Max: 3000 Default: 400
        GunFear_ReactDelayMs = 400,
        -- In melee, NPCs step back while swinging when zombies press or outnumber them, and step in when a lone zombie is within reach or backing off. Decided each swing from the zombies' positions and facing.
        Combat_MeleeFootwork = true,
        -- A hostile NPC holding a melee weapon runs at its human target until it is in reach, and sprints over longer gaps while it has the breath. It never runs on a wounded leg or when winded. Off keeps the guarded walk. Default on.
        Combat_MeleeChargeRun = true,
        -- How many zombies facing an NPC within the step-back radius it takes before the NPC steps back between swings. 0 turns stepping back off. Min: 0 Max: 8 Default: 2
        Combat_MeleeKiteCrowd = 2,
        -- How far around an NPC zombies are counted for melee footwork. Min: 1 Max: 5 Default: 2
        Combat_MeleeKiteTiles = 2,
        -- How far an NPC steps back between swings. It never steps out of weapon reach. 16 is 1.6 tiles. Min: 3 Max: 30 Default: 16
        Combat_MeleeStepBackTenths = 16,
        -- How far an NPC steps toward a lone zombie that is in reach or backing off. 11 is 1.1 tiles. Min: 3 Max: 25 Default: 11
        Combat_MeleeStepInTenths = 11,
        -- A zombie an NPC has just struck with a melee weapon cannot start or finish a bite and stops chasing for this long, so a fighter who keeps swinging is not bitten by the zombie in front of him. 0 turns the stun off. Min: 0 Max: 3000 Default: 1100
        Combat_ZombieStunMs = 1100,
        -- How quickly zombies notice and engage NPCs compared with the old pace. 500 is five times faster, 100 is the old pace. Higher values cost a little more processing near NPCs. Min: 100 Max: 1000 Default: 500
        Zombies_ReactSpeed = 500,
        -- How many of the attacks on a standing NPC are scratches instead of bites. Min: 0 Max: 100 Default: 35
        Zombies_ScratchPercent = 35,
        -- How long the NPC is held down before it dies. 30 is 3 seconds. Min: 5 Max: 60 Default: 30
        Zombies_DragDownTenths = 30,
        -- The base armour system for NPCs, with the same rules a player gets. It is not a Creator module. Every hit on an NPC (zombie bites and scratches, melee, bullets; from NPCs and from players) rolls against the matching protection of what is worn on the struck body part: bite, scratch or bullet defense. 100 always blocks, 0 never does, layers add up to 100. A blocked hit does no damage and cannot wound or infect, and the clothing tears. Body parts with no protection take the normal damage. Off ignores worn clothing. Default on.
        Combat_NpcArmorVsZombies = true,
        -- Teammates and friendly members of the same faction this close to the injured NPC may come to help. Helpers outside his squad also need a clear line of sight. Hostile NPCs never rescue him. Min: 5 Max: 40 Default: 15
        Injury_RescueRange = 15,
        -- When an NPC would start bleeding out, this is the chance it goes injured instead. 0 means only the debug menu makes injured NPCs. Min: 0 Max: 100 Default: 50
        Injury_AutoPercent = 50,
        -- Health an NPC has when it goes down injured. Min: 2 Max: 40 Default: 12
        Injury_DownHpPercent = 12,
        -- Each question put to an injured NPC can kill it. The player sees that it bled out. Min: 0 Max: 100 Default: 25
        Injury_InterrogationDeathPercent = 25,
        -- Taken once per injured NPC when you question a friendly, neutral or careful one. Hostile NPCs cost nothing. Min: 0 Max: 20 Default: 3
        Injury_RepPenalty = 3,
        -- Small reward for giving a bandage or medical item. Min: 0 Max: 20 Default: 4
        Injury_RepGain = 4,
        -- Only used when Rescues happen in front of players is off: then a teammate rescues an injured NPC only when no player is within this range or in sight. Min: 10 Max: 60 Default: 25
        Injury_PlayerRangeTiles = 25,
        -- After you bandage an injured NPC it turns neutral and walks this far from you. Min: 30 Max: 120 Default: 45
        Injury_LeaveTiles = 45,
        -- Lets downed NPCs run on a server with connected players. The client that controls the NPC keeps its own bleed-out timers and wound list; the server only hands it a downed state. Off keeps the ordinary bleed-out in multiplayer. Single player is not affected.
        -- Default on.
        Injury_MultiplayerEnabled = true,
        -- How fast an NPC's open wounds bleed: scratches and cuts clot on their own, deep wounds and bullet wounds bleed until bandaged. 0 turns the bleeding off. Min: 0 Max: 300 Default: 100
        Combat_InjuryBleed = 100,
        -- Chance that an NPC's hit with a heavy blunt weapon (bat, sledgehammer) breaks the player's arm or leg it lands on. Blunt weapons never cut: a laceration becomes a scratch. Min: 0 Max: 50 Default: 4
        Combat_BluntFracture = 4,
        -- How often the raid director checks automatic eligibility. Min: 1 Max: 120 Default: 10
        Raid_CheckMinutes = 10,
        -- Paces reinforcement waves after the initial warning. Min: 1 Max: 120 Default: 5
        Raid_WaveDelayMinutes = 5,
        -- Wait this long after scouts successfully arrive before a raid can start. Min: 0.00 Max: 72.00 Default: 6.00
        Raid_ScoutBuildupHours = 6.0,
        -- An expired scout report cannot authorize a raid; new scouts must be sent. Min: 1.00 Max: 168.00 Default: 48.00
        Raid_ScoutLifetimeHours = 48.0,
        -- How often an NPC that could shoot a zombie does so. Gunfire draws more zombies, so lowering this makes NPCs walk around zombies, use melee on a lone one, and keep their guns for NPCs and players. They still shoot when cornered, hurt, defending a hurt player, on a horde that blocks the way, or on duty as military or police. 0 means never unless cornered. 100 is the old behaviour. Default 70. A stored 50 from an older save still acts as 70 in the first 14 days. Min: 0 Max: 100 Default: 70
        Combat_GunsVsZombiesPercent = 50,
        -- An NPC holds fire when more than this many zombies are within 25 tiles, unless it is cornered, hurt or defending a hurt player. 0 turns the check off. Default 24 (a stored 8, the old default, counts as 24). Min: 0 Max: 40 Default: 24
        Combat_GunNoiseZombies = 8,
        -- A group of at least this many zombies within 12 tiles that blocks an NPC's route may be shot at, if it is not too loud (see the noise limit). Default 5. Min: 2 Max: 30 Default: 5
        Combat_GunHordeSize = 5,
        -- Size of the blood pool when an NPC is killed with a blade, bat or other melee weapon, and the blood on the attacker. Only used while the NPC blood amount is above 100%. Default 300%. Min: 100 Max: 800 Default: 300
        Blood_MeleeKillPercent = 300,
        -- Shooters can advance to nearby cover and briefly step out to fire. Eligible squad gunners provide bounded covering fire. Turning this off cancels active maneuvers.
        Combat_FireManeuver = true,
        -- Maximum length of a forward cover leg. Default 4; range 2-6. Weapon distance and movement safety still apply. Min: 2 Max: 6 Default: 4
        Combat_ForwardCoverTiles = 4,
        -- Time at the firing point before returning to cover. Default 1200; range 600-2000. At most two shots; weapon cycles finish normally. Min: 600 Max: 2000 Default: 1200
        Combat_PeekWindowMs = 1200,
        -- Maximum covering fire time for one squad maneuver. Default 4000; range 2000-6000. Requires an eligible gunner and a clear friendly-safe line. Min: 2000 Max: 6000 Default: 4000
        Combat_PinWindowMs = 4000,
        -- Prefer nearby retreat destinations that hide the NPC from the threat. Existing retreat triggers, stamina and fallback destinations remain in use.
        Combat_RetreatLOS = true,
        -- Multiplies the NPC loot percent for guns and melee weapons. Ignored while NPC weapon drop chance is a fixed choice. For example, 50 halves weapon drops.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Loot_NpcWeaponPercent = 100,
        -- Multiplies the NPC loot percent for worn armor and clothing, including rare armor. For example, 50 halves armor drops.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Loot_NpcArmorPercent = 100,
        -- Multiplies the NPC loot percent for dropped magazines and loose ammo. For example, 50 halves ammo drops.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Loot_NpcAmmoPercent = 100,
        -- Multiplies the NPC loot percent for food, medicine, tools and pocket items; identity cards always stay. For example, 50 halves supply drops.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Loot_NpcSuppliesPercent = 100,
        -- Scales how far zombies and others hear NPC gunfire. At 50, a shot carries half as far. Players and NPCs hear the same reduced range. Lower it on busy servers where NPC shooting pulls hordes across the map. Default 100. Min: 10 Max: 100 Default: 100
        Combat_NpcShotNoisePercent = 100,
        -- Adds extra visitor lines to the QA dump and the flight recorder to help find problems. Leave off for normal play.
        -- Default off.
        Visitors_Debug = false,
        -- The admin console, spawn panel, encounter list, outpost builder and raid setup in the right-click menu. Players also need Diagnostics ticked in Options. Turn this off for a clean right-click menu; the Creator (Insert key) and world status (Home key) stay on their keys and the pause menu. Admins on a server are unaffected.
        -- Default on.
        Debug_ShowAdminTools = true,
        -- After an admin has run CLEANUP A-LIFE to the end, the mod stays inert in that world so it can be removed safely. Turn this on only if you want the mod to spawn people and outposts again in a cleaned world.
        -- Default off.
        Cleanup_RespawnAfter = false,
        -- Turns on the maneuver recorder: a key starts and stops a recording of what you do (moves, aim, shots, reloads) into a file for the developer. Single player, or admins on a server. Off means nothing runs. Takes effect when the game starts.
        -- Default off.
        Recorder_Enabled = false,
        -- With the recorder on, raising a weapon starts a recording and lowering it for a few seconds stops it.
        -- Default off.
        Recorder_AutoOnAim = false,
        -- How long you can keep the weapon lowered before an aim-started recording ends. Recordings you start by key run until you stop them.
        -- Default 4. Min: 1 Max: 30 Default: 4
        Recorder_AutoStopSeconds = 4,
        -- How often the recorder writes your position and state. More is smoother and makes bigger files.
        -- Default 10. Min: 5 Max: 20 Default: 10
        Recorder_SampleHz = 10,
        -- A recording stops by itself when its file reaches this size.
        -- Default 2048. Min: 256 Max: 8192 Default: 2048
        Recorder_MaxFileKB = 2048,
        -- How many recordings are kept. Older ones are emptied (the game cannot delete files); you can delete the folder by hand.
        -- Default 40. Min: 5 Max: 200 Default: 40
        Recorder_MaxFiles = 40,
        -- Escorts 22 tiles to this side and 6 tiles behind your direction of travel. Auto chooses the more open side and avoids rapid switching.
        -- Default Right (1). Default = Right
        -- 1 = Right
        -- 2 = Left
        -- 3 = Auto
        Helicopter_EscortSide = 1,
        -- When behind, the helicopter can fly this much faster than your vehicle, within its flight limits. It never teleports.
        -- Default 75. Min: 60 Max: 90 Default: 75
        Helicopter_EscortChaseKmh = 75,
        -- While the player drives (or runs), a circling helicopter flies beside the player instead of staying behind, then returns to circling when the player stops. Off: it only circles a slowly moving centre.
        -- Default on.
        Helicopter_Escort = true,
        -- How far to the side of the player the escorting helicopter flies.
        -- Default 22. Min: 6 Max: 60 Default: 22
        Helicopter_EscortSideTiles = 22,
        -- The game's own helicopter event, set in the base Helicopter sandbox option, sends our Black Hawk instead on the same days and hours. Never both at once. Off: the game's helicopter returns.
        -- Default on.
        Helicopter_ReplaceVanilla = true,
        -- Average time between helicopters that fly past or circle near a player, at random. Not during the first hours of a character. 0 turns flybys off.
        -- Default 36. Min: 0 Max: 240 Default: 36
        Helicopter_FlybyHours = 36,
        -- How far a flying helicopter is heard by zombies. Lower flight and hovering are louder, passing is quieter. 0 means zombies ignore helicopters.
        -- Default 50. Min: 0 Max: 150 Default: 50
        Helicopter_NoiseRadius = 50,
        -- Expose living Jeem residents as residents through the A-Life compatibility API when the Jeem extension is active. Needs an available actor registry. Does not replace the Companion Dogs patch. Applied at world startup; restart after changing this.
        Compat_JeemResidents = true,
        -- Enable the A-Life compatibility adapter when Point Blank is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_PointBlank = true,
        -- Enable the A-Life compatibility adapter when Wandering Zombies is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_WanderingZombies = true,
        -- Enable the A-Life compatibility adapter when Cye's Push Doors is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_CyesPushDoors = true,
        -- Enable the A-Life compatibility adapter when More Traits Definitive is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_MoreTraits = true,
        -- Enable the A-Life compatibility adapter when Project Exile is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_ProjectExile = true,
        -- Enable the A-Life compatibility adapter when Pixel Strike Indicator is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_PixelStrike = true,
        -- Enable the A-Life compatibility adapter when GaelGunStore-Firearms is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_GaelGunStore = true,
        -- Enable the A-Life compatibility adapter when Project RV Interior is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_RVInterior = true,
        -- Enable the A-Life compatibility adapter when Advanced Trajectory is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_AdvancedTrajectory = true,
        -- Enable the A-Life compatibility adapter when Auto All is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_AutoAll = true,
        -- Mark A-Life people as already searched when they appear, so the vanilla zombie pocket loot is not rolled on their bodies. Off keeps the vanilla loot. Use it with mods that add loot to zombies.
        -- Default off.
        Compat_NoPocketLoot = false,
        -- Let Cry of Fear monsters bite A-Life people when their own attack animation never starts, at the same pace as ordinary zombies. Applied once at world startup; restart after changing this. Does nothing without the monsters mod.
        Compat_CryOfFear = true,
        -- Enable the A-Life compatibility adapter when Immersive Driving is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_ImmersiveDriving = true,
        -- Enable the A-Life compatibility adapter when The Mutants is active. Applied once at world startup; restart after changing this. Turning it off disables only this adapter, not the other mod.
        Compat_PZTheMutants = true,
        -- A zombie that has hit an NPC waits this long before it can hit again. Lower is deadlier. 3000 default, 4500 was the old value. Min: 1200 Max: 8000 Default: 3000
        Zombies_BiteIntervalMs = 3000,
        -- Established outposts can send three existing squads together. Their people leave the site; this does not create extra survivors.
        -- Default on.
        Outposts_TrioEnabled = true,
        -- Game days between coordinated departures from each outpost. Set 0 to stop these departures.
        -- Default 5. Min: 0.00 Max: 120.00 Default: 5.00
        Outposts_TrioGapDays = 5.0,
        -- An outpost must exist this many game days before sending three squads. At 0, a new site can qualify if it has enough people.
        -- Default 7. Min: 0.00 Max: 120.00 Default: 7.00
        Outposts_TrioMinAgeDays = 7.0,
        -- Automatic keeps these groups off on Easy difficulty and on otherwise. Choose Off or On to override that rule at any difficulty.
        -- Default Automatic: off on Easy, on otherwise (1). Default = Automatic: off on Light, on otherwise
        -- 1 = Automatic: off on Light, on otherwise
        -- 2 = Off
        -- 3 = On
        Outposts_MegaEnabled = 1,
        -- Game days between large-group departures from each outpost. They use existing people and weaken the site while away. Set 0 to stop departures.
        -- Default 12. Min: 0.00 Max: 120.00 Default: 12.00
        Outposts_MegaGapDays = 12.0,
        -- People combined from an outpost and its existing squads. A site without enough people cannot send the group. Rendering remains spread across frames.
        -- Default 16. Min: 12 Max: 40 Default: 16
        Outposts_MegaSize = 16,
        -- An outpost must exist this many game days before sending a large group. At 0, a new site can qualify if it has enough people.
        -- Default 10. Min: 0.00 Max: 120.00 Default: 10.00
        Outposts_MegaMinAgeDays = 10.0,
        -- Adds rare, tougher hostile factions after their earliest day. Their weapons and clothing use existing game items. Off keeps these new factions out.
        -- Default on.
        Late_FactionsEnabled = true,
        -- Earliest world day for the new raider and hazmat factions. Special forces have a separate earliest day. At 0, no minimum day applies.
        -- Default 14. Min: 0 Max: 3650 Default: 14
        Late_FactionStartDay = 14,
        -- Scales later weapon, ammunition and armour progression for new groups after day 13. The early worn-weapon curve stays unchanged. Set 0 to disable this progression.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Late_WeaponScalePercent = 100,
        -- Earliest world day for rare four-to-six-person special forces groups. At 0, no minimum day applies; late hostile factions must still be enabled.
        -- Default 21. Min: 0 Max: 3650 Default: 21
        Late_SpecialForcesStartDay = 21,
        -- Chance to react to a distant hit, close bullet crack or witnessed killing. People need a real cue, not knowledge of a hidden shooter. Set 0 to disable.
        -- Default 100. Min: 0 Max: 100 Default: 100
        Combat_SniperAwareness = 100,
        -- Shots from at least this many tiles can trigger distant-fire reactions. Scoped rifles can qualify closer; normal sight and ownership checks still apply.
        -- Default 40. Min: 10 Max: 200 Default: 40
        Combat_SniperAwarenessTiles = 40,
        -- Military checkpoint crews are hostile by default and warn once before firing. Off restores their careful stance. Earned relations and combat safety still apply.
        -- Default on.
        Outposts_BridgeHostile = true,
        -- Crews that arrive by car may drive past the player and shoot from the windows.
        -- Default on.
        Car_DriveBy = true,
        -- How far a drive-by car swerves from side to side while it passes the player, kept on the road. 0 drives straight.
        -- Default 2. Min: 0 Max: 4 Default: 2
        Car_DriveByWeaveTiles = 2,
        -- A car whose hostile crew fires on you keeps after you once it has passed, instead of driving away, until it loses you or runs out of time.
        -- Default on.
        Car_Pursuit = true,
        -- A chasing car drives through you instead of stopping beside you to let the crew out.
        -- Default off.
        Car_PursuitRam = false,
        -- How long a car keeps chasing before it gives up and drives off.
        -- Default 60. Min: 10 Max: 300 Default: 60
        Car_PursuitSeconds = 60,
        -- Each driver has a fixed skill: poor ones drive slower and take bends gently, and crews in a moving car aim worse the faster it goes. Off: all drivers are equally good.
        -- Default on.
        Car_DriverSkill = true,
        -- A damaged car slows down, corners gently and swerves once when hit. With a dead engine or three flat tires the crew bails out: hostile crews fight, the rest flee.
        -- Default on.
        Car_DamageEffects = true,
        -- A car that makes no progress for 12 seconds backs up and replans, rams a light obstacle if ramming is on, or stops and the crew goes on foot.
        -- Default on.
        Car_Blockade = true,
        -- How long a blocked car keeps backing up and replanning before it rams (if allowed) or the crew gets out.
        -- Default 45. Min: 15 Max: 300 Default: 45
        Car_BlockadeSeconds = 45,
        -- A crew that gets out of a stopped car takes cover on the side of the car away from you, behind the engine block first, then the doors, instead of just behind the car on your line.
        -- Default on.
        Car_HullCover = true,
        -- Crews that arrive by car stop near the player, step out and take cover before they talk or fight.
        -- Default on.
        Car_PullUp = true,
        -- Backup crews called into a fight may come in a car.
        -- Default on.
        Car_Reinforcements = true,
        -- A crew that finishes its business may leave in the car it came in.
        -- Default on.
        Car_DriveOff = true,
        -- Members of a squad lean toward the target a squadmate just called, so their fire lands on one enemy instead of spreading. Raises squad lethality.
        -- Default off.
        Combat_FocusFire = false,
        -- An NPC with a loaded gun opens fire on a zombie it sees within this many tiles instead of walking past it. Gun discipline still applies. 0 = only when cornered or on a mission.
        -- Default 14. Min: 0 Max: 30 Default: 14
        Combat_RangedZombieTiles = 14,
        -- A shooter does not fire through a squadmate. It holds, then steps to a side lane with a clear line.
        -- Default on.
        Combat_FriendlyLine = true,
        -- How far a melee fighter stands from a car whose rider cannot be reached (doors shut, windows whole) instead of pressing against it. 0 switches it off. Ranged fighters are not affected.
        -- Default 3. Min: 0 Max: 8 Default: 3
        Combat_VehicleKeepOutTiles = 3,
        -- How close a crew must be before it can hold you up. The crew walks up to you and one of them must see you. Backup, support and helicopter crews never rob.
        -- Default 8. Min: 4 Max: 20 Default: 8
        Robbery_StartTiles = 8,
        -- An admin can right-click the ground and send a crewed NPC car there. The car brakes and idles when the way is blocked or the spot cannot be reached.
        -- Default on.
        Car_DriveHere = true,
        -- How long a car sent with Drive here waits without a route before it brakes and idles. With a route but no progress it waits twice as long.
        -- Default 15. Min: 5 Max: 120 Default: 15
        Car_DriveHereGiveUpSeconds = 15,
        -- A driven NPC car that has not moved after about 6 seconds is moved along its route in position steps. 0 never, 1 only when stuck, 2 always.
        -- Default 1. Min: 0 Max: 2 Default: 1
        Car_ScriptedDrive = 1,
        -- A commanded NPC car whose crew is not loaded continues as an offline trip along the roads and is recreated with its crew when a player comes close. Off refuses the order.
        -- Default on.
        Car_OfflineTrips = true,
        -- Squads that notice an abandoned car may break in or hot-wire it, check fuel, drive to a destination and leave it when the situation says so. Off: NPCs never take cars on their own.
        -- Default off.
        Car_LifeEnabled = false,
        -- Base chance per attempt to force a door or smash a window. Skilled squad members raise it. Forcing is quiet and slow, smashing is loud and fast. 0 means locked cars stay locked.
        -- Default 60. Min: 0 Max: 100 Default: 60
        Car_BreakInChance = 60,
        -- Base chance per attempt, raised by mechanic, burglar and engineer squad members. A failed attempt can burn out the wiring. 0 means squads only take cars they have keys for.
        -- Default 35. Min: 0 Max: 100 Default: 35
        Car_HotwireChance = 35,
        -- On: a squad whose car is low on fuel looks for a can, a powered pump or another unowned car to siphon. Off: it gives up on a car that is short of fuel.
        -- Default on.
        Car_RefuelEnabled = true,
        -- On: before a route enters a town the squad parks at the roadside, works the town on foot and returns to the car later. Off: it drives in.
        -- Default on.
        Car_DitchBeforeCity = true,
        -- Scales the thresholds and chances of the exit rules (crash, fire, dead engine, gunfire, horde ahead). 0 keeps crews driving longer, 2 makes them leave sooner.
        -- Default 1. Min: 0 Max: 2 Default: 1
        Car_ExitRules = 1,
        -- Passengers shoot from the car at hostile targets on their side. 1: only under 25 km/h. 2: also up to 60 km/h, less accurate; the driver may fire a pistol under 15 km/h. 0: never.
        -- Default 2. Min: 0 Max: 2 Default: 2
        Car_FireFromCar = 2,
        -- A hostile crew slows to this speed within 25 tiles of you so its passengers can shoot, then drives on. With shooting set to 1 the pass is at most 25.
        -- Default 35. Min: 15 Max: 60 Default: 35
        Car_PassByKmh = 35,
        -- Scales cruise speed, bend speed and braking distance of NPC cars. Hostile crews that chase or flee drive at least Fast, civilian travellers Careful.
        -- Default Normal (2). Default = Normal
        -- 1 = Careful
        -- 2 = Normal
        -- 3 = Fast
        -- 4 = Reckless
        Car_DriveStyle = 2,
        -- How often hostile drive-bys and road pull-ups come up: 100 is about one every two weeks of game time, 300 triples it, 0 turns both off. The car switches still apply.
        -- Default 100. Min: 0 Max: 500 Default: 100
        Car_EncounterPercent = 100,
        -- A gun, or a weapon raised at close range, ends what that NPC was doing to you: hold-up, standoff, demand, question. Hostile crews fight, scared people run, friends lower their weapon.
        -- Default on.
        Combat_AimCancelsStandoff = true,
        -- Keep a gun on a crew that holds you at bay and back away: hostile crews fire, careful ones fire a warning shot first. Backing away is not giving in.
        -- Default on.
        Combat_AimRetreatEscalates = true,
        -- How long the crosshair must stay on a crew member before backing away is answered.
        -- Default 1.0. Min: 0.30 Max: 5.00 Default: 1.00
        Combat_AimRetreatHoldSeconds = 1.0,
        -- A careful crew fires a warning shot, then opens fire after this long if you keep aiming and backing away.
        -- Default 1.5. Min: 0.50 Max: 6.00 Default: 1.50
        Combat_AimRetreatStepSeconds = 1.5,
        -- How much farther from the crew than your nearest point you must get, while aiming, before it counts as backing away.
        -- Default 1. Min: 1 Max: 6 Default: 1
        Combat_AimRetreatTiles = 1,
        -- Hostile NPCs in close quarters raise the weapon sooner, think more often and skip the first-sight freeze. Warn-first crews still warn first.
        -- Default on.
        Combat_QuickReaction = true,
        -- Inside this distance the fast first shot applies.
        -- Default 8. Min: 3 Max: 16 Default: 8
        Combat_CqbTiles = 8,
        -- A group asks, warns or demands once. One member speaks; the others hold or cover you. When that member escalates, the whole group fights. Aiming at any of them ends the demand.
        -- Default on.
        Combat_GroupSingleSpeaker = true,
        -- A second group waits this long after the first group spoke before it opens its own question.
        -- Default 2500. Min: 0 Max: 10000 Default: 2500
        Combat_GroupVoiceQueueMs = 2500,
        -- Longest a group keeps one speaker on you. The role passes sooner when the speaker dies, goes down, runs or loses sight of you.
        -- Default 45. Min: 5 Max: 300 Default: 45
        Combat_GroupLockTimeoutS = 45,
        -- Hold your aim on a stair top, doorway or corridor end and hostile crews stop walking into that line and wait outside it behind cover. Reckless ones still push now and then.
        -- Default on.
        Combat_HoldAngleAvoid = true,
        -- How long you must stand still with the crosshair on one point before crews treat it as held.
        -- Default 2.5. Min: 1.00 Max: 10.00 Default: 2.50
        Combat_HoldAngleSeconds = 2.5,
        -- A crew that loses someone in an angle you hold keeps away from it for this long, even after you lower the weapon.
        -- Default 120. Min: 10 Max: 900 Default: 120
        Combat_KillZoneMemorySeconds = 120,
        -- A person who keeps getting hit is staggered for a shorter time each time, then shrugs off the next hits for a moment, and ducks low after a gunshot. Off: every hit staggers like before.
        -- Default on.
        Combat_StunDiminish = true,
        -- When on, NPCs pull back once enough zombies are close by, using the count and distance below. Healthy gun users keep firing instead of pulling back; NPCs unable to fight disengage.
        -- Default off.
        Retreat_HordeEnabled = false,
        -- How many zombies need to be within the distance below before an NPC retreats.
        -- Default 8. Min: 2 Max: 60 Default: 8
        Retreat_HordeCount = 8,
        -- How far around an NPC zombies are counted. For example 8 zombies within 30 tiles, or 15 within 50.
        -- Default 30. Min: 5 Max: 80 Default: 30
        Retreat_HordeRadius = 30,
        -- Which NPCs follow the retreat rule above.
        -- Default Everyone except military (2). Default = Everyone except military
        -- 1 = Everyone
        -- 2 = Everyone except military
        Retreat_HordeScope = 2,
        -- NPC bites resolve after the full attack animation; an NPC can escape by moving a tile off or behind the zombie first. Off keeps the current timing.
        -- Default off.
        Zombies_BiteEscapeTest = false,
        -- An NPC with a loaded gun, standing, guarding or walking, shoots a zombie coming at it inside this range instead of waiting for melee. Gun discipline still applies.
        -- Default on.
        Combat_RangedZombieStart = true,
        -- A gunman who has fired steps back from a person nearer than this share of the usual keep-away distance. 100 = the old habit of backing away after every shot, lower = stands and shoots.
        -- Default 55. Min: 20 Max: 100 Default: 55
        Combat_KitePersonPercent = 55,
        -- A zombie hitting an NPC picks a swipe, a lunge or a bite by distance and chance, and the NPC staggers harder after a swipe or lunge.
        -- Default on.
        Zombies_AttackVariants = true,
        -- Zombies that reach a parked or slow car with a seated NPC claw at it and wear down its windows and doors. A car faster than 8 km/h is never attacked.
        -- Default on.
        Zombies_AttackCars = true,
        -- Zombies this close to a car with a seated NPC count as gathered at it, and the crew can react. Zombies touching the hull attack. At most 8 attack one car at a time.
        -- Default 6. Min: 2 Max: 12 Default: 6
        Zombies_CarAttackTiles = 6,
        -- Condition points taken from a window or door per second by each attacking zombie. Engine, tires and fuel tank are never touched and doors stop at 30. 0 means the zombies only pose.
        -- Default 2. Min: 0 Max: 20 Default: 2
        Zombies_CarDamagePerSecond = 2,
        -- Scales NPC melee and gun damage to players. At 50, each hit deals half the original damage; 100 is the original amount.
        -- Default 72. Min: 0 Max: 200 Default: 72
        Combat_DamagePercent = 72,
        -- Scales each survivor's original health. At 80, they have four-fifths of their usual health; profession differences still apply.
        -- Default 98. Min: 25 Max: 300 Default: 98
        NpcHealth_Percent = 98,
        -- Higher choices make NPC gunfire more accurate against players. Medium keeps their own aiming skill; zombie accuracy is separate.
        -- Default Medium (3). Default = Medium
        -- 1 = Very Easy
        -- 2 = Easy
        -- 3 = Medium
        -- 4 = Hard
        -- 5 = Very Hard
        -- 6 = Hardcore
        Combat_AimDifficulty = 3,
        -- Share of crews set to attack on sight that warn anyway. Each group rolls once and keeps its result. 0 means none; 100 means all. Reputation does not change this; raids use their own chance.
        -- Default 15. Min: 0 Max: 100 Default: 15
        Warning_ChancePercent = 15,
        -- Share of hostile crews that open fire with no warning on a player at the lowest reputation (The Villain). The share falls smoothly as reputation rises.
        -- Default 90. Min: 0 Max: 100 Default: 90
        Warning_KosAtVillain = 90,
        -- Share of hostile crews that open fire with no warning on a player with no reputation either way. Crews that do not attack at once try to make the player surrender.
        -- Default 15. Min: 0 Max: 100 Default: 15
        Warning_KosAtNeutral = 15,
        -- Share of hostile crews that open fire with no warning on a player at the highest reputation (The Legend). Raids stay dangerous for everyone.
        -- Default 4. Min: 0 Max: 100 Default: 4
        Warning_KosAtLegend = 4,
        -- Scales how often outlaws choose robbery rather than a fight. 0 means never; 200 means twice the normal rate, not a guaranteed robbery.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Robbery_Chance = 100,
        -- Scales outlaw flanking during talks. A flanker circles while the leader stalls; calling it out or raising a gun makes them back off. 0 disables this betrayal.
        -- Default 100. Min: 0 Max: 200 Default: 100
        Encounter_BetrayalPercent = 100,
        -- Chance that an NPC panics when a gun is aimed at it. Rolled once per NPC and player, so the same NPC always reacts the same way to the same player. A gun that is raised but not pointed at it counts half. Default 60. Min: 0 Max: 100 Default: 60
        GunFear_Percent = 60,
        -- 100% is the standard curve: full fright on days 0 and 1, then easing off. Lower values make survivors calmer, higher values keep them frightened longer. 0 turns the panic off. Min: 0 Max: 200 Default: 100
        Panic_Strength = 100,
        -- Chance for scouts to begin a raid buildup on each check. Set 0 to stop automatic raids; cooldown and earliest-day limits still apply.
        -- Default 0.025. Min: 0.00 Max: 100.00 Default: 0.03
        Raid_Chance = 0.03,
        -- Automatic raids cannot begin before the world reaches this age. For example, 60 prevents them during the first 60 game days.
        -- Default 21. Min: 0 Max: 365 Default: 21
        Raid_MinDay = 21,
        -- Sets the minimum time between automatic full-scale raids. For example, 14 requires at least two game weeks between raids.
        -- Default 14. Min: 0.25 Max: 60.00 Default: 14.00
        Raid_CooldownDays = 14.0,
        -- Sets the number of attacking waves in a raid. The total attacker limit still applies, so extra waves do not bypass that limit.
        -- Default 4. Min: 1 Max: 10 Default: 4
        Raid_Waves = 4,
        -- Sets the requested attackers in each wave. The total raid limit and other spawn limits can reduce the actual number.
        -- Default 8. Min: 1 Max: 12 Default: 8
        Raid_GroupSize = 8,
        -- Sets the chance that an allowed backup call succeeds. For example, 50 gives each permitted call a one-in-two chance of an answer.
        -- Default 35. Min: 0 Max: 100 Default: 35
        Support_Chance = 35,
        -- Sets the minimum wait between successful backup calls by the same group. For example, 6 means it must wait a quarter of a game day.
        -- Default 1.5. Min: 0.00 Max: 24.00 Default: 1.50
        Support_CooldownHours = 1.5,
        -- How often a law, military or elite group that calls for backup gets a helicopter that rappels the squad in, instead of a car. 0 means cars only.
        -- Default 40. Min: 0 Max: 100 Default: 40
        Support_HeliBackupPercent = 40,
        -- Sets the chance of a searchlight call from an NPC authorized to request helicopter support. Ground-only callers cannot request it.
        -- Default 20. Min: 0 Max: 100 Default: 20
        Support_SpotlightChance = 20,
        -- Stops new travelling crews at this living-NPC count, including peaceful survivors. It is not the county population; existing crews stay.
        -- Default 32. Min: 4 Max: 160 Default: 32
        Population_HostileCeiling = 48,
        -- Scales the chance of natural faction encounters. At 50, these checks have half their normal chance of bringing a group.
        -- Default 200. Min: 25 Max: 400 Default: 200
        Population_RatePercent = 300,
        -- Saved travelling groups return up to this rate-scaled limit after restart; at 0 or in Local only, the saved-crew cap applies. Lowering stops new groups; extras keep moving until reload.
        -- Default 45. Min: 0 Max: 500 Default: 45
        Offline_SquadCap = 45,
        -- Limits outpost garrisons and persistent crews kept after restart. Distant travelling groups and starting building residents have separate limits. Lowering it affects the next save.
        -- Default 60. Min: 0 Max: 500 Default: 60
        Population_PersistentSquadCap = 60,
        -- Scales the number of NPCs in naturally appearing groups. At 100, groups keep their original sizes. Faction size limits still apply.
        -- Default 125. Min: 50 Max: 200 Default: 125
        Population_PartyPercent = 125,
        -- Sets the relative frequency of natural 1-3-person parties compared with larger groups. Higher means more small parties; faction-specific rules take priority.
        -- Default 2. Min: 0.00 Max: 20.00 Default: 2.00
        Party_LoneWeight = 2.0,
        -- Sets the relative frequency of natural groups of 4 or more compared with small parties. Equal weights give both sizes equal selection weight.
        -- Default 2. Min: 0.00 Max: 20.00 Default: 2.00
        Party_GroupWeight = 2.0,
        -- Sets the chance of a group on each natural encounter check. Both the game-hour faction checks and game-minute encounter checks use it.
        -- Default 15. Min: 0 Max: 100 Default: 15
        Encounters_RollPercent = 30,
        -- Sets the time between natural faction encounter checks. A check can fail; this is not a guaranteed time between meetings.
        -- Default 3. Min: 1 Max: 24 Default: 3
        Encounters_GapHours = 3,
        -- Sets the time between random encounter checks, including while sleeping or fast-forwarding. The encounter chance still decides whether a group appears.
        -- Default 45. Min: 10 Max: 720 Default: 45
        Encounters_IntervalMinutes = 45,
        -- Limits how many outposts may exist at once across the map. At 0, outposts are disabled.
        -- Default 9. Min: 0 Max: 24 Default: 9
        Outposts_MaxSites = 9,
        -- Limits how many fortified-building outposts each town may hold. Outdoor camps have a separate limit.
        -- Default 2. Min: 1 Max: 4 Default: 2
        Outposts_PerCity = 2,
        -- Limits outdoor sites such as forest camps, field bases and aid stations, separate from fortified town buildings. At 0, outdoor sites are disabled.
        -- Default 4. Min: 0 Max: 12 Default: 4
        Outposts_OutsideCity = 4,
        -- Chance that an outpost check founds a new site, if a suitable location is available.
        -- Default 35. Min: 0 Max: 100 Default: 35
        Outposts_Chance = 35,
        -- Time between chances to found an outpost. Sleep and fast-forward count. If the game clock stops, checks use this many real minutes instead.
        -- Default 20. Min: 5 Max: 120 Default: 20
        Outposts_IntervalMinutes = 20,
        -- Caps simultaneous patrol, scavenging and hunting teams from each outpost. At 0, none are sent. Teams last for the session; the outpost stays saved.
        -- Default 3. Min: 0 Max: 4 Default: 3
        Outposts_TaskSquadCap = 3,
        -- Caps attackers across all automatic raid waves, spread evenly among the waves. Earlier scouts do not count. Admin-forced raids ignore this limit.
        -- Default 12. Min: 1 Max: 48 Default: 12
        Raid_MaxAttackers = 12,
        -- Sets how many enemy scouts arrive before an automatic full-scale raid. They are separate from the raid's total attacker limit.
        -- Default 4. Min: 1 Max: 8 Default: 4
        Raid_ScoutSize = 4,
        -- Sets backup size only when the calling NPC or its faction has no size of its own. It does not replace sizes chosen in their profiles.
        -- Default 4. Min: 1 Max: 8 Default: 4
        Support_GroupSize = 4,
        -- Limits how many reinforcement requests one group may make, preventing repeated backup calls without end.
        -- Default 2. Min: 0 Max: 10 Default: 2
        Support_MaxCalls = 2,
        -- Limits buildings selected for starting residents across the whole map. Selection happens once per world; stations, firehouses and clinics take priority.
        -- Default 75. Min: 1 Max: 200 Default: 75
        Population_PopulateMax = 75,
        -- Sets the minimum time between new distant travelling groups. Existing groups stay; the world group limit and local quiet periods still apply.
        -- Default 3. Min: 0.25 Max: 48.00 Default: 3.00
        Offline_FoundGapHours = 3.0,
        -- Sets the finite survivor pool when the world starts. Natural groups and reinforcements draw from it; deaths reduce it. Slow arrivals replace losses. Admin spawns do not count.
        -- Default 360. Min: 20 Max: 5000 Default: 360
        Census_Size = 360,
        -- How many welcome groups each new character gets, and how many can be alive in one town at once, even when several players start there.
        -- Default 8. Min: 1 Max: 8 Default: 8
        TownWelcome_GroupsPerTown = 8,
        -- Blocks new travelling groups when this many already live within 240 tiles. From day 4, the limit drops by one but never below one.
        -- Default 4. Min: 1 Max: 8 Default: 4
        Population_NeighbourGroups = 4,
        -- Maximum outposts with a coordinated group away at once. Set 0 to stop departures.
        -- Default 2. Min: 0 Max: 8 Default: 2
        Outposts_TrioMaxActive = 2,
        -- Maximum large marching groups away at once, with one per faction. Set 0 to stop departures.
        -- Default 1. Min: 0 Max: 8 Default: 1
        Outposts_MegaMaxActive = 1,
        -- Single player only. While you pick a reply the game runs slowly, then eases back when you choose or close.
        -- Default on.
        Talk_SlowTimeWhileChoosing = true,
        -- How fast the game runs while you choose a reply: 1 is normal speed, 0.2 is one fifth, 0.05 is almost frozen. Only used when slowing time is on.
        -- Default 0.2. Min: 0.05 Max: 1.00 Default: 0.20
        Talk_SlowTimeFactor = 0.2,
        -- Replies and the window fade in and out, the chosen reply flashes. Off when Animated text is off.
        -- Default on.
        Talk_FadeAnimations = true,
        -- Replies that have a consequence show in yellow at the top, asked questions drop out of the list, and skill or reputation replies show a small tag.
        -- Default on.
        Talk_CyberStyle = true,
        -- With someone to talk to in sight, F opens the conversation instead of the flashlight; otherwise F stays the flashlight. The talk key always works. Off: talk key only.
        -- Default on.
        Talk_KeyF = true,
        -- Which conversation window players get. New is the side panel; Old cinematic is the earlier window with numbered answers. A player's Journal setting still wins unless you pick a forced value.
        -- Default New. Default = New
        -- 1 = New
        -- 2 = Old cinematic
        -- 3 = New (forced)
        -- 4 = Old cinematic (forced)
        Talk_WindowStyle = 1,
        -- Shows the skill and reputation replies you do not qualify for yet, greyed out with their requirement.
        -- Default off.
        Talk_ShowLockedLines = false,
        -- Only one question is open at a time, questions from different people keep a gap, and low-value ones are rationed. Danger and robbery questions always get through.
        -- Default on.
        Talk_AskGovernor = true,
        -- Real seconds before a lesser question from another person or crew may reach you after the last one. Needs the question limit on.
        -- Default 60. Min: 0 Max: 600 Default: 60
        Talk_AskGapSeconds = 60,
        -- Real seconds before the same person or crew may ask you something new after their last question. Needs the question limit on.
        -- Default 180. Min: 0 Max: 1800 Default: 180
        Talk_AskSameNpcGapSeconds = 180,
        -- At most this many trade offers and small-talk questions reach you per real hour; 0 blocks them. Needs the question limit on.
        -- Default 4. Min: 0 Max: 60 Default: 4
        Talk_LowValueAsksPerHour = 4,
        -- Top speed of NPC cars on roads (arrivals, drive here, patrol). Drive-by and chase speeds are not affected. Corners and obstacles still slow the car.
        -- Default 60. Min: 20 Max: 90 Default: 60
        Car_CruiseKmh = 60,
        -- Multiplies the push the driver gives the car when it speeds up. Higher reaches cruise speed sooner.
        -- Default 150. Min: 100 Max: 300 Default: 150
        Car_AccelBoost = 150,
        -- Writes one line per driven NPC car every few seconds to Lua/alife_cars_dump.txt and flags stalls and other problems as [ALIFE-CARS] ANOMALY lines in console.txt. Costs nothing while no car drives.
        -- Default on.
        Car_DumpLog = true,
        -- How often each driven NPC car writes a dump line. State changes are written at once.
        -- Default 2. Min: 1 Max: 30 Default: 2
        Car_DumpLogIntervalS = 2,
        -- Colours of the A-Life windows. Cyber: graphite panels, cyan for the selected item, amber for what matters. Classic cyan: the old all-cyan look. Amber: amber instead of cyan.
        -- Default Cyber. Default = Cyber (cyan + amber)
        -- 1 = Cyber (cyan + amber)
        -- 2 = Classic cyan
        -- 3 = Amber
        UI_Theme = 1,
        -- NPCs on foot in the path of a moving car sidestep out of it and run when it is about to hit. Parked, receding and passing cars are ignored.
        -- Default on.
        Move_EvadeVehicles = true,
        -- NPCs go from calm to suspicious to alert to fighting, and hold each level for a while before calming down.
        -- Default on.
        Perception_Alertness = true,
        -- How long an NPC stays at full alert after the last sign of a fight.
        -- Default 12. Min: 1 Max: 120 Default: 12
        Perception_CombatHoldSeconds = 12,
        -- How long an NPC stays alert after it spotted a threat and lost sight of it.
        -- Default 20. Min: 1 Max: 180 Default: 20
        Perception_AlertHoldSeconds = 20,
        -- How long an NPC stays suspicious after a noise or a glimpse.
        -- Default 15. Min: 1 Max: 120 Default: 15
        Perception_SuspicionSeconds = 15,
        -- How far an NPC's shout about a threat reaches crewmates. 0 turns callouts off.
        -- Default 25. Min: 0 Max: 80 Default: 25
        Perception_CalloutTiles = 25,
        -- How long a crewmate takes to react to a shout.
        -- Default 900. Min: 0 Max: 5000 Default: 900
        Perception_CalloutDelayMs = 900,
        -- Size of the hold-Q companion order wheel as a share of its normal size, so it covers less of the player. 70 to 130.
        -- Default 100. Min: 70 Max: 130 Default: 100
        Wheel_Scale = 100,
        -- Fades and scales the order wheel in and out for about a tenth of a second. Players who chose static text in the A-Life options always get an instant wheel.
        -- Default on.
        Wheel_Animated = true,
        -- Robbing or ordering people about needs Strength, more for harder groups. A reply you cannot pass shows greyed with its requirement.
        -- Default on.
        Talk_ChecksEnabled = true,
        -- Scales the Strength needed against each group. 100 is the standard table (military 10, civilians about 4), 50 halves it. The cap stays 10.
        -- Default 100. Min: 25 Max: 300 Default: 100
        Talk_CheckStrictness = 100,
        -- Master switch for the ambient world sounds: phones, alarms, TV and radio noise, police chatter, distant gunfire and screams, bells and sirens, ocean and forest, the numbers station. Off silences all of them.
        -- Default on.
        MetaSound_Enabled = true,
        -- House phones, the phones of the dead, and alarm beeps. A dead body's phone also stops drawing zombies when this is off.
        -- Default on.
        MetaSound_Phones = true,
        -- Emergency broadcast tones, radio backup calls and the radio cutting out.
        -- Default on.
        MetaSound_TvRadio = true,
        -- Dispatch chatter from police cars near you.
        -- Default on.
        MetaSound_PoliceRadio = true,
        -- Far-off shootouts, artillery, explosions, screams and cries for help.
        -- Default on.
        MetaSound_Gunfire = true,
        -- Church bells, police and service sirens, air raid sirens.
        -- Default on.
        MetaSound_BellsSirens = true,
        -- Ocean waves near open water and wind in the forest.
        -- Default on.
        MetaSound_Nature = true,
        -- The numbers station and its gong on radios and TVs.
        -- Default on.
        MetaSound_Numbers = true,
        -- Scales every ambient meta sound above. 0 silences them.
        -- Default 100. Min: 0 Max: 100 Default: 100
        MetaSound_Volume = 100,
        -- Ambient NPC cars (travelers, start traffic, cars that become real when you near them) never appear closer than this to a player. Raid, pull-up, drive-by and police cars may come closer but never inside your view, and walls do not hide them.
        -- Default 70. Min: 30 Max: 200 Default: 70
        Cars_SpawnDistanceTiles = 70,
        -- NPC cars never spawn or appear this close to a player base edge, and arriving crews stop and get out before it. 0 keeps them out of the base itself only.
        -- Default 40. Min: 0 Max: 150 Default: 40
        Cars_BaseKeepOutTiles = 40,
    },
    ALifeDriving = {
        -- NPC driving, passenger crews and automatic multiplayer control handover. Driving debug controls require admin access.
        Enabled = true,
        -- By car spawns create functioning vehicles with seated NPC crews. They drive to a reachable nearby road and dismount. Requires loaded terrain.
        VehicleArrivals = true,
    },
    ALifeJimmy = {
        -- No NPC spawns in player bases (right-click > [A-Life Jimmy] Bases), and non-hostile NPCs won't break, pick or scavenge anything inside.
        Base_Protect = true,
        -- NPCs open doors they can open, but only smash windows, break doors, pull down barricades or pick locks when they're looting or raiding, and only when there's no door they could open instead. When forcing their way in they go for a window before a door (much quicker), and looters may use windows when a building's doors are all locked. Everyone else goes another way or somewhere else.
        Breach_Policy = true,
        -- NPCs don't choose spots inside your grounds to wander to, and anyone who lingers there without belonging (6 seconds) walks back out. Not your residents, people following a player's orders, captives, raiders or anyone fighting a player, or someone you're standing next to (talking or trading).
        Base_KeepOut = true,
        -- NPCs fighting a player, and raiders, may still break doors and barricades in base areas, and walk past door and window markers anywhere. Off: bases and markers hold them too.
        Base_HostileCanBreach = true,
        -- Your residents shut a door or window of their base behind them once they've gone through and nobody is in the way, and one they opened in passing (one you opened or left open stays as it is). An outside door that was locked locks again. Off: doors and windows they open stay open.
        Base_ShutDoors = true,
        -- Right-click a door or window > [A-Life Jimmy] to mark it No trespassing (NPCs who don't belong keep out; your residents, people on your orders and captives may pass) or Private (everyone keeps out, your residents too). Raiders and anyone fighting a player pass both while Attackers can breach bases is on. NPCs can always get out, and shut a marked door they opened behind them (never one you opened or left open).
        Doors_Marks = true,
        -- How many bases each player (or vanilla faction) may mark. Admins aren't limited. Min: 0 Max: 20 Default: 2
        Base_MaxBases = 2,
        -- Rectangles (main, quarters, yard) one base may have. Admins aren't limited. Min: 1 Max: 30 Default: 6
        Base_MaxAreas = 6,
        -- Rooms (a bedroom, say) one base may mark as quarters. They don't count toward the areas limit. Admins are limited too. Min: 1 Max: 50 Default: 12
        Base_MaxQuartersRooms = 12,
        -- Tiles a resident crew stands guard on. Admins aren't limited. Min: 0 Max: 40 Default: 8
        Base_MaxPosts = 8,
        -- Right-click near an allied crew to invite them to one of your bases. They stand guard at your guard posts, live in the quarters and defend the base. A-Life never builds there.
        Residents_Enabled = true,
        -- People living at your base become members of an A-Life faction for your group (civilian, never spawns on its own), keeping their looks; restyle them in A-Life's Faction & NPC Creator. They go back to their old faction if they leave. Single player: A-Life keeps this faction in a file shared by all your SP worlds.
        Residents_JoinFaction = true,
        -- In A-Life's conversation, people living at your base talk to you as their own people, not as strangers: they greet you by name, call the base home, don't ask to join or offer you a walk, and A-Life's stranger, robbery and recruiting choices are hidden for them. On A-Life 1.4 their window gets a Home tab (how they're holding up, what they're on, base news, how long they've been here, what they think of you), and their small talk at the base is about the base. Off: A-Life's own lines, as before.
        Residents_Talk = true,
        -- When one of your residents gets a new kind of task (a guard post, a body to move, a weapon to fetch, a job) they say a short line, like "Heading to the Gate." At most one line each every 45 seconds, only with a player nearby. Default = Text and voice
        -- 1 = Off
        -- 2 = Text only
        -- 3 = Text and voice
        Residents_Announce = 3,
        -- Guards take turns on the posts, by the schedule or by tiredness: each base picks with Shifts by on its Schedule tab (the setting below is the default). By tiredness, on posts you haven't pinned anyone to, a rested resident relieves a tired guard (needs tiredness to be on). A tired guard sits down at the post (and gets up to fight). Off: posts are filled in order and nobody takes turns - no schedule and no Trip shifts (the setting below does nothing).
        Residents_Shifts = true,
        -- The default for a base that has not chosen: each base picks its own on the Schedule tab (Shifts by), and that choice wins over this option. The schedule (the default for a new world): three 8-hour shifts (day 06-14, evening 14-22, night 22-06) and a schedule per resident - a guard post, work, training, a trip, free time, sleep - dealt by the base itself (Auto-schedule, on by default) or set by hand. 20 minutes before a shift starts the relief walks up beside the post, and only then does the guard go off duty. Tiredness (automatic): a rested resident relieves a tired guard, as before; pins and jobs work as they do today. Switching between the two keeps what you set up: pins and picks become schedules, and a schedule is parked while shifts go by tiredness and comes back when they go by the schedule again. A world from before the schedule goes on it too when you load it: pins become Guard cells, workers the Worker role, and Auto-schedule deals in the rest; a base that prefers tiredness presses Shifts by on its Schedule tab. There is no 12-hour watch any more: a guard who stands two shifts in a row covers 16 hours. Default = The schedule
        -- 1 = Tiredness (automatic)
        -- 2 = The schedule
        Residents_ShiftMode = 2,
        -- Residents off a post live their day with animations of their own, with either kind of guards' shifts. They sleep in their room in their sleep window (in their own bed with Residents sleep in beds on): with Shifts by: The schedule, their Sleep shift (15-45 minutes in, to its end, or to the call before a Guard, Work or Train shift); otherwise (tiredness) about 22:30 to 06:30. Worn out, they take a two-hour nap. They eat and drink in their room at meal times - about one, six and twelve hours after their sleep shift ends, so around 07:00, 12:00 and 18:00 for someone who sleeps at night (and for everyone with tiredness shifts) - or when hungry or thirsty, unless the base is out of food. Otherwise they relax on the floor in their room, read, exercise or have a smoke (outside by day), which keeps them from wandering in and out of the house. Danger wakes them at once, and when a real threat gathers at the base (one of the crew fighting people, hostile people close by, zombies in numbers) everyone off duty gets up until it has passed, with a note for you. Workers and trainees keep their work. Off: as before.
        Residents_DayPlan = false,
        -- During their work, residents with a job work at it with the tool for it: a woodcutter chops with an axe (and fells the trees in your woodlots), a carpenter saws and hammers, gatherers forage across the yard, a farmer walks the crops, the quartermaster sorts at the drop box. With the day plan on or off. Off: they stand by the materials store while they work, as before, and nobody fells trees.
        Residents_WorkActs = true,
        -- A woodcutter needs an axe, a carpenter a saw and a farmer a watering can from one of the base's Tools stores. They take it out when their work starts, wear it as they work and put it back when they stop. With none in a Tools store that job makes nothing (the farmer only skips the watering). Off: they work with no tool, as before.
        Residents_JobTools = true,
        -- A woodcutter felling trees in a woodlot plants a young tree of the same kind where each one stood, once its wood is in the materials store. Off: the woodlot is cleared for good, as when you fell trees yourself.
        Jobs_ReplantTrees = false,
        -- Each resident gets a bed of their own in their quarters (a double bed sleeps two; everyone has a bed to themselves before anyone shares), kept until the beds or their quarters change. In their sleep window they walk to it, get in and lie down to sleep, and get up out of it at the end, at an alarm, when danger comes or when you talk to them. With no bed free, or none they can get to, they sit down and doze. Their task says Asleep only while they really are, else Going to bed, Dozing, Getting up or Resting. With the day plan off this still runs for the schedule's Sleep shifts. Off: they sit beside a bed as before.
        Residents_Beds = true,
        -- When a real threat comes to a base, everyone living there gets up and the crew off the guard posts go to it. It goes off when one of the crew is fighting people, shot or killed at the base, a raider is within 40 tiles, two other hostile people are within 25, hostile people drive up, a loud noise near the grounds comes with hostile people about (A-Life 1.4), or zombies gather in numbers by a building or a sleeper. Sleepers stand up, training and work pause (the task says Alarm), and those off a post head for the fight, with a longer reach while it lasts; the guards hold their posts, and with more than three going one stays in each quarters. It lasts 15 minutes after the last sign of the threat, with a note in the base's News. A loud noise alone sends whoever is awake to look, without waking anyone. Off: they react only to what each of them sees.
        Residents_BaseAlarm = true,
        -- Your people inside their own base behave like people at home. Nobody sneaks about (A-Life's Stealth specialty and its quiet walking). Nobody leaves the base to look for a zombie that went out of sight past the fence, or walks out to a noise past it (someone who shot at them is still hunted). Nobody goes to check a noise made by their own crew or by you, or treats the base's own barricades, generators and cars as clues to search. Guards stay on their posts unless a crewmate close by calls for help. The early-outbreak panic doesn't grip them. A real threat changes all of it: someone they see and fight, the base alarm, a mission, an escort. Off: A-Life decides as it does everywhere else.
        Residents_HomeCalm = true,
        -- With a working two-way radio (a walkie-talkie in your inventory, or a ham radio you stand next to: on, with power), right-click it > Call your people: a status check of your bases (who's at home, on a post, asleep, out, hurt or bitten, and the alarm), Come to me (1, 2 or 4 of the people off the guard posts, or one by name, follow you as an escort for a day), Hold the base (everyone at home up and alert for an hour), Sound the alarm, Stand down and Head home. The base must be within the reach of both your radio and the base's own radio. People you call travel unseen and come into view about 40 tiles from you, after about one game hour per 400 tiles. Off: no radio menu.
        Radio_Enabled = true,
        -- How far each base's own radio reaches, in tiles. A call goes through when the base is within both this and your radio's own range (750 tiles for a toy walkie-talkie, 2000 for an ordinary one, up to 20000 for military and high-end radios). A radioman living at the base doubles it. Min: 100 Max: 20000 Default: 4000
        Radio_BaseRange = 4000,
        -- Off duty, residents spread out over the quarters' rooms instead of crowding the middle, keep away from bodies, and at night rest beside the beds.
        Residents_RestSpots = true,
        -- When a resident dies the others mourn for three game days: one of them says something, they fight worse if the base is raided, and they turn on whoever did it (a player who isn't one of the base's people, or an NPC crew you can then send people to hunt).
        Residents_Grief = true,
        -- A-Life 1.4 only. A resident whose opinion of the base's people stays at A-Life's worst (Hates you) for 6 game hours leaves, as if sent away: no grudge, back to their old faction. Only hours with one of the base's people online count. They wait until they're home, off shift and awake. An admin's Clear opinions or a kind act before then puts it right.
        Residents_LeaveWhenHated = true,
        -- An off-duty resident carries zombie corpses out of the base to its body dump, one at a time. Set a dump from the Bases menu; with none, bodies are left where they are.
        Residents_ClearBodies = true,
        -- Residents can be given a mission or a clean-up duty that repeats at the same hour (faction window > People > Every day...). It runs by the game clock, whether or not the player who set it is online. At a base whose shifts go by the schedule it also runs the Trip shifts (Scavenge, Patrol, Patrol an area) and the Scavenger role. Off: nothing runs; saved routines and Trip shifts are kept, a Trip shift counts as Free and a Scavenger stands watch like an All-rounder.
        Residents_Routines = true,
        -- A routine never sends out so many that fewer than this many residents stay at the base, and Auto-schedule keeps a Scavenger home for the same; a Trip shift you put in someone's schedule yourself goes regardless. Pinned guards and workers are never picked automatically, and at a base on the schedule a routine takes only people on a Free shift. Min: 0 Max: 12 Default: 2
        Residents_RoutineKeepHome = 2,
        -- A crew only moves in if the base's quarters have a bed for each of them: single beds and sleeping bags hold 1, double beds 2, bunk beds twice that. Residents per base still caps it.
        Residents_NeedBeds = true,
        -- Residents eat 1 supply a day each and scrounge half that themselves; mark a container as a Food store (My people > Bases > Stores...) and they eat from it when their supplies run low. Out of food for 7 days, they leave. Off: they never go hungry, and only take enough from the Food store for training and trades (medicine in a Medical store still heals).
        Residents_NeedFood = false,
        -- Off: the crew never touches containers in the quarters, so your things are safe there; they only take what they need from containers you mark as stores (My people > Bases > Stores..., or right-click a container > Bases > Store). On (the old way): every 10 minutes while nobody is near, food, drink, smokes and medicine in the quarters' containers become supplies, and ammo and weapons go to their armory. Containers marked as stores are always left out of it.
        Residents_QuartersIntake = false,
        -- A-Life gives about half of all groups a flashlight beam at night (19:00 to 07:00), and a base's residents share one group. Not indoors (the default): residents put the light away while they sleep, sit, or are inside one of the base's buildings (a main building or quarters), and take it out again outside: on a post in the yard, on patrol, escorting you, on a trip. Traders visiting a base do the same inside its buildings. Always: A-Life's way, the light on wherever they are. Never: residents and visiting traders never carry one. Their night sight stays the same either way. Default = Not indoors at the base
        -- 1 = Not indoors at the base
        -- 2 = Always (A-Life's way)
        -- 3 = Never
        Residents_Flashlights = 1,
        -- On (A-Life's way): once a game hour while a player is near, A-Life switches on every ceiling light and street light inside a base that has residents, the way it keeps an outpost lit. Off: the light switches are yours; a light already on stays on until someone turns it off, and a dark room stays dark. Residents still put flashlights away indoors (see Residents use flashlights), so off leaves unlit rooms dark at night; it doesn't change how far they see.
        Residents_BaseLights = true,
        -- How many NPCs may live at one base (default 12, up to 30), whatever the beds say; beds in the quarters are the other limit. A crew only moves in if all of them fit. Min: 0 Max: 30 Default: 12
        Base_MaxResidents = 12,
        -- Longest side of one base area, for players. Admins may mark up to 400. Min: 10 Max: 400 Default: 80
        Base_MaxSide = 80,
        -- Hostile groups may attack a base with residents while no player is within 110 tiles (from day 7, at most every 3 days a base). Guard posts help; a crew out of food fights worse. Nobody takes the base over.
        Bases_Raids = true,
        -- Per hostile group within 80 tiles, checked every game hour while you're away. Min: 0 Max: 100 Default: 5
        Bases_RaidChance = 5,
        -- Under the name of someone living at your base: what they're meant to be doing (on guard, working, carrying a body, patrolling...), how far they are from where they should be, and whether they're stuck. Their spot is highlighted. Only for your own bases.
        NpcTags_Tasks = true,
        -- Under an NPC's name: keeping their distance from you, attacking you, protecting you, fighting zombies, checking out a noise, searching, scavenging, running away... So someone marked hostile who isn't attacking shows why.
        NpcTags_Intent = true,
        -- Outpost theft only angers the garrison at the players who were inside; avengers only hunt someone who actually killed that outpost's people; manhunters never switch to a bystander.
        Blame_Fair = true,
        -- Deeds move points with each faction; your standing moves one step at a time from the faction's default (hostile, careful, neutral, friendly, allied). Attacking or killing costs points instead of turning a faction hostile forever (the people you fought still turn on you). Helping them and gifts raise it.
        Standing_Enabled = true,
        -- Scales every standing gain (gifts, help). Factions also differ: families trust readily, raiders and hostile factions slowly. Min: 0 Max: 500 Default: 100
        Standing_GainRate = 100,
        -- Scales every standing loss (attacks, killings). Law and military take violence hardest, raiders and gangs least. Min: 0 Max: 500 Default: 100
        Standing_LossRate = 100,
        -- Puts a Reset standing button on everyone's Standing tab in the faction window: it wipes their standing points with every faction and crew. Admins can always reset. NPCs' own grudges stay.
        Standing_PlayersMayReset = false,
        -- With A-Life's per-person opinion on, a faction's standing with you is built from what its people think of you, what the faction remembers (your old points, and what people who are gone thought of you) and rumours. Hits, kills and help in a fight count through the people (they fade as A-Life's opinions do); gifts, trades and the rest add to what the faction remembers. Off: your standing points alone decide, as before.
        Standing_OneReputation = true,
        -- Food and medicine become supplies (growth; medicine heals defenders), guns, ammo and melee weapons go to the outpost's armory (defenders use them in sieges). Players who were inside recently gain standing with that faction (capped per day). Taken in once you're 40+ tiles away.
        Donations_Enabled = true,
        -- When you start talking, NPCs may bring up real things you did to their faction or crew (gifts, help, attacks, killings) with where and when it happened. Only deeds their faction has heard about.
        Memories_Enabled = true,
        -- Say 'take this' (or 'here you go', 'this is for you') to someone who isn't hostile while holding an item: they take it and your standing with their faction rises. Outpost members pass supplies and weapons on to their outpost.
        HandGifts_Enabled = true,
        -- Right-click one of your residents or someone following you > Equip (or 'Gear up for this.' in conversation): hand them weapons, clothes (residents) and gear from your inventory for a trip, and take any of it back whenever you like. No prices, no standing. Ammo that fits their gun goes into their spare rounds and isn't given back.
        Equip_Enabled = true,
        -- When someone you equipped stops following or waiting for you (for a quarter of an hour), what you lent them goes back into your inventory if you're within 30 tiles, or else a resident's goes into their base's stores and anyone else's waits until you're near. Off: they keep it until you take it back.
        Equip_AutoReturn = true,
        -- Now and then a few traders from a peaceable faction that you get on with walk to one of your bases, wait a few tiles outside the grounds and trade through the Trade window (right-click them, or say: want to trade). They sell food, medicine, tools, general goods or guns and ammo, and pay for what they want. Needs Trade (hand gifts) on.
        Traders_Enabled = true,
        -- Percent, each game hour from 7:00 to 17:00, that a base with one of its people online nearby gets traders. 3 is about one or two visits a week for a base someone plays at most days. 0: no visits (the debug menu still sends them). Min: 0 Max: 100 Default: 3
        Traders_Chance = 3,
        -- Game hours after traders leave a base before the next visit there can happen. Min: 6 Max: 336 Default: 48
        Traders_CooldownHours = 48,
        -- The world day from which traders visit. Min: 0 Max: 60 Default: 3
        Traders_MinDay = 3,
        -- Game hours traders wait once they've reached your base (a little longer if you're in the middle of trading). They leave sooner if they sell out or the base is raided. Min: 1 Max: 24 Default: 6
        Traders_StayHours = 6,
        -- A trader plus guards. More people means more who can fight off zombies while they wait, and more NPCs on the map. Min: 1 Max: 4 Default: 2
        Traders_PartySize = 2,
        -- Now and then a gunsmith comes, selling guns, ammo and gun parts. Off: never.
        Traders_Guns = true,
        -- Attack, hold up or kill a trader and the rest run; no traders visit that base for this many days. Traders killed by zombies bring no penalty. Min: 0 Max: 60 Default: 14
        Traders_BanDays = 14,
        -- A visiting trader can be asked to live at your base (Would you stay with us?). They need friendly standing with their faction, to like you (or a trade first), a free bed and some supplies. They keep a stall, restock from their faction, buy what you put in a Trade goods store and trade through the Trade window. Off: nobody can be asked, and a trader who stayed is an ordinary resident.
        Traders_CanStay = true,
        -- On A-Life 1.4 with its NPC opinions on: how much the trader must think of you (16 is Likes you, 41 Trusts you). Without opinions they want one trade with you first. Min: -100 Max: 100 Default: 16
        Traders_StayOpinion = 16,
        -- Taken from the base's supplies when a trader agrees to stay. 0: free. Min: 0 Max: 100 Default: 10
        Traders_StayCost = 10,
        -- Every this many game hours a trader living at your base gets fresh goods from their faction (about half of what a visit brings, up to twice a visit's most of each). Min: 6 Max: 168 Default: 24
        Traders_RestockHours = 24,
        -- With Sell what we can spare, a resident trader sells only what the base's Food and Medical stores hold beyond this many items of each. Min: 0 Max: 200 Default: 20
        Traders_SurplusKeep = 20,
        -- Now and then people from a peaceable faction that you get on with come to a base that has a free bed, and ask to be let in. Off: they never come.
        Refugees_Enabled = true,
        -- Percent, each game hour from 7:00 to 19:00, that a base with a free bed gets refugees. Twice that for a base with nobody living there. 0: none come. Min: 0 Max: 100 Default: 2
        Refugees_Chance = 2,
        -- The world day from which refugees come. Min: 0 Max: 60 Default: 2
        Refugees_MinDay = 2,
        -- Game hours after refugees leave a base before the next party can come there. Min: 6 Max: 336 Default: 48
        Refugees_CooldownHours = 48,
        -- 1 to 3. A party is cut to the free beds the base has. Min: 1 Max: 3 Default: 3
        Refugees_PartyMax = 3,
        -- Game hours refugees wait for an answer before they give up and leave. Min: 1 Max: 24 Default: 6
        Refugees_StayHours = 6,
        -- Taken from the base's supplies when a party is taken in. 0: free. Min: 0 Max: 50 Default: 0
        Refugees_Cost = 0,
        -- With friendly standing, say 'follow me', 'wait here' or 'go away' to someone (or answer yes to 'Maybe we can work together?'): their crew follows you for 3 game hours or holds its spot for 6. At most 4 followers.
        Friendlies_Enabled = true,
        -- Your own people and anyone following or waiting for you never complain or get scared when your gun points their way. Allies don't either while a fight is on around them. Anyone hostile to you or fighting you still reacts as usual.
        AimCalm_Enabled = true,
        -- NPCs normally only fight other NPCs their faction is at war with. With this on, anyone hostile to you is hostile to your residents too (anywhere, and while you are away: a grudge against the base owner, a raid, a faction hostile to all players). Allied NPCs step in within 25 tiles of you, friendly ones only when it is right on you (6 tiles). It fights back.
        Defenders_Enabled = true,
        -- A crew you've helped (or wronged) enough treats you by its own standing, not just its faction's: a crew that owes you stays friendly even if its faction turns hostile, and the other way round. A grudge or a raid still wins.
        CrewStanding_Enabled = true,
        -- How many times one of your own people or an ally lets it go when you hit them (within 10 minutes): no anger, no grudge, no lost standing, they don't fight back. The next hit turns that one person against you, never their faction or crew. Killing still counts as killing. 0: off (A-Life's own rule only). Min: 0 Max: 10 Default: 2
        FriendlyFire_Forgiven = 2,
        -- Once a faction hears what you did, the story reaches other factions over the next day or so - weaker, and sometimes exaggerated, played down, lost or pinned on someone else. The victim's friends think less of you, their enemies a little better; raiders barely care about violence, the law cares most. Rumors fade over a few days and on their own never make a faction hostile (careful at worst). Harm to people who were hostile to you angers nobody. Off by default.
        Rumours_Enabled = false,
        -- Emotes count as saying the matching thing to the nearest person you face: wave = hello, follow me / come here = follow, stop / freeze = wait, move out = go away, thank you, thumbs up, insult, yes / no answer their questions.
        Emotes_Enabled = true,
        -- Aim a gun at an NPC and tap the shout key (Q). They may surrender: hands up, and you can make them drop their weapon or empty their pockets, or let them go. If they refuse, they hold a grudge.
        Intimidation_Enabled = true,
        -- A-Life has hold-ups of its own (orders in the talk window). A-Life's: Q while aiming gives its orders (hands up, then hand over weapons, then empty pockets), with ours on top: the disarmed stay disarmed, standing, grudges, Mercy. Ours: our own hold-ups (Q) beside A-Life's, one owner per NPC. Talk window only: Q is the game's own shout. Default = A-Life's, Q gives its orders
        -- 1 = A-Life's, Q gives its orders
        -- 2 = Ours
        -- 3 = Talk window only
        Intimidation_Mode14 = 1,
        -- A-Life weighs a hold-up its own way. On: someone hurt, frightened or in pain gives in more easily, and crew-mates you killed lately make them more or less likely to (by who they are), up to 30 points either way. Only with Hold people up at gunpoint on.
        Intimidation_Odds14 = true,
        -- Told to drop their weapon or empty their pockets, someone who surrendered may refuse: run for it, or (still armed) fight. More likely when they're angry with you, hostile, or have the numbers; less when they're wounded or peaceable.
        Intimidation_Defiance = true,
        -- How long someone who surrendered stays put with nobody aiming at them before they may make a break for it (checked every 3 seconds after that). Walk more than 30 tiles away and they slip off anyway. Only with 'Captives may refuse orders' on. Min: 3 Max: 300 Default: 15
        Intimidation_CoverSeconds = 15,
        -- Someone you let go after a hold-up remembers how you treated them. Treated well, they may put in a good word or their crew may offer to join you; robbed or hurt, they may warn everyone or their squad may come after you. Killing someone who surrendered costs extra standing and brings revenge.
        Mercy_Enabled = true,
        -- A-Life only saves squads and a few outposts. Promoted keeps crews you've interacted with; All keeps every living NPC. Default = Promoted crews
        -- 1 = A-Life default
        -- 2 = Promoted crews
        -- 3 = All living NPCs
        Persist_Mode = 2,
        -- Min: 0 Max: 500 Default: 150
        Persist_Cap = 150,
        -- Once an outpost has been manned it no longer expires of old age; it falls only when its garrison is wiped out. One that is never built or manned still expires as in A-Life. Scripted events are unaffected.
        Outposts_Permanent = true,
        -- When a player talks to (or fights) an encounter crew, it becomes a real squad: it lives on off-screen, travels and scavenges, and is saved with the world. Uses a roaming-squad slot.
        Promote_Enabled = true,
        -- A crew you fight carries on as a real squad - whether you hit them first or they opened fire on you. Survivors remember it through faction reputation.
        Promote_OnFight = true,
        -- A crew that robs you and walks away carries on as a real squad you may meet again.
        Promote_OnRobbery = true,
        -- A-Life fills its roaming-squad cap quickly in a new world. Crews you interact with can still be promoted past it, up to this many at once. Min: 0 Max: 50 Default: 10
        Promote_MaxExtra = 10,
        -- Off-screen squads head to an outpost of their own faction and join its garrison; they appear there the next time you're nearby. Calls for help are answered by the outpost's own faction. Fewer groups roam as a result.
        Homes_Enabled = true,
        -- Per squad, per game hour, when an outpost of its faction has room nearby. Doubled when the garrison is under half strength. Min: 0 Max: 100 Default: 4
        Homes_JoinChance = 4,
        -- Squads only consider outposts within this distance. Calls for help reach any distance. Min: 100 Max: 5000 Default: 900
        Homes_JoinRadius = 900,
        -- A small squad (3 or fewer) with no outpost of its own nearby may move in with a friendly peaceable faction, like a lone nurse joining a family. They keep their own faction.
        Homes_Mixed = true,
        -- This share of squads never settle down or join an outpost. Min: 0 Max: 100 Default: 30
        Homes_NomadShare = 30,
        -- For squads of 1-3 whose faction has no outpost nearby. The home (a holdout, forest camp or held house, whatever the faction uses) is placed when a player is 60-150 tiles from their town, never within 40 tiles of a player, never in a base area or a building a player has been in. Min: 0 Max: 100 Default: 2
        Homes_FoundChance = 2,
        -- Real garrison members leave to scavenge or patrol and come back (or don't). Replaces A-Life's outpost squads, which appear from nowhere and never return. Members only leave while no player is within 120 tiles, and the garrison never drops below its minimum.
        Expeditions_Enabled = true,
        -- Outposts spend supplies from expeditions (and a little foraging) to add a supply crate and campfire, then a fence with a gate at the main door, then take over a neighbouring building. Only placed while no player is within 40 tiles. The main entrance is never blocked.
        Growth_Enabled = false,
        -- When an outpost's garrison is wiped out, its barricades, fences, crates (and their loot) stay standing instead of vanishing. New groups prefer to settle in ruins of a type their faction uses.
        Ruins_Keep = true,
        -- When A-Life's groups fight each other away from players, the fallen are left where it happened, dressed as who they were. Bodies appear the next time a player comes within about 110 tiles (never within 40, never in a base area).
        WarDead_Enabled = true,
        -- Away from players, a group may attack an outpost of a faction it's hostile to (A-Life's own faction stances; peaceable factions never do). Fences and buildings help defenders. Outposts that lose everyone fall and leave ruins, and the attackers may move in.
        Sieges_Enabled = true,
        -- Per eligible group and outpost within 80 tiles. Each outpost can be attacked at most every 2 days. Min: 0 Max: 100 Default: 15
        Sieges_Chance = 15,
        -- Across the whole map. 0 turns sieges off. Min: 0 Max: 50 Default: 3
        Sieges_PerDay = 3,
        -- An outpost whose faction counts a player as Friendly defends this much better in off-screen sieges. Min: 0 Max: 200 Default: 15
        Sieges_FriendlyBonus = 15,
        -- The same, for a faction that counts a player as Allied. Min: 0 Max: 200 Default: 30
        Sieges_AlliedBonus = 30,
        -- Each gun given to an outpost goes to one of its guards, with some of its ammo; they carry it the next time they spawn and drop it if killed.
        ArmedGuards_Enabled = true,
        -- Give NPCs longer before a path counts as stuck, and before they give up. Turn off for a baseline session.
        Tuning_Enabled = true,
        -- How long without progress before a move counts as stalled. A-Life default 800. Min: 500 Max: 10000 Default: 800
        Tuning_StallMs = 800,
        -- Time allowed for the pathfinder to start moving. A-Life default 1600. Min: 1000 Max: 20000 Default: 1600
        Tuning_StartupGraceMs = 1600,
        -- A-Life default 3. Min: 1 Max: 20 Default: 3
        Tuning_MaxStalls = 3,
        -- Checks (every 0.5s) before a player's game lets go of an NPC it no longer owns. Higher means fewer resets when players move near each other. A-Life default 3. Min: 1 Max: 40 Default: 8
        Tuning_OwnershipLossReads = 8,
        -- When deciding whether a roaming squad may appear, ignore encounter crews and camps.
        Crowding_SquadsOnly = true,
        -- In multiplayer, when a different player's game takes over an NPC, it resumes chasing or searching where the last owner left off instead of forgetting.
        Handoff_Enabled = true,
        -- Fixes for bugs inside A-Life itself. NPCs are put away before the area around them unloads, so they don't come back as zombies (single player and servers). In multiplayer, NPCs left frozen are rebuilt. NPCs inside a building can unlock its key-locked doors, as a player there could, and knock broken glass out of a window before climbing through. On servers, zombies no longer drop masks and hats they aren't wearing (clothing left on reused zombie bodies). Also removes an error that filled the log. Off brings these bugs back.
        AlifeFixes_Enabled = true,
        -- A zombie the game creates inside a base's main building or quarters, or on an upper floor anywhere in a base, as the area loads or the zombie population fills it, is removed in the moment it is made, before anyone sees it. Zombies that walk in, and people or NPCs who turn inside, are never touched: only the game's own new zombies are. Zombies spawned there by an admin or another mod are removed too. Needs Fix A-Life bugs on. Off by default.
        AlifeFixes_NoZombiesInBase = false,
        -- Instead of chasing every zombie in sight, NPCs fight zombies that are close, coming for them, their allies or a player they're friendly with, or at their outpost or post. They stay calmer and will stop to talk.
        ZombieFocus_Enabled = true,
        -- Zombies closer than this are always fought. A-Life's own range is 16-21+ tiles. Min: 2 Max: 30 Default: 8
        ZombieFocus_Radius = 8,
        -- Unless attacked or holding a grudge, NPCs won't start fights when outgunned, low on ammo against an armed target, or surrounded by zombies (gunfire would draw them). Against zombies they switch to melee when the dead are thick around or ammo is low.
        Discretion_Enabled = true,
        -- A-Life infects and turns bitten NPCs by its own Mortality and Transmission settings. This adds a Bitten tag and the infection moodles, sets how often one zombie bites, and, where A-Life's own wounds are off, has an infected NPC die when their time comes.
        ZombieBites_Enabled = true,
        -- How long each zombie waits before biting the same NPC again. A-Life's own is 4.5; it lets up to 8 zombies bite one NPC at once. Min: 0.50 Max: 10.00 Default: 3.50
        ZombieBites_BiteGap = 3.5,
        -- Hits leave wounds on body parts: scratches, lacerations, deep wounds, bites, bullet wounds, bruises and fractures, depending on what hit them. Wounds bleed until bandaged or clotted, heal over days, and show on the hover tag.
        Injuries_Enabled = true,
        -- A broken or badly hurt leg makes them limp, and hurt arms make them aim worse, until healed or treated.
        Injuries_Effects = true,
        -- How fast open wounds drain health. 0: wounds never bleed. At 100 an untreated bullet wound kills in about six minutes. Min: 0 Max: 300 Default: 100
        Injuries_BleedRate = 100,
        -- At 100 a scratch heals in about two days, a bullet wound in about ten, a fracture (with a splint) in about forty. Min: 10 Max: 1000 Default: 100
        Injuries_HealSpeed = 100,
        -- Right-click a hurt NPC who isn't hostile to you (or has surrendered to you) to bandage, stitch or splint their wounds with your own supplies. Gives First Aid experience, and a little standing with their faction and crew.
        Injuries_Treatment = true,
        -- A bleeding NPC who isn't fighting bandages the wound with their own kit, even on guard or under orders; a resident fighting zombies stops to do it once none is close. With nothing left they call out when someone can come or hear them, and the nearest crewmate or fellow resident with a bandage (a medic first) comes over and does it. One dressing per wound.
        Injuries_SelfCare = true,
        -- Tops up each NPC's first aid when they appear. A-Life gives most 1-2 (medics 4). 0 leaves A-Life's own. Min: 0 Max: 10 Default: 3
        Injuries_Bandages = 3,
        -- Open wounds that aren't disinfected can get infected (not the zombie infection): they heal at a quarter of the speed and hurt more until disinfected. Alcohol bandages disinfect as they go on.
        Injuries_WoundInfection = true,
        -- A-Life spares NPCs from fall damage. With this on, a fall of a floor bruises or breaks a leg, two floors most likely break one, and three or more mean bad breaks and real harm.
        Injuries_Falls = true,
        -- NPCs on fire build up burns: painful, slow to heal and prone to infection. Treat them by disinfecting and bandaging.
        Injuries_Burns = true,
        -- With nothing bleeding, an NPC's health slowly comes back (about a day to full), held back by wounds that haven't healed yet. A-Life has no recovery of its own.
        Injuries_Regen = true,
        -- A resident with the Medic specialty walks over to wounded residents of their base, downed ones first, then the worst bleeding, and treats them with supplies from the base's Medical store (bandage, disinfect, stitch, splint, take a bullet out). Players of the base can call them too: right-click Call the medic, or Medic! in a conversation. During the base alarm they only treat people under a roof.
        Injuries_MedicRounds = true,
        -- NPCs near you and your residents have needs, shown in Medical Check and on the hover tag when pressing. Residents eat and drink at a base with food and sleep at night (in their Sleep shift where shifts go by the schedule); NPCs away from you look after themselves. Food and drink you hand them help; so does a drink for their nerves. Wounds, losing crewmates and being held up stress them.
        Needs_Enabled = true,
        -- Tired NPCs can't sprint; very hungry, thirsty, exhausted or panicked ones aim worse; starving or dehydrated residents slowly lose health (anyone else gets by on their own supplies), and wounds heal at half speed. Stressed or panicked NPCs give up more easily when held up.
        Needs_Effects = true,
        -- At 100 an NPC with no food gets hungry in about a day; a resident at a base with no food starves in under two. Thirst is a little faster. Min: 10 Max: 500 Default: 100
        Needs_Rate = 100,
        -- Now and then an NPC near you says something about their most pressing moodle: hunger, thirst, tiredness, stress, pain, drink, sickness, grief or the infection taking hold. Never in a fight.
        Needs_Lines = true,
        -- An NPC near you says something when they change course: backing off from a fight that isn't worth it (and why: the odds, the noise, their ammo), deciding it's on after all when you come too close, or stepping in to protect you or their base. At most once every 45 seconds each.
        Intent_Lines = true,
        -- Off: NPCs never get hungry (no moodle, no effects).
        Needs_Hunger = true,
        -- Off: NPCs never get thirsty (no moodle, no effects).
        Needs_Thirst = true,
        -- Off: NPCs never get tired (no moodle, no sprinting limits).
        Needs_Fatigue = true,
        -- Coffee, tea, Vitamins, coffee beans or a cola handed to an NPC makes them less tired, and residents on watch take one from a base Food or Medical store when tired. Each dose works less while the last is still in them, part of the tiredness comes back as it wears off, and too much makes them jittery. Needs tiredness on.
        Needs_Caffeine = true,
        -- Off: no stress from wounds, losses or hold-ups (no moodle, no effect on aim or surrendering).
        Needs_Stress = true,
        -- Off: alcohol you hand over still calms them but never gets them drunk.
        Needs_Drunk = true,
        -- Off: living near bodies doesn't sicken NPCs (no smell or sickness moodles, no effects).
        Needs_CorpseSickness = true,
        -- Residents mourning a crewmate are Depressed, then Unhappy, then Sad over three days, and stay a little stressed. Off: no moodle or stress (they still mourn).
        Needs_Grief = true,
        -- Shows A-Life's own fear and panic as moodles. Display only: A-Life acts on them either way.
        Needs_Fear = true,
        -- Bitten NPCs go Unwell, Feverish, Delirious and Zombified as they near turning, getting weaker. Off: no moodle or weakness (they still turn).
        ZombieBites_Stages = true,
        -- Lets an admin run Debug > Self-test > Scenario test in single player: it builds a base, spawns a crew, zombies and a hostile group, and changes the world for good. Only tick this on a world made for testing.
        Scenario_Allow = false,
        -- Off hides the [A-Life Jimmy] entry of the right-click menu for everyone, admins and -debug games included, and its Debug (admin) tools go with it until it is back on. Each player can also hide it just for themselves in Options > Mods. Trade, Medical Check and the other entries outside it stay. With it hidden: the faction window opens from the people button in the sidebar (its Bases section has the tools for land, buildings, guard posts, stores and the body dump, and the Show bases on the ground tick box), NPC safety from its sidebar button or the faction window, and you invite someone to your nearest base by talking to them (Come live at our base). Only in this menu: the Status panel, door and window marks, letting someone who surrendered go (Q still makes them drop their weapon and empty their pockets), sending a whole base crew away at once (People > Actions sends one at a time) and inviting someone to a base other than your nearest.
        ContextMenu_Show = true,
        -- Shows Debug (admin) in the [A-Life Jimmy] right-click menu in single player: admin tools for testing (self-test, spawning, sieges, traders). Off, it shows only in a -debug game, on a test world (the scenario test option, or a save with the word test in its name), and to admins in multiplayer.
        Debug_Menu = false,
        -- Write A-Life counters (ownership handoffs, movement stalls, squads, saves) to the server log as [ALIFE-JIMMY] diag lines.
        Diagnostics_Enabled = false,
        -- Min: 1 Max: 60 Default: 5
        Diagnostics_IntervalMinutes = 5,
        -- With your safety on, hitting, shooting or shoving one of your own people (see Who safety protects) does nothing (no damage, no anger). Multiplayer uses the game's own safety button (server option SafetySystem); single player gets a safety button in the left sidebar.
        NpcSafety_Enabled = true,
        -- With your safety on, which NPCs your hits can't hurt. People hostile to you can always be hurt. Default = Your residents and allies
        -- 1 = Your residents
        -- 2 = Your residents and allies
        -- 3 = Anyone not hostile to you
        NpcSafety_Who = 2,
        -- Multiplayer. On: a faction's leader can set their people (residents and parties) to treat every player outside the faction as hostile (My people > Reputation). The server's PvP setting, safehouses and non-PvP zones still apply, and faction members are never targets. Off: the switch is greyed out.
        HostileFactions_Allow = false,
        -- To the game an NPC is a zombie, so any NPC near you means "Not safe to sleep here", fast-forward dropping to normal speed, search mode switching off, panic when one walks into view, and the jump-scare sound when one steps out right beside you. With this on, NPCs who aren't hostile to you no longer do any of that. Zombies in view, hostile NPCs within 20 tiles and anyone attacking or robbing you still stop you resting; a zombie or a hostile NPC coming into view still panics you, and one stepping out beside you still plays the sound. Followers also stand back while you sit, rest or sleep. Fast-forward is single player only; on a server the panic part runs on the server. Off: the game's own rules.
        RestNearNpcs_Enabled = true,
        -- A-Life 1.4 draws a random name for every NPC unless their NPC Creation preset's NPC name is Set name. On, a preset you made yourself that has no name setting (every preset made before 1.4, and Random name, which A-Life saves the same way) names its people with its Display name, as before 1.4, in our tags and windows and, for your residents, in A-Life's too. Off, or a preset set to Random male name or Random female name: A-Life's random names.
        Names_CreatorDisplayName = true,
        -- Hover the mouse over an NPC to see their name above their head, coloured by how they feel about you.
        NpcTags_Names = true,
        -- Adds a [TAG] (the faction's initials) before the name, so you can tell who belongs to which faction.
        NpcTags_Factions = true,
        -- A skull in front of the label of anyone hostile to you, even if they seem friendly.
        NpcTags_Hostile = true,
    },
    SIMBAproduz_TSY = {
        -- 0 = anytime; 1 = day and brighter twilight; 2 = night and darker twilight. Dawn and dusk change gradually. Min: 0 Max: 2 Default: 0
        TimeMode = 0,
        -- Allows sprinters without a locked target to scream occasionally while a player is within the encounter range. Disable it to keep only screams tied to target lock, the hunt, close range or a player shout.
        EnablePresenceScreams = true,
        -- Rolled once whenever a distant presence scream becomes eligible. 0 prevents it; 100 preserves the original frequency. A failed roll waits for a new normal interval. Other scream types are unaffected. Min: 0 Max: 100 Default: 35
        PresenceScreamChance = 35,
        -- Spontaneous presence screams and target-locked hunt screams can occur only while a player is within this distance. The full 10-300 tile range is supported. Min: 10 Max: 300 Default: 150
        FarRange = 150,
        -- Allows an extra scream when a sprinter enters within 8 tiles after being farther away. Disable it to reduce noise during close combat.
        EnableNearScream = true,
        -- Time without the target or clear sight before a rediscovery scream can occur. 0.04 = 144 in-game seconds; real time follows day length. Min: 0.01 Max: 0.20 Default: 0.04
        RediscoveryHours = 0.04,
        -- One roll is made per eligible chase interval. 0 disables chase screams; 100 makes every eligible interval succeed. Identification is always guaranteed on target lock. Min: 0 Max: 100 Default: 20
        ChaseScreechChance = 20,
        -- Interval between chase-scream attempts for the same sprinter. 0.03 = 108 in-game seconds. Lower values are more vocal; real time follows day length. Min: 0.00 Max: 0.10 Default: 0.03
        ChaseCooldownHours = 0.03,
        -- Maximum confirmed screams in one hunt chapter. Identification or rediscovery starts a chapter; after 0.1 in-game hour, a silent sprinter can gain a second wind. Min: 1 Max: 20 Default: 3
        MaxScreamsPerChapter = 3,
        -- Multiplier applied to every mod voice. 1.0 keeps the intended mix; lower values soften it and higher values amplify it. Min: 0.10 Max: 3.00 Default: 1.00
        GlobalVolume = 1.0,
        -- Controls every scream except the close-range scream. 0.08 is recommended; 0.10 is normal level; values above 0.10 progressively amplify it up to 3x. Min: 0.01 Max: 1.00 Default: 0.08
        FarVolume = 0.08,
        -- Volume multiplier used only for close-range screams. 1.0 is normal; lower values soften them and higher values make them louder. Min: 0.10 Max: 3.00 Default: 1.00
        NearVolume = 1.0,
        -- Maximum pitch offset assigned from each sprinter's stable identity. 0 keeps the source pitch; 7 allows up to +/-7%. The same sprinter keeps its voice and pitch. Min: 0 Max: 15 Default: 7
        PitchVariation = 7,
        -- After a scream is confirmed, one vanilla world sound starts at the sprinter's real position. Any zombie type inside the radius may react. Disable for audio only.
        AlertNearbyZombies = true,
        -- Hearing radius for normal zombies and sprinters. This works only when attraction is enabled; larger values can move a larger horde. Min: 10 Max: 120 Default: 40
        AlertRadius = 80,
        -- Turn this off to make distant presence screams a warning for players only. They still play, but zombies do not react to them.
        AlertFromPresenceScreams = true,
        -- Turn this off to make close-range screams a warning for players only. They still play, but zombies do not react to them.
        AlertFromCloseScreams = true,
        -- Covers the identification, chase, rediscovery and recovery screams, and the reaction to a player shout. Turn this off and they still play, but zombies do not react to them.
        AlertFromHuntScreams = true,
        -- A real player shout has only a limited chance of an answer, and at most one eligible sprinter responds. After answering, it stays silent for 0.4 in-game hour; repeated shouts cannot force replies.
        ShoutResponse = true,
        -- Maximum distance for an eligible sprinter to answer. This works only when shout responses are enabled; area limits may reduce the number of replies. Min: 10 Max: 120 Default: 50
        ShoutResponseRadius = 50,
        -- Nearby confirmed screams share an area budget. Larger values suppress more overlapping follow-up screams. The target-lock identification scream bypasses this limit. Min: 5 Max: 80 Default: 35
        ClusterRadius = 35,
        -- How long confirmed screams remain in the nearby-area budget. 0.01 = 36 in-game seconds; real time follows day length. Min: 0.00 Max: 0.10 Default: 0.01
        ClusterCooldownHours = 0.01,
        -- Number of confirmed screams the area can hold before follow-up screams are suppressed. Identification screams still occur, then quiet later screams nearby. Min: 1 Max: 10 Default: 1
        MaxClusterScreams = 1,
        -- Limits how far away target-locked sprinters are fully evaluated. Spontaneous voices use the vocal range, so that range becomes the minimum automatically. Higher values may use more CPU. Min: 50 Max: 400 Default: 220
        MaxProcessDistance = 220,
        -- Lower values react sooner and use more CPU; higher values spread the work and react later. 6 is recommended. Timing does not depend on frame rate. Min: 1 Max: 20 Default: 6
        TickRate = 6,
        -- Kept only so that old presets still load. Identification happens when a sprinter locks a player as its chase target; this value has no effect. Min: 0 Max: 100 Default: 60
        ScreechChance = 60,
        -- Kept only so that old presets still load. Every scream now plays from the real sprinter's moving 3D source; this value has no effect.
        NearAsWorldSound = false,
        -- Kept only so that old presets still load. A confirmed world sound always starts at the sprinter's real position and floor; this value has no effect.
        AlertAtScreamPosition = true,
    },
    StarvingZombies = {
        -- When enabled (checked), the size of the body has an effect on the distance.
        BodySizeImpactsSmell = true,
        -- When enabled (checked), only zombies in the same building as a body are capable of smelling it.
        BodyIndoorCheck = true,
        -- When enabled (checked), worn/attached items will be visible on the skeleton.
        -- This can look weird.
        AllowWornAttachedItems = false,
        -- When a body is consumed, every individual item has this chance of being destroyed. Min: 0 Max: 100 Default: 50
        ItemDestroyChance = 50,
        -- This value is used to calculate how long a body takes to be eaten.
        -- It is in real world seconds.
        -- The actual time taken to consume a corpse is adjusted by:
        -- - Size of the body relative(ish) to a human.
        -- - Number of zombies eating the body.
        -- - Current game speed. Min: 60 Max: 2147483647 Default: 1200
        BaseEatTime = 1200,
        -- Any body within this distance from a zombie will always be selected as a possible target. Min: 0 Max: 20 Default: 3
        BodyStartDistance = 3,
        -- Any body further than this distance from a zombie will never be selected as a target. Min: 20 Max: 200 Default: 100
        BodyMaxDistance = 100,
        -- Bodies will have their age (world hours) multiplied by this value, which is then added to Start Distance.
        -- Any body within this distance will be selected as a possible target. Min: 0.00 Max: 2.00 Default: 0.35
        BodyAgeMultiplier = 0.35,
        -- The current wind speed (km/h) is multiplied by this value, which is then added to the result of [Start Distance + Age Multiplier]. Min: 0.00 Max: 2.00 Default: 0.75
        BodyWindSpeedMultiplier = 0.75,
        -- This angle is used to determine whether a zombie falls inside an area that is projected from bodies in the direction of the wind, up to a distance of [Start Distance + Age Multiplier + Wind Speed Multiplier].
        -- Set to 0 to disable, causing wind direction to have no effect. Min: 0 Max: 90 Default: 55
        BodyDispersionAngle = 55,
        -- This value is divided by the current temperature, to get a multiplier that adjusts the result of [Start Distance + Age Multiplier].
        -- This value is in celsius.
        -- Set to 0 to disable temperature having an effect.
        -- At default, temperatures above 26C increase the distance bodies can be smelled by zombies, while temperatures below 26C decrease the distance. Min: 0.00 Max: 50.00 Default: 26.00
        BodyTemperaturePeak = 26.0,
        -- When enabled (checked), zombies will be able to smell players.
        CanSmellPlayer = true,
        -- Any player within this distance from a zombie will always be targeted. Min: 0 Max: 20 Default: 0
        PlayerStartDistance = 0,
        -- Any player further than this distance from a zombie will never be selected as a target. Min: 0 Max: 200 Default: 50
        PlayerMaxDistance = 10,
        -- The amount of blood on a player, and on items in their inventory, will be multiplied by this value, which is then added to Start Distance. Min: -1.00 Max: 2.00 Default: 0.75
        PlayerBloodMultiplier = 0.75,
        -- The current wind speed (km/h) is multiplied by this value, which is then added to the result of [Start Distance + Blood Multiplier]. Min: 0.00 Max: 2.00 Default: 0.25
        PlayerWindSpeedMultiplier = 0.25,
        -- This angle is used to determine whether a zombie falls inside an area that is projected from players in the direction of the wind, up to a distance of [Start Distance + Blood Multiplier + Wind Speed Multiplier].
        -- Set to 0 disable, causing wind direction to have no effect. Min: 0 Max: 90 Default: 35
        PlayerDispersionAngle = 35,
    },
    WanderingZombies = {
        -- When enabled, lone zombies will use pathToSound, which causes them to attack objects in their path
        -- If using 'Always' with Destroyable World Fences, a lot of zombies will be found attacking fences, which makes things easier for awhile Default = Indoors
        -- 1 = Always
        -- 2 = Indoors
        -- 3 = Random
        -- 4 = Never
        Destructive = 2,
        -- Zombies will try not to path further than this
        -- Does not account for needing to walk around objects(walls, etc) Min: 10 Max: 100 Default: 40
        MaxTravel = 40,
        -- Method used for ticks Default = EveryOneMinute (in-game)
        -- 1 = Always
        -- 2 = OnTick (frame)
        -- 3 = EveryOneMinute (in-game)
        -- 4 = EveryTenMinutes (in-game)
        -- 5 = EveryHours (in-game)
        Counter = 3,
        -- How many times the chosen counter must occur before a zombie may wander Min: 1 Max: 9999999 Default: 5
        NumTicks = 5,
        -- Maximum ticks that can be added randomly to the above setting Min: 0 Max: 9999999 Default: 10
        RandTicks = 10,
        -- At what hour should lone zombies start wandering randomly
        -- If set to static, uses Start Hour: Max
        -- If set to random, Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownStartHour = 1,
        -- Refer to Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MinStartHour = 0,
        -- Refer to Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MaxStartHour = 0,
        -- Period of time lone zombies are allowed to wander for when the hour reaches Start Hour
        -- If set to static, uses Total Hours: Max
        -- If set to random, Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownTotalHours = 1,
        -- Refer to Total Hours tooltip for information Min: 0 Max: 24 Default: 0
        MinTotalHours = 0,
        -- Refer to Total Hours tooltip for information Min: 0 Max: 24 Default: 24
        MaxTotalHours = 24,
        -- Chance each zombie has of wandering randomly
        -- Chance is only rolled when the timer has elapsed and the zombie is ready to move
        -- If set to static, uses Random Chance: Max
        -- If set to random, Random Chance is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownWanderChance = 1,
        -- Refer to Random Chance tooltip for information Min: 0 Max: 100 Default: 0
        MinWanderChance = 0,
        -- Refer to Random Chance tooltip for information Min: 0 Max: 100 Default: 100
        MaxWanderChance = 100,
        -- At what hour should lone zombies start homing in on the nearest player
        -- If set to static, uses Homing Start Hour: Max
        -- If set to random, Homing Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHomingStartHour = 1,
        -- Refer to Homing Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MinHomingStartHour = 0,
        -- Refer to Homing Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MaxHomingStartHour = 0,
        -- Period of time lone zombies are allowed to home onto players when the hour reaches Homing Start Hour
        -- If set to static, uses Homing Total Hours: Max
        -- If set to random, Homing Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHomingTotalHours = 1,
        -- Refer to Homing Total Hours tooltip for information Min: 0 Max: 24 Default: 0
        MinHomingTotalHours = 0,
        -- Refer to Homing Total Hours tooltip for information Min: 0 Max: 24 Default: 24
        MaxHomingTotalHours = 24,
        -- Chance each zombie has of homing in on the nearest player
        -- Chance is only rolled when the timer has elapsed and the zombie is ready to move
        -- Max Travel applies to homing zombies
        -- If set to static, uses Homing Chance: Max
        -- If set to random, Homing Chance is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownToPlayers = 1,
        -- Refer to Homing Chance tooltip for information Min: 0 Max: 100 Default: 0
        MinToPlayers = 0,
        -- Refer to Homing Chance tooltip for information Min: 0 Max: 100 Default: 20
        MaxToPlayers = 20,
        -- Lone zombies inside this radius ignore the homing settings
        -- If set to static, uses Random Radius: Max
        -- If set to random, Random Radius is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownRadius = 1,
        -- Refer to Random Radius tooltip for information Min: 0 Max: 90 Default: 0
        MinRadius = 0,
        -- Refer to Random Radius tooltip for information Min: 0 Max: 90 Default: 70
        MaxRadius = 70,
        -- When enabled, lone zombies that are homing in on the player have their current path interrupted as soon as they're inside the Random Radius Default = Off
        -- 1 = On
        -- 2 = Off
        -- 3 = Random
        RadiusInterrupt = 2,
        -- At what hour should lone zombies flee from the nearest player
        -- If set to static, uses Flee Start Hour: Max
        -- If set to random, Flee Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleeStartHour = 1,
        -- Refer to Flee Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MinFleeStartHour = 0,
        -- Refer to Flee Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MaxFleeStartHour = 0,
        -- Period of time lone zombies are allowed to flee from players when the hour reaches Flee Start Hour
        -- If set to static, uses Flee Total Hours: Max
        -- If set to random, Flee Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleeTotalHours = 1,
        -- Refer to Flee Total Hours tooltip for information Min: 0 Max: 24 Default: 0
        MinFleeTotalHours = 0,
        -- Refer to Flee Total Hours tooltip for information Min: 0 Max: 24 Default: 24
        MaxFleeTotalHours = 24,
        -- Chance each zombie has of moving away from the nearest player when inside Flee Radius
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- Max Travel applies to fleeing hordes
        -- If set to static, uses Flee Chance: Max
        -- If set to random, Flee Chance is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleePlayers = 1,
        -- Refer to Flee Chance tooltip for information Min: 0 Max: 100 Default: 0
        MinFleePlayers = 0,
        -- Refer to Flee Chance tooltip for information Min: 0 Max: 100 Default: 0
        MaxFleePlayers = 0,
        -- Lone zombies inside this radius move away from the player
        -- This takes priority over Random Radius
        -- If set to static, uses Flee Radius: Max
        -- If set to random, Flee Radius is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownFleeRadius = 1,
        -- Refer to Flee Radius tooltip for information Min: 0 Max: 90 Default: 0
        MinFleeRadius = 0,
        -- Refer to Flee Radius tooltip for information Min: 0 Max: 90 Default: 0
        MaxFleeRadius = 0,
        -- Allows zombies to form and move together as hordes
        -- Hordes use the rally group settings to function
        -- When Rally Group Size is set to 0, there is no limit on horde size
        -- Zeds will separate from a horde if they can't stay within Rally Travel Distance
        -- The options below have no effect if this is disabled
        Hordes = true,
        -- Allow hordes to merge when within Rally Travel Distance
        -- Horde merging does not respect Rally Group Size, they can grow to any size.
        Merge = true,
        -- When above zero, a horde is incapable of merging again until a cooldown has elapsed
        -- Time is in milliseconds
        -- Value is multipled by followers in a horde:
        -- (followers in horde) * (Merge Cooldown) Min: 0 Max: 9999999 Default: 3000
        MergeCooldown = 3000,
        -- When enabled, only zombies that share the same speed(sprinter, crawler, etc) will form a horde together
        -- Works with Random Zombies, but will incorrectly group together zombies until Random Zombies updates their speed
        GroupBySpeed = false,
        -- When enabled, sprinters are allowed to be in hordes
        AllowSprinters = true,
        -- When enabled, fast shamblers are allowed to be in hordes
        AllowFastShamblers = true,
        -- When enabled, slow shamblers are allowed to be in hordes
        AllowShamblers = true,
        -- When enabled, crawlers are allowed to be in hordes
        AllowCrawlers = true,
        -- When enabled, hordes will use pathToSound, which causes them to attack objects in their path
        -- If using 'Always' with Destroyable World Fences, a lot of zombies will be found attacking fences, which makes things easier for awhile Default = Indoors
        -- 1 = Always
        -- 2 = Indoors
        -- 3 = Random
        -- 4 = Never
        HordeDestructive = 2,
        -- Hordes will try not to path further than this
        -- Does not account for needing to walk around objects(walls, etc) Min: 10 Max: 100 Default: 40
        HordeMaxTravel = 40,
        -- Method used for ticks Default = EveryOneMinute (in-game)
        -- 1 = Always
        -- 2 = OnTick (frame)
        -- 3 = EveryOneMinute (in-game)
        -- 4 = EveryTenMinutes (in-game)
        -- 5 = EveryHours (in-game)
        HordeCounter = 3,
        -- How many times the chosen counter must occur before a horde may wander Min: 1 Max: 9999999 Default: 5
        HordeNumTicks = 5,
        -- Maximum ticks that can be added randomly to the above setting Min: 0 Max: 9999999 Default: 10
        HordeRandTicks = 10,
        -- Additional ticks are added based on the amount of followers in a horde:
        -- (followers in horde) * (Follower Ticks)
        -- Result is floored (rounded down) Min: 0.00 Max: 100.00 Default: 0.00
        FollowerTicks = 0.0,
        -- At what hour should hordes start wandering randomly
        -- If set to static, uses Start Hour: Max
        -- If set to random, Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeStartHour = 1,
        -- Refer to Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MinHordeStartHour = 0,
        -- Refer to Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MaxHordeStartHour = 0,
        -- Period of time hordes are allowed to wander for when the hour reaches Start Hour
        -- If set to static, uses Total Hours: Max
        -- If set to random, Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeTotalHours = 1,
        -- Refer to Total Hours tooltip for information Min: 0 Max: 24 Default: 0
        MinHordeTotalHours = 0,
        -- Refer to Total Hours tooltip for information Min: 0 Max: 24 Default: 24
        MaxHordeTotalHours = 24,
        -- Chance each horde has of wandering randomly
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- If set to static, uses Random Chance: Max
        -- If set to random, Random Chance is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeWanderChance = 1,
        -- Refer to Random Chance tooltip for information Min: 0 Max: 100 Default: 0
        MinHordeWanderChance = 0,
        -- Refer to Random Chance tooltip for information Min: 0 Max: 100 Default: 100
        MaxHordeWanderChance = 100,
        -- At what hour should hordes start homing in on the nearest player
        -- If set to static, uses Homing Start Hour: Max
        -- If set to random, Homing Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeHomingStartHour = 1,
        -- Refer to Homing Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MinHordeHomingStartHour = 0,
        -- Refer to Homing Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MaxHordeHomingStartHour = 0,
        -- Period of time hordes are allowed to home onto players when the hour reaches Homing Start Hour
        -- If set to static, uses Homing Total Hours: Max
        -- If set to random, Homing Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeHomingTotalHours = 1,
        -- Refer to Homing Total Hours tooltip for information Min: 0 Max: 24 Default: 0
        MinHordeHomingTotalHours = 0,
        -- Refer to Homing Total Hours tooltip for information Min: 0 Max: 24 Default: 24
        MaxHordeHomingTotalHours = 0,
        -- Chance each horde has of homing in on the nearest player
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- Max Travel applies to homing hordes
        -- If set to static, uses Homing Chance: Max
        -- If set to random, Homing Chance is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeToPlayers = 1,
        -- Refer to Homing Chance tooltip for information Min: 0 Max: 100 Default: 0
        MinHordeToPlayers = 0,
        -- Refer to Homing Chance tooltip for information Min: 0 Max: 100 Default: 20
        MaxHordeToPlayers = 0,
        -- Hordes inside this radius ignore the homing settings
        -- If set to static, uses Random Radius: Max
        -- If set to random, Random Radius is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeRadius = 1,
        -- Refer to Random Radius tooltip for information Min: 0 Max: 90 Default: 0
        MinHordeRadius = 0,
        -- Refer to Random Radius tooltip for information Min: 0 Max: 90 Default: 70
        MaxHordeRadius = 70,
        -- When enabled, hordes that are homing in on the player have their current path interrupted as soon as they're inside the Random Radius Default = Off
        -- 1 = On
        -- 2 = Off
        -- 3 = Random
        HordeRadiusInterrupt = 2,
        -- At what hour should hordes flee from the nearest player
        -- If set to static, uses Flee Start Hour: Max
        -- If set to random, Flee Start Hour is randomised after the time period has elapsed using the below values (inclusive)
        -- Supports Min/Max order switching, for example (6pm -> 6am): Min = 18, Max = 6
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleeStartHour = 1,
        -- Refer to Flee Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MinHordeFleeStartHour = 0,
        -- Refer to Flee Start Hour tooltip for information Min: 0 Max: 23 Default: 0
        MaxHordeFleeStartHour = 0,
        -- Period of time hordes are allowed to flee from players when the hour reaches Flee Start Hour
        -- If set to static, uses Flee Total Hours: Max
        -- If set to random, Flee Total Hours is randomised after the time period has elapsed using the below values (inclusive)
        -- Multiple periods of activity can occur in a single day
        -- Periods of activity can chain, for example:
        -- Start Hour Min: 18, Start Hour Max: 6 (6pm -> 6am)
        -- Total Hours Min: 0, Total Hours Max: 12
        -- The above can lead to a 24 hour period of activity if Start Hour is randomised to 6am, and Total Hours is randomised to 12 Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleeTotalHours = 1,
        -- Refer to Flee Total Hours tooltip for information Min: 0 Max: 24 Default: 0
        MinHordeFleeTotalHours = 0,
        -- Refer to Flee Total Hours tooltip for information Min: 0 Max: 24 Default: 24
        MaxHordeFleeTotalHours = 24,
        -- Chance each horde has of moving away from the nearest player when inside Flee Radius
        -- Chance is only rolled when the timer has elapsed and the horde is ready to move
        -- Max Travel applies to fleeing hordes
        -- If set to static, uses Flee Chance: Max
        -- If set to random, Flee Chance is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleePlayers = 1,
        -- Refer to Flee Chance tooltip for information Min: 0 Max: 100 Default: 0
        MinHordeFleePlayers = 0,
        -- Refer to Flee Chance tooltip for information Min: 0 Max: 100 Default: 0
        MaxHordeFleePlayers = 0,
        -- Hordes inside this radius move away from the player
        -- This takes priority over Random Radius
        -- If set to static, uses Flee Radius: Max
        -- If set to random, Flee Radius is randomised once per day using the below values (inclusive) Default = Static
        -- 1 = Static
        -- 2 = Random
        DropdownHordeFleeRadius = 1,
        -- Refer to Flee Radius tooltip for information Min: 0 Max: 90 Default: 0
        MinHordeFleeRadius = 0,
        -- Refer to Flee Radius tooltip for information Min: 0 Max: 90 Default: 0
        MaxHordeFleeRadius = 0,
        -- Maximum amount of zeds that can be processed per update
        -- Update runs once per frame
        -- At 60fps, a zed limit of 20 would mean 1200 zeds per second are processed Min: 1 Max: 100 Default: 20
        UpdateZedLimit = 20,
        -- Maximum amount of milliseconds that the update can run for
        -- Update runs once per frame
        -- 16.67ms is the time limit per frame for a stable 60fps
        -- With a low zombie limit, it should not be necessary to change this value
        -- Horde updates have a hardcoded cap of 2ms that is separate from this value Min: 1 Max: 4 Default: 2
        UpdateMsLimit = 2,
        -- Monitor zed pathing to try and stop them walking outside the active area around a player
        TryStopVirtual = true,
        -- Minimum amount of hours a player needs to of survived before zeds will home in on them Min: 0 Max: 99999999 Default: 0
        HoursSurvived = 0,
    },
    WZS = {
        S1 = false,
        S2 = false,
        S3 = false,
        S4 = false,
        HS1 = false,
        HS2 = false,
        HS3 = false,
    },
    ZomVisFix = {
        -- let zombies revealed by this mod also detect the player (default: true)
        AffectZombieVision = true,
        -- a zombie's entire width needs to be unobscured in order to be revealed by this mod (default: false)
        HardMode = false,
    },
    ZCollision = {
        -- Min: 3 Max: 15 Default: 6
        MaxHitboxes = 6,
        -- Min: 3 Max: 15 Default: 6
        MaxDistanceFromPlayer = 6,
        -- Min: 0.01 Max: 0.99 Default: 0.46
        BaseRadius = 0.46,
        -- Min: 0.01 Max: 0.99 Default: 0.05
        BasePushForce = 0.05,
        -- Min: 0.01 Max: 0.99 Default: 0.65
        StunRadius = 0.65,
        -- Min: 0.01 Max: 0.99 Default: 0.19
        StunPushForce = 0.19,
        -- Min: 0.01 Max: 0.99 Default: 0.75
        FallingRadius = 0.75,
        -- Min: 0.01 Max: 0.99 Default: 0.24
        FallingPushForce = 0.24,
        DebugMode = false,
    },
    HorseMod = {
        -- Min: 0.10 Max: 10.00 Default: 1.00
        WalkSpeed = 1.0,
        -- Min: 0.10 Max: 10.00 Default: 1.00
        GallopSpeed = 1.0,
        -- Min: 0.10 Max: 2.00 Default: 1.00
        StaminaMultiplier = 1.0,
        RidingPainGrunt = true,
    },
    CompanionDogs = {
        -- How much trust a pet must reach (by feeding) before it becomes your companion. Min: 1 Max: 1000 Default: 100
        TameThreshold = 100,
        -- Maximum number of animals a player can keep bonded at once. 0 = no limit. Min: 0 Max: 30 Default: 0
        MaxCompanions = 0,
        -- Allow pets to attack nearby zombies.
        CombatEnabled = true,
        -- Default damage is 1. 0 means the pet can no longer kill zombies. Min: 0.00 Max: 5.00 Default: 1.00
        DogDamageMultiplier = 1.0,
        -- Turns hunger, thirst, loyalty and stress on or off.
        UpkeepEnabled = true,
        -- Daily hunger and thirst rate. Raise it and the pet eats and drinks more often. Min: 0.00 Max: 5.00 Default: 1.00
        NeedsRateMultiplier = 1.0,
        -- Base loss. A hungry or thirsty pet loses it faster. Min: 0.00 Max: 100.00 Default: 12.00
        LoyaltyDecayPerDay = 12.0,
        -- Enables the animal's need for protein in its diet.
        ProteinNeedEnabled = true,
        -- How many hours a pet can go without protein before it turns Weak. Min: 6 Max: 168 Default: 72
        ProteinHours = 72,
        -- The pets' ability to detect zombies.
        SentinelEnabled = true,
        -- Less boredom when petting or sleeping next to the animal.
        BondingEnabled = true,
        -- Moodle whose buff reduces panic, stress, sadness and boredom and makes you tire more slowly.
        RestedBuffEnabled = true,
        -- How many hours the Well Rested moodle lasts. Min: 0.50 Max: 24.00 Default: 2.00
        RestedBuffHours = 2.0,
        -- Enables the moodle with each breed's unique buffs.
        BreedMoodlesEnabled = true,
        -- Global multiplier for the pet's skills. Min: 0.10 Max: 10.00 Default: 0.50
        SkillXPRate = 0.5,
        -- Lets the pet take on caring for animals in pens. Affects server performance (low impact).
        FarmCareEnabled = true,
        -- Enables the pet's tricks. Can be OP on a server.
        TricksEnabled = true,
        -- Barking, meowing and the like can attract zombies.
        DogNoiseAttractsZombies = true,
        -- Text with the pet's name. Turn off for more immersion.
        ShowNameTags = true,
        -- Animal spawn rate. Default is 1, 0 disables spawning. Min: 0.00 Max: 5.00 Default: 1.00
        DogSpawnMultiplier = 1.0,
        -- When on, wild animals cannot die from vehicles, fire, attacks and the like.
        WildDogsInvincible = false,
        -- When the owner logs out of the server, the animal leaves with them.
        DespawnOnOwnerOffline = true,
        -- Multiplies the saddlebag's cargo capacity. 0 makes it purely cosmetic. Min: 0.00 Max: 5.00 Default: 1.00
        CargoCapacityMultiplier = 1.0,
        -- Lets pets breed. Affects server performance (low impact).
        BreedingEnabled = true,
        -- How many in-game days a pregnant pet carries before giving birth. Min: 1 Max: 60 Default: 4
        GestationDays = 4,
        -- How many in-game days a puppy takes to grow into an adult. Min: 1 Max: 365 Default: 90
        MaturityDays = 90,
        -- Percent chance per in-game day that a nearby adult male and female with the same owner breed on their own (rolled hourly). Same conditions as manual breeding: fed, loyal, healthy, off cooldown, a free dog slot, and breeding not blocked on either. Only while they are loaded near you. 0 = off. Min: 0.00 Max: 100.00 Default: 5.00
        BreedChancePerDay = 5.0,
        -- When on, running into a pet can knock you down.
        TripOverDogs = true,
        -- The pet can pick up wounds and illnesses. Default: on.
        VetCareEnabled = true,
        -- Everyone starts out knowing every vet care recipe, no need for the mod's magazine.
        VetRecipesUnlocked = true,
        -- The pet can die of illness, hunger and thirst. Default: off.
        Death = true,
        -- Chance that a bite the pet lands on a zombie hurts its paw. Default 0.4 percent. Each Combat level of the pet lowers it by 5 percent of this value, so at level 10 it is halved. Min: 0.00 Max: 100.00 Default: 0.40
        VetWoundChance = 0.4,
        -- Percent chance that each fence the pet hops leaves it with a sprained paw. Default 0.5, 0 means never. Min: 0.00 Max: 100.00 Default: 0.50
        VetSprainChance = 0.5,
        -- Percent chance the pet catches worms for every 6 hours with an upset stomach. Default 10 percent. Min: 0.00 Max: 100.00 Default: 10.00
        VetWormsChance = 10.0,
        -- Chance that bad food or water leaves the pet vomiting. Default 25 percent. Min: 0.00 Max: 100.00 Default: 25.00
        VetSpoiledChance = 25.0,
        -- Chance of catching the flu: rolled while the pet is starving, and for each hour beside a sick dog. Default 15 percent. Min: 0.00 Max: 100.00 Default: 15.00
        VetFluChance = 15.0,
        -- Rolled for every 6 straight hours outdoors. Going indoors resets the count. Default 1.5 percent. Min: 0.00 Max: 100.00 Default: 1.50
        VetHeartwormChance = 1.5,
        -- Chance that the pet is born allergic to one meat for life, rolled once per pet. Default 5 percent. Min: 0.00 Max: 100.00 Default: 5.00
        VetAllergyChance = 5.0,
        -- Chance that each bite in a fight brings fleas or ticks. Default 0.2 percent. Min: 0.00 Max: 100.00 Default: 0.20
        VetInfestChance = 0.2,
    },
    CompanionCat = {
        -- Scales how often stray cats appear in houses, shops and pet stores. 1.0 is the normal rate, 2.0 doubles them, 0 turns cat spawns off. This is separate from the dog spawn setting: turning stray dogs down or off no longer takes the cats with them. Min: 0.00 Max: 5.00 Default: 1.00
        CatSpawnMultiplier = 1.0,
    },
    M13ReadingTweaks = {
        -- Enable this to allow you to read a book while walking.
        RWW = true,
        -- Enable this to blur the surrounding area while your character is reading.
        RB = true,
        -- Sets reading overlay darkness from 0% (none) to 100% (maximum darkness). Min: 0.00 Max: 100.00 Default: 50.00
        RBD = 50.0,
        -- This value multiplies reading speed while your character is sitting or resting. Min: 0.01 Max: 100.00 Default: 2.00
        PSM = 2.0,
    },
    IKnowIt = {
        -- Size of the overlay symbols in percent of the default layout (100 = ball about half the icon). Range 50-200. Min: 50 Max: 200 Default: 100
        IconScale = 100,
        -- Open bags, purses, key rings, first aid kits etc. lying inside cabinets, corpses or cars and take single items without emptying the outer container. Off = looting is pure vanilla. Not extensively tested yet - turn off if you see problems.
        NestLootEnabled = true,
        -- Extra features for skill books: XP symbol, [Skillbook] title prefix and less boredom while reading skill books. Off = Look up is disabled as well. Traffic light, light bulb and the other media symbols are not affected.
        SkillBookFeature = true,
        -- Adds 'Look up' right below 'Read' for fully read skill books within their level range. Each book type can be looked up only ONCE per character, the book is consumed. Max +1 level, never above the book's max level. Needs the skill book feature.
        StudyEnabled = true,
        -- Look-up duration = this factor x duration of a full read of this book (incl. the game's normal reading modifiers such as traits). Default 0.5 = twice as fast as reading. Min: 0.10 Max: 2.00 Default: 0.50
        StudyTimeMultiplier = 0.5,
    },
    LetMeDrive = {
        -- Off: everything runs exactly as vanilla would, for comparing.
        Enabled = true,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        EnabledByServer = false,
        -- Off: other mods' map work runs straight away, and shedding and the garbage-collector block stop. The driving controls below keep working.
        Smoothing = true,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        SmoothingByServer = false,
        -- Recommended: leave this on "Match the game's frame-rate cap". Deferred work only uses the time a frame at this rate has to spare, so the mod never pushes your fps below it. Default = Match the game's frame-rate cap
        -- 1 = Match the game's frame-rate cap
        -- 2 = 244
        -- 3 = 240
        -- 4 = 165
        -- 5 = 144
        -- 6 = 120
        -- 7 = 95
        -- 8 = 90
        -- 9 = 75
        -- 10 = 60
        -- 11 = 55
        -- 12 = 45
        -- 13 = 30
        -- 14 = 24
        MinFps = 1,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        MinFpsByServer = false,
        -- Ceiling on the milliseconds one frame may spend on deferred work, whatever the frame rate. Min: 1 Max: 8 Default: 4
        MaxBudgetMs = 4,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        MaxBudgetMsByServer = false,
        -- On: other mods' map work is delayed on foot too. If items or corpses vanish, or you get stuck mid-action, untick this: on foot that work then runs straight away, as in the unmodded game.
        DeferOnFoot = true,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        DeferOnFootByServer = false,
        -- Some mods call collectgarbage during play. In this engine that is a full Java garbage collection, a visible freeze. Blocked in game, counted in the console line.
        GcShield = true,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        GcShieldByServer = false,
        -- Experimental. Above this speed, other mods' per-frame handlers that measure as heavy run every other frame instead of every frame. Fine for effects and scanners, wrong for anything that must not miss a frame. The console line marks heavy handlers with ! and counts what was shed. Min: 0 Max: 120 Default: 0
        ShedKmh = 0,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        ShedKmhByServer = false,
        -- Holds shedding while animals or mod-made NPCs are loaded, so pet and NPC mods keep their full frame rate. Costs a little work each frame while shedding would apply.
        ShedGuard = false,
        -- Ticked: every player uses the value above and cannot change it. Unticked: each player chooses.
        ShedGuardByServer = false,
    },
    MKevMP = {
        -- Test phase tool. Writes where new zombies come from (mod spawn with mod name, vanilla room spawn, cell load, reanimation) and a zombie count around each player to Zomboid/Lua/mkev_zedmonitor_server.log and mkev_zedmonitor_client.log. Max 2 MB per file, one old file kept. Turn off when the tests are done.
        ZedMonitor = true,
    },
}
